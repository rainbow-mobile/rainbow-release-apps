/****************************************************************************
** Meta object code from reading C++ file 'comm_rrs.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../comm_rrs.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'comm_rrs.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_COMM_RRS_t {
    QByteArrayData data[77];
    char stringdata0[1032];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_COMM_RRS_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_COMM_RRS_t qt_meta_stringdata_COMM_RRS = {
    {
QT_MOC_LITERAL(0, 0, 8), // "COMM_RRS"
QT_MOC_LITERAL(1, 9, 11), // "signal_move"
QT_MOC_LITERAL(2, 21, 0), // ""
QT_MOC_LITERAL(3, 22, 9), // "DATA_MOVE"
QT_MOC_LITERAL(4, 32, 3), // "msg"
QT_MOC_LITERAL(5, 36, 19), // "signal_localization"
QT_MOC_LITERAL(6, 56, 17), // "DATA_LOCALIZATION"
QT_MOC_LITERAL(7, 74, 11), // "signal_load"
QT_MOC_LITERAL(8, 86, 9), // "DATA_LOAD"
QT_MOC_LITERAL(9, 96, 16), // "signal_randomseq"
QT_MOC_LITERAL(10, 113, 14), // "DATA_RANDOMSEQ"
QT_MOC_LITERAL(11, 128, 14), // "signal_mapping"
QT_MOC_LITERAL(12, 143, 12), // "DATA_MAPPING"
QT_MOC_LITERAL(13, 156, 11), // "signal_dock"
QT_MOC_LITERAL(14, 168, 9), // "DATA_DOCK"
QT_MOC_LITERAL(15, 178, 17), // "signal_view_lidar"
QT_MOC_LITERAL(16, 196, 15), // "DATA_VIEW_LIDAR"
QT_MOC_LITERAL(17, 212, 16), // "signal_view_path"
QT_MOC_LITERAL(18, 229, 14), // "DATA_VIEW_PATH"
QT_MOC_LITERAL(19, 244, 10), // "signal_led"
QT_MOC_LITERAL(20, 255, 8), // "DATA_LED"
QT_MOC_LITERAL(21, 264, 12), // "signal_motor"
QT_MOC_LITERAL(22, 277, 10), // "DATA_MOTOR"
QT_MOC_LITERAL(23, 288, 11), // "signal_path"
QT_MOC_LITERAL(24, 300, 9), // "DATA_PATH"
QT_MOC_LITERAL(25, 310, 11), // "signal_vobs"
QT_MOC_LITERAL(26, 322, 9), // "DATA_VOBS"
QT_MOC_LITERAL(27, 332, 13), // "signal_vobs_r"
QT_MOC_LITERAL(28, 346, 11), // "DATA_VOBS_R"
QT_MOC_LITERAL(29, 358, 13), // "signal_vobs_c"
QT_MOC_LITERAL(30, 372, 11), // "DATA_VOBS_C"
QT_MOC_LITERAL(31, 384, 13), // "sio_connected"
QT_MOC_LITERAL(32, 398, 16), // "sio_disconnected"
QT_MOC_LITERAL(33, 415, 25), // "sio::client::close_reason"
QT_MOC_LITERAL(34, 441, 6), // "reason"
QT_MOC_LITERAL(35, 448, 9), // "sio_error"
QT_MOC_LITERAL(36, 458, 9), // "recv_move"
QT_MOC_LITERAL(37, 468, 11), // "std::string"
QT_MOC_LITERAL(38, 480, 4), // "name"
QT_MOC_LITERAL(39, 485, 17), // "sio::message::ptr"
QT_MOC_LITERAL(40, 503, 4), // "data"
QT_MOC_LITERAL(41, 508, 6), // "hasAck"
QT_MOC_LITERAL(42, 515, 19), // "sio::message::list&"
QT_MOC_LITERAL(43, 535, 8), // "ack_resp"
QT_MOC_LITERAL(44, 544, 17), // "recv_localization"
QT_MOC_LITERAL(45, 562, 9), // "recv_load"
QT_MOC_LITERAL(46, 572, 14), // "recv_randomseq"
QT_MOC_LITERAL(47, 587, 12), // "recv_mapping"
QT_MOC_LITERAL(48, 600, 9), // "recv_dock"
QT_MOC_LITERAL(49, 610, 22), // "recv_view_lidar_on_off"
QT_MOC_LITERAL(50, 633, 21), // "recv_view_path_on_off"
QT_MOC_LITERAL(51, 655, 8), // "recv_led"
QT_MOC_LITERAL(52, 664, 10), // "recv_motor"
QT_MOC_LITERAL(53, 675, 9), // "recv_path"
QT_MOC_LITERAL(54, 685, 9), // "recv_vobs"
QT_MOC_LITERAL(55, 695, 16), // "recv_vobs_robots"
QT_MOC_LITERAL(56, 712, 18), // "recv_vobs_closures"
QT_MOC_LITERAL(57, 731, 9), // "slot_move"
QT_MOC_LITERAL(58, 741, 17), // "slot_localization"
QT_MOC_LITERAL(59, 759, 9), // "slot_load"
QT_MOC_LITERAL(60, 769, 14), // "slot_randomseq"
QT_MOC_LITERAL(61, 784, 12), // "slot_mapping"
QT_MOC_LITERAL(62, 797, 9), // "slot_dock"
QT_MOC_LITERAL(63, 807, 15), // "slot_view_lidar"
QT_MOC_LITERAL(64, 823, 14), // "slot_view_path"
QT_MOC_LITERAL(65, 838, 8), // "slot_led"
QT_MOC_LITERAL(66, 847, 10), // "slot_motor"
QT_MOC_LITERAL(67, 858, 9), // "slot_path"
QT_MOC_LITERAL(68, 868, 9), // "slot_vobs"
QT_MOC_LITERAL(69, 878, 11), // "slot_vobs_r"
QT_MOC_LITERAL(70, 890, 11), // "slot_vobs_c"
QT_MOC_LITERAL(71, 902, 18), // "send_move_response"
QT_MOC_LITERAL(72, 921, 26), // "send_localization_response"
QT_MOC_LITERAL(73, 948, 18), // "send_load_response"
QT_MOC_LITERAL(74, 967, 23), // "send_randomseq_response"
QT_MOC_LITERAL(75, 991, 21), // "send_mapping_response"
QT_MOC_LITERAL(76, 1013, 18) // "send_dock_response"

    },
    "COMM_RRS\0signal_move\0\0DATA_MOVE\0msg\0"
    "signal_localization\0DATA_LOCALIZATION\0"
    "signal_load\0DATA_LOAD\0signal_randomseq\0"
    "DATA_RANDOMSEQ\0signal_mapping\0"
    "DATA_MAPPING\0signal_dock\0DATA_DOCK\0"
    "signal_view_lidar\0DATA_VIEW_LIDAR\0"
    "signal_view_path\0DATA_VIEW_PATH\0"
    "signal_led\0DATA_LED\0signal_motor\0"
    "DATA_MOTOR\0signal_path\0DATA_PATH\0"
    "signal_vobs\0DATA_VOBS\0signal_vobs_r\0"
    "DATA_VOBS_R\0signal_vobs_c\0DATA_VOBS_C\0"
    "sio_connected\0sio_disconnected\0"
    "sio::client::close_reason\0reason\0"
    "sio_error\0recv_move\0std::string\0name\0"
    "sio::message::ptr\0data\0hasAck\0"
    "sio::message::list&\0ack_resp\0"
    "recv_localization\0recv_load\0recv_randomseq\0"
    "recv_mapping\0recv_dock\0recv_view_lidar_on_off\0"
    "recv_view_path_on_off\0recv_led\0"
    "recv_motor\0recv_path\0recv_vobs\0"
    "recv_vobs_robots\0recv_vobs_closures\0"
    "slot_move\0slot_localization\0slot_load\0"
    "slot_randomseq\0slot_mapping\0slot_dock\0"
    "slot_view_lidar\0slot_view_path\0slot_led\0"
    "slot_motor\0slot_path\0slot_vobs\0"
    "slot_vobs_r\0slot_vobs_c\0send_move_response\0"
    "send_localization_response\0"
    "send_load_response\0send_randomseq_response\0"
    "send_mapping_response\0send_dock_response"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_COMM_RRS[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      51,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      14,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  269,    2, 0x06 /* Public */,
       5,    1,  272,    2, 0x06 /* Public */,
       7,    1,  275,    2, 0x06 /* Public */,
       9,    1,  278,    2, 0x06 /* Public */,
      11,    1,  281,    2, 0x06 /* Public */,
      13,    1,  284,    2, 0x06 /* Public */,
      15,    1,  287,    2, 0x06 /* Public */,
      17,    1,  290,    2, 0x06 /* Public */,
      19,    1,  293,    2, 0x06 /* Public */,
      21,    1,  296,    2, 0x06 /* Public */,
      23,    1,  299,    2, 0x06 /* Public */,
      25,    1,  302,    2, 0x06 /* Public */,
      27,    1,  305,    2, 0x06 /* Public */,
      29,    1,  308,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      31,    0,  311,    2, 0x08 /* Private */,
      32,    1,  312,    2, 0x08 /* Private */,
      35,    0,  315,    2, 0x08 /* Private */,
      36,    4,  316,    2, 0x08 /* Private */,
      44,    4,  325,    2, 0x08 /* Private */,
      45,    4,  334,    2, 0x08 /* Private */,
      46,    4,  343,    2, 0x08 /* Private */,
      47,    4,  352,    2, 0x08 /* Private */,
      48,    4,  361,    2, 0x08 /* Private */,
      49,    4,  370,    2, 0x08 /* Private */,
      50,    4,  379,    2, 0x08 /* Private */,
      51,    4,  388,    2, 0x08 /* Private */,
      52,    4,  397,    2, 0x08 /* Private */,
      53,    4,  406,    2, 0x08 /* Private */,
      54,    4,  415,    2, 0x08 /* Private */,
      55,    4,  424,    2, 0x08 /* Private */,
      56,    4,  433,    2, 0x08 /* Private */,
      57,    1,  442,    2, 0x0a /* Public */,
      58,    1,  445,    2, 0x0a /* Public */,
      59,    1,  448,    2, 0x0a /* Public */,
      60,    1,  451,    2, 0x0a /* Public */,
      61,    1,  454,    2, 0x0a /* Public */,
      62,    1,  457,    2, 0x0a /* Public */,
      63,    1,  460,    2, 0x0a /* Public */,
      64,    1,  463,    2, 0x0a /* Public */,
      65,    1,  466,    2, 0x0a /* Public */,
      66,    1,  469,    2, 0x0a /* Public */,
      67,    1,  472,    2, 0x0a /* Public */,
      68,    1,  475,    2, 0x0a /* Public */,
      69,    1,  478,    2, 0x0a /* Public */,
      70,    1,  481,    2, 0x0a /* Public */,
      71,    1,  484,    2, 0x0a /* Public */,
      72,    1,  487,    2, 0x0a /* Public */,
      73,    1,  490,    2, 0x0a /* Public */,
      74,    1,  493,    2, 0x0a /* Public */,
      75,    1,  496,    2, 0x0a /* Public */,
      76,    1,  499,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    4,
    QMetaType::Void, 0x80000000 | 8,    4,
    QMetaType::Void, 0x80000000 | 10,    4,
    QMetaType::Void, 0x80000000 | 12,    4,
    QMetaType::Void, 0x80000000 | 14,    4,
    QMetaType::Void, 0x80000000 | 16,    4,
    QMetaType::Void, 0x80000000 | 18,    4,
    QMetaType::Void, 0x80000000 | 20,    4,
    QMetaType::Void, 0x80000000 | 22,    4,
    QMetaType::Void, 0x80000000 | 24,    4,
    QMetaType::Void, 0x80000000 | 26,    4,
    QMetaType::Void, 0x80000000 | 28,    4,
    QMetaType::Void, 0x80000000 | 30,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 33,   34,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 37, 0x80000000 | 39, QMetaType::Bool, 0x80000000 | 42,   38,   40,   41,   43,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    4,
    QMetaType::Void, 0x80000000 | 8,    4,
    QMetaType::Void, 0x80000000 | 10,    4,
    QMetaType::Void, 0x80000000 | 12,    4,
    QMetaType::Void, 0x80000000 | 14,    4,
    QMetaType::Void, 0x80000000 | 16,    4,
    QMetaType::Void, 0x80000000 | 18,    4,
    QMetaType::Void, 0x80000000 | 20,    4,
    QMetaType::Void, 0x80000000 | 22,    4,
    QMetaType::Void, 0x80000000 | 24,    4,
    QMetaType::Void, 0x80000000 | 26,    4,
    QMetaType::Void, 0x80000000 | 28,    4,
    QMetaType::Void, 0x80000000 | 30,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    4,
    QMetaType::Void, 0x80000000 | 8,    4,
    QMetaType::Void, 0x80000000 | 10,    4,
    QMetaType::Void, 0x80000000 | 12,    4,
    QMetaType::Void, 0x80000000 | 14,    4,

       0        // eod
};

void COMM_RRS::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<COMM_RRS *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signal_move((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        case 1: _t->signal_localization((*reinterpret_cast< DATA_LOCALIZATION(*)>(_a[1]))); break;
        case 2: _t->signal_load((*reinterpret_cast< DATA_LOAD(*)>(_a[1]))); break;
        case 3: _t->signal_randomseq((*reinterpret_cast< DATA_RANDOMSEQ(*)>(_a[1]))); break;
        case 4: _t->signal_mapping((*reinterpret_cast< DATA_MAPPING(*)>(_a[1]))); break;
        case 5: _t->signal_dock((*reinterpret_cast< DATA_DOCK(*)>(_a[1]))); break;
        case 6: _t->signal_view_lidar((*reinterpret_cast< DATA_VIEW_LIDAR(*)>(_a[1]))); break;
        case 7: _t->signal_view_path((*reinterpret_cast< DATA_VIEW_PATH(*)>(_a[1]))); break;
        case 8: _t->signal_led((*reinterpret_cast< DATA_LED(*)>(_a[1]))); break;
        case 9: _t->signal_motor((*reinterpret_cast< DATA_MOTOR(*)>(_a[1]))); break;
        case 10: _t->signal_path((*reinterpret_cast< DATA_PATH(*)>(_a[1]))); break;
        case 11: _t->signal_vobs((*reinterpret_cast< DATA_VOBS(*)>(_a[1]))); break;
        case 12: _t->signal_vobs_r((*reinterpret_cast< DATA_VOBS_R(*)>(_a[1]))); break;
        case 13: _t->signal_vobs_c((*reinterpret_cast< DATA_VOBS_C(*)>(_a[1]))); break;
        case 14: _t->sio_connected(); break;
        case 15: _t->sio_disconnected((*reinterpret_cast< const sio::client::close_reason(*)>(_a[1]))); break;
        case 16: _t->sio_error(); break;
        case 17: _t->recv_move((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 18: _t->recv_localization((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 19: _t->recv_load((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 20: _t->recv_randomseq((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 21: _t->recv_mapping((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 22: _t->recv_dock((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 23: _t->recv_view_lidar_on_off((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 24: _t->recv_view_path_on_off((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 25: _t->recv_led((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 26: _t->recv_motor((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 27: _t->recv_path((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 28: _t->recv_vobs((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 29: _t->recv_vobs_robots((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 30: _t->recv_vobs_closures((*reinterpret_cast< const std::string(*)>(_a[1])),(*reinterpret_cast< const sio::message::ptr(*)>(_a[2])),(*reinterpret_cast< bool(*)>(_a[3])),(*reinterpret_cast< sio::message::list(*)>(_a[4]))); break;
        case 31: _t->slot_move((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        case 32: _t->slot_localization((*reinterpret_cast< DATA_LOCALIZATION(*)>(_a[1]))); break;
        case 33: _t->slot_load((*reinterpret_cast< DATA_LOAD(*)>(_a[1]))); break;
        case 34: _t->slot_randomseq((*reinterpret_cast< DATA_RANDOMSEQ(*)>(_a[1]))); break;
        case 35: _t->slot_mapping((*reinterpret_cast< DATA_MAPPING(*)>(_a[1]))); break;
        case 36: _t->slot_dock((*reinterpret_cast< DATA_DOCK(*)>(_a[1]))); break;
        case 37: _t->slot_view_lidar((*reinterpret_cast< DATA_VIEW_LIDAR(*)>(_a[1]))); break;
        case 38: _t->slot_view_path((*reinterpret_cast< DATA_VIEW_PATH(*)>(_a[1]))); break;
        case 39: _t->slot_led((*reinterpret_cast< DATA_LED(*)>(_a[1]))); break;
        case 40: _t->slot_motor((*reinterpret_cast< DATA_MOTOR(*)>(_a[1]))); break;
        case 41: _t->slot_path((*reinterpret_cast< DATA_PATH(*)>(_a[1]))); break;
        case 42: _t->slot_vobs((*reinterpret_cast< DATA_VOBS(*)>(_a[1]))); break;
        case 43: _t->slot_vobs_r((*reinterpret_cast< DATA_VOBS_R(*)>(_a[1]))); break;
        case 44: _t->slot_vobs_c((*reinterpret_cast< DATA_VOBS_C(*)>(_a[1]))); break;
        case 45: _t->send_move_response((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        case 46: _t->send_localization_response((*reinterpret_cast< DATA_LOCALIZATION(*)>(_a[1]))); break;
        case 47: _t->send_load_response((*reinterpret_cast< DATA_LOAD(*)>(_a[1]))); break;
        case 48: _t->send_randomseq_response((*reinterpret_cast< DATA_RANDOMSEQ(*)>(_a[1]))); break;
        case 49: _t->send_mapping_response((*reinterpret_cast< DATA_MAPPING(*)>(_a[1]))); break;
        case 50: _t->send_dock_response((*reinterpret_cast< DATA_DOCK(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOCALIZATION >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOAD >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_RANDOMSEQ >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MAPPING >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_DOCK >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VIEW_LIDAR >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VIEW_PATH >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LED >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOTOR >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_PATH >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_R >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_C >(); break;
            }
            break;
        case 31:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        case 32:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOCALIZATION >(); break;
            }
            break;
        case 33:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOAD >(); break;
            }
            break;
        case 34:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_RANDOMSEQ >(); break;
            }
            break;
        case 35:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MAPPING >(); break;
            }
            break;
        case 36:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_DOCK >(); break;
            }
            break;
        case 37:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VIEW_LIDAR >(); break;
            }
            break;
        case 38:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VIEW_PATH >(); break;
            }
            break;
        case 39:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LED >(); break;
            }
            break;
        case 40:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOTOR >(); break;
            }
            break;
        case 41:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_PATH >(); break;
            }
            break;
        case 42:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS >(); break;
            }
            break;
        case 43:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_R >(); break;
            }
            break;
        case 44:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_C >(); break;
            }
            break;
        case 45:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        case 46:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOCALIZATION >(); break;
            }
            break;
        case 47:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOAD >(); break;
            }
            break;
        case 48:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_RANDOMSEQ >(); break;
            }
            break;
        case 49:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MAPPING >(); break;
            }
            break;
        case 50:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_DOCK >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (COMM_RRS::*)(DATA_MOVE );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_move)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_LOCALIZATION );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_localization)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_LOAD );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_load)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_RANDOMSEQ );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_randomseq)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_MAPPING );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_mapping)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_DOCK );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_dock)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_VIEW_LIDAR );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_view_lidar)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_VIEW_PATH );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_view_path)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_LED );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_led)) {
                *result = 8;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_MOTOR );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_motor)) {
                *result = 9;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_PATH );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_path)) {
                *result = 10;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_VOBS );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_vobs)) {
                *result = 11;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_VOBS_R );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_vobs_r)) {
                *result = 12;
                return;
            }
        }
        {
            using _t = void (COMM_RRS::*)(DATA_VOBS_C );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_vobs_c)) {
                *result = 13;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject COMM_RRS::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_COMM_RRS.data,
    qt_meta_data_COMM_RRS,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *COMM_RRS::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *COMM_RRS::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_COMM_RRS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int COMM_RRS::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 51)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 51;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 51)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 51;
    }
    return _id;
}

// SIGNAL 0
void COMM_RRS::signal_move(DATA_MOVE _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void COMM_RRS::signal_localization(DATA_LOCALIZATION _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void COMM_RRS::signal_load(DATA_LOAD _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void COMM_RRS::signal_randomseq(DATA_RANDOMSEQ _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void COMM_RRS::signal_mapping(DATA_MAPPING _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void COMM_RRS::signal_dock(DATA_DOCK _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void COMM_RRS::signal_view_lidar(DATA_VIEW_LIDAR _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void COMM_RRS::signal_view_path(DATA_VIEW_PATH _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void COMM_RRS::signal_led(DATA_LED _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void COMM_RRS::signal_motor(DATA_MOTOR _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void COMM_RRS::signal_path(DATA_PATH _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void COMM_RRS::signal_vobs(DATA_VOBS _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void COMM_RRS::signal_vobs_r(DATA_VOBS_R _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void COMM_RRS::signal_vobs_c(DATA_VOBS_C _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
