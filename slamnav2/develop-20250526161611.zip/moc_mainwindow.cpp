/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[109];
    char stringdata0[1450];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 20), // "signal_move_response"
QT_MOC_LITERAL(2, 32, 0), // ""
QT_MOC_LITERAL(3, 33, 9), // "DATA_MOVE"
QT_MOC_LITERAL(4, 43, 3), // "msg"
QT_MOC_LITERAL(5, 47, 14), // "slot_write_log"
QT_MOC_LITERAL(6, 62, 8), // "user_log"
QT_MOC_LITERAL(7, 71, 10), // "color_code"
QT_MOC_LITERAL(8, 82, 21), // "slot_main_tab_changed"
QT_MOC_LITERAL(9, 104, 21), // "slot_menu_tab_changed"
QT_MOC_LITERAL(10, 126, 10), // "map_update"
QT_MOC_LITERAL(11, 137, 10), // "obs_update"
QT_MOC_LITERAL(12, 148, 11), // "topo_update"
QT_MOC_LITERAL(13, 160, 11), // "pick_update"
QT_MOC_LITERAL(14, 172, 10), // "all_update"
QT_MOC_LITERAL(15, 183, 12), // "bt_ViewReset"
QT_MOC_LITERAL(16, 196, 13), // "bt_SetTopView"
QT_MOC_LITERAL(17, 210, 9), // "plot_loop"
QT_MOC_LITERAL(18, 220, 10), // "plot_loop2"
QT_MOC_LITERAL(19, 231, 7), // "qa_loop"
QT_MOC_LITERAL(20, 239, 13), // "bt_ConfigLoad"
QT_MOC_LITERAL(21, 253, 12), // "bt_MotorInit"
QT_MOC_LITERAL(22, 266, 12), // "bt_Emergency"
QT_MOC_LITERAL(23, 279, 7), // "bt_Sync"
QT_MOC_LITERAL(24, 287, 11), // "bt_MoveStop"
QT_MOC_LITERAL(25, 299, 14), // "bt_MoveLinearX"
QT_MOC_LITERAL(26, 314, 14), // "bt_MoveLinearY"
QT_MOC_LITERAL(27, 329, 13), // "bt_MoveRotate"
QT_MOC_LITERAL(28, 343, 7), // "bt_JogF"
QT_MOC_LITERAL(29, 351, 7), // "bt_JogB"
QT_MOC_LITERAL(30, 359, 7), // "bt_JogL"
QT_MOC_LITERAL(31, 367, 7), // "bt_JogR"
QT_MOC_LITERAL(32, 375, 14), // "bt_JogReleased"
QT_MOC_LITERAL(33, 390, 12), // "bt_MapReload"
QT_MOC_LITERAL(34, 403, 11), // "bt_MapSave2"
QT_MOC_LITERAL(35, 415, 10), // "bt_AddNode"
QT_MOC_LITERAL(36, 426, 10), // "bt_DelNode"
QT_MOC_LITERAL(37, 437, 10), // "bt_DelLink"
QT_MOC_LITERAL(38, 448, 11), // "bt_AddLink1"
QT_MOC_LITERAL(39, 460, 11), // "bt_AddLink2"
QT_MOC_LITERAL(40, 472, 11), // "bt_AutoLink"
QT_MOC_LITERAL(41, 484, 11), // "bt_AutoNode"
QT_MOC_LITERAL(42, 496, 12), // "bt_AddPoints"
QT_MOC_LITERAL(43, 509, 14), // "bt_EditNodePos"
QT_MOC_LITERAL(44, 524, 15), // "bt_EditNodeType"
QT_MOC_LITERAL(45, 540, 15), // "bt_EditNodeInfo"
QT_MOC_LITERAL(46, 556, 15), // "bt_EditNodeName"
QT_MOC_LITERAL(47, 572, 14), // "bt_MinGapNodeX"
QT_MOC_LITERAL(48, 587, 14), // "bt_MinGapNodeY"
QT_MOC_LITERAL(49, 602, 13), // "bt_AlignNodeX"
QT_MOC_LITERAL(50, 616, 13), // "bt_AlignNodeY"
QT_MOC_LITERAL(51, 630, 14), // "bt_AlignNodeTh"
QT_MOC_LITERAL(52, 645, 12), // "bt_ClearTopo"
QT_MOC_LITERAL(53, 658, 14), // "bt_NodePoseXUp"
QT_MOC_LITERAL(54, 673, 14), // "bt_NodePoseYUp"
QT_MOC_LITERAL(55, 688, 15), // "bt_NodePoseThUp"
QT_MOC_LITERAL(56, 704, 16), // "bt_NodePoseXDown"
QT_MOC_LITERAL(57, 721, 16), // "bt_NodePoseYDown"
QT_MOC_LITERAL(58, 738, 17), // "bt_NodePoseThDown"
QT_MOC_LITERAL(59, 756, 18), // "bt_QuickAnnotStart"
QT_MOC_LITERAL(60, 775, 17), // "bt_QuickAnnotStop"
QT_MOC_LITERAL(61, 793, 15), // "bt_QuickAddNode"
QT_MOC_LITERAL(62, 809, 16), // "bt_QuickAddAruco"
QT_MOC_LITERAL(63, 826, 16), // "bt_QuickAddCloud"
QT_MOC_LITERAL(64, 843, 11), // "bt_SetMapTf"
QT_MOC_LITERAL(65, 855, 13), // "bt_CheckNodes"
QT_MOC_LITERAL(66, 869, 11), // "bt_MapBuild"
QT_MOC_LITERAL(67, 881, 10), // "bt_MapSave"
QT_MOC_LITERAL(68, 892, 10), // "bt_MapLoad"
QT_MOC_LITERAL(69, 903, 12), // "bt_MapLastLc"
QT_MOC_LITERAL(70, 916, 10), // "bt_LocInit"
QT_MOC_LITERAL(71, 927, 18), // "bt_LocInitSemiAuto"
QT_MOC_LITERAL(72, 946, 14), // "bt_LocInitAuto"
QT_MOC_LITERAL(73, 961, 11), // "bt_LocStart"
QT_MOC_LITERAL(74, 973, 10), // "bt_LocStop"
QT_MOC_LITERAL(75, 984, 10), // "bt_SimInit"
QT_MOC_LITERAL(76, 995, 7), // "bt_Test"
QT_MOC_LITERAL(77, 1003, 10), // "bt_TestLed"
QT_MOC_LITERAL(78, 1014, 13), // "ckb_TestDebug"
QT_MOC_LITERAL(79, 1028, 14), // "bt_TestImgSave"
QT_MOC_LITERAL(80, 1043, 11), // "bt_AutoMove"
QT_MOC_LITERAL(81, 1055, 12), // "bt_AutoMove2"
QT_MOC_LITERAL(82, 1068, 12), // "bt_AutoMove3"
QT_MOC_LITERAL(83, 1081, 11), // "bt_AutoStop"
QT_MOC_LITERAL(84, 1093, 12), // "bt_AutoPause"
QT_MOC_LITERAL(85, 1106, 13), // "bt_AutoResume"
QT_MOC_LITERAL(86, 1120, 19), // "bt_ReturnToCharging"
QT_MOC_LITERAL(87, 1140, 23), // "slot_local_path_updated"
QT_MOC_LITERAL(88, 1164, 24), // "slot_global_path_updated"
QT_MOC_LITERAL(89, 1189, 11), // "bt_ObsClear"
QT_MOC_LITERAL(90, 1201, 10), // "bt_TaskAdd"
QT_MOC_LITERAL(91, 1212, 10), // "bt_TaskDel"
QT_MOC_LITERAL(92, 1223, 11), // "bt_TaskSave"
QT_MOC_LITERAL(93, 1235, 11), // "bt_TaskLoad"
QT_MOC_LITERAL(94, 1247, 11), // "bt_TaskPlay"
QT_MOC_LITERAL(95, 1259, 12), // "bt_TaskPause"
QT_MOC_LITERAL(96, 1272, 13), // "bt_TaskCancel"
QT_MOC_LITERAL(97, 1286, 11), // "cb_NodeType"
QT_MOC_LITERAL(98, 1298, 4), // "type"
QT_MOC_LITERAL(99, 1303, 17), // "bt_SelectPreNodes"
QT_MOC_LITERAL(100, 1321, 18), // "bt_SelectPostNodes"
QT_MOC_LITERAL(101, 1340, 10), // "bt_SendMap"
QT_MOC_LITERAL(102, 1351, 20), // "slot_sim_random_init"
QT_MOC_LITERAL(103, 1372, 4), // "seed"
QT_MOC_LITERAL(104, 1377, 19), // "slot_sim_random_seq"
QT_MOC_LITERAL(105, 1397, 12), // "bt_DockStart"
QT_MOC_LITERAL(106, 1410, 11), // "bt_DockStop"
QT_MOC_LITERAL(107, 1422, 14), // "bt_UnDockStart"
QT_MOC_LITERAL(108, 1437, 12) // "bt_TestAnnot"

    },
    "MainWindow\0signal_move_response\0\0"
    "DATA_MOVE\0msg\0slot_write_log\0user_log\0"
    "color_code\0slot_main_tab_changed\0"
    "slot_menu_tab_changed\0map_update\0"
    "obs_update\0topo_update\0pick_update\0"
    "all_update\0bt_ViewReset\0bt_SetTopView\0"
    "plot_loop\0plot_loop2\0qa_loop\0bt_ConfigLoad\0"
    "bt_MotorInit\0bt_Emergency\0bt_Sync\0"
    "bt_MoveStop\0bt_MoveLinearX\0bt_MoveLinearY\0"
    "bt_MoveRotate\0bt_JogF\0bt_JogB\0bt_JogL\0"
    "bt_JogR\0bt_JogReleased\0bt_MapReload\0"
    "bt_MapSave2\0bt_AddNode\0bt_DelNode\0"
    "bt_DelLink\0bt_AddLink1\0bt_AddLink2\0"
    "bt_AutoLink\0bt_AutoNode\0bt_AddPoints\0"
    "bt_EditNodePos\0bt_EditNodeType\0"
    "bt_EditNodeInfo\0bt_EditNodeName\0"
    "bt_MinGapNodeX\0bt_MinGapNodeY\0"
    "bt_AlignNodeX\0bt_AlignNodeY\0bt_AlignNodeTh\0"
    "bt_ClearTopo\0bt_NodePoseXUp\0bt_NodePoseYUp\0"
    "bt_NodePoseThUp\0bt_NodePoseXDown\0"
    "bt_NodePoseYDown\0bt_NodePoseThDown\0"
    "bt_QuickAnnotStart\0bt_QuickAnnotStop\0"
    "bt_QuickAddNode\0bt_QuickAddAruco\0"
    "bt_QuickAddCloud\0bt_SetMapTf\0bt_CheckNodes\0"
    "bt_MapBuild\0bt_MapSave\0bt_MapLoad\0"
    "bt_MapLastLc\0bt_LocInit\0bt_LocInitSemiAuto\0"
    "bt_LocInitAuto\0bt_LocStart\0bt_LocStop\0"
    "bt_SimInit\0bt_Test\0bt_TestLed\0"
    "ckb_TestDebug\0bt_TestImgSave\0bt_AutoMove\0"
    "bt_AutoMove2\0bt_AutoMove3\0bt_AutoStop\0"
    "bt_AutoPause\0bt_AutoResume\0"
    "bt_ReturnToCharging\0slot_local_path_updated\0"
    "slot_global_path_updated\0bt_ObsClear\0"
    "bt_TaskAdd\0bt_TaskDel\0bt_TaskSave\0"
    "bt_TaskLoad\0bt_TaskPlay\0bt_TaskPause\0"
    "bt_TaskCancel\0cb_NodeType\0type\0"
    "bt_SelectPreNodes\0bt_SelectPostNodes\0"
    "bt_SendMap\0slot_sim_random_init\0seed\0"
    "slot_sim_random_seq\0bt_DockStart\0"
    "bt_DockStop\0bt_UnDockStart\0bt_TestAnnot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
     101,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  519,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    2,  522,    2, 0x0a /* Public */,
       8,    0,  527,    2, 0x0a /* Public */,
       9,    0,  528,    2, 0x0a /* Public */,
      10,    0,  529,    2, 0x0a /* Public */,
      11,    0,  530,    2, 0x0a /* Public */,
      12,    0,  531,    2, 0x0a /* Public */,
      13,    0,  532,    2, 0x0a /* Public */,
      14,    0,  533,    2, 0x0a /* Public */,
      15,    0,  534,    2, 0x0a /* Public */,
      16,    0,  535,    2, 0x0a /* Public */,
      17,    0,  536,    2, 0x0a /* Public */,
      18,    0,  537,    2, 0x0a /* Public */,
      19,    0,  538,    2, 0x0a /* Public */,
      20,    0,  539,    2, 0x0a /* Public */,
      21,    0,  540,    2, 0x0a /* Public */,
      22,    0,  541,    2, 0x0a /* Public */,
      23,    0,  542,    2, 0x0a /* Public */,
      24,    0,  543,    2, 0x0a /* Public */,
      25,    0,  544,    2, 0x0a /* Public */,
      26,    0,  545,    2, 0x0a /* Public */,
      27,    0,  546,    2, 0x0a /* Public */,
      28,    0,  547,    2, 0x0a /* Public */,
      29,    0,  548,    2, 0x0a /* Public */,
      30,    0,  549,    2, 0x0a /* Public */,
      31,    0,  550,    2, 0x0a /* Public */,
      32,    0,  551,    2, 0x0a /* Public */,
      33,    0,  552,    2, 0x0a /* Public */,
      34,    0,  553,    2, 0x0a /* Public */,
      35,    0,  554,    2, 0x0a /* Public */,
      36,    0,  555,    2, 0x0a /* Public */,
      37,    0,  556,    2, 0x0a /* Public */,
      38,    0,  557,    2, 0x0a /* Public */,
      39,    0,  558,    2, 0x0a /* Public */,
      40,    0,  559,    2, 0x0a /* Public */,
      41,    0,  560,    2, 0x0a /* Public */,
      42,    0,  561,    2, 0x0a /* Public */,
      43,    0,  562,    2, 0x0a /* Public */,
      44,    0,  563,    2, 0x0a /* Public */,
      45,    0,  564,    2, 0x0a /* Public */,
      46,    0,  565,    2, 0x0a /* Public */,
      47,    0,  566,    2, 0x0a /* Public */,
      48,    0,  567,    2, 0x0a /* Public */,
      49,    0,  568,    2, 0x0a /* Public */,
      50,    0,  569,    2, 0x0a /* Public */,
      51,    0,  570,    2, 0x0a /* Public */,
      52,    0,  571,    2, 0x0a /* Public */,
      53,    0,  572,    2, 0x0a /* Public */,
      54,    0,  573,    2, 0x0a /* Public */,
      55,    0,  574,    2, 0x0a /* Public */,
      56,    0,  575,    2, 0x0a /* Public */,
      57,    0,  576,    2, 0x0a /* Public */,
      58,    0,  577,    2, 0x0a /* Public */,
      59,    0,  578,    2, 0x0a /* Public */,
      60,    0,  579,    2, 0x0a /* Public */,
      61,    0,  580,    2, 0x0a /* Public */,
      62,    0,  581,    2, 0x0a /* Public */,
      63,    0,  582,    2, 0x0a /* Public */,
      64,    0,  583,    2, 0x0a /* Public */,
      65,    0,  584,    2, 0x0a /* Public */,
      66,    0,  585,    2, 0x0a /* Public */,
      67,    0,  586,    2, 0x0a /* Public */,
      68,    0,  587,    2, 0x0a /* Public */,
      69,    0,  588,    2, 0x0a /* Public */,
      70,    0,  589,    2, 0x0a /* Public */,
      71,    0,  590,    2, 0x0a /* Public */,
      72,    0,  591,    2, 0x0a /* Public */,
      73,    0,  592,    2, 0x0a /* Public */,
      74,    0,  593,    2, 0x0a /* Public */,
      75,    0,  594,    2, 0x0a /* Public */,
      76,    0,  595,    2, 0x0a /* Public */,
      77,    0,  596,    2, 0x0a /* Public */,
      78,    0,  597,    2, 0x0a /* Public */,
      79,    0,  598,    2, 0x0a /* Public */,
      80,    0,  599,    2, 0x0a /* Public */,
      81,    0,  600,    2, 0x0a /* Public */,
      82,    0,  601,    2, 0x0a /* Public */,
      83,    0,  602,    2, 0x0a /* Public */,
      84,    0,  603,    2, 0x0a /* Public */,
      85,    0,  604,    2, 0x0a /* Public */,
      86,    0,  605,    2, 0x0a /* Public */,
      87,    0,  606,    2, 0x0a /* Public */,
      88,    0,  607,    2, 0x0a /* Public */,
      89,    0,  608,    2, 0x0a /* Public */,
      90,    0,  609,    2, 0x0a /* Public */,
      91,    0,  610,    2, 0x0a /* Public */,
      92,    0,  611,    2, 0x0a /* Public */,
      93,    0,  612,    2, 0x0a /* Public */,
      94,    0,  613,    2, 0x0a /* Public */,
      95,    0,  614,    2, 0x0a /* Public */,
      96,    0,  615,    2, 0x0a /* Public */,
      97,    1,  616,    2, 0x0a /* Public */,
      99,    0,  619,    2, 0x0a /* Public */,
     100,    0,  620,    2, 0x0a /* Public */,
     101,    0,  621,    2, 0x0a /* Public */,
     102,    1,  622,    2, 0x0a /* Public */,
     104,    0,  625,    2, 0x0a /* Public */,
     105,    0,  626,    2, 0x0a /* Public */,
     106,    0,  627,    2, 0x0a /* Public */,
     107,    0,  628,    2, 0x0a /* Public */,
     108,    0,  629,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    6,    7,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   98,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,  103,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signal_move_response((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        case 1: _t->slot_write_log((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 2: _t->slot_main_tab_changed(); break;
        case 3: _t->slot_menu_tab_changed(); break;
        case 4: _t->map_update(); break;
        case 5: _t->obs_update(); break;
        case 6: _t->topo_update(); break;
        case 7: _t->pick_update(); break;
        case 8: _t->all_update(); break;
        case 9: _t->bt_ViewReset(); break;
        case 10: _t->bt_SetTopView(); break;
        case 11: _t->plot_loop(); break;
        case 12: _t->plot_loop2(); break;
        case 13: _t->qa_loop(); break;
        case 14: _t->bt_ConfigLoad(); break;
        case 15: _t->bt_MotorInit(); break;
        case 16: _t->bt_Emergency(); break;
        case 17: _t->bt_Sync(); break;
        case 18: _t->bt_MoveStop(); break;
        case 19: _t->bt_MoveLinearX(); break;
        case 20: _t->bt_MoveLinearY(); break;
        case 21: _t->bt_MoveRotate(); break;
        case 22: _t->bt_JogF(); break;
        case 23: _t->bt_JogB(); break;
        case 24: _t->bt_JogL(); break;
        case 25: _t->bt_JogR(); break;
        case 26: _t->bt_JogReleased(); break;
        case 27: _t->bt_MapReload(); break;
        case 28: _t->bt_MapSave2(); break;
        case 29: _t->bt_AddNode(); break;
        case 30: _t->bt_DelNode(); break;
        case 31: _t->bt_DelLink(); break;
        case 32: _t->bt_AddLink1(); break;
        case 33: _t->bt_AddLink2(); break;
        case 34: _t->bt_AutoLink(); break;
        case 35: _t->bt_AutoNode(); break;
        case 36: _t->bt_AddPoints(); break;
        case 37: _t->bt_EditNodePos(); break;
        case 38: _t->bt_EditNodeType(); break;
        case 39: _t->bt_EditNodeInfo(); break;
        case 40: _t->bt_EditNodeName(); break;
        case 41: _t->bt_MinGapNodeX(); break;
        case 42: _t->bt_MinGapNodeY(); break;
        case 43: _t->bt_AlignNodeX(); break;
        case 44: _t->bt_AlignNodeY(); break;
        case 45: _t->bt_AlignNodeTh(); break;
        case 46: _t->bt_ClearTopo(); break;
        case 47: _t->bt_NodePoseXUp(); break;
        case 48: _t->bt_NodePoseYUp(); break;
        case 49: _t->bt_NodePoseThUp(); break;
        case 50: _t->bt_NodePoseXDown(); break;
        case 51: _t->bt_NodePoseYDown(); break;
        case 52: _t->bt_NodePoseThDown(); break;
        case 53: _t->bt_QuickAnnotStart(); break;
        case 54: _t->bt_QuickAnnotStop(); break;
        case 55: _t->bt_QuickAddNode(); break;
        case 56: _t->bt_QuickAddAruco(); break;
        case 57: _t->bt_QuickAddCloud(); break;
        case 58: _t->bt_SetMapTf(); break;
        case 59: _t->bt_CheckNodes(); break;
        case 60: _t->bt_MapBuild(); break;
        case 61: _t->bt_MapSave(); break;
        case 62: _t->bt_MapLoad(); break;
        case 63: _t->bt_MapLastLc(); break;
        case 64: _t->bt_LocInit(); break;
        case 65: _t->bt_LocInitSemiAuto(); break;
        case 66: _t->bt_LocInitAuto(); break;
        case 67: _t->bt_LocStart(); break;
        case 68: _t->bt_LocStop(); break;
        case 69: _t->bt_SimInit(); break;
        case 70: _t->bt_Test(); break;
        case 71: _t->bt_TestLed(); break;
        case 72: _t->ckb_TestDebug(); break;
        case 73: _t->bt_TestImgSave(); break;
        case 74: _t->bt_AutoMove(); break;
        case 75: _t->bt_AutoMove2(); break;
        case 76: _t->bt_AutoMove3(); break;
        case 77: _t->bt_AutoStop(); break;
        case 78: _t->bt_AutoPause(); break;
        case 79: _t->bt_AutoResume(); break;
        case 80: _t->bt_ReturnToCharging(); break;
        case 81: _t->slot_local_path_updated(); break;
        case 82: _t->slot_global_path_updated(); break;
        case 83: _t->bt_ObsClear(); break;
        case 84: _t->bt_TaskAdd(); break;
        case 85: _t->bt_TaskDel(); break;
        case 86: _t->bt_TaskSave(); break;
        case 87: _t->bt_TaskLoad(); break;
        case 88: _t->bt_TaskPlay(); break;
        case 89: _t->bt_TaskPause(); break;
        case 90: _t->bt_TaskCancel(); break;
        case 91: _t->cb_NodeType((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 92: _t->bt_SelectPreNodes(); break;
        case 93: _t->bt_SelectPostNodes(); break;
        case 94: _t->bt_SendMap(); break;
        case 95: _t->slot_sim_random_init((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 96: _t->slot_sim_random_seq(); break;
        case 97: _t->bt_DockStart(); break;
        case 98: _t->bt_DockStop(); break;
        case 99: _t->bt_UnDockStart(); break;
        case 100: _t->bt_TestAnnot(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(DATA_MOVE );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::signal_move_response)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 101)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 101;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 101)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 101;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::signal_move_response(DATA_MOVE _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
