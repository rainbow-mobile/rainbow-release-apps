/****************************************************************************
** Meta object code from reading C++ file 'comm_rrs.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../comm_rrs.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'comm_rrs.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_COMM_RRS_t {
    QByteArrayData data[31];
    char stringdata0[558];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_COMM_RRS_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_COMM_RRS_t qt_meta_stringdata_COMM_RRS = {
    {
QT_MOC_LITERAL(0, 0, 8), // "COMM_RRS"
QT_MOC_LITERAL(1, 9, 34), // "signal_request_restart_applic..."
QT_MOC_LITERAL(2, 44, 0), // ""
QT_MOC_LITERAL(3, 45, 13), // "sio_connected"
QT_MOC_LITERAL(4, 59, 16), // "sio_disconnected"
QT_MOC_LITERAL(5, 76, 25), // "sio::client::close_reason"
QT_MOC_LITERAL(6, 102, 6), // "reason"
QT_MOC_LITERAL(7, 109, 9), // "sio_error"
QT_MOC_LITERAL(8, 119, 18), // "send_move_response"
QT_MOC_LITERAL(9, 138, 9), // "DATA_MOVE"
QT_MOC_LITERAL(10, 148, 3), // "msg"
QT_MOC_LITERAL(11, 152, 26), // "send_localization_response"
QT_MOC_LITERAL(12, 179, 17), // "DATA_LOCALIZATION"
QT_MOC_LITERAL(13, 197, 18), // "send_load_response"
QT_MOC_LITERAL(14, 216, 9), // "DATA_LOAD"
QT_MOC_LITERAL(15, 226, 23), // "send_randomseq_response"
QT_MOC_LITERAL(16, 250, 14), // "DATA_RANDOMSEQ"
QT_MOC_LITERAL(17, 265, 21), // "send_mapping_response"
QT_MOC_LITERAL(18, 287, 12), // "DATA_MAPPING"
QT_MOC_LITERAL(19, 300, 18), // "send_dock_response"
QT_MOC_LITERAL(20, 319, 9), // "DATA_DOCK"
QT_MOC_LITERAL(21, 329, 18), // "send_path_response"
QT_MOC_LITERAL(22, 348, 9), // "DATA_PATH"
QT_MOC_LITERAL(23, 358, 29), // "send_software_update_response"
QT_MOC_LITERAL(24, 388, 13), // "DATA_SOFTWARE"
QT_MOC_LITERAL(25, 402, 30), // "send_cam_order_change_response"
QT_MOC_LITERAL(26, 433, 13), // "DATA_CAM_INFO"
QT_MOC_LITERAL(27, 447, 22), // "send_cam_info_response"
QT_MOC_LITERAL(28, 470, 30), // "send_update_variables_response"
QT_MOC_LITERAL(29, 501, 20), // "DATA_UPDATE_VARIABLE"
QT_MOC_LITERAL(30, 522, 35) // "send_software_version_info_re..."

    },
    "COMM_RRS\0signal_request_restart_application\0"
    "\0sio_connected\0sio_disconnected\0"
    "sio::client::close_reason\0reason\0"
    "sio_error\0send_move_response\0DATA_MOVE\0"
    "msg\0send_localization_response\0"
    "DATA_LOCALIZATION\0send_load_response\0"
    "DATA_LOAD\0send_randomseq_response\0"
    "DATA_RANDOMSEQ\0send_mapping_response\0"
    "DATA_MAPPING\0send_dock_response\0"
    "DATA_DOCK\0send_path_response\0DATA_PATH\0"
    "send_software_update_response\0"
    "DATA_SOFTWARE\0send_cam_order_change_response\0"
    "DATA_CAM_INFO\0send_cam_info_response\0"
    "send_update_variables_response\0"
    "DATA_UPDATE_VARIABLE\0"
    "send_software_version_info_response"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_COMM_RRS[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      16,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   94,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       3,    0,   95,    2, 0x08 /* Private */,
       4,    1,   96,    2, 0x08 /* Private */,
       7,    0,   99,    2, 0x08 /* Private */,
       8,    1,  100,    2, 0x0a /* Public */,
      11,    1,  103,    2, 0x0a /* Public */,
      13,    1,  106,    2, 0x0a /* Public */,
      15,    1,  109,    2, 0x0a /* Public */,
      17,    1,  112,    2, 0x0a /* Public */,
      19,    1,  115,    2, 0x0a /* Public */,
      21,    1,  118,    2, 0x0a /* Public */,
      23,    1,  121,    2, 0x0a /* Public */,
      25,    1,  124,    2, 0x0a /* Public */,
      27,    1,  127,    2, 0x0a /* Public */,
      28,    1,  130,    2, 0x0a /* Public */,
      30,    0,  133,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,   10,
    QMetaType::Void, 0x80000000 | 12,   10,
    QMetaType::Void, 0x80000000 | 14,   10,
    QMetaType::Void, 0x80000000 | 16,   10,
    QMetaType::Void, 0x80000000 | 18,   10,
    QMetaType::Void, 0x80000000 | 20,   10,
    QMetaType::Void, 0x80000000 | 22,   10,
    QMetaType::Void, 0x80000000 | 24,   10,
    QMetaType::Void, 0x80000000 | 26,   10,
    QMetaType::Void, 0x80000000 | 26,   10,
    QMetaType::Void, 0x80000000 | 29,   10,
    QMetaType::Void,

       0        // eod
};

void COMM_RRS::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<COMM_RRS *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signal_request_restart_application(); break;
        case 1: _t->sio_connected(); break;
        case 2: _t->sio_disconnected((*reinterpret_cast< const sio::client::close_reason(*)>(_a[1]))); break;
        case 3: _t->sio_error(); break;
        case 4: _t->send_move_response((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        case 5: _t->send_localization_response((*reinterpret_cast< DATA_LOCALIZATION(*)>(_a[1]))); break;
        case 6: _t->send_load_response((*reinterpret_cast< DATA_LOAD(*)>(_a[1]))); break;
        case 7: _t->send_randomseq_response((*reinterpret_cast< DATA_RANDOMSEQ(*)>(_a[1]))); break;
        case 8: _t->send_mapping_response((*reinterpret_cast< DATA_MAPPING(*)>(_a[1]))); break;
        case 9: _t->send_dock_response((*reinterpret_cast< DATA_DOCK(*)>(_a[1]))); break;
        case 10: _t->send_path_response((*reinterpret_cast< DATA_PATH(*)>(_a[1]))); break;
        case 11: _t->send_software_update_response((*reinterpret_cast< DATA_SOFTWARE(*)>(_a[1]))); break;
        case 12: _t->send_cam_order_change_response((*reinterpret_cast< DATA_CAM_INFO(*)>(_a[1]))); break;
        case 13: _t->send_cam_info_response((*reinterpret_cast< DATA_CAM_INFO(*)>(_a[1]))); break;
        case 14: _t->send_update_variables_response((*reinterpret_cast< DATA_UPDATE_VARIABLE(*)>(_a[1]))); break;
        case 15: _t->send_software_version_info_response(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOCALIZATION >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOAD >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_RANDOMSEQ >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MAPPING >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_DOCK >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_PATH >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_SOFTWARE >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_CAM_INFO >(); break;
            }
            break;
        case 13:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_CAM_INFO >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_UPDATE_VARIABLE >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (COMM_RRS::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_RRS::signal_request_restart_application)) {
                *result = 0;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject COMM_RRS::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_COMM_RRS.data,
    qt_meta_data_COMM_RRS,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *COMM_RRS::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *COMM_RRS::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_COMM_RRS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int COMM_RRS::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 16)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 16;
    }
    return _id;
}

// SIGNAL 0
void COMM_RRS::signal_request_restart_application()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
