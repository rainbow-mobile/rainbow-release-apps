/****************************************************************************
** Meta object code from reading C++ file 'comm_fms.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../comm_fms.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'comm_fms.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_COMM_FMS_t {
    QByteArrayData data[35];
    char stringdata0[420];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_COMM_FMS_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_COMM_FMS_t qt_meta_stringdata_COMM_FMS = {
    {
QT_MOC_LITERAL(0, 0, 8), // "COMM_FMS"
QT_MOC_LITERAL(1, 9, 23), // "signal_send_move_status"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 9), // "recv_move"
QT_MOC_LITERAL(4, 44, 9), // "DATA_MOVE"
QT_MOC_LITERAL(5, 54, 3), // "msg"
QT_MOC_LITERAL(6, 58, 17), // "recv_localization"
QT_MOC_LITERAL(7, 76, 17), // "DATA_LOCALIZATION"
QT_MOC_LITERAL(8, 94, 9), // "recv_load"
QT_MOC_LITERAL(9, 104, 9), // "DATA_LOAD"
QT_MOC_LITERAL(10, 114, 14), // "recv_randomseq"
QT_MOC_LITERAL(11, 129, 14), // "DATA_RANDOMSEQ"
QT_MOC_LITERAL(12, 144, 9), // "recv_path"
QT_MOC_LITERAL(13, 154, 9), // "DATA_PATH"
QT_MOC_LITERAL(14, 164, 11), // "recv_vobs_r"
QT_MOC_LITERAL(15, 176, 11), // "DATA_VOBS_R"
QT_MOC_LITERAL(16, 188, 11), // "recv_vobs_c"
QT_MOC_LITERAL(17, 200, 11), // "DATA_VOBS_C"
QT_MOC_LITERAL(18, 212, 9), // "recv_vobs"
QT_MOC_LITERAL(19, 222, 9), // "DATA_VOBS"
QT_MOC_LITERAL(20, 232, 12), // "recv_message"
QT_MOC_LITERAL(21, 245, 3), // "buf"
QT_MOC_LITERAL(22, 249, 14), // "reconnect_loop"
QT_MOC_LITERAL(23, 264, 9), // "connected"
QT_MOC_LITERAL(24, 274, 12), // "disconnected"
QT_MOC_LITERAL(25, 287, 16), // "send_move_status"
QT_MOC_LITERAL(26, 304, 9), // "slot_move"
QT_MOC_LITERAL(27, 314, 17), // "slot_localization"
QT_MOC_LITERAL(28, 332, 9), // "slot_load"
QT_MOC_LITERAL(29, 342, 14), // "slot_randomseq"
QT_MOC_LITERAL(30, 357, 9), // "slot_path"
QT_MOC_LITERAL(31, 367, 9), // "slot_vobs"
QT_MOC_LITERAL(32, 377, 11), // "slot_vobs_r"
QT_MOC_LITERAL(33, 389, 11), // "slot_vobs_c"
QT_MOC_LITERAL(34, 401, 18) // "send_move_response"

    },
    "COMM_FMS\0signal_send_move_status\0\0"
    "recv_move\0DATA_MOVE\0msg\0recv_localization\0"
    "DATA_LOCALIZATION\0recv_load\0DATA_LOAD\0"
    "recv_randomseq\0DATA_RANDOMSEQ\0recv_path\0"
    "DATA_PATH\0recv_vobs_r\0DATA_VOBS_R\0"
    "recv_vobs_c\0DATA_VOBS_C\0recv_vobs\0"
    "DATA_VOBS\0recv_message\0buf\0reconnect_loop\0"
    "connected\0disconnected\0send_move_status\0"
    "slot_move\0slot_localization\0slot_load\0"
    "slot_randomseq\0slot_path\0slot_vobs\0"
    "slot_vobs_r\0slot_vobs_c\0send_move_response"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_COMM_FMS[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       9,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  129,    2, 0x06 /* Public */,
       3,    1,  130,    2, 0x06 /* Public */,
       6,    1,  133,    2, 0x06 /* Public */,
       8,    1,  136,    2, 0x06 /* Public */,
      10,    1,  139,    2, 0x06 /* Public */,
      12,    1,  142,    2, 0x06 /* Public */,
      14,    1,  145,    2, 0x06 /* Public */,
      16,    1,  148,    2, 0x06 /* Public */,
      18,    1,  151,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      20,    1,  154,    2, 0x08 /* Private */,
      22,    0,  157,    2, 0x08 /* Private */,
      23,    0,  158,    2, 0x08 /* Private */,
      24,    0,  159,    2, 0x08 /* Private */,
      25,    0,  160,    2, 0x08 /* Private */,
      26,    1,  161,    2, 0x08 /* Private */,
      27,    1,  164,    2, 0x08 /* Private */,
      28,    1,  167,    2, 0x08 /* Private */,
      29,    1,  170,    2, 0x08 /* Private */,
      30,    1,  173,    2, 0x08 /* Private */,
      31,    1,  176,    2, 0x08 /* Private */,
      32,    1,  179,    2, 0x08 /* Private */,
      33,    1,  182,    2, 0x08 /* Private */,
      34,    1,  185,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 7,    5,
    QMetaType::Void, 0x80000000 | 9,    5,
    QMetaType::Void, 0x80000000 | 11,    5,
    QMetaType::Void, 0x80000000 | 13,    5,
    QMetaType::Void, 0x80000000 | 15,    5,
    QMetaType::Void, 0x80000000 | 17,    5,
    QMetaType::Void, 0x80000000 | 19,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,   21,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 7,    5,
    QMetaType::Void, 0x80000000 | 9,    5,
    QMetaType::Void, 0x80000000 | 11,    5,
    QMetaType::Void, 0x80000000 | 13,    5,
    QMetaType::Void, 0x80000000 | 19,    5,
    QMetaType::Void, 0x80000000 | 15,    5,
    QMetaType::Void, 0x80000000 | 17,    5,
    QMetaType::Void, 0x80000000 | 4,    5,

       0        // eod
};

void COMM_FMS::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<COMM_FMS *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->signal_send_move_status(); break;
        case 1: _t->recv_move((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        case 2: _t->recv_localization((*reinterpret_cast< DATA_LOCALIZATION(*)>(_a[1]))); break;
        case 3: _t->recv_load((*reinterpret_cast< DATA_LOAD(*)>(_a[1]))); break;
        case 4: _t->recv_randomseq((*reinterpret_cast< DATA_RANDOMSEQ(*)>(_a[1]))); break;
        case 5: _t->recv_path((*reinterpret_cast< DATA_PATH(*)>(_a[1]))); break;
        case 6: _t->recv_vobs_r((*reinterpret_cast< DATA_VOBS_R(*)>(_a[1]))); break;
        case 7: _t->recv_vobs_c((*reinterpret_cast< DATA_VOBS_C(*)>(_a[1]))); break;
        case 8: _t->recv_vobs((*reinterpret_cast< DATA_VOBS(*)>(_a[1]))); break;
        case 9: _t->recv_message((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->reconnect_loop(); break;
        case 11: _t->connected(); break;
        case 12: _t->disconnected(); break;
        case 13: _t->send_move_status(); break;
        case 14: _t->slot_move((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        case 15: _t->slot_localization((*reinterpret_cast< DATA_LOCALIZATION(*)>(_a[1]))); break;
        case 16: _t->slot_load((*reinterpret_cast< DATA_LOAD(*)>(_a[1]))); break;
        case 17: _t->slot_randomseq((*reinterpret_cast< DATA_RANDOMSEQ(*)>(_a[1]))); break;
        case 18: _t->slot_path((*reinterpret_cast< DATA_PATH(*)>(_a[1]))); break;
        case 19: _t->slot_vobs((*reinterpret_cast< DATA_VOBS(*)>(_a[1]))); break;
        case 20: _t->slot_vobs_r((*reinterpret_cast< DATA_VOBS_R(*)>(_a[1]))); break;
        case 21: _t->slot_vobs_c((*reinterpret_cast< DATA_VOBS_C(*)>(_a[1]))); break;
        case 22: _t->send_move_response((*reinterpret_cast< DATA_MOVE(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOCALIZATION >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOAD >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_RANDOMSEQ >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_PATH >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_R >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_C >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS >(); break;
            }
            break;
        case 14:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        case 15:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOCALIZATION >(); break;
            }
            break;
        case 16:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_LOAD >(); break;
            }
            break;
        case 17:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_RANDOMSEQ >(); break;
            }
            break;
        case 18:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_PATH >(); break;
            }
            break;
        case 19:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS >(); break;
            }
            break;
        case 20:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_R >(); break;
            }
            break;
        case 21:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_VOBS_C >(); break;
            }
            break;
        case 22:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< DATA_MOVE >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (COMM_FMS::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::signal_send_move_status)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_MOVE );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_move)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_LOCALIZATION );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_localization)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_LOAD );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_load)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_RANDOMSEQ );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_randomseq)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_PATH );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_path)) {
                *result = 5;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_VOBS_R );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_vobs_r)) {
                *result = 6;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_VOBS_C );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_vobs_c)) {
                *result = 7;
                return;
            }
        }
        {
            using _t = void (COMM_FMS::*)(DATA_VOBS );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&COMM_FMS::recv_vobs)) {
                *result = 8;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject COMM_FMS::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_COMM_FMS.data,
    qt_meta_data_COMM_FMS,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *COMM_FMS::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *COMM_FMS::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_COMM_FMS.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int COMM_FMS::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void COMM_FMS::signal_send_move_status()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void COMM_FMS::recv_move(DATA_MOVE _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void COMM_FMS::recv_localization(DATA_LOCALIZATION _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void COMM_FMS::recv_load(DATA_LOAD _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void COMM_FMS::recv_randomseq(DATA_RANDOMSEQ _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void COMM_FMS::recv_path(DATA_PATH _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void COMM_FMS::recv_vobs_r(DATA_VOBS_R _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void COMM_FMS::recv_vobs_c(DATA_VOBS_C _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void COMM_FMS::recv_vobs(DATA_VOBS _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
