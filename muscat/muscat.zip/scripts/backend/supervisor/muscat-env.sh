#!/bin/bash
# Shared helpers for applying Muscat runtime environment files.

muscat_env_file() {
  echo "${MUSCAT_ENV_FILE:-/app/data/.env.muscat}"
}

muscat_source_env_file() {
  local env_file="${1:-$(muscat_env_file)}"
  [[ -f "$env_file" ]] || return 1

  set -a
  # shellcheck disable=SC1090
  . "$env_file"
  set +a
}

muscat_supervisor_env_entries() {
  local env_file="${1:-$(muscat_env_file)}"
  shift || true
  [[ -f "$env_file" ]] || return 0

  local pybin="python3"
  command -v "$pybin" >/dev/null 2>&1 || pybin="python"

  "$pybin" - "$env_file" "$@" <<'PY'
import os
import re
import sys

env_file = sys.argv[1]
excluded = set(sys.argv[2:])
keys = []

with open(env_file, encoding="utf-8") as file:
    for line in file:
        match = re.match(r"\s*(?:export\s+)?([A-Za-z_][A-Za-z0-9_]*)\s*=", line)
        if not match:
            continue
        key = match.group(1)
        if key not in excluded and key not in keys:
            keys.append(key)


def supervisor_quote(value: str) -> str:
    value = value.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    return f'"{value}"'


print(",".join(f"{key}={supervisor_quote(os.environ.get(key, ''))}" for key in keys))
PY
}
