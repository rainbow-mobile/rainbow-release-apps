#!/usr/bin/env python3
"""cgroup(v2) 자원 압박 감시. 임계 초과 시 crash_events.jsonl 에 기록. stdlib only."""
import json
import os
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

CRASH_FILE = os.environ.get("RB_CRASH_EVENTS_FILE", "/app/data/log/crash_events.jsonl")
CGROUP_ROOT = os.environ.get("RB_CGROUP_ROOT", "/sys/fs/cgroup")
MAX_BYTES = 1 * 1024 * 1024
INTERVAL_SEC = float(os.environ.get("RB_RESOURCE_WATCH_INTERVAL_SEC", "5"))
REPEAT_SEC = 30.0

THROTTLE_RATIO = 0.25
MEM_RATIO = 0.85
MEM_MAX_HITS = 5  # memory.events max 델타/샘플. 한계 도달 = reclaim 중
MAJFAULT_PER_SEC = 20.0  # memory.stat pgmajfault 델타/초. 코드 페이지가 날아가 디스크에서 다시 읽는 중
PSI_CPU_SOME = 50.0  # avg10 %
PSI_MEM_SOME = 10.0
PSI_IO_SOME = 20.0


def _read(name: str) -> str | None:
    try:
        with open(os.path.join(CGROUP_ROOT, name), encoding="utf-8") as f:
            return f.read()
    except OSError:
        return None


def _kv(name: str) -> dict[str, int]:
    raw = _read(name) or ""
    out: dict[str, int] = {}
    for line in raw.splitlines():
        k, _, v = line.partition(" ")
        if v.strip().isdigit():
            out[k] = int(v)
    return out


def _int(name: str) -> int | None:
    raw = (_read(name) or "").strip()
    return int(raw) if raw.isdigit() else None


def _psi_some_avg10(name: str) -> float | None:
    raw = _read(name) or ""
    for line in raw.splitlines():
        if line.startswith("some"):
            for tok in line.split():
                if tok.startswith("avg10="):
                    try:
                        return float(tok[6:])
                    except ValueError:
                        return None
    return None


def sample() -> dict:
    cpu = _kv("cpu.stat")
    return {
        "t": time.monotonic(),
        "usage_usec": cpu.get("usage_usec"),
        "throttled_usec": cpu.get("throttled_usec"),
        "nr_throttled": cpu.get("nr_throttled"),
        "mem_current": _int("memory.current"),
        "mem_max": _int("memory.max"),
        "oom_kill": _kv("memory.events").get("oom_kill"),
        "mem_max_hits": _kv("memory.events").get("max"),
        "pgmajfault": _kv("memory.stat").get("pgmajfault"),
        "psi_cpu": _psi_some_avg10("cpu.pressure"),
        "psi_mem": _psi_some_avg10("memory.pressure"),
        "psi_io": _psi_some_avg10("io.pressure"),
    }


def evaluate(prev: dict, cur: dict) -> tuple[str, list[str]]:
    reasons: list[str] = []
    level = "warning"
    dt = max(1e-3, cur["t"] - prev["t"])

    if cur.get("oom_kill") is not None and prev.get("oom_kill") is not None:
        d = cur["oom_kill"] - prev["oom_kill"]
        if d > 0:
            level = "error"
            reasons.append(f"OOM kill +{d} (cgroup memory.events)")

    if cur.get("mem_max_hits") is not None and prev.get("mem_max_hits") is not None:
        d = cur["mem_max_hits"] - prev["mem_max_hits"]
        if d >= MEM_MAX_HITS:
            reasons.append(f"memory limit hit +{d} in {dt:.0f}s (cgroup memory.events max; reclaim thrash)")

    if cur.get("pgmajfault") is not None and prev.get("pgmajfault") is not None:
        rate = (cur["pgmajfault"] - prev["pgmajfault"]) / dt
        if rate > MAJFAULT_PER_SEC:
            reasons.append(f"major page faults {rate:.0f}/s (code/file pages evicted, reading back from disk)")

    if cur.get("throttled_usec") is not None and prev.get("throttled_usec") is not None:
        ratio = (cur["throttled_usec"] - prev["throttled_usec"]) / (dt * 1e6)
        if ratio > THROTTLE_RATIO:
            reasons.append(f"cpu throttled {ratio:.0%} of last {dt:.0f}s")

    if cur.get("mem_current") is not None and cur.get("mem_max"):
        ratio = cur["mem_current"] / cur["mem_max"]
        if ratio > MEM_RATIO:
            reasons.append(
                f"memory {cur['mem_current'] // 2**20}/{cur['mem_max'] // 2**20}MB ({ratio:.0%})"
            )

    for key, limit, label in (
        ("psi_cpu", PSI_CPU_SOME, "cpu"),
        ("psi_mem", PSI_MEM_SOME, "memory"),
        ("psi_io", PSI_IO_SOME, "io"),
    ):
        v = cur.get(key)
        if v is not None and v > limit:
            reasons.append(f"PSI {label} some avg10={v:.1f}%")

    return level, reasons


def cpu_usage_ratio(prev: dict, cur: dict) -> float | None:
    if cur.get("usage_usec") is None or prev.get("usage_usec") is None:
        return None
    dt = max(1e-3, cur["t"] - prev["t"])
    return (cur["usage_usec"] - prev["usage_usec"]) / (dt * 1e6)


def top_rss(n: int = 5) -> list[str]:
    rows: list[tuple[int, str, int]] = []
    try:
        pids = [d for d in os.listdir("/proc") if d.isdigit()]
    except OSError:
        return []
    for pid in pids:
        try:
            name = ""
            rss = 0
            with open(f"/proc/{pid}/status", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if line.startswith("Name:"):
                        name = line.split(None, 1)[1].strip()
                    elif line.startswith("VmRSS:"):
                        rss = int(line.split()[1])  # kB
            if rss:
                rows.append((rss, name, int(pid)))
        except (OSError, ValueError, IndexError):
            continue
    rows.sort(reverse=True)
    return [f"{name}({pid})={rss // 1024}MB" for rss, name, pid in rows[:n]]


def make_record(level: str, message: str) -> dict:
    try:
        ts = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()) + " UTC"
    return {"ts": ts, "event": "RESOURCE_PRESSURE", "level": level, "message": message}


def append_event(record: dict) -> None:
    os.makedirs(os.path.dirname(CRASH_FILE), exist_ok=True)
    try:
        if os.path.exists(CRASH_FILE) and os.path.getsize(CRASH_FILE) > MAX_BYTES:
            os.remove(CRASH_FILE)
    except OSError:
        pass
    with open(CRASH_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
        f.flush()


def main() -> None:
    if _read("cpu.stat") is None and _read("memory.current") is None:
        sys.stderr.write("[resource-watch] no cgroup v2 files; idle\n")
        while True:
            time.sleep(3600)

    prev = sample()
    active = False
    last_log = 0.0
    while True:
        time.sleep(INTERVAL_SEC)
        cur = sample()
        level, reasons = evaluate(prev, cur)
        now = time.monotonic()
        if reasons:
            if not active or (now - last_log) >= REPEAT_SEC or level == "error":
                usage = cpu_usage_ratio(prev, cur)
                usage_txt = "?" if usage is None else f"{usage:.2f}cpu"
                msg = "; ".join(reasons) + f"; cpu_usage={usage_txt}; top_rss={' '.join(top_rss())}"
                append_event(make_record(level, msg))
                last_log = now
            active = True
        elif active:
            append_event(make_record("warning", "resource pressure recovered"))
            active = False
        prev = cur


if __name__ == "__main__":
    main()
