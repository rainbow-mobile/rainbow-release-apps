#!/usr/bin/env python3
"""dev 소스 워처 — uvicorn --reload 대체.

--reload 는 서버를 손자로 만들어(supervisor → bash → reloader → worker) worker 가
죽어도 reloader 부모가 살아남는다. supervisor 는 RUNNING 으로 오인하고 안 살린다.
여기서는 서버를 supervisor 직계 자식으로 두고 재시작만 이 워처가 맡는다.

    dev-watcher.py --backend /app/backend --quiet 2.0 common log
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

from watchfiles import DefaultFilter, watch

WATCH_EXTS = (".py", ".pyi", ".so")


class SourceFilter(DefaultFilter):
    ignore_dirs = DefaultFilter.ignore_dirs + (
        ".gen-staging",
        ".mypy_cache",
        ".ruff_cache",
        ".pytest_cache",
    )

    def __call__(self, change, path: str) -> bool:
        if "/.out-" in path:  # build.sh 산출물
            return False
        return path.endswith(WATCH_EXTS) and super().__call__(change, path)


def targets_for(paths, services: set[str], services_root: Path) -> set[str]:
    """변경 경로 → 재시작할 서비스. packages 가 섞이면 전체."""
    hit: set[str] = set()
    for p in paths:
        try:
            rel = Path(p).relative_to(services_root)
        except ValueError:
            return set(services)
        if rel.parts and rel.parts[0] in services:
            hit.add(rel.parts[0])
    return hit


def log(msg: str) -> None:
    print(f"[dev-watcher] {msg}", flush=True)


def _self_check() -> None:
    root = Path("/app/backend/services")
    svcs = {"common", "log"}
    assert targets_for([f"{root}/common/app/main.py"], svcs, root) == {"common"}
    assert targets_for([f"{root}/host/app/main.py"], svcs, root) == set()
    assert targets_for(["/app/backend/packages/rb_sdk/x.py"], svcs, root) == svcs
    assert targets_for([f"{root}/log/a.py", "/app/backend/packages/b.so"], svcs, root) == svcs
    f = SourceFilter()
    from watchfiles import Change

    assert f(Change.modified, "/app/backend/packages/rb_sdk/a.pyi")
    assert f(Change.modified, "/app/backend/packages/rb_zenoh/_core.so")
    assert not f(Change.modified, "/app/backend/services/common/common.amd64.bin")
    assert not f(Change.modified, "/app/backend/services/common/.out-amd64/run.py")
    print("ok")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("services", nargs="*", help="감시/재시작 대상 서비스")
    ap.add_argument("--backend", default="/app/backend")
    ap.add_argument(
        "--quiet",
        type=float,
        default=2.0,
        help="마지막 변경 후 이 시간(초) 동안 조용하면 재시작",
    )
    ap.add_argument("--self-check", action="store_true")
    args = ap.parse_args()

    if args.self_check:
        _self_check()
        return 0
    if not args.services:
        ap.error("서비스를 하나 이상 지정하세요")

    backend = Path(args.backend).resolve()
    services_root = backend / "services"
    services = set(args.services)

    paths = [backend / "packages"] + [services_root / s for s in args.services]
    paths = [p for p in paths if p.is_dir()]
    if not paths:
        log(f"감시할 디렉토리가 없습니다: {backend}")
        return 1

    log(
        f"watch {[str(p) for p in paths]} exts={WATCH_EXTS} "
        f"quiet={args.quiet}s services={','.join(sorted(services))}"
    )

    pending: set[str] = set()
    last = 0.0

    for changes in watch(
        *paths,
        watch_filter=SourceFilter(),
        debounce=200,
        step=50,
        rust_timeout=250,
        yield_on_timeout=True,
    ):
        if changes:
            pending.update(path for _, path in changes)
            last = time.monotonic()
            continue
        if pending and time.monotonic() - last >= args.quiet:
            svcs = sorted(targets_for(pending, services, services_root))
            log(f"{len(pending)} file(s) changed → restart: {' '.join(svcs) or '(none)'}")
            pending.clear()
            if svcs:
                subprocess.run(["supervisorctl", "restart", *svcs], check=False)

    return 0


if __name__ == "__main__":
    sys.exit(main())
