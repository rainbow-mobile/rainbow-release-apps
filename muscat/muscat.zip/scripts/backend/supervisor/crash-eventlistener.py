#!/usr/bin/env python3
"""supervisord eventlistener: 서비스의 unexpected exit / FATAL 을 jsonl 로 기록.

stdlib only — 컨테이너 시스템 python 에는 rainbow 패키지가 설치되지 않으므로
여기서 zenoh publish 를 직접 하지 않는다. log 서비스가 이 파일을 ingest 해
rb_log ERROR 로 DB 에 남긴다 (log 서비스 자신이 죽은 경우에도 재시작 후
자기 크래시 기록을 자기가 읽는다).

프로토콜: stdout 은 supervisor eventlistener 프로토콜 전용. 디버그는 stderr.
"""
import json
import os
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

CRASH_FILE = os.environ.get("RB_CRASH_EVENTS_FILE", "/app/data/log/crash_events.jsonl")
# log 서비스가 ingest 하지 않는 구성에서도 무한 성장하지 않도록 하는 상한
MAX_BYTES = 1 * 1024 * 1024
_SELF = "crash-watch"


def parse_kv(text: str) -> dict:
    return dict(item.split(":", 1) for item in text.split() if ":" in item)


def handle_event(eventname: str, payload: str):
    """기록할 이벤트면 record dict, 아니면 None."""
    if eventname not in ("PROCESS_STATE_EXITED", "PROCESS_STATE_FATAL"):
        return None
    kv = parse_kv(payload)
    program = kv.get("processname", "unknown")
    if program == _SELF:  # 자기 자신의 재시작 이벤트로 루프/노이즈 방지
        return None
    if eventname == "PROCESS_STATE_EXITED" and kv.get("expected", "0") != "0":
        return None  # supervisorctl stop / 배포 stop / one-shot 정상 종료
    try:
        ts = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()) + " UTC"
    return {"ts": ts, "program": program, "event": eventname}


def append_event(record: dict) -> None:
    os.makedirs(os.path.dirname(CRASH_FILE), exist_ok=True)
    try:
        if os.path.exists(CRASH_FILE) and os.path.getsize(CRASH_FILE) > MAX_BYTES:
            os.remove(CRASH_FILE)
    except OSError:
        pass
    with open(CRASH_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
        f.flush()
        os.fsync(f.fileno())  # 컨테이너가 곧 죽어도 볼륨에 남도록


def main() -> None:
    while True:
        sys.stdout.write("READY\n")
        sys.stdout.flush()
        header_line = sys.stdin.readline()
        if not header_line:
            return  # supervisor 종료
        header = parse_kv(header_line.strip())
        payload = sys.stdin.read(int(header.get("len", 0)))
        try:
            record = handle_event(header.get("eventname", ""), payload)
            if record:
                append_event(record)
        except Exception as e:  # 기록 실패로 리스너가 죽지는 말 것
            sys.stderr.write(f"[crash-watch] {e}\n")
        sys.stdout.write("RESULT 2\nOK")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
