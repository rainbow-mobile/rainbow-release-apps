#!/usr/bin/env python3
"""supervisord eventlistener: 서비스의 unexpected exit / FATAL 을 jsonl 로 기록.

stdlib only — 컨테이너 시스템 python 에는 rainbow 패키지가 설치되지 않으므로
여기서 zenoh publish 를 직접 하지 않는다. log 서비스가 이 파일을 ingest 해
rb_log ERROR 로 DB 에 남긴다 (log 서비스 자신이 죽은 경우에도 재시작 후
자기 크래시 기록을 자기가 읽는다).

프로토콜: stdout 은 supervisor eventlistener 프로토콜 전용. 디버그는 stderr.
"""
import http.client
import json
import os
import socket
import sys
import time
import xmlrpc.client
from datetime import datetime
from zoneinfo import ZoneInfo

CRASH_FILE = os.environ.get("RB_CRASH_EVENTS_FILE", "/app/data/log/crash_events.jsonl")
# log 서비스가 ingest 하지 않는 구성에서도 무한 성장하지 않도록 하는 상한
MAX_BYTES = 1 * 1024 * 1024
_SELF = "crash-watch"
SUPERVISOR_SOCK = os.environ.get("RB_SUPERVISOR_SOCK", "/var/run/supervisor.sock")
CGROUP_ROOT = os.environ.get("RB_CGROUP_ROOT", "/sys/fs/cgroup")
_prev_oom_kill: int | None = None


class _UnixTransport(xmlrpc.client.Transport):
    """unix socket XML-RPC (stdlib 만)"""

    def __init__(self, path: str):
        super().__init__()
        self._path = path

    def make_connection(self, host):
        path = self._path

        class _Conn(http.client.HTTPConnection):
            def connect(self):
                self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                self.sock.settimeout(2.0)
                self.sock.connect(path)

        return _Conn("localhost")


def supervisor_exit_status(program: str) -> int | None:
    """-1 = 시그널 종료, N = exit code"""
    try:
        proxy = xmlrpc.client.ServerProxy(
            "http://localhost/RPC2", transport=_UnixTransport(SUPERVISOR_SOCK)
        )
        info = proxy.supervisor.getProcessInfo(program)
        return int(info.get("exitstatus"))
    except Exception:
        return None


def _read_cgroup_kv(name: str) -> dict[str, int]:
    try:
        with open(os.path.join(CGROUP_ROOT, name), encoding="utf-8") as f:
            out = {}
            for line in f:
                k, _, v = line.partition(" ")
                if v.strip().isdigit():
                    out[k] = int(v)
            return out
    except OSError:
        return {}


def _read_cgroup_int(name: str) -> int | None:
    try:
        with open(os.path.join(CGROUP_ROOT, name), encoding="utf-8") as f:
            raw = f.read().strip()
        return int(raw) if raw.isdigit() else None  # "max"
    except OSError:
        return None


def cgroup_snapshot() -> dict:
    cur = _read_cgroup_int("memory.current")
    mx = _read_cgroup_int("memory.max")
    return {
        "oom_kill": _read_cgroup_kv("memory.events").get("oom_kill"),
        "mem_current_mb": None if cur is None else cur // (1024 * 1024),
        "mem_max_mb": None if mx is None else mx // (1024 * 1024),
    }


def enrich(record: dict, *, exitstatus: int | None, cgroup: dict, prev_oom_kill: int | None) -> dict:
    oom = cgroup.get("oom_kill")
    record["exitstatus"] = exitstatus
    record["oom_kill_delta"] = (
        None if oom is None or prev_oom_kill is None else max(0, oom - prev_oom_kill)
    )
    record["mem_current_mb"] = cgroup.get("mem_current_mb")
    record["mem_max_mb"] = cgroup.get("mem_max_mb")
    return record


def parse_kv(text: str) -> dict:
    return dict(item.split(":", 1) for item in text.split() if ":" in item)


def handle_event(eventname: str, payload: str):
    """기록할 이벤트면 record dict, 아니면 None."""
    if eventname not in ("PROCESS_STATE_EXITED", "PROCESS_STATE_FATAL"):
        return None
    kv = parse_kv(payload)
    program = kv.get("processname", "unknown")
    if program == _SELF:  # 자기 자신의 재시작 이벤트로 루프/노이즈 방지
        return None
    if eventname == "PROCESS_STATE_EXITED" and kv.get("expected", "0") != "0":
        return None  # supervisorctl stop / 배포 stop / one-shot 정상 종료
    try:
        ts = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        ts = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()) + " UTC"
    record = {"ts": ts, "program": program, "event": eventname}
    return _enrich_live(record, program)


def _enrich_live(record: dict, program: str) -> dict:
    global _prev_oom_kill
    cg = cgroup_snapshot()
    enrich(
        record,
        exitstatus=supervisor_exit_status(program),
        cgroup=cg,
        prev_oom_kill=_prev_oom_kill if _prev_oom_kill is not None else _initial_oom_kill(),
    )
    if cg.get("oom_kill") is not None:
        _prev_oom_kill = cg["oom_kill"]
    return record


_boot_oom_kill: int | None = None


def _initial_oom_kill() -> int | None:
    return _boot_oom_kill


def append_event(record: dict) -> None:
    os.makedirs(os.path.dirname(CRASH_FILE), exist_ok=True)
    try:
        if os.path.exists(CRASH_FILE) and os.path.getsize(CRASH_FILE) > MAX_BYTES:
            os.remove(CRASH_FILE)
    except OSError:
        pass
    with open(CRASH_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(record) + "\n")
        f.flush()
        os.fsync(f.fileno())  # 컨테이너가 곧 죽어도 볼륨에 남도록


def main() -> None:
    global _boot_oom_kill
    _boot_oom_kill = cgroup_snapshot().get("oom_kill")
    while True:
        sys.stdout.write("READY\n")
        sys.stdout.flush()
        header_line = sys.stdin.readline()
        if not header_line:
            return  # supervisor 종료
        header = parse_kv(header_line.strip())
        payload = sys.stdin.read(int(header.get("len", 0)))
        try:
            record = handle_event(header.get("eventname", ""), payload)
            if record:
                append_event(record)
        except Exception as e:  # 기록 실패로 리스너가 죽지는 말 것
            sys.stderr.write(f"[crash-watch] {e}\n")
        sys.stdout.write("RESULT 2\nOK")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
