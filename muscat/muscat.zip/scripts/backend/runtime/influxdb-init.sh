#!/bin/bash
set -euo pipefail

host="${INFLUXDB_URL:-http://127.0.0.1:8086}"
org="${INFLUXDB_ORG:-rrs}"
bucket="${INFLUXDB_BUCKET:-rrs-rt}"
username="rainbow"
password="rainbow123"
token="rainbowInfluxToken"
# password_file="${INFLUXDB_PASSWORD_FILE:-/app/data/secrets/influxdb_password}"
# token_file="${INFLUXDB_TOKEN_FILE:-/app/data/secrets/influxdb_token}"

for i in $(seq 1 90); do
  if curl -sf "$host/health" >/dev/null 2>&1; then
    break
  fi
  echo "waiting for InfluxDB... ($i/90)"
  sleep 1
done

# if [[ -f "$password_file" ]]; then
#   password="$(tr -d '\r\n' < "$password_file")"
# fi
# if [[ -f "$token_file" ]]; then
#   token="$(tr -d '\r\n' < "$token_file")"
# fi

allowed="$(curl -sf "$host/api/v2/setup" | sed -n 's/.*"allowed"[[:space:]]*:[[:space:]]*\(true\|false\).*/\1/p' || true)"
if [[ "$allowed" == "false" ]]; then
  if curl -sf -H "Authorization: Token $token" "$host/api/v2/buckets?org=$org" >/dev/null 2>&1; then
    echo "InfluxDB already initialized and fixed token is valid."
  else
    echo "InfluxDB already initialized, but fixed token is not valid for this data volume."
    echo "Reset the InfluxDB data directory to initialize it with the fixed token."
  fi
  exit 0
fi

influx setup \
  --host "$host" \
  --org "$org" \
  --bucket "$bucket" \
  --username "$username" \
  --password "$password" \
  --token "$token" \
  --force
