#!/bin/bash
set -euo pipefail

host="${INFLUXDB_URL:-http://127.0.0.1:8086}"
org="${INFLUXDB_ORG:-rrs}"
bucket="${INFLUXDB_BUCKET:-rrs-rt}"
username="${INFLUXDB_USERNAME:-rainbow}"
password_file="${INFLUXDB_PASSWORD_FILE:-/app/data/secrets/influxdb_password}"
token_file="${INFLUXDB_TOKEN_FILE:-/app/data/secrets/influxdb_token}"

for i in $(seq 1 90); do
  if curl -sf "$host/health" >/dev/null 2>&1; then
    break
  fi
  echo "waiting for InfluxDB... ($i/90)"
  sleep 1
done

allowed="$(curl -sf "$host/api/v2/setup" | sed -n 's/.*"allowed"[[:space:]]*:[[:space:]]*\(true\|false\).*/\1/p' || true)"
if [[ "$allowed" == "false" ]]; then
  echo "InfluxDB already initialized."
  exit 0
fi

password="$(tr -d '\r\n' < "$password_file")"
token="$(tr -d '\r\n' < "$token_file")"

influx setup \
  --host "$host" \
  --org "$org" \
  --bucket "$bucket" \
  --username "$username" \
  --password "$password" \
  --token "$token" \
  --force
