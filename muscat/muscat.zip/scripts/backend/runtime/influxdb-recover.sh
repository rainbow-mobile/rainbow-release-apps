#!/bin/bash
# Restore the fixed Muscat InfluxDB token without requiring Docker or the host service.
set -euo pipefail

host="${INFLUXDB_URL:-http://127.0.0.1:8086}"
org="${INFLUXDB_ORG:-rrs}"
bucket="${INFLUXDB_BUCKET:-rrs-rt}"
username="${INFLUXDB_USERNAME:-rainbow}"
password="${INFLUXDB_PASSWORD:-rainbow123}"
token="rainbowInfluxToken"
data_dir="/app/data/influxdb2"
backup_dir="/app/data/influxdb-token-reset-$(date -u +%Y%m%dT%H%M%SZ)"
lock_dir="/app/data/influxdb-token-reset.lock"
backup_created=0

acquire_lock() {
  local attempt owner_pid
  for attempt in $(seq 1 3600); do
    if mkdir "$lock_dir" 2>/dev/null; then
      echo "$$" > "$lock_dir/pid"
      return 0
    fi

    owner_pid="$(cat "$lock_dir/pid" 2>/dev/null || true)"
    if [[ -z "$owner_pid" ]] || ! kill -0 "$owner_pid" 2>/dev/null; then
      rm -rf -- "$lock_dir"
      continue
    fi
    sleep 1
  done
  echo "Timed out waiting for another InfluxDB token recovery" >&2
  return 1
}

release_lock() {
  rm -rf -- "$lock_dir"
}

acquire_lock
trap release_lock EXIT

fixed_token_valid() {
  curl -fsS -H "Authorization: Token $token" \
    "$host/api/v2/buckets?org=$org" >/dev/null 2>&1
}

wait_for_health() {
  local attempt
  for attempt in $(seq 1 90); do
    if curl -fsS "$host/health" >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
  done
  echo "InfluxDB health check timed out" >&2
  return 1
}

wait_for_fixed_token() {
  local attempt
  for attempt in $(seq 1 90); do
    if fixed_token_valid; then
      return 0
    fi
    sleep 1
  done
  echo "InfluxDB fixed-token authentication timed out" >&2
  return 1
}

on_error() {
  local exit_code=$?
  echo "InfluxDB token recovery failed." >&2
  if [[ "$backup_created" == "1" ]]; then
    echo "Backup retained at: $backup_dir" >&2
  fi
  supervisorctl start influxdb >/dev/null 2>&1 || true
  exit "$exit_code"
}
trap on_error ERR

if fixed_token_valid; then
  echo "InfluxDB fixed token is already valid."
  exit 0
fi

echo "Stopping InfluxDB and creating a recovery operator token."
supervisorctl stop influxdb >/dev/null
recovery_output="$(
  influxd recovery auth create-operator \
    --bolt-path "$data_dir/influxd.bolt" \
    --username "$username" \
    --org "$org"
)"
recovery_token="$(
  printf '%s\n' "$recovery_output" \
    | grep -Eo '[A-Za-z0-9_-]{40,}={0,2}' \
    | awk 'length($0) > length(longest) { longest=$0 } END { print longest }'
)"
if [[ -z "$recovery_token" ]]; then
  echo "Unable to parse the recovery operator token" >&2
  exit 1
fi

echo "Backing up existing InfluxDB data to $backup_dir."
supervisorctl start influxdb >/dev/null
wait_for_health
timeout 3600 influx backup \
  --host "$host" \
  --org "$org" \
  --token "$recovery_token" \
  "$backup_dir"
backup_created=1

echo "Reinitializing InfluxDB with the fixed token."
supervisorctl stop influxdb >/dev/null
rm -rf -- "$data_dir"
mkdir -p "$data_dir"
supervisorctl start influxdb >/dev/null
wait_for_health
influx setup \
  --host "$host" \
  --org "$org" \
  --bucket "$bucket" \
  --username "$username" \
  --password "$password" \
  --token "$token" \
  --force

echo "Restoring existing InfluxDB data."
timeout 3600 influx restore \
  --host "$host" \
  --token "$token" \
  --operator-token "$token" \
  --full \
  "$backup_dir"

wait_for_fixed_token
rm -rf -- "$backup_dir"
backup_created=0
trap - ERR
echo "InfluxDB data preserved and fixed token restored."
