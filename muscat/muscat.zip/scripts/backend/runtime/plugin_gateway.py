#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import uuid

import engineio
import socketio
import uvicorn

engineio.payload.Payload.max_decode_packets = 250


class PluginGateway(socketio.AsyncNamespace):
    def __init__(self, namespace: str = "/") -> None:
        super().__init__(namespace)
        self._queryables: dict[str, str] = {}
        self._pending: dict[str, asyncio.Future] = {}

    async def on_connect(self, sid, environ, auth):
        return True

    async def on_disconnect(self, sid):
        self._queryables = {k: v for k, v in self._queryables.items() if v != sid}

    async def on_sub(self, sid, data):
        topic = (data or {}).get("topic")
        if topic:
            await self.enter_room(sid, f"t:{topic}")

    async def on_unsub(self, sid, data):
        topic = (data or {}).get("topic")
        if topic:
            await self.leave_room(sid, f"t:{topic}")

    async def on_pub(self, sid, data):
        topic = (data or {}).get("topic")
        payload = (data or {}).get("payload")
        if topic:
            await self.emit("msg", {"topic": topic, "payload": payload}, room=f"t:{topic}")

    async def on_serve_register(self, sid, data):
        topic = (data or {}).get("topic")
        if topic:
            self._queryables[topic] = sid

    async def on_serve_unregister(self, sid, data):
        topic = (data or {}).get("topic")
        if topic and self._queryables.get(topic) == sid:
            self._queryables.pop(topic)

    async def on_serve_reply(self, sid, data):
        fut = self._pending.pop((data or {}).get("id"), None)
        if fut and not fut.done():
            fut.set_result((data or {}).get("payload"))

    async def on_action(self, sid, data):
        topic = (data or {}).get("topic")
        payload = (data or {}).get("payload")
        target = self._queryables.get(topic)
        if not target:
            return None

        call_id = str(uuid.uuid4())
        fut = asyncio.get_running_loop().create_future()
        self._pending[call_id] = fut
        await self.emit(
            "serve_call",
            {"id": call_id, "topic": topic, "payload": payload},
            room=target,
        )

        try:
            return await asyncio.wait_for(fut, timeout=10.0)
        except TimeoutError:
            self._pending.pop(call_id, None)
            return None


def create_app() -> socketio.ASGIApp:
    sio = socketio.AsyncServer(
        async_mode="asgi",
        cors_allowed_origins="*",
        async_handlers=True,
        ping_interval=20,
        ping_timeout=45,
    )
    sio.register_namespace(PluginGateway("/"))
    return socketio.ASGIApp(sio, socketio_path="/socket.io")


def main() -> None:
    parser = argparse.ArgumentParser(description="Muscat plugin Socket.IO gateway")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=10000)
    args = parser.parse_args()
    uvicorn.run(create_app(), host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
