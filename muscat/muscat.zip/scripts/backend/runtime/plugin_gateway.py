#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import uuid

import engineio
import socketio
import uvicorn

engineio.payload.Payload.max_decode_packets = 250


ROUTE_CALL_TIMEOUT_SEC = 10.0


class PluginGateway(socketio.AsyncNamespace):
    def __init__(self, namespace: str = "/") -> None:
        super().__init__(namespace)
        self._queryables: dict[str, str] = {}
        # call_id -> future. 결과는 serve_reply 의 data dict 전체 ({id, payload, error?, code?})
        self._pending: dict[str, asyncio.Future] = {}

    async def on_connect(self, sid, environ, auth):
        return True

    async def on_disconnect(self, sid):
        self._queryables = {k: v for k, v in self._queryables.items() if v != sid}

    async def on_sub(self, sid, data):
        topic = (data or {}).get("topic")
        if topic:
            await self.enter_room(sid, f"t:{topic}")

    async def on_unsub(self, sid, data):
        topic = (data or {}).get("topic")
        if topic:
            await self.leave_room(sid, f"t:{topic}")

    async def on_pub(self, sid, data):
        topic = (data or {}).get("topic")
        payload = (data or {}).get("payload")
        if topic:
            await self.emit("msg", {"topic": topic, "payload": payload}, room=f"t:{topic}")

    async def on_serve_register(self, sid, data):
        topic = (data or {}).get("topic")
        if topic:
            self._queryables[topic] = sid

    async def on_serve_unregister(self, sid, data):
        topic = (data or {}).get("topic")
        if topic and self._queryables.get(topic) == sid:
            self._queryables.pop(topic)

    async def on_serve_reply(self, sid, data):
        data = data or {}
        fut = self._pending.pop(data.get("id"), None)
        if fut and not fut.done():
            fut.set_result(data)

    async def _call_plugin(self, topic: str, payload) -> dict | None:
        """플러그인 queryable 호출. 핸들러 없으면 None, 타임아웃이면 {"error": ..., "code": 504}."""
        target = self._queryables.get(topic)
        if not target:
            return None

        call_id = str(uuid.uuid4())
        fut = asyncio.get_running_loop().create_future()
        self._pending[call_id] = fut
        await self.emit(
            "serve_call",
            {"id": call_id, "topic": topic, "payload": payload},
            room=target,
        )
        try:
            return await asyncio.wait_for(fut, timeout=ROUTE_CALL_TIMEOUT_SEC)
        except TimeoutError:
            self._pending.pop(call_id, None)
            return {"error": "plugin handler timeout", "code": 504}

    async def on_action(self, sid, data):
        # 브라우저/플러그인 간 기존 프로토콜: payload 만 반환 (에러·미존재는 None)
        reply = await self._call_plugin((data or {}).get("topic"), (data or {}).get("payload"))
        return None if reply is None else reply.get("payload")

    async def on_route_call(self, sid, data):
        # common 의 catch-all 이 쓰는 프로토콜: 상태 코드를 구분해 돌려준다
        topic = (data or {}).get("topic")
        reply = await self._call_plugin(topic, (data or {}).get("payload"))
        if reply is None:
            return {"ok": False, "code": 404, "error": f"no plugin handler: {topic}"}
        if reply.get("error"):
            return {"ok": False, "code": reply.get("code", 500), "error": reply["error"]}
        return {"ok": True, "payload": reply.get("payload")}


def create_app() -> socketio.ASGIApp:
    sio = socketio.AsyncServer(
        async_mode="asgi",
        cors_allowed_origins="*",
        async_handlers=True,
        ping_interval=20,
        ping_timeout=45,
    )
    sio.register_namespace(PluginGateway("/"))
    return socketio.ASGIApp(sio, socketio_path="/socket.io")


def main() -> None:
    parser = argparse.ArgumentParser(description="Muscat plugin Socket.IO gateway")
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=10000)
    args = parser.parse_args()
    uvicorn.run(create_app(), host=args.host, port=args.port, log_level="info")


if __name__ == "__main__":
    main()
