#!/bin/bash
set -euo pipefail

for i in $(seq 1 90); do
  if mongosh --host 127.0.0.1:27017 --quiet --eval "db.adminCommand({ ping: 1 }).ok" >/dev/null 2>&1; then
    break
  fi
  echo "waiting for MongoDB... ($i/90)"
  sleep 1
done

# 인증 모드면 MONGO_URI_PROD 의 계정으로 접속한다(허용 문자가 [A-Za-z0-9._~-] 라 디코딩 불필요).
auth_args=()
if [[ "${MONGO_URI_PROD:-}" =~ ^mongodb://([^:@/]+):([^@/]+)@ ]]; then
  auth_args=(-u "${BASH_REMATCH[1]}" -p "${BASH_REMATCH[2]}" --authenticationDatabase admin)
fi

mongosh --host 127.0.0.1:27017 "${auth_args[@]}" --quiet --eval '
  const desiredHost = "127.0.0.1:27017";
  const desired = {
    _id: "rs0",
    members: [{ _id: 0, host: desiredHost }]
  };

  function isNetworkClose(e) {
    return e.name === "MongoNetworkError" ||
           (e.message && e.message.includes("closed"));
  }

  function forceConfigure() {
    let cfg = db.getSiblingDB("local").system.replset.findOne();
    if (!cfg) {
      cfg = desired;
    }
    cfg._id = cfg._id || "rs0";
    cfg.members = [{ _id: 0, host: desiredHost }];
    cfg.version = (cfg.version || 1) + 1;
    try {
      db.adminCommand({ replSetReconfig: cfg, force: true });
      print("Replica set reconfigured for " + desiredHost + ".");
    } catch (e) {
      if (isNetworkClose(e)) {
        print("Connection closed after reconfig (expected) for " + desiredHost + ".");
      } else {
        throw e;
      }
    }
  }

  try {
    const cfg = rs.conf();
    if (!cfg.members || cfg.members.length !== 1 || cfg.members[0].host !== desiredHost) {
      forceConfigure();
    } else {
      print("Replica set already initialized.");
    }
  } catch (e) {
    const needInit =
      e.codeName === "NotYetInitialized" ||
      e.code === 94 ||
      (e.message && e.message.includes("no replset config has been received"));
    const invalidConfig =
      e.codeName === "InvalidReplicaSetConfig" ||
      e.code === 93 ||
      (e.message && (e.message.includes("not a member") || e.message.includes("config is invalid")));

    if (needInit) {
      try {
        rs.initiate(desired);
        print("Replica set initiated for " + desiredHost + ".");
      } catch (e2) {
        if (isNetworkClose(e2)) {
          print("Connection closed after initiate (expected) for " + desiredHost + ".");
        } else {
          throw e2;
        }
      }
    } else if (invalidConfig) {
      forceConfigure();
    } else {
      throw e;
    }
  }
'
