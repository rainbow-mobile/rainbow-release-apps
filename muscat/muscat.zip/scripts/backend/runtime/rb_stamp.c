// 플러그인 stdout/stderr 줄별 시각 스탬프 LD_PRELOAD shim (common plugin_module 이 env 주입).
// fd 1/2 를 pipe 로 바꾸고 스레드 하나가 읽어 시각 붙여 원래 파일에 쓴다 — write(2) 가로채기는
// glibc stdio 가 내부 __write 로 우회해서 안 된다. 세부(exec/fork/시그널)는 각 함수 주석.
#define _GNU_SOURCE
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

static int g_rfd = -1;  // pipe read end
static int g_out = -1;  // 원래 fd 1 (로그 파일)
static pthread_t g_thr;
static int g_active;
static pid_t g_owner;  // pipe 를 만든 pid
static volatile sig_atomic_t g_pump_done;

static int same_file(int a, int b) {
    struct stat sa, sb;
    return fstat(a, &sa) == 0 && fstat(b, &sb) == 0 && sa.st_dev == sb.st_dev && sa.st_ino == sb.st_ino;
}

static size_t stamp(char *out) {
    struct timespec ts;
    struct tm tm;
    clock_gettime(CLOCK_REALTIME, &ts);
    time_t kst = ts.tv_sec + 9 * 3600;
    gmtime_r(&kst, &tm);
    size_t n = strftime(out, 24, "%Y-%m-%d %H:%M:%S", &tm);
    return n + (size_t)snprintf(out + n, 8, ".%03ld ", ts.tv_nsec / 1000000);
}

static int write_all(int fd, const char *p, size_t n) {
    while (n > 0) {
        ssize_t w = write(fd, p, n);
        if (w < 0) {
            if (errno == EINTR) continue;
            return -1;
        }
        p += (size_t)w;
        n -= (size_t)w;
    }
    return 0;
}

static void *pump(void *arg) {
    (void)arg;
    char in[8192], out[8192];
    size_t used = 0;
    int bol = 1;
    for (;;) {
        ssize_t r = read(g_rfd, in, sizeof in);
        if (r < 0) {
            if (errno == EINTR) continue;
            break;
        }
        if (r == 0) break;
        size_t n = (size_t)r, i = 0;
        while (i < n) {
            if (bol) {
                if (used + 32 > sizeof out) {
                    write_all(g_out, out, used);
                    used = 0;
                }
                used += stamp(out + used);
                bol = 0;
            }
            const char *nl = memchr(in + i, '\n', n - i);
            size_t seg = nl ? (size_t)(nl - (in + i)) + 1 : n - i;
            if (nl) bol = 1;
            while (seg > 0) {
                if (used == sizeof out) {
                    write_all(g_out, out, used);
                    used = 0;
                }
                size_t chunk = seg < sizeof out - used ? seg : sizeof out - used;
                memcpy(out + used, in + i, chunk);
                used += chunk;
                i += chunk;
                seg -= chunk;
            }
        }
        if (used > 0) {
            write_all(g_out, out, used);
            used = 0;
        }
    }
    g_pump_done = 1;
    return NULL;
}

// fd 를 되돌려 write end 를 닫고 pump 가 EOF 로 끝나길 최대 300ms 기다린다. 시그널 핸들러에서도 부르므로
// async-signal-safe 만 쓴다. fork 자식(fd 1 이 $(…) 캡처 pipe 일 수 있고 vfork 면 메모리 공유)에서는 금지.
static void restore_and_drain(void) {
    if (!g_active || getpid() != g_owner) return;
    int both = same_file(1, 2);
    dup2(g_out, 1);
    if (both) dup2(g_out, 2);
    struct timespec tick = {0, 1000 * 1000};
    for (int i = 0; i < 300 && !g_pump_done; i++) nanosleep(&tick, NULL);
    g_active = 0;
}

// 기본 처리인 치명 시그널만 가로채 비운 뒤 다시 던진다. 안 하면 "terminate called …" 직후 abort() 하는
// 크래시 메시지가 유실된다. 플러그인이 나중에 자기 핸들러를 걸면 그쪽이 이긴다.
static void on_fatal(int sig) {
    restore_and_drain();
    signal(sig, SIG_DFL);
    raise(sig);
}

static void hook_fatal_signals(void) {
    static const int sigs[] = {SIGABRT, SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGTERM, SIGINT, SIGHUP, SIGQUIT};
    for (size_t i = 0; i < sizeof sigs / sizeof *sigs; i++) {
        struct sigaction cur;
        if (sigaction(sigs[i], NULL, &cur) != 0 || cur.sa_handler != SIG_DFL) continue;
        struct sigaction sa;
        memset(&sa, 0, sizeof sa);
        sa.sa_handler = on_fatal;
        sigemptyset(&sa.sa_mask);
        sigaction(sigs[i], &sa, NULL);
    }
}

static int start_thread(void) {
    pthread_attr_t attr;
    pthread_attr_init(&attr);
    pthread_attr_setstacksize(&attr, 64 * 1024);
    g_pump_done = 0;
    int rc = pthread_create(&g_thr, &attr, pump, NULL);
    pthread_attr_destroy(&attr);
    g_active = (rc == 0);
    if (g_active) hook_fatal_signals();
    return g_active;
}

static void set_env_int(const char *k, int v) {
    char buf[16];
    snprintf(buf, sizeof buf, "%d", v);
    setenv(k, buf, 1);
}

static void setup_pipe(void) {
    struct stat st;
    int p[2];
    if (fstat(1, &st) != 0 || pipe(p) != 0) return;
    int out = dup(1);
    if (out < 0) {
        close(p[0]);
        close(p[1]);
        return;
    }
    int both = same_file(1, 2);
    g_rfd = p[0];
    g_out = out;
    dup2(p[1], 1);
    if (both) dup2(p[1], 2);
    close(p[1]);
    if (!start_thread()) {
        dup2(out, 1);
        if (both) dup2(out, 2);
        close(p[0]);
        close(out);
        g_rfd = g_out = -1;
        return;
    }
    g_owner = getpid();
    set_env_int("RB_STAMP_PID", (int)getpid());
    set_env_int("RB_STAMP_RFD", g_rfd);
    set_env_int("RB_STAMP_OUT", g_out);
}

__attribute__((constructor)) static void rb_stamp_init(void) {
    const char *pid_s = getenv("RB_STAMP_PID");
    if (pid_s) {
        if (atoi(pid_s) != (int)getpid()) return;  // fork 자식
        // 못 가로챈 exec 뒤라 fd 1 이 아직 우리 pipe 면 상속받은 fd 로 스레드만 복구
        const char *r = getenv("RB_STAMP_RFD"), *o = getenv("RB_STAMP_OUT");
        if (r && o) {
            int rfd = atoi(r), out = atoi(o);
            if (fcntl(rfd, F_GETFD) >= 0 && fcntl(out, F_GETFD) >= 0 && same_file(1, rfd)) {
                g_rfd = rfd;
                g_out = out;
                g_owner = getpid();
                setvbuf(stdout, NULL, _IOLBF, 0);
                start_thread();
                return;
            }
        }
    } else {
        const char *id = getenv("RB_PLUGIN_ID");
        if (!id || !*id) return;
    }
    // 리다이렉트된 C stdio 는 전체 버퍼링 → 줄 단위로 (python 은 PYTHONUNBUFFERED=1)
    setvbuf(stdout, NULL, _IOLBF, 0);
    setup_pipe();
}

__attribute__((destructor)) static void rb_stamp_fini(void) {
    if (!g_active) return;
    fflush(stdout);
    restore_and_drain();
}

// exec 가로채기: 비우고 되돌린 뒤 진짜 exec. 실패하면 다시 세팅.
#define REAL(name, ...)                                                   \
    static int (*real_##name)(__VA_ARGS__);                               \
    if (!real_##name) real_##name = (int (*)(__VA_ARGS__))dlsym(RTLD_NEXT, #name);

static void pre_exec(void) {
    if (!g_active) return;
    fflush(stdout);
    restore_and_drain();
}

static void post_exec_failed(void) {
    int saved = errno;
    if (g_rfd >= 0 && getpid() == g_owner) {
        close(g_rfd);
        close(g_out);
        g_rfd = g_out = -1;
        setup_pipe();
    }
    errno = saved;
}

int execve(const char *path, char *const argv[], char *const envp[]) {
    REAL(execve, const char *, char *const[], char *const[]);
    pre_exec();
    int rc = real_execve(path, argv, envp);
    post_exec_failed();
    return rc;
}

int execv(const char *path, char *const argv[]) {
    REAL(execv, const char *, char *const[]);
    pre_exec();
    int rc = real_execv(path, argv);
    post_exec_failed();
    return rc;
}

int execvp(const char *file, char *const argv[]) {
    REAL(execvp, const char *, char *const[]);
    pre_exec();
    int rc = real_execvp(file, argv);
    post_exec_failed();
    return rc;
}

int execvpe(const char *file, char *const argv[], char *const envp[]) {
    REAL(execvpe, const char *, char *const[], char *const[]);
    pre_exec();
    int rc = real_execvpe(file, argv, envp);
    post_exec_failed();
    return rc;
}
