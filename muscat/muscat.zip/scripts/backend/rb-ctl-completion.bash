# 플러그인 로그 디렉터리의 *.log 에서 플러그인 id 목록을 뽑는다
_rb_ctl_plugin_ids() {
  local dir="${RB_LOG_PLUGINS_DIR:-/app/data/log/plugins}"
  [[ -d "$dir" ]] || return 0
  local f
  for f in "$dir"/*.log; do
    [[ -e "$f" ]] || continue
    f="${f##*/}"
    printf '%s\n' "${f%.log}"
  done
}

_rb_ctl_completions() {
  local cur prev
  cur="${COMP_WORDS[COMP_CWORD]}"
  prev="${COMP_WORDS[COMP_CWORD-1]}"

  local commands="status ls logs logs-err logs-plugin start stop restart restart-all reload reload-env listen-endpoints exec help"

  case "$prev" in
    rb-ctl)
      COMPREPLY=($(compgen -W "$commands" -- "$cur"))
      return 0
      ;;
    logs)
      # logs 는 서비스 로그와 플러그인 로그를 모두 받는다
      local svcs plugins
      svcs=$(supervisorctl status 2>/dev/null | awk '{print $1}' | grep -v '^_' || true)
      plugins=$(_rb_ctl_plugin_ids)
      COMPREPLY=($(compgen -W "$svcs $plugins" -- "$cur"))
      return 0
      ;;
    logs-plugin)
      COMPREPLY=($(compgen -W "$(_rb_ctl_plugin_ids)" -- "$cur"))
      return 0
      ;;
    logs-err|start|stop|restart|exec)
      local svcs
      svcs=$(supervisorctl status 2>/dev/null | awk '{print $1}' | grep -v '^_' || true)
      COMPREPLY=($(compgen -W "$svcs" -- "$cur"))
      return 0
      ;;
    reload-env)
      COMPREPLY=($(compgen -W "auto docker supervisor services none --docker-restart --supervisor --services --no-restart" -- "$cur"))
      return 0
      ;;
    listen-endpoints)
      local svcs
      svcs=$(supervisorctl status 2>/dev/null | awk '{print $1}' | grep -v '^_' || true)
      COMPREPLY=($(compgen -W "common service $svcs" -- "$cur"))
      return 0
      ;;
    common|service|amr|log|manipulate|vision|rby1|accessory)
      if [[ "${COMP_WORDS[1]}" == "listen-endpoints" ]]; then
        COMPREPLY=($(compgen -W "list add remove clear" -- "$cur"))
      fi
      return 0
      ;;
  esac
}

complete -F _rb_ctl_completions rb-ctl
