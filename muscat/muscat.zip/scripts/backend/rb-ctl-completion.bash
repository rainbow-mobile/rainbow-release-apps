_rb_ctl_completions() {
  local cur prev
  cur="${COMP_WORDS[COMP_CWORD]}"
  prev="${COMP_WORDS[COMP_CWORD-1]}"

  local commands="status ls logs logs-err start stop restart restart-all reload reload-env listen-endpoints exec help"

  case "$prev" in
    rb-ctl)
      COMPREPLY=($(compgen -W "$commands" -- "$cur"))
      return 0
      ;;
    logs|logs-err|start|stop|restart|exec)
      local svcs
      svcs=$(supervisorctl status 2>/dev/null | awk '{print $1}' | grep -v '^_' || true)
      COMPREPLY=($(compgen -W "$svcs" -- "$cur"))
      return 0
      ;;
    reload-env)
      COMPREPLY=($(compgen -W "auto docker supervisor services none --docker-restart --supervisor --services --no-restart" -- "$cur"))
      return 0
      ;;
    listen-endpoints)
      local svcs
      svcs=$(supervisorctl status 2>/dev/null | awk '{print $1}' | grep -v '^_' || true)
      COMPREPLY=($(compgen -W "common service $svcs" -- "$cur"))
      return 0
      ;;
    common|service|amr|log|manipulate|vision|rby1|accessory)
      if [[ "${COMP_WORDS[1]}" == "listen-endpoints" ]]; then
        COMPREPLY=($(compgen -W "list add remove clear" -- "$cur"))
      fi
      return 0
      ;;
  esac
}

complete -F _rb_ctl_completions rb-ctl
