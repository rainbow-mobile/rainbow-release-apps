#!/bin/bash
# Muscat all-in-one runtime entrypoint.
# It starts infrastructure daemons and muscat services under one supervisord.

set -euo pipefail

if [[ "${1:-}" == "rb-runtime" ]]; then
  shift
  exec /usr/local/bin/rb-runtime "$@"
fi

if [[ $# -gt 0 ]]; then
  exec "$@"
fi

export RB_MODE="${RB_MODE:-prod}"
export RB_BIN_DIR="${RB_BIN_DIR:-/app/services}"

if [[ "$RB_MODE" == "dev" ]]; then
  umask 000
  # 내장 인프라가 127.0.0.1에 뜨므로 DEV URL을 localhost로 고정
  export MONGO_URI_DEV="${MONGO_URI_DEV:-mongodb://127.0.0.1:27017?replicaSet=rs0}"
  export INFLUXDB_URL_DEV="${INFLUXDB_URL_DEV:-http://127.0.0.1:8086}"
  export MQTT_HOST="${MQTT_HOST:-127.0.0.1}"
  # 서비스간 hostname 호출(common, manipulate 등)을 localhost로 resolve
  KNOWN_SERVICES=(common manipulate amr vision deploy log rby1 accessory)
  if ! grep -q "# muscat service aliases" /etc/hosts 2>/dev/null; then
    {
      echo ""
      echo "# muscat service aliases (added by runtime-entrypoint.sh)"
      for svc in "${KNOWN_SERVICES[@]}"; do
        echo "127.0.0.1 $svc"
      done
    } >> /etc/hosts 2>/dev/null || true
  fi
  # uv workspace 초기화 (volume mount된 소스 기준으로 venv 구성)
  DEV_BACKEND="${RB_DEV_BACKEND_DIR:-/app/backend}"
  if [[ -f "$DEV_BACKEND/pyproject.toml" ]]; then
    echo "ℹ️  uv sync 실행 중..."
    cd "$DEV_BACKEND" && uv sync --all-packages --frozen
    cd /
  fi
fi
export RB_LOG_MAX_MB="${RB_LOG_MAX_MB:-50}"
export RB_LOG_BACKUPS="${RB_LOG_BACKUPS:-5}"
export INFLUXDB_URL="${INFLUXDB_URL:-http://127.0.0.1:8086}"
export INFLUXDB_ORG="${INFLUXDB_ORG:-rrs}"
export INFLUXDB_BUCKET="${INFLUXDB_BUCKET:-rrs-rt}"
export INFLUXDB_USERNAME="${INFLUXDB_USERNAME:-rainbow}"
export INFLUXDB_PASSWORD_FILE="${INFLUXDB_PASSWORD_FILE:-/app/data/secrets/influxdb_password}"
export INFLUXDB_TOKEN_FILE="${INFLUXDB_TOKEN_FILE:-/app/data/secrets/influxdb_token}"
mkdir -p \
  /app/data/log/services \
  /app/data/mongo \
  /app/data/influxdb2 \
  /app/data/mosquitto \
  /app/data/media \
  /app/data/secrets

if [[ ! -f "$INFLUXDB_PASSWORD_FILE" ]]; then
  printf '%s' "${INFLUXDB_PASSWORD:-rainbow2011}" > "$INFLUXDB_PASSWORD_FILE"
fi

if [[ ! -f "$INFLUXDB_TOKEN_FILE" ]]; then
  if command -v openssl >/dev/null 2>&1; then
    openssl rand -hex 32 > "$INFLUXDB_TOKEN_FILE"
  else
    date +%s%N | sha256sum | cut -d' ' -f1 > "$INFLUXDB_TOKEN_FILE"
  fi
fi

echo "============================================================"
echo " muscat runtime starting"
echo "   RB_ENABLED_SERVICES = ${RB_ENABLED_SERVICES:-(auto-detect)}"
echo "   RB_BIN_DIR          = ${RB_BIN_DIR}"
echo "   data volume         = /app/data"
echo "============================================================"

/opt/rb-supervisor/generate-supervisor-conf.sh

if [[ "${RB_RUNTIME_ENABLE_MONGO:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/mongo.conf /etc/supervisor/conf.d/mongo.conf
  install -m 0644 /opt/rb-runtime-supervisor/mongo-init.conf /etc/supervisor/conf.d/mongo-init.conf
fi

if [[ "${RB_RUNTIME_ENABLE_INFLUXDB:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/influxdb.conf /etc/supervisor/conf.d/influxdb.conf
  install -m 0644 /opt/rb-runtime-supervisor/influxdb-init.conf /etc/supervisor/conf.d/influxdb-init.conf
fi

if [[ "$RB_MODE" == "prod" && "${RB_RUNTIME_ENABLE_ZENOH_BRIDGE:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/zenoh-bridge-jazzy.conf /etc/supervisor/conf.d/zenoh-bridge-jazzy.conf
  install -m 0644 /opt/rb-runtime-supervisor/zenoh-bridge-humble.conf /etc/supervisor/conf.d/zenoh-bridge-humble.conf
fi

if [[ "${RB_RUNTIME_ENABLE_MQTT:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/mqtt.conf /etc/supervisor/conf.d/mqtt.conf
fi

if [[ "${RB_RUNTIME_ENABLE_MEDIAMTX:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/mediamtx.conf /etc/supervisor/conf.d/mediamtx.conf
fi

if [[ "${RB_RUNTIME_ENABLE_NGINX:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/nginx.conf /etc/supervisor/conf.d/nginx.conf
  install -m 0644 /opt/rb-runtime-supervisor/nginx-watchdog.conf /etc/supervisor/conf.d/nginx-watchdog.conf
fi

exec /usr/bin/supervisord -c /etc/supervisor/supervisord.conf
