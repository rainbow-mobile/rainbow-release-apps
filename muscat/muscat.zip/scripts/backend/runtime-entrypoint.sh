#!/bin/bash
# Muscat all-in-one runtime entrypoint.
# It starts infrastructure daemons and muscat services under one supervisord.

set -euo pipefail

ENV_HELPER="/opt/rb-supervisor/muscat-env.sh"
if [[ -f "$ENV_HELPER" ]]; then
  # shellcheck disable=SC1090
  source "$ENV_HELPER"
  if muscat_source_env_file; then
    echo "ℹ️  muscat env applied: $(muscat_env_file)"
  fi
fi

if [[ "${1:-}" == "rb-runtime" ]]; then
  shift
  exec /usr/local/bin/rb-runtime "$@"
fi

if [[ $# -gt 0 ]]; then
  exec "$@"
fi

export RB_MODE="${RB_MODE:-prod}"
export RB_BIN_DIR="${RB_BIN_DIR:-/app/services}"

if [[ "$RB_MODE" == "dev" ]]; then
  umask 000
  # 내장 인프라가 127.0.0.1에 뜨므로 DEV URL을 localhost로 고정
  export MONGO_URI_DEV="${MONGO_URI_DEV:-mongodb://127.0.0.1:27017?replicaSet=rs0}"
  export INFLUXDB_URL_DEV="${INFLUXDB_URL_DEV:-http://127.0.0.1:8086}"
  export MQTT_HOST="${MQTT_HOST:-127.0.0.1}"
  # 서비스간 hostname 호출(common, manipulate 등)을 localhost로 resolve
  KNOWN_SERVICES=(common manipulate amr vision log rby1 accessory)
  if ! grep -q "# muscat service aliases" /etc/hosts 2>/dev/null; then
    {
      echo ""
      echo "# muscat service aliases (added by runtime-entrypoint.sh)"
      for svc in "${KNOWN_SERVICES[@]}"; do
        echo "127.0.0.1 $svc"
      done
    } >> /etc/hosts 2>/dev/null || true
  fi
  # uv workspace 초기화 (volume mount된 소스 기준으로 venv 구성)
  DEV_BACKEND="${RB_DEV_BACKEND_DIR:-/app/backend}"
  if [[ -f "$DEV_BACKEND/pyproject.toml" ]]; then
    echo "ℹ️  uv sync 실행 중..."
    cd "$DEV_BACKEND" && uv sync --all-packages --frozen
    cd /
  fi
fi
# 암호화 전용 모드: 평문 리스너를 127.0.0.1 로만 연다. 나머지는 각자 RB_TLS_ONLY 를 읽고, mediamtx·influxd 만 env 로 준다.
if [[ "${RB_TLS_ONLY:-0}" == "1" ]]; then
  export MTX_RTSPADDRESS=127.0.0.1:8554 MTX_WEBRTCADDRESS=127.0.0.1:8889
  export MTX_APIADDRESS=127.0.0.1:9997 MTX_METRICSADDRESS=127.0.0.1:9998
  export INFLUXD_HTTP_BIND_ADDRESS=127.0.0.1:8086
fi
export RB_LOG_MAX_MB="${RB_LOG_MAX_MB:-50}"
export RB_LOG_BACKUPS="${RB_LOG_BACKUPS:-5}"
export RB_PLUGIN_GATEWAY_PORT="${RB_PLUGIN_GATEWAY_PORT:-10000}"
export INFLUXDB_URL="${INFLUXDB_URL:-http://127.0.0.1:8086}"
export INFLUXDB_ORG="${INFLUXDB_ORG:-rrs}"
export INFLUXDB_BUCKET="${INFLUXDB_BUCKET:-rrs-rt}"
export INFLUXDB_USERNAME="${INFLUXDB_USERNAME:-rainbow}"
export INFLUXDB_PASSWORD="${INFLUXDB_PASSWORD:-rainbow123}"
# 기본은 고정 토큰. common 의 DB 계정 설정(POST /db/credentials)이 토큰을 교체하면
# /app/data/.env.muscat 의 INFLUXDB_TOKEN 이 우선한다.
export INFLUXDB_TOKEN="${INFLUXDB_TOKEN:-rainbowInfluxToken}"
mkdir -p \
  /app/data/log/services \
  /app/data/mongo \
  /app/data/influxdb2 \
  /app/data/mosquitto \
  /app/data/media \
  /app/data/secrets

echo "============================================================"
echo " muscat runtime starting"
echo "   RB_ENABLED_SERVICES = ${RB_ENABLED_SERVICES:-(auto-detect)}"
echo "   RB_BIN_DIR          = ${RB_BIN_DIR}"
echo "   data volume         = /app/data"
echo "============================================================"

/opt/rb-supervisor/generate-supervisor-conf.sh

if [[ "${RB_RUNTIME_ENABLE_MONGO:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/mongo.conf /etc/supervisor/conf.d/mongo.conf
  install -m 0644 /opt/rb-runtime-supervisor/mongo-init.conf /etc/supervisor/conf.d/mongo-init.conf
fi

if [[ "${RB_RUNTIME_ENABLE_INFLUXDB:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/influxdb.conf /etc/supervisor/conf.d/influxdb.conf
  install -m 0644 /opt/rb-runtime-supervisor/influxdb-init.conf /etc/supervisor/conf.d/influxdb-init.conf
fi

if [[ "$RB_MODE" == "prod" && "${RB_RUNTIME_ENABLE_ZENOH_BRIDGE:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/zenoh-bridge-jazzy.conf /etc/supervisor/conf.d/zenoh-bridge-jazzy.conf
  install -m 0644 /opt/rb-runtime-supervisor/zenoh-bridge-humble.conf /etc/supervisor/conf.d/zenoh-bridge-humble.conf
fi

if [[ "${RB_RUNTIME_ENABLE_MQTT:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/mqtt.conf /etc/supervisor/conf.d/mqtt.conf
fi

if [[ "${RB_RUNTIME_ENABLE_PLUGIN_GATEWAY:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/plugin-socketio.conf /etc/supervisor/conf.d/plugin-socketio.conf
fi

if [[ "${RB_RUNTIME_ENABLE_MEDIAMTX:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/mediamtx.conf /etc/supervisor/conf.d/mediamtx.conf
fi

if [[ "${RB_RUNTIME_ENABLE_NGINX:-1}" == "1" ]]; then
  install -m 0644 /opt/rb-runtime-supervisor/nginx.conf /etc/supervisor/conf.d/nginx.conf
  install -m 0644 /opt/rb-runtime-supervisor/nginx-watchdog.conf /etc/supervisor/conf.d/nginx-watchdog.conf
fi

exec /usr/bin/supervisord -c /etc/supervisor/supervisord.conf
