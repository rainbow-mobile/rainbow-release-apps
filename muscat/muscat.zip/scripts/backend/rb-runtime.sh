#!/bin/bash
set -euo pipefail

RB_ROS_DISTRO="${RB_ROS_DISTRO:-${ROS_DISTRO:-jazzy}}"
RB_RUNTIME_ROOT="${RB_RUNTIME_ROOT:-${DATA_DIR:-/app/data}/runtime}"
RB_RUNTIME_VENV="${RB_RUNTIME_VENV:-${RB_RUNTIME_ROOT}/venv}"
RB_ROS_WS="${RB_ROS_WS:-${RB_RUNTIME_ROOT}/ros2_ws}"
RB_EXTENSIONS_DIR="${RB_EXTENSIONS_DIR:-${RB_RUNTIME_ROOT}/extensions}"
RB_EXTENSIONS_AVAILABLE_DIR="${RB_EXTENSIONS_AVAILABLE_DIR:-${RB_EXTENSIONS_DIR}/available}"
RB_EXTENSIONS_ENABLED_DIR="${RB_EXTENSIONS_ENABLED_DIR:-${RB_EXTENSIONS_DIR}/enabled}"
RB_RUNTIME_STATE_DIR="${RB_RUNTIME_STATE_DIR:-${RB_RUNTIME_ROOT}/state}"
RB_RUNTIME_LOG_DIR="${RB_RUNTIME_LOG_DIR:-${RB_RUNTIME_STATE_DIR}/logs}"
RB_RUNTIME_TMP_DIR="${RB_RUNTIME_TMP_DIR:-${RB_RUNTIME_ROOT}/tmp}"
RB_STORE_DIR="${RB_STORE_DIR:-${RB_RUNTIME_ROOT}/store}"
RB_ROS_AUTO_BUILD="${RB_ROS_AUTO_BUILD:-0}"
RB_EXTENSIONS_AUTOSTART="${RB_EXTENSIONS_AUTOSTART:-1}"

rb_runtime_usage() {
  cat <<'EOF'
사용법:
  rb-runtime prepare
  rb-runtime install <name> <source> [--enable] [--editable]
  rb-runtime enable <name>
  rb-runtime disable <name>
  rb-runtime list
  rb-runtime build-workspace
  rb-runtime start
  rb-runtime run-with-extensions -- <cmd> [args...]
  rb-runtime print-env
  rb-runtime shell

개념:
  - install: 확장 소스를 영속 디렉토리에 적재합니다.
  - enable: 확장을 Python/ROS2 런타임 경로에 연결합니다.
  - start: enabled 확장의 start.sh 또는 extension.env의 시작 명령을 실행합니다.
EOF
}

rb_runtime_log() {
  printf '[rb-runtime] %s\n' "$*"
}

rb_runtime_warn() {
  printf '[rb-runtime] 경고: %s\n' "$*" >&2
}

# uname -m (x86_64/aarch64) → Docker 표준 arch 이름 (amd64/arm64)
rb_runtime_arch() {
  local m
  m="$(uname -m)"
  case "$m" in
    x86_64)  echo "amd64" ;;
    aarch64) echo "arm64" ;;
    *)       echo "$m"    ;;
  esac
}

rb_runtime_init_dirs() {
  mkdir -p \
    "$RB_RUNTIME_ROOT" \
    "$RB_ROS_WS/src" \
    "$RB_EXTENSIONS_AVAILABLE_DIR" \
    "$RB_EXTENSIONS_ENABLED_DIR" \
    "$RB_RUNTIME_STATE_DIR" \
    "$RB_RUNTIME_LOG_DIR" \
    "$RB_RUNTIME_TMP_DIR" \
    "${RB_STORE_DIR}/py"
}

rb_runtime_ros_setup_path() {
  local setup="/opt/ros/${RB_ROS_DISTRO}/setup.bash"
  if [[ -f "$setup" ]]; then
    printf '%s\n' "$setup"
  fi
}

rb_runtime_source_ros() {
  local ros_setup
  local restore_nounset=0

  if [[ $- == *u* ]]; then
    restore_nounset=1
    set +u
  fi

  ros_setup="$(rb_runtime_ros_setup_path || true)"
  if [[ -n "$ros_setup" ]]; then
    # shellcheck disable=SC1090
    source "$ros_setup"
  fi

  if [[ -f "${RB_ROS_WS}/install/setup.bash" ]]; then
    # shellcheck disable=SC1091
    source "${RB_ROS_WS}/install/setup.bash"
  elif [[ -f "${RB_ROS_WS}/install/local_setup.bash" ]]; then
    # shellcheck disable=SC1091
    source "${RB_ROS_WS}/install/local_setup.bash"
  fi

  if (( restore_nounset )); then
    set -u
  fi
}

rb_runtime_ensure_venv() {
  if [[ ! -x "${RB_RUNTIME_VENV}/bin/python" ]]; then
    python3 -m venv --system-site-packages "$RB_RUNTIME_VENV"
    "$RB_RUNTIME_VENV/bin/python" -m pip install --upgrade pip setuptools wheel >/dev/null
  fi
}

rb_runtime_collect_python_paths() {
  local -a paths=()
  local target

  rb_runtime_ensure_venv
  # ponytail: 공유 runtime venv(site-packages)는 PYTHONPATH에 넣지 않는다.
  # PYTHONPATH는 각 프로세스 venv의 site-packages보다 앞서므로, 여기 넣으면
  # runtime venv의 fastapi/pydantic 등이 백엔드 .venv 의 pin 버전을 shadow 한다
  # (Swagger 파일 업로드 picker 깨짐 등). 플러그인 python 백엔드는 runtime venv
  # python 을 직접 실행(--system-site-packages)하므로 이 주입 없이도 패키지를 본다.
  # 확장 소스 경로만 주입한다.

  shopt -s nullglob
  for target in "$RB_EXTENSIONS_ENABLED_DIR"/*; do
    [[ -e "$target" ]] || continue
    target="$(cd "$target" 2>/dev/null && pwd -P)"
    [[ -n "$target" ]] || continue

    [[ -d "$target" ]] && paths+=("$target")
    [[ -d "$target/src" ]] && paths+=("$target/src")
    [[ -d "$target/python" ]] && paths+=("$target/python")

    while IFS= read -r site_dir; do
      [[ -d "$site_dir" ]] && paths+=("$site_dir")
    done < <(find "$target" -type d -path '*/site-packages' 2>/dev/null | sort -u)
  done
  shopt -u nullglob

  printf '%s\n' "${paths[@]}" | awk 'NF && !seen[$0]++'
}

rb_runtime_export_pythonpath() {
  local joined=""
  local path
  while IFS= read -r path; do
    [[ -n "$path" ]] || continue
    if [[ -z "$joined" ]]; then
      joined="$path"
    else
      joined="${joined}:$path"
    fi
  done < <(rb_runtime_collect_python_paths)

  if [[ -n "$joined" ]]; then
    export PYTHONPATH="$joined${PYTHONPATH:+:${PYTHONPATH}}"
  fi
}

rb_runtime_workspace_has_sources() {
  find "${RB_ROS_WS}/src" -mindepth 1 -maxdepth 3 \( -name package.xml -o -name setup.py -o -name pyproject.toml \) -print -quit 2>/dev/null | grep -q .
}

rb_runtime_workspace_needs_build() {
  local stamp="${RB_RUNTIME_STATE_DIR}/workspace.build.stamp"

  if [[ ! -f "${RB_ROS_WS}/install/setup.bash" && ! -f "${RB_ROS_WS}/install/local_setup.bash" ]]; then
    return 0
  fi

  if [[ ! -f "$stamp" ]]; then
    return 0
  fi

  find "${RB_ROS_WS}/src" -type f \( -name '*.py' -o -name '*.xml' -o -name '*.yaml' -o -name '*.yml' -o -name '*.launch.py' -o -name 'package.xml' -o -name 'setup.py' -o -name 'pyproject.toml' -o -name 'CMakeLists.txt' \) -newer "$stamp" -print -quit 2>/dev/null | grep -q .
}

rb_runtime_build_workspace() {
  rb_runtime_init_dirs

  if ! command -v colcon >/dev/null 2>&1; then
    rb_runtime_warn "colcon이 없어 ROS2 워크스페이스를 빌드할 수 없습니다."
    return 1
  fi

  if ! rb_runtime_workspace_has_sources; then
    rb_runtime_log "빌드할 ROS2 소스가 없어 워크스페이스 빌드를 건너뜁니다."
    return 0
  fi

  rb_runtime_source_ros
  rb_runtime_export_pythonpath

  rb_runtime_log "ROS2 워크스페이스 빌드를 시작합니다: ${RB_ROS_WS}"
  (
    cd "$RB_ROS_WS"
    colcon build --merge-install --symlink-install --base-paths src
  )
  touch "${RB_RUNTIME_STATE_DIR}/workspace.build.stamp"
}

rb_runtime_prepare() {
  rb_runtime_init_dirs
  rb_runtime_ensure_venv
  rb_runtime_source_ros
  rb_runtime_export_pythonpath
  export PATH="${RB_RUNTIME_VENV}/bin:${PATH}"

  if [[ "$RB_ROS_AUTO_BUILD" == "1" ]] && rb_runtime_workspace_has_sources; then
    if rb_runtime_workspace_needs_build; then
      rb_runtime_build_workspace
      rb_runtime_source_ros
    fi
  fi
}

rb_runtime_copy_source() {
  local source="$1"
  local destination="$2"

  rm -rf "$destination"
  mkdir -p "$destination"

  case "$source" in
    http://*|https://*|git@*|ssh://*)
      git clone --depth 1 "$source" "$destination"
      ;;
    *.tar.gz|*.tgz)
      tar -xzf "$source" -C "$destination" --strip-components=1
      ;;
    *.tar)
      tar -xf "$source" -C "$destination" --strip-components=1
      ;;
    *.zip)
      unzip -q "$source" -d "$destination"
      local entries
      entries="$(find "$destination" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')"
      if [[ "$entries" == "1" ]] && [[ -z "$(find "$destination" -mindepth 1 -maxdepth 1 -type f -print -quit)" ]]; then
        local inner
        inner="$(find "$destination" -mindepth 1 -maxdepth 1 -type d -print -quit)"
        if [[ -n "$inner" ]] && [[ "$(basename "$inner")" != "dist" ]]; then
          find "$inner" -mindepth 1 -maxdepth 1 -exec mv {} "$destination"/ \;
          rmdir "$inner"
        fi
      fi
      ;;
    *)
      if [[ -d "$source" ]]; then
        cp -R "$source"/. "$destination"/
      else
        rb_runtime_warn "지원하지 않는 source 형식입니다: $source"
        return 1
      fi
      ;;
  esac
}

# wheel 파일명의 platform tag(마지막 필드)가 현재 머신 arch와 호환되는지 확인.
# "any"(순수 python)는 항상 호환. 그 외에는 arch별 manylinux/linux 태그 문자열 포함 여부로 판단.
rb_runtime_wheel_matches_arch() {
  local basename="$1" arch="$2"
  local platform_tag
  platform_tag="$(echo "$basename" | awk -F'-' '{print $NF}')"
  # 정확히 일치해야 함: *any* 글롭은 "manylinux"("m-any-linux")에도 false-match 된다.
  if [[ "$platform_tag" == "any" ]]; then
    return 0
  fi
  case "$arch" in
    amd64)
      if [[ "$platform_tag" == *x86_64* ]]; then return 0; else return 1; fi
      ;;
    arm64)
      if [[ "$platform_tag" == *aarch64* || "$platform_tag" == *arm64* ]]; then return 0; else return 1; fi
      ;;
    *)
      return 0  # 알 수 없는 arch면 필터링 없이 통과(기존 동작 유지)
      ;;
  esac
}

# dist/wheels/ 안의 휠들을 공유 store에 언팩한 뒤, dist/requirements.lock을 작성하고 dist/wheels/를 삭제한다.
# store 경로: ${RB_STORE_DIR}/py/{name_norm}/{version}/{arch}/
# arch 세그먼트가 없으면 플랫폼이 다른 wheel(예: arm64로 빌드된 numpy)이 x86_64 로봇에서도
# "이미 존재"로 오인되어 재사용되며 ImportError를 낸다 (aarch64 .so를 x86_64 python이 로드 시도).
# "Both(fat ZIP)" 빌드는 dist/wheels/에 amd64+arm64 wheel이 한 폴더에 같이 들어오므로,
# platform tag가 현재 머신과 안 맞는 wheel은 언팩하지 않고 건너뛴다(마지막에 wheels_dir 통째로 삭제됨).
rb_runtime_unpack_to_store() {
  local extension_dir="$1"
  local wheels_dir="${extension_dir}/dist/wheels"
  local lock_file="${extension_dir}/dist/requirements.lock"

  [[ -d "$wheels_dir" ]] || return 0

  local arch
  arch="$(rb_runtime_arch)"

  local wheel_file name_raw name_norm version store_entry basename
  local -a lock_lines=()

  shopt -s nullglob
  for wheel_file in "${wheels_dir}"/*.whl; do
    # 파일명 형식: {name}-{version}-{python}-{abi}-{platform}.whl
    basename="$(basename "$wheel_file" .whl)"

    if ! rb_runtime_wheel_matches_arch "$basename" "$arch"; then
      rb_runtime_log "store 스킵 (arch 불일치): $(basename "$wheel_file")"
      continue
    fi

    name_raw="$(echo "$basename" | cut -d'-' -f1)"
    version="$(echo "$basename" | cut -d'-' -f2)"
    name_norm="${name_raw//-/_}"

    store_entry="${RB_STORE_DIR}/py/${name_norm}/${version}/${arch}"
    if [[ -d "$store_entry" ]]; then
      rb_runtime_log "store 이미 존재: ${name_norm}==${version} (${arch})"
    else
      mkdir -p "$store_entry"
      python3 -m zipfile -e "$wheel_file" "$store_entry" 2>/dev/null || {
        # zipfile 모듈이 없으면 unzip 폴백
        unzip -q "$wheel_file" -d "$store_entry"
      }
      rb_runtime_log "store 언팩 완료: ${name_norm}==${version}"
    fi
    lock_lines+=("${name_norm}==${version}")
  done
  shopt -u nullglob

  if [[ ${#lock_lines[@]} -gt 0 ]]; then
    printf '%s\n' "${lock_lines[@]}" > "$lock_file"
    rb_runtime_log "requirements.lock 작성: $(wc -l < "$lock_file")개 패키지"
  fi

  rm -rf "$wheels_dir"
  rb_runtime_log "dist/wheels/ 정리 완료 (store로 이전됨)"
}

rb_runtime_chmod_cpp_binary() {
  local extension_dir="$1"
  local arch
  arch="$(rb_runtime_arch)"
  local arch_bin="${extension_dir}/dist/${arch}"
  local legacy_bin="${extension_dir}/dist"

  if [[ -d "$arch_bin" ]]; then
    find "$arch_bin" -maxdepth 1 -type f -exec chmod +x {} \;
  else
    find "$legacy_bin" -maxdepth 1 -type f \( -not -name "*.json" -not -name "*.txt" -not -name "*.yaml" -not -name "*.yml" \) -exec chmod +x {} \; 2>/dev/null || true
  fi
}

# 설치 후 이 로봇 arch에 맞지 않는 바이너리/ros2_ws를 정리한다.
rb_runtime_cleanup_other_arch() {
  local extension_dir="$1"
  local manifest="${extension_dir}/dist/manifest.json"
  [[ -f "$manifest" ]] || return 0

  local runtime_type ros_client
  runtime_type="$(python3 -c "import json; d=json.load(open('$manifest')); print(d.get('runtime',{}).get('type',''))" 2>/dev/null || true)"
  ros_client="$(python3 -c "import json; d=json.load(open('$manifest')); print(d.get('runtime',{}).get('rosClient',''))" 2>/dev/null || true)"

  local arch other_arch
  arch="$(rb_runtime_arch)"
  case "$arch" in
    amd64) other_arch="arm64" ;;
    arm64) other_arch="amd64" ;;
    *)     return 0 ;;
  esac

  if [[ "$runtime_type" == "cpp" ]]; then
    local other_dir="${extension_dir}/dist/${other_arch}"
    if [[ -d "$other_dir" ]]; then
      rm -rf "$other_dir"
      rb_runtime_log "다른 arch 바이너리 정리: dist/${other_arch}/"
    fi
  fi

  if [[ "$runtime_type" == "ros2" && "$ros_client" == "rclcpp" ]]; then
    local other_install="${extension_dir}/dist/ros2_ws/install-${other_arch}"
    if [[ -d "$other_install" ]]; then
      rm -rf "$other_install"
      rb_runtime_log "다른 arch ros2_ws 정리: dist/ros2_ws/install-${other_arch}/"
    fi
  fi
}

rb_runtime_install_python_bits() {
  local extension_dir="$1"
  local editable_mode="$2"

  rb_runtime_ensure_venv

  # dist/wheels/ 가 있으면 공유 store로 언팩 (pip 없이)
  if [[ -d "${extension_dir}/dist/wheels" ]]; then
    rb_runtime_unpack_to_store "$extension_dir"
  elif [[ -f "${extension_dir}/requirements.txt" ]]; then
    rb_runtime_log "requirements.txt를 영속 venv에 설치합니다."
    "$RB_RUNTIME_VENV/bin/pip" install -r "${extension_dir}/requirements.txt"
  fi

  if [[ "$editable_mode" == "1" ]]; then
    if [[ -f "${extension_dir}/pyproject.toml" || -f "${extension_dir}/setup.py" ]]; then
      rb_runtime_log "확장을 editable 모드로 영속 venv에 설치합니다."
      "$RB_RUNTIME_VENV/bin/pip" install --editable "$extension_dir"
    else
      rb_runtime_warn "editable 설치 조건(pyproject.toml/setup.py)이 없어 건너뜁니다."
    fi
  fi
}

rb_runtime_link_extension_workspace() {
  local name="$1"
  local extension_dir="$2"
  local workspace_link_root="${RB_ROS_WS}/src/extensions"

  mkdir -p "$workspace_link_root"
  rm -f "${workspace_link_root}/${name}"

  if [[ -d "${extension_dir}/ros2_ws/src" ]]; then
    ln -sfn "${extension_dir}/ros2_ws/src" "${workspace_link_root}/${name}"
    return 0
  fi

  if [[ -f "${extension_dir}/package.xml" || -f "${extension_dir}/setup.py" || -f "${extension_dir}/pyproject.toml" ]]; then
    ln -sfn "$extension_dir" "${workspace_link_root}/${name}"
    return 0
  fi

  if find "$extension_dir" -mindepth 1 -maxdepth 3 -name package.xml -print -quit 2>/dev/null | grep -q .; then
    ln -sfn "$extension_dir" "${workspace_link_root}/${name}"
  fi
}

rb_runtime_install_extension() {
  local name="$1"
  local source="$2"
  shift 2
  local enable_mode=0
  local editable_mode=0
  local extension_dir="${RB_EXTENSIONS_AVAILABLE_DIR}/${name}"
  local staging_dir="${RB_RUNTIME_TMP_DIR}/install-${name}-$$"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --enable)
        enable_mode=1
        ;;
      --editable)
        editable_mode=1
        ;;
      *)
        rb_runtime_warn "알 수 없는 install 옵션: $1"
        return 1
        ;;
    esac
    shift
  done

  rb_runtime_init_dirs
  rm -rf "$staging_dir"
  rb_runtime_copy_source "$source" "$staging_dir"

  rm -rf "$extension_dir"
  mv "$staging_dir" "$extension_dir"

  rb_runtime_install_python_bits "$extension_dir" "$editable_mode"
  rb_runtime_cleanup_other_arch "$extension_dir"

  if [[ "$enable_mode" == "1" ]]; then
    rb_runtime_enable_extension "$name"
  fi

  rb_runtime_log "확장 설치 완료: ${name} -> ${extension_dir}"
}

rb_runtime_enable_extension() {
  local name="$1"
  local extension_dir="${RB_EXTENSIONS_AVAILABLE_DIR}/${name}"

  if [[ ! -d "$extension_dir" ]]; then
    rb_runtime_warn "설치된 확장이 없습니다: $name"
    return 1
  fi

  rb_runtime_init_dirs
  ln -sfn "$extension_dir" "${RB_EXTENSIONS_ENABLED_DIR}/${name}"
  rb_runtime_link_extension_workspace "$name" "$extension_dir"
  rb_runtime_log "확장 활성화 완료: $name"
}

rb_runtime_disable_extension() {
  local name="$1"
  rm -f "${RB_EXTENSIONS_ENABLED_DIR}/${name}"
  rm -f "${RB_ROS_WS}/src/extensions/${name}"
  rb_runtime_log "확장 비활성화 완료: $name"
}

rb_runtime_list_extensions() {
  local name
  local status
  shopt -s nullglob
  for path in "$RB_EXTENSIONS_AVAILABLE_DIR"/*; do
    [[ -d "$path" ]] || continue
    name="$(basename "$path")"
    status="installed"
    if [[ -e "${RB_EXTENSIONS_ENABLED_DIR}/${name}" ]]; then
      status="enabled"
    fi
    printf '%s\t%s\n' "$name" "$status"
  done
  shopt -u nullglob
}

rb_runtime_start_extensions_once() {
  local -n _pids_ref=$1
  local target
  local name
  local log_file
  local start_cmd

  if [[ "$RB_EXTENSIONS_AUTOSTART" != "1" ]]; then
    rb_runtime_log "RB_EXTENSIONS_AUTOSTART=0 이므로 확장 시작을 건너뜁니다."
    return 0
  fi

  shopt -s nullglob
  for target in "$RB_EXTENSIONS_ENABLED_DIR"/*; do
    [[ -e "$target" ]] || continue
    name="$(basename "$target")"
    target="$(cd "$target" 2>/dev/null && pwd -P)"
    [[ -n "$target" ]] || continue

    unset RB_EXTENSION_START_CMD
    if [[ -f "${target}/extension.env" ]]; then
      # shellcheck disable=SC1090
      source "${target}/extension.env"
    fi

    start_cmd="${RB_EXTENSION_START_CMD:-}"
    log_file="${RB_RUNTIME_LOG_DIR}/${name}.log"

    if [[ -x "${target}/start.sh" ]]; then
      rb_runtime_log "확장 시작: ${name} (start.sh)"
      (
        cd "$target"
        exec bash "${target}/start.sh"
      ) >>"$log_file" 2>&1 &
      _pids_ref+=("$!")
      continue
    fi

    if [[ -n "$start_cmd" ]]; then
      rb_runtime_log "확장 시작: ${name} (extension.env)"
      (
        cd "$target"
        exec bash -lc "$start_cmd"
      ) >>"$log_file" 2>&1 &
      _pids_ref+=("$!")
      continue
    fi

  done
  shopt -u nullglob
}

rb_runtime_cleanup_pids() {
  local -a pids=("$@")
  local pid
  for pid in "${pids[@]}"; do
    if [[ -n "$pid" ]] && kill -0 "$pid" >/dev/null 2>&1; then
      kill "$pid" >/dev/null 2>&1 || true
      wait "$pid" 2>/dev/null || true
    fi
  done
}

rb_runtime_start_extensions_forever() {
  local -a extension_pids=()
  rb_runtime_prepare
  rb_runtime_start_extensions_once extension_pids

  trap 'rb_runtime_cleanup_pids "${extension_pids[@]-}"' EXIT INT TERM

  if [[ ${#extension_pids[@]} -eq 0 ]]; then
    rb_runtime_log "시작된 확장이 없습니다."
    return 0
  fi

  set +e
  wait "${extension_pids[@]}"
  local status=$?
  set -e
  return "$status"
}

rb_runtime_run_with_extensions() {
  if [[ $# -eq 0 ]]; then
    rb_runtime_warn "run-with-extensions 뒤에는 실행할 명령이 필요합니다."
    return 1
  fi

  rb_runtime_prepare

  local -a extension_pids=()
  rb_runtime_start_extensions_once extension_pids

  # main_pid 는 local 인데 cleanup trap 이 함수 종료 후에도 EXIT 로 트리거될 수 있다.
  # 그 시점엔 local 변수가 unset 이므로 set -u 환경에서 unbound 가 난다.
  # ${var-} 패턴으로 unbound 안전, 그리고 함수 종료 직전 trap 을 해제한다.
  local main_pid=""

  "$@" &
  main_pid=$!

  cleanup() {
    rb_runtime_cleanup_pids "${main_pid-}" "${extension_pids[@]-}"
  }

  trap cleanup EXIT INT TERM

  set +e
  wait "$main_pid"
  local status=$?
  set -e

  # 정상 종료 경로 — trap 해제하여 함수 외부 EXIT 에서 cleanup 재호출되지 않게 한다
  trap - EXIT INT TERM

  rb_runtime_cleanup_pids "${extension_pids[@]-}"
  return "$status"
}

rb_runtime_print_env() {
  rb_runtime_prepare
  cat <<EOF
RB_ROS_DISTRO=${RB_ROS_DISTRO}
RB_RUNTIME_ROOT=${RB_RUNTIME_ROOT}
RB_RUNTIME_VENV=${RB_RUNTIME_VENV}
RB_ROS_WS=${RB_ROS_WS}
RB_EXTENSIONS_DIR=${RB_EXTENSIONS_DIR}
RB_RUNTIME_STATE_DIR=${RB_RUNTIME_STATE_DIR}
PYTHONPATH=${PYTHONPATH:-}
EOF
}

rb_runtime_shell() {
  rb_runtime_prepare
  exec bash
}

main() {
  local command="${1:-}"
  case "$command" in
    prepare)
      shift
      rb_runtime_prepare
      ;;
    install)
      shift
      [[ $# -ge 2 ]] || { rb_runtime_usage; exit 1; }
      rb_runtime_install_extension "$@"
      ;;
    enable)
      shift
      [[ $# -eq 1 ]] || { rb_runtime_usage; exit 1; }
      rb_runtime_enable_extension "$1"
      ;;
    disable)
      shift
      [[ $# -eq 1 ]] || { rb_runtime_usage; exit 1; }
      rb_runtime_disable_extension "$1"
      ;;
    list)
      shift
      rb_runtime_list_extensions
      ;;
    build-workspace)
      shift
      rb_runtime_build_workspace
      ;;
    start)
      shift
      rb_runtime_start_extensions_forever
      ;;
    run-with-extensions)
      shift
      if [[ "${1:-}" == "--" ]]; then
        shift
      fi
      rb_runtime_run_with_extensions "$@"
      ;;
    print-env)
      shift
      rb_runtime_print_env
      ;;
    shell)
      shift
      rb_runtime_shell
      ;;
    -h|--help|help|"")
      rb_runtime_usage
      ;;
    *)
      rb_runtime_warn "알 수 없는 명령: ${command}"
      rb_runtime_usage
      exit 1
      ;;
  esac
}

main "$@"
