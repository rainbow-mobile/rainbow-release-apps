import { defineConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";

import federation from "@originjs/vite-plugin-federation";
import react from "@vitejs/plugin-react";
import envCompatible from "vite-plugin-env-compatible";
import tailwindcss from "@tailwindcss/vite";
import { ViteSvgComponentPlugin } from "auto-svg-component-generator";
import { dependencies } from "./package.json";
// https://vite.dev/config/
export default defineConfig({
  build: {
    target: "esnext",
  },
  plugins: [
    react({
      jsxImportSource: "@emotion/react",
      babel: {
        plugins: ["@emotion/babel-plugin"],
      },
    }),
    tsconfigPaths(),
    envCompatible(),
    federation({
      name: "@app/rrs",
      filename: "remoteEntry.js",
      // Modules to expose
      exposes: {
        "./App": "./src/App.tsx",
      },
      shared: {
        react: {
          shareScope: "@app/shell",
          requiredVersion: dependencies.react,
        },
        "react-dom": {
          shareScope: "@app/shell",
          requiredVersion: dependencies.react,
        },
      },
    }),
    tailwindcss(),
    ViteSvgComponentPlugin({
      svgFileDir: "public/icons",
      outputDir: "src/assets/icons",
      typescript: true,
      svgo: {
        plugins: [
          "removeUselessDefs",
          {
            name: "preset-default",
            params: {
              overrides: {
                removeViewBox: false, // ✅ viewBox 유지
              },
            },
          },
          {
            name: "removeDimensions", // ✅ width, height 제거
          },
          {
            name: "addAttributesToSVGElement", // ✅ width, height 기본값 추가
            params: {
              attributes: [{ width: "1em" }, { height: "1em" }],
            },
          },
          {
            name: "convertColors",
            params: { currentColor: true }, // ✅ fill을 currentColor로 변경
          },
          {
            name: "convertStyleToAttrs", // ✅ CSS 스타일을 속성으로 변환
          },
        ],
      },
    }),
  ],
  server: {
    port: 5172,
    allowedHosts: true,
  },
  preview: {
    port: 5172,
  },
});
