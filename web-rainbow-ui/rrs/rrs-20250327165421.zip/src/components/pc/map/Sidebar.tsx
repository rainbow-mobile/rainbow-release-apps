import { ChipTab } from "@repo/rb-components";
import SidebarAnnotation from "./Sidebar.Annotation";
import { CloudDimension } from "@repo/rb-editor/interface";

interface EditorSidebarProps {
  onChangeAnnotationMode: () => void;
  onChangeCloudDimension: (dimension: CloudDimension) => void;
  onChangeCloudOpacity: (value: number) => void;
}
const EditorSidebar = ({
  onChangeAnnotationMode,
  onChangeCloudDimension,
  onChangeCloudOpacity,
}: EditorSidebarProps) => {
  const tabItems = [
    {
      children: (
        <SidebarAnnotation
          onChangeAnnotationMode={onChangeAnnotationMode}
          onChangeCloudDimension={onChangeCloudDimension}
          onChangeCloudOpacity={onChangeCloudOpacity}
        />
      ),
      disabled: false,
      isHide: false,
      key: "1",
      label: <div>Annotation</div>,
    },
    {
      children: (
        <div className="example-tab-content  _example-tab-content_ur71g_48">
          2 컨텐츠 입니다.
        </div>
      ),
      disabled: false,
      isHide: false,
      key: "2",
      label: <div>Map Edit</div>,
    },
  ];
  return (
    <div className="basis-1/5 h-full">
      <ChipTab tabItems={tabItems}></ChipTab>
    </div>
  );
};

export default EditorSidebar;
