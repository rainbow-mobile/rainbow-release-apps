import {
  Card,
  CardContent,
  CardDescription,
  // CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CloudDimension } from "@repo/rb-editor/interface";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";

interface SidebarAnnotationProps {
  onChangeAnnotationMode: () => void;
  onChangeCloudDimension: (dimension: CloudDimension) => void;
  onChangeCloudOpacity: (value: number) => void;
}
const SidebarAnnotation = ({
  onChangeAnnotationMode,
  onChangeCloudDimension,
  onChangeCloudOpacity,
}: SidebarAnnotationProps) => {
  return (
    <div className="flex flex-col justify-center align-middle gap-2">
      <Card className="w-[450px]">
        <CardHeader>
          <CardTitle>Add</CardTitle>
          <CardDescription>Add nodes and links</CardDescription>
          <div className="flex items-center gap-2">
            <Switch id="annotation-mode" onClick={onChangeAnnotationMode} />
            <Label htmlFor="annotation-mode">Annotation Mode </Label>
          </div>
        </CardHeader>
        <CardContent className="grid grid-cols-4 gap-3">
          <Button>Goal</Button>
          <Button>Route</Button>
          <Button>Init</Button>
          <Button>1 Link (l)</Button>
          <Button>1 R-Link</Button>
          <Button>2 Link (L)</Button>
        </CardContent>
      </Card>
      <Card className="w-[450px]">
        <CardHeader>
          <CardTitle>Cloud</CardTitle>
          <CardDescription>클라우드 데이터 조작</CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col gap-2">
          <div className="flex flex-col gap-2">
            <Label>Cloud Opacity</Label>
            <Slider
              defaultValue={[50]}
              max={100}
              min={1}
              step={1}
              onValueChange={(value) => {
                onChangeCloudOpacity(value[0]);
              }}
            />
          </div>

          <div className="grid grid-cols-4 gap-3">
            <Button
              onClick={() => {
                onChangeCloudDimension("2D");
              }}
            >
              평탄화
            </Button>
            <Button
              onClick={() => {
                onChangeCloudDimension("3D");
              }}
            >
              입체화
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default SidebarAnnotation;
