import { useEffect, useRef } from "react";
import { useEditor } from "@repo/rb-editor";
import { Viewport } from "@repo/rb-editor";

const CanvasWrapper = () => {
  const initialized = useRef<boolean>(false);
  const editor = useEditor();

  useEffect(() => {
    editor.initialize();
    const viewport = new Viewport(editor, "editor");

    editor.bootstrapper.register4RRSEvents();

    if (!initialized.current) {
      editor.bootstrapper.bootstrap4RRS();
      initialized.current = true;
    }

    return () => {
      editor.dispose();
      viewport.dispose();
    };
  }, [editor]);
  return <div id="editor-canvas__wrapper" className="h-full w-full" />;
};

export { CanvasWrapper };
