import React, { useRef } from "react";
import {
  Menubar,
  MenubarContent,
  MenubarItem,
  MenubarMenu,
  MenubarSeparator,
  MenubarTrigger,
} from "@/components/ui/menubar";

import { TopologyItem } from "@repo/rb-editor/interface";

interface EditorMenubarProps {
  onCloudFileParsed: (data: string[][]) => void;
  onTopoFileParsed: (data: TopologyItem[]) => void;
}

const EditorMenubar = ({
  onCloudFileParsed,
  onTopoFileParsed,
}: EditorMenubarProps) => {
  // 숨겨진 파일 입력 요소에 접근하기 위한 ref 생성
  const fileInputRefCloud = useRef<HTMLInputElement>(null);
  const fileInputRefTopo = useRef<HTMLInputElement>(null);

  // CSV 파일 선택 창 열기
  const onClickOpenCloud = () => {
    fileInputRefCloud.current?.click();
  };

  // JSON 파일 선택 창 열기
  const onClickOpenTopo = () => {
    fileInputRefTopo.current?.click();
  };

  // CSV 파일 선택 시 처리 핸들러
  const handleCloudFileChange = (
    event: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        try {
          const fileContent = _parseCSV(e.target.result as string);
          onCloudFileParsed(fileContent); // 파싱된 결과를 상위 컴포넌트로 전달
        } catch (error) {
          console.error(
            `Error occurred while loading CSV file: ${file.name}`,
            error,
          );
        }
      }
    };
    reader.readAsText(file);
  };

  // JSON 파일 선택 시 처리 핸들러
  const handleTopoFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      if (e.target?.result) {
        try {
          const fileContent = JSON.parse(e.target.result as string);
          onTopoFileParsed(fileContent); // 파싱된 결과를 상위 컴포넌트로 전달
        } catch (error) {
          console.error("Error occurred while loading the file:", error);
        }
      }
    };
    reader.readAsText(file);
  };

  // CSV 문자열을 2차원 배열로 파싱하는 유틸리티 함수
  const _parseCSV = (csvString: string): string[][] => {
    const rows = csvString.trim().split("\n");
    return rows.map((row) => row.split(",").map((value) => value.trim()));
  };

  return (
    <>
      {/* 숨겨진 파일 선택 input 요소들 */}
      <input
        ref={fileInputRefCloud}
        type="file"
        accept=".csv"
        style={{ display: "none" }}
        onChange={handleCloudFileChange}
      />
      <input
        ref={fileInputRefTopo}
        type="file"
        accept=".json"
        style={{ display: "none" }}
        onChange={handleTopoFileChange}
      />

      {/* 파일 열기 메뉴 UI */}
      <Menubar>
        <MenubarMenu>
          <MenubarTrigger>File</MenubarTrigger>
          <MenubarContent>
            <MenubarItem onClick={onClickOpenCloud}>Open Cloud</MenubarItem>
            <MenubarItem onClick={onClickOpenTopo}>Open Topology</MenubarItem>
            <MenubarSeparator />
          </MenubarContent>
        </MenubarMenu>
      </Menubar>
    </>
  );
};

export default EditorMenubar;
