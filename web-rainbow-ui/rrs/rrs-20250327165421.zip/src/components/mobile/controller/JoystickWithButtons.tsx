import styled from "@emotion/styled";
import { JoyStick, RbJoyStickEventData } from "@repo/rb-components";
import { useCheckDevice } from "@repo/rb-hooks";
import { cn } from "@repo/rb-utils/parserUtils";
import {
  ReactElement,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";

export type JoyStickSubButtonType = {
  key: string;
  element: ReactElement;
};

type Props = {
  className?: string;
  joystickType: "direction" | "curved";
  disableDiagonal?: boolean;
  buttonsDirection: "left" | "right";
  buttons?: JoyStickSubButtonType[];
  onJoystickMove?: (params: {
    type: "direction" | "curved";
    isMoving: boolean;
    data: RbJoyStickEventData;
  }) => void;
};

const JoystickWithButtons = ({
  className,
  joystickType,
  disableDiagonal,
  buttonsDirection,
  buttons,
  onJoystickMove,
}: Props) => {
  const btnGroupRef = useRef<HTMLDivElement>(null);
  const btnGroupItemsRef = useRef<(HTMLDivElement | null)[]>([]);

  const { isMobile, isSmallTablet } = useCheckDevice();

  const [isJoystickActive, setIsJoystickActive] = useState(false);

  const btnsStyles = useMemo(() => {
    const length = buttons?.length ?? 0;

    if (length >= 4) {
      return {
        oneObjectDeg: 35,
        initDeg: buttonsDirection === "left" ? -5 : 5,
      };
    } else if (length === 3) {
      return {
        oneObjectDeg: 40,
        initDeg: buttonsDirection === "left" ? 15 : -15,
      };
    } else {
      return {
        oneObjectDeg: 45,
        initDeg: buttonsDirection === "left" ? 25 : -25,
      };
    }
  }, [buttons?.length, buttonsDirection]);

  const joystickSize = useMemo(() => {
    if (isMobile) {
      return 70;
    } else if (isSmallTablet) {
      return 100;
    } else {
      return 130;
    }
  }, [isMobile, isSmallTablet]);

  const handleJoystickStart = (data: RbJoyStickEventData) => {
    setIsJoystickActive(true);

    onJoystickMove?.({ isMoving: true, type: joystickType, data });
  };

  const handleJoystickMove = (data: RbJoyStickEventData) => {
    console.log(data);

    onJoystickMove?.({ isMoving: true, type: joystickType, data });
  };

  const handleJoystickEnd = (data: RbJoyStickEventData) => {
    setIsJoystickActive(false);

    onJoystickMove?.({ isMoving: false, type: joystickType, data });
  };

  const handleCircleBtnsRender = useCallback(
    ({ oneObjectDeg, initDeg }: { oneObjectDeg: number; initDeg: number }) => {
      if (!btnGroupRef.current) return;

      const rect = btnGroupRef.current.getBoundingClientRect();
      const centerX = rect.width / 2; // 컨테이너 내부 중심 좌표
      const centerY = rect.height / 2;
      const radius = rect.width / 2; // 원 경계에서 살짝 안쪽

      buttons?.forEach((_, index) => {
        const btnGroupItem = btnGroupItemsRef.current[index];

        if (btnGroupItem) {
          // 버튼 초기 위치 설정 (12시보다 살짝 왼쪽에서 시작)
          const startAngle = (initDeg - 90) * (Math.PI / 180);
          const targetAngle =
            buttonsDirection === "left"
              ? (initDeg - 90 + index * oneObjectDeg) * (Math.PI / 180)
              : (initDeg - 90 - index * oneObjectDeg) * (Math.PI / 180);

          let currentAngle = startAngle;
          let opacity = 0.1; // 시작 시 투명
          let velocity = 0.06; // 부드러운 초반 가속
          const friction = 0.85; // 감속 계수 (너무 길어지지 않도록 안정화)
          const spring = 0.02; // 탄성 효과 (최소한만 적용, 너무 튀지 않음)

          // 초기 위치 설정
          const startX = centerX + Math.cos(startAngle) * radius;
          const startY = centerY + Math.sin(startAngle) * radius;

          btnGroupItem.style.position = "absolute";
          btnGroupItem.style.left = `${startX - btnGroupItem.clientWidth / 2}px`;
          btnGroupItem.style.top = `${startY - btnGroupItem.clientHeight / 2}px`;
          btnGroupItem.style.opacity = `${opacity}`;
          btnGroupItem.style.transform = `scale(0.98)`; // subtle한 크기 변화 적용

          // 부드럽고 절제된 애니메이션
          const animate = () => {
            const angleDiff = targetAngle - currentAngle;
            velocity += angleDiff * spring; // 탄성 효과 추가
            velocity *= friction; // 감속 효과 적용
            currentAngle += velocity; // 현재 각도 업데이트

            // opacity는 부드럽게 점진적으로 증가
            opacity += 0.03;
            opacity = Math.min(opacity, 1);

            // subtle한 크기 변화 (너무 출렁이지 않도록 최소한 적용)
            const scaleValue =
              0.98 + (1 - Math.abs(angleDiff) / Math.PI) * 0.02;

            const x = centerX + Math.cos(currentAngle) * radius;
            const y = centerY + Math.sin(currentAngle) * radius;

            btnGroupItem.style.left = `${x - btnGroupItem.clientWidth / 2}px`;
            btnGroupItem.style.top = `${y - btnGroupItem.clientHeight / 2}px`;
            btnGroupItem.style.opacity = `${opacity}`;
            btnGroupItem.style.transform = `scale(${scaleValue})`;

            if (Math.abs(angleDiff) > 0.002 || Math.abs(velocity) > 0.002) {
              requestAnimationFrame(animate);
            } else {
              btnGroupItem.style.opacity = "1";
              btnGroupItem.style.transform = `scale(1)`; // 최종적으로 안정화
            }
          };

          setTimeout(() => {
            requestAnimationFrame(animate);
          }, index * 60); // 촤라락 펼쳐지는 느낌을 위해 각 버튼마다 짧은 딜레이 추가
        }
      });
    },
    [buttons, buttonsDirection],
  );

  useEffect(() => {
    handleCircleBtnsRender(btnsStyles);
  }, [handleCircleBtnsRender, btnsStyles, joystickSize]);

  return (
    <JoystickWithButtonsStyle className={cn(className)}>
      <div className="inner">
        <div ref={btnGroupRef} className="btn-group">
          {buttons?.map((item, index) => (
            <div
              key={item.key}
              ref={(el) => {
                btnGroupItemsRef.current[index] = el;
              }}
              className={cn("btn-group-item", { disabled: isJoystickActive })}
            >
              {item.element}
            </div>
          ))}
        </div>
        <JoyStick
          className="joy-stick"
          type={joystickType}
          size={joystickSize}
          disableDiagonal={disableDiagonal}
          keepMoveEventInterval={200}
          onStart={handleJoystickStart}
          onMove={handleJoystickMove}
          onEnd={handleJoystickEnd}
        />
      </div>
    </JoystickWithButtonsStyle>
  );
};

const JoystickWithButtonsStyle = styled.div`
  .inner {
    position: relative;
    /* margin: 0 -0.8rem;
    margin-bottom: -0.8rem; */
    padding: 2.8rem;

    @media (min-width: 1024px) {
      padding: 3.8rem;
    }

    .btn-group {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      border-radius: 50%;
    }

    .btn-group-item {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
      width: 2.5rem;
      height: 2.5rem;
      min-width: 30px;
      min-height: 30px;
      padding: 0;
      opacity: 0;
      background-color: rgba(255, 255, 255, 0.1);
      border-radius: 50%;
      transition: opacity 0.05s ease-out;

      &.disabled {
        opacity: 0.2 !important;
        pointer-events: none;
      }

      > * {
        width: 100%;
        height: 100%;
      }
    }
  }

  .joy-stick {
    position: relative;
    z-index: 9;
  }
`;

export default JoystickWithButtons;
