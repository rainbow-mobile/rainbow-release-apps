import styled from "@emotion/styled";
import { HStack, RbJoyStickEventData } from "@repo/rb-components";
import { cn } from "@repo/rb-utils/parserUtils";
import JoystickWithButtons, {
  JoyStickSubButtonType,
} from "./JoystickWithButtons";

type JoyStickConfig = {
  joystickType: "direction" | "curved";
  disableDiagonal?: boolean;
  buttons: JoyStickSubButtonType[];
};

type Props = {
  className?: string;
  leftJoystickConfig?: JoyStickConfig;
  rightJoystickConfig?: JoyStickConfig;
  onJoystickMove?: (params: {
    isMoving: boolean;
    type: "direction" | "curved";
    data: RbJoyStickEventData;
  }) => void;
};

const MoveControlPannel = ({
  className,
  leftJoystickConfig,
  rightJoystickConfig,
  onJoystickMove,
}: Props) => {
  return (
    <MoveControlPannelStyle className={cn(className)}>
      <HStack justifyContent="space-between">
        <div>
          {!!leftJoystickConfig && (
            <JoystickWithButtons
              buttonsDirection="left"
              joystickType={leftJoystickConfig.joystickType}
              disableDiagonal={leftJoystickConfig.disableDiagonal}
              buttons={leftJoystickConfig.buttons}
              onJoystickMove={onJoystickMove}
            />
          )}
        </div>
        <div>
          {!!rightJoystickConfig && (
            <JoystickWithButtons
              buttonsDirection="right"
              joystickType={rightJoystickConfig.joystickType}
              disableDiagonal={rightJoystickConfig.disableDiagonal}
              buttons={rightJoystickConfig.buttons}
              onJoystickMove={onJoystickMove}
            />
          )}
        </div>
      </HStack>
    </MoveControlPannelStyle>
  );
};

const MoveControlPannelStyle = styled.div`
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 99;
  width: 100%;
`;

export default MoveControlPannel;
