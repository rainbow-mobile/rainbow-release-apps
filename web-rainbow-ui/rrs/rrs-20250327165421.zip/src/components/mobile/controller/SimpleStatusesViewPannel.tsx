import {
  SvgIcoConnect,
  SvgIcoFillPower2,
  SvgIcoSettingFill,
  SvgIcoUnconnect,
} from "@/assets/icons";
import styled from "@emotion/styled";
import {
  Battery,
  EmergencyButton,
  HStack,
  VStack,
  WhiteButton,
} from "@repo/rb-components";
import { useRbSubscribtion } from "@repo/rb-providers/RbSocketProvider";
import { cn } from "@repo/rb-utils/parserUtils";
import { isEqual } from "lodash";
import { useState } from "react";

type Props = {
  className?: string;
};

const SimpleStatusesViewPannel = ({ className }: Props) => {
  const [isConnected, setIsConnected] = useState(false);
  const [isOnPower, setIsOnPower] = useState(false);

  const { data: robotStatus } = useRbSubscribtion("programStatus", {
    equalityFn: (prev, next) => {
      const timeExcludedPrev = { ...prev };
      delete timeExcludedPrev.time;
      const timeExcludedNext = { ...next };
      delete timeExcludedNext.time;

      return isEqual(timeExcludedPrev, timeExcludedNext);
    },
  });

  return (
    <SimpleStatusesViewPannelStyle className={className}>
      <HStack className={cn("simple-statuses-view-pannel")} gap={8}>
        <WhiteButton className="btn-setting">
          <SvgIcoSettingFill />
        </WhiteButton>
        <HStack className="robot-status-area" alignItems="center" gap={8}>
          <HStack className="robot-status-inner" gap={6}>
            <span className={cn("status-connect", { connect: isConnected })}>
              {isConnected ? <SvgIcoConnect /> : <SvgIcoUnconnect />}
            </span>
            <span className={cn("status-power", { power: isOnPower })}>
              <SvgIcoFillPower2 />
            </span>
            <HStack className="status-battery" alignItems="center" gap={6}>
              <Battery size="small" />
              <VStack alignItems="center" gap={0}>
                <span className="battery-percent">45%</span>
                <span className="battery-voltage">(12.5V)</span>
              </VStack>
            </HStack>
          </HStack>
        </HStack>
        <EmergencyButton className="btn-emergency">
          EMERGENCY STOP
        </EmergencyButton>
      </HStack>
    </SimpleStatusesViewPannelStyle>
  );
};

const SimpleStatusesViewPannelStyle = styled.div`
  .simple-statuses-view-pannel {
    display: inline-flex;
    margin: 0.625rem;

    .btn-setting {
      height: auto;
      padding: 0.25rem;
      font-size: 1.125rem;
      border-radius: 0.25rem;
    }
  }

  .robot-status-area {
    position: relative;
    padding: 0.25rem;
    border-radius: 0.25rem;

    &::after {
      content: "";
      display: block;
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
      width: 100%;
      height: 100%;
      background-color: var(--rb-background-normal-normal);
      opacity: 0.4;
      border-radius: 0.25rem;
    }

    .robot-status-inner {
      position: relative;
      z-index: 2;
      font-size: 1rem;

      .status-connect {
        display: inline-flex;
        vertical-align: middle;
        justify-content: center;
        align-items: center;
        width: 1.375rem;
        height: 1.375rem;
        padding: 0.375rem;
        color: var(--rb-static-white);
        border-radius: 0.25rem;
        background-color: var(--rb-status-negative);

        &.connect {
          color: var(--rb-static-white);
          background-color: var(--rb-status-positive);

          path {
            fill: currentColor;
          }
        }
      }

      .status-power {
        display: inline-flex;
        vertical-align: middle;
        justify-content: center;
        align-items: center;
        width: 1.375rem;
        height: 1.375rem;
        padding: 0.375rem;
        font-size: 1.25rem;
        color: var(--rb-status-negative);
        border-radius: 0.25rem;
        background-color: var(--rb-line-solid-neutral);

        &.power {
          color: var(--rb-status-positive);
        }

        path:first-of-type {
          fill: currentColor;
        }
      }

      .status-battery {
        display: inline-flex;
        vertical-align: middle;
        justify-content: center;
        align-items: center;
        margin-left: 4px;
        color: var(--rb-static-white);

        .battery-body {
          width: 0.875rem;
          height: 1.188rem;
          border-radius: 0.188rem;
        }

        .battery-percent {
          font-size: 0.625rem;
          color: var(--rb-label-normal);
          font-weight: 500;
        }

        .battery-voltage {
          font-size: 0.5rem;
          line-height: 1;
          color: var(--rb-label-normal);
        }
      }

      svg {
        display: inline-block;
        vertical-align: middle;
        line-height: 1;
      }
    }
  }
`;

export default SimpleStatusesViewPannel;
