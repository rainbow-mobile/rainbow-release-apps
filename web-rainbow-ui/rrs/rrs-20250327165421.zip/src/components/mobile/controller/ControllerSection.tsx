import styled from "@emotion/styled";
import MoveControlPannel from "./MoveControlPannel";
import { RadioButton, RbJoyStickEventData } from "@repo/rb-components";
import {
  SvgIco3DView,
  SvgIcoFindRoute2,
  SvgIcoPanoramaCamera,
  SvgIcoRBQSitMode,
  SvgIcoRBQStairUp,
  SvgIcoRBQStandMode,
} from "@/assets/icons";
import SimpleStatusesViewPannel from "./SimpleStatusesViewPannel";
import { useRbSocket } from "@repo/rb-providers/RbSocketProvider";
import { getDateFormat } from "@repo/rb-utils/dateUtils";
import getImageUrl from "@repo/rb-utils/viteUtils";

const LINEAR_SPEED = 0.4;
const ROTATION_SPEED = 0.2;

const BACKGROUND_IMAGE = getImageUrl("/imgs/quadrupedal-robot-base-bg.png");

const ControllerSection = () => {
  const { socketEventEmit } = useRbSocket();

  const handleDirectionMove = ({
    data,
    type,
  }: {
    isMoving: boolean;
    type: "direction" | "curved";
    data: RbJoyStickEventData;
  }) => {
    const directionWithDegree =
      data.direction.x === "left"
        ? data.rotate.degree - 360
        : data.rotate.degree;

    const vx = (data.normalizedDistance.y * LINEAR_SPEED).toFixed(2);
    const vy = (data.normalizedDistance.x * LINEAR_SPEED * -1).toFixed(2);
    const wz = (directionWithDegree * ROTATION_SPEED * -1).toFixed(0);

    socketEventEmit("move", {
      command: "jog",
      vx: type === "curved" ? "0" : vx,
      vy: type === "curved" ? "0" : vy,
      // vz: "0", // 높낮이
      wx: "0",
      wy: "0",
      wz: type === "curved" ? wz : "0",
      time: getDateFormat(Date.now(), "YYYY-MM-DD HH:mm:ss.SSS"),
    });
  };

  return (
    <ControllerSectionStyle>
      <SimpleStatusesViewPannel />
      <MoveControlPannel
        leftJoystickConfig={{
          joystickType: "direction",
          disableDiagonal: true,
          buttons: [
            {
              key: "sit-mode",
              element: (
                <RadioButton className="btn-mode" name="RBQ-mode">
                  <SvgIcoRBQSitMode className="icon-RBQ-sit-mode" />
                </RadioButton>
              ),
            },
            {
              key: "stand-mode",
              element: (
                <RadioButton className="btn-mode" name="RBQ-mode">
                  <SvgIcoRBQStandMode className="icon-RBQ-stand-mode" />
                </RadioButton>
              ),
            },
            {
              key: "stair-up",
              element: (
                <RadioButton className="btn-mode" name="RBQ-mode">
                  <SvgIcoRBQStairUp className="icon-RBQ-stair-up" />
                </RadioButton>
              ),
            },
          ],
        }}
        rightJoystickConfig={{
          joystickType: "curved",
          buttons: [
            {
              key: "3d-view",
              element: (
                <RadioButton className="btn-mode" name="map-mode">
                  <SvgIco3DView className="icon-3d-view" />
                </RadioButton>
              ),
            },
            {
              key: "panorama-camera",
              element: (
                <RadioButton className="btn-mode" name="map-mode">
                  <SvgIcoPanoramaCamera className="icon-panorama-camera" />
                </RadioButton>
              ),
            },
            {
              key: "find-route",
              element: (
                <RadioButton className="btn-mode" name="map-mode">
                  <SvgIcoFindRoute2 className="icon-find-route" />
                </RadioButton>
              ),
            },
          ],
        }}
        onJoystickMove={handleDirectionMove}
      />
    </ControllerSectionStyle>
  );
};

const ControllerSectionStyle = styled.div`
  width: 100%;
  height: calc(var(--vh, 1vh) * 100);
  background-image: url(${BACKGROUND_IMAGE});
  background-size: cover;
  background-position: center;
  touch-action: none;

  .btn-mode {
    height: 100%;
    min-height: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--rb-background-normal-normal);
    /* opacity: 0.6; */

    .text {
      font-size: 1.125rem;
      color: var(--rb-label-normal);

      &::after {
        border-color: var(--rb-background-normal-normal);
        background-color: var(--rb-background-normal-normal) !important;
      }
    }

    input {
      &:checked {
        ~ .text {
          color: var(--rb-accent-redOrange);

          &::after {
            border-color: var(--rb-accent-redOrange);
          }
        }
      }
    }

    .icon-RBQ-sit-mode {
      font-size: 1.875rem;
    }

    .icon-RBQ-stand-mode {
      font-size: 1.563rem;
    }

    .icon-RBQ-stair-up {
      font-size: 18px;
    }

    .icon-mic {
      font-size: 1.125rem;
    }

    .icon-3d-view {
      font-size: 1.625rem;

      path {
        fill: currentColor;
      }
    }

    .icon-panorama-camera {
      font-size: 1.375rem;
    }

    .icon-find-route {
      font-size: 1.375rem;
      fill: currentColor;
    }
  }
`;

export default ControllerSection;
