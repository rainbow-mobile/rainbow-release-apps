import RrsMobileIndexPage from "@/pages/mobile";
import { isMobileIOS } from "@repo/rb-utils/browserUtils";
import CloudEditor from "@/pages/pc/cloud-editor";
import Map from "@/pages/pc/map";
import { isDesktop } from "react-device-detect";
import { RouteObject, useRoutes } from "react-router-dom";

console.log("mobileIOS", isMobileIOS());

const mobileRoutes: RouteObject[] = [
  {
    path: "",
    element: <RrsMobileIndexPage />,
  },
];

const pcRoutes: RouteObject[] = [
  {
    path: "cloud-editor",
    element: <CloudEditor />,
  },
  {
    path: "map",
    element: <Map />,
  },
];

export const routes: RouteObject[] = [
  {
    path: "/",
    children: isDesktop && !isMobileIOS() ? pcRoutes : mobileRoutes,
  },
  {
    path: "/rrs",
    children: isDesktop && !isMobileIOS() ? pcRoutes : mobileRoutes,
  },
];

const RrsRoutes = () => {
  const routeElments = useRoutes(routes);

  return routeElments;
};

export default RrsRoutes;
