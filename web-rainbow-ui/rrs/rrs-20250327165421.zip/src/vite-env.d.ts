/// <reference types="vite/client" />
/// <reference types="vite-plugin-svgr/client" />
/// <reference types="@repo/typescript-config" />

declare module "swiper/css" {}
declare module "swiper/css/pagination" {}
declare module "swiper/css/autoplay" {}
declare module "swiper/css/effect-fade" {}
declare module "swiper/css/navigation" {}
