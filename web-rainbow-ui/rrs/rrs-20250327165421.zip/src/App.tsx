import { RainbowUiProvider } from "@repo/rb-components/provider";
import RrsRoutes from "./routes";
import { HistoryRouter } from "./routes/HistoryRouter";
import { history } from "./routes/history";
import RbSocketProvider from "@repo/rb-providers/RbSocketProvider";
import "./globals.css";

function App() {
  return (
    <RainbowUiProvider theme="light">
      <RbSocketProvider url={"ws://192.168.0.12:11337"}>
        {import.meta.env.VITE_STAND_ALONE ? (
          <HistoryRouter history={history}>
            <RrsRoutes />
          </HistoryRouter>
        ) : (
          <RrsRoutes />
        )}
      </RbSocketProvider>
    </RainbowUiProvider>
  );
}

export default App;
