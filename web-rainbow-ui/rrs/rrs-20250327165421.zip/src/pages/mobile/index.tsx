import ControllerSection from "@/components/mobile/controller/ControllerSection";
import styled from "@emotion/styled";
import { useCheckDevice } from "@repo/rb-hooks";
import { useLayoutEffect } from "react";

const RrsMobileIndexPage = () => {
  const { isMobile, isSmallTablet, isBigTablet } = useCheckDevice();

  useLayoutEffect(() => {
    if (isMobile) {
      document.documentElement.style.fontSize = "13px";
    } else if (isSmallTablet) {
      document.documentElement.style.fontSize = "";
    } else {
      document.documentElement.style.fontSize = "20px";
    }
  }, [isMobile, isSmallTablet, isBigTablet]);

  return (
    <RrsMobileIndexPageStyle>
      <ControllerSection />
    </RrsMobileIndexPageStyle>
  );
};

const RrsMobileIndexPageStyle = styled.div``;

export default RrsMobileIndexPage;
