import { EditorProvider } from "@repo/rb-editor";
import { CanvasWrapper } from "@/components/pc/cloud-editor/CanvasWrapper";
// import EditorMenubar from "@/components/pc/cloud-editor/EditorMenubar";

const CloudEditor = () => {
  return (
    <div className="grid h-[calc(100*var(--vh))] w-screen grid-rows-[auto_1fr]">
      <EditorProvider>
        {/* <EditorMenubar /> */}
        {/* Eidtor-body */}
        <div className="grid h-full grid-cols-[1fr_24rem]">
          <CanvasWrapper />

          <div className="bg-gray-700 p-4 text-white">SIDE BAR</div>
        </div>
      </EditorProvider>
    </div>
  );
};

export default CloudEditor;
