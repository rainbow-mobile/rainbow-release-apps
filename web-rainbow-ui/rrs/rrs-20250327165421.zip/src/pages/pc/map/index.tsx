import { EditorComponent } from "@repo/rb-editor";
import { TopologyItem } from "@repo/rb-editor/interface";
import { useEffect, useState } from "react";
import EditorMenubar from "@/components/pc/map/EditorMenubar";
import EditorSidebar from "@/components/pc/map/Sidebar";
import { CloudDimension } from "@repo/rb-editor/interface";

const Map = () => {
  const [cloudData, setCloudData] = useState<string[][] | null>(null);
  const [topoData, setTopoData] = useState<TopologyItem[] | null>(null);
  const [isAnnotationMode, setIsAnnotationMode] = useState<boolean>(false);

  const [cloudDimension, setCloudDimension] = useState<CloudDimension>("3D");
  const [cloudOpacity, setCloudOpacity] = useState<number>(50);

  // Handlers
  const handleChangeAnnotationMode = () => {
    setIsAnnotationMode(!isAnnotationMode);
  };

  const handleChangeCloudDimension = (dimension: CloudDimension) => {
    setCloudDimension(dimension);
  };

  const handleChangeCloudOpacity = (value: number) => {
    setCloudOpacity(value);
  };

  return (
    <div className="flex flex-col h-[calc(100*var(--vh))] w-full">
      {/* Menubar(Header) */}
      <EditorMenubar
        onCloudFileParsed={(data) => setCloudData(data)}
        onTopoFileParsed={(data) => setTopoData(data)}
      />

      {/* Body */}
      <div className="flex h-full w-full">
        <div className="basis-4/5 h-full">
          <EditorComponent
            bootstrapOption={"RRS"}
            isAnnotationMode={isAnnotationMode}
            cloudData={cloudData}
            topoData={topoData}
            cloudDimension={cloudDimension}
            cloudOpacity={cloudOpacity}
          />
        </div>

        <EditorSidebar
          onChangeAnnotationMode={handleChangeAnnotationMode}
          onChangeCloudDimension={handleChangeCloudDimension}
          onChangeCloudOpacity={handleChangeCloudOpacity}
        />
      </div>
    </div>
  );
};

export default Map;
