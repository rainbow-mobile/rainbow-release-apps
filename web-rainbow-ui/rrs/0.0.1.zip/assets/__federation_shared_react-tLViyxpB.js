import{r,g as t}from"./index-zCPSE6if.js";var e=r();const o=t(e);export{o as default};
