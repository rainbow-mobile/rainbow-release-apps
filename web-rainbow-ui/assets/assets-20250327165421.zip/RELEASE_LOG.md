# Release log

## [assets-20250327105340] - 2025-03-27
- [App: assets, Version: assets-20250327105340] release 배포


## [assets-20250327101836] - 2025-03-27
- [App: assets, Version: assets-20250327101836] release 배포


## [assets-20250327101016] - 2025-03-27
- [App: assets, Version: assets-20250327101016] release 배포


## [assets-20250327100409] - 2025-03-27
- [App: assets, Version: assets-20250327100409] release 배포


## [assets-20250326222700] - 2025-03-26
- [App: assets, Version: assets-20250326222700] release 배포


## [assets-20250326220040] - 2025-03-26
- [App: assets, Version: assets-20250326220040] release 배포


## [assets-20250326213351] - 2025-03-26
- [App: assets, Version: assets-20250326213351] release 배포

