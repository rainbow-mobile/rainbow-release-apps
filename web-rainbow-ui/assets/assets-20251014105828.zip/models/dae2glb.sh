#!/usr/bin/env bash
# apps/web/assets/public/models/dae2glb.sh
# 사용법:
#   bash dae2glb.sh rb3_730es_u
#   bash dae2glb.sh              # → 프롬프트로 폴더명 입력
#
# 동작:
# 1) models/<TARGET>/meshes/visual/*.dae → temp_*.glb → *.glb (Z-up 베이크, temp 삭제)
# 2) models/<TARGET>/*.urdf 파일에서 <mesh filename="...*.dae"> 를 *.glb 로 치환(백업 생성)

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)" # apps/web/assets/public/models
ZUP="${ZUP:-$HOME/gltf-tools/zup.mjs}"

# 의존성 확인
command -v assimp >/dev/null || {
  echo "[ERR] assimp 미설치. brew install assimp"
  exit 1
}
command -v node >/dev/null || {
  echo "[ERR] node   미설치. brew install node"
  exit 1
}
[[ -f "$ZUP" ]] || {
  echo "[ERR] zup 스크립트가 없습니다: $ZUP"
  exit 1
}

# 대상 폴더 입력
TARGET="${1-}"
if [[ -z "${TARGET}" ]]; then
  read -rp "변환할 폴더명을 입력하세요 (예: rb3_730es_u): " TARGET
fi

TARGET_DIR="$ROOT_DIR/$TARGET"
VIS_DIR="$TARGET_DIR/meshes/visual"

[[ -d "$TARGET_DIR" ]] || {
  echo "[ERR] 폴더가 없습니다: $TARGET_DIR"
  exit 1
}
[[ -d "$VIS_DIR" ]] || {
  echo "[ERR] 'meshes/visual' 이 없습니다: $VIS_DIR"
  exit 1
}

echo "▶ 작업 대상: $TARGET_DIR"
echo "▶ ZUP 스크립트: $ZUP"
echo

# --- 1) .dae → .glb(+Z-up) ---
cd "$VIS_DIR"
shopt -s nullglob
found_dae=0

for dae in *.dae; do
  found_dae=1
  base="${dae%.dae}"
  tmp_glb="temp_${base}.glb"
  out_glb="${base}.glb"

  # 1-1) assimp 변환
  if [[ -f "$tmp_glb" ]]; then
    echo "[SKIP] temp 존재: $tmp_glb"
  else
    echo "[ASSIMP] $dae  →  $tmp_glb"
    if ! assimp export "$dae" "$tmp_glb"; then
      echo "[FAIL] assimp 변환 실패: $dae"
      continue
    fi
  fi

  # 1-2) Z-up 베이크
  if [[ -f "$out_glb" ]]; then
    echo "[SKIP] 최종 존재: $out_glb (temp 정리)"
    rm -f "$tmp_glb" 2>/dev/null || true
    continue
  fi

  echo "[Z-UP]   $tmp_glb  →  $out_glb"
  if node "$ZUP" "$tmp_glb" "$out_glb"; then
    rm -f "$tmp_glb"
  else
    echo "[FAIL] Z-up 변환 실패: $tmp_glb (temp 유지)"
  fi
done

if [[ "$found_dae" -eq 0 ]]; then
  echo "[INFO] 처리할 .dae 파일이 없습니다: $VIS_DIR"
fi
echo

# --- 2) URDF 내 경로 치환 (.dae → .glb) ---
# 대상: models/<TARGET>/*.urdf
cd "$TARGET_DIR"
shopt -s nullglob
urdf_list=(*.urdf)

if ((${#urdf_list[@]} == 0)); then
  echo "[INFO] URDF 파일을 찾지 못했습니다: $TARGET_DIR"
else
  for urdf in "${urdf_list[@]}"; do
    backup="${urdf}.bak.$(date +%Y%m%d-%H%M%S)"
    cp -p "$urdf" "$backup"

    echo "[URDF] 치환: $urdf  (백업: $backup)"
    # macOS(BSD sed) / GNU sed 모두 지원
    if sed --version >/dev/null 2>&1; then
      # GNU sed
      sed -E -i 's/(<mesh[[:space:]]+filename="[^"]+)\.dae"/\1.glb"/g' "$urdf"
    else
      # BSD sed (macOS)
      sed -E -i '' 's/(<mesh[[:space:]]+filename="[^"]+)\.dae"/\1.glb"/g' "$urdf"
    fi
  done
fi

echo
echo "✅ 완료: $TARGET"
