import{g as r}from"./index-BP6BFPOo.js";import{r as o}from"./index-DenIldTB.js";var t=o();const m=r(t);export{m as default};
