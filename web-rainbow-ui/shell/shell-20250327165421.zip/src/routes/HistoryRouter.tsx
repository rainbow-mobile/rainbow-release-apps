import React, { createElement, useLayoutEffect, useState } from "react";
import { Router } from "react-router-dom";
import { BrowserHistory } from "history";

interface HistoryRouterProps {
  history: BrowserHistory;
  children: React.ReactNode;
}

export const HistoryRouter: React.FC<HistoryRouterProps> = ({
  history,
  children,
}) => {
  const [state, setState] = useState({
    action: history.action,
    location: history.location,
  });

  useLayoutEffect(() => {
    const unlisten = history.listen((historyState) => {
      setState(historyState);
    });

    return unlisten;
  }, [history]);

  return createElement(
    Router,
    Object.assign({ children, navigator: history }, state),
  );
};
