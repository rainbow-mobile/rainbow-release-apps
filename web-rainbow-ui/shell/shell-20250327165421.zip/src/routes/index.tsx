import { lazy } from "react";
import { RouteObject, Navigate, useRoutes } from "react-router-dom";
import NotFoundPage from "@/pages/404";

const RrsApp = lazy(() => import("@app/rrs/App"));

export const routes: RouteObject[] = [
  {
    path: "/",
    element: <Navigate to="/rrs" replace />,
  },
  {
    path: "/rrs/*",
    element: <RrsApp />,
  },
  {
    path: "404",
    element: <NotFoundPage />,
  },
  {
    path: "*",
    element: <Navigate to="/404" replace />,
  },
];

const Routes = () => {
  const routeElments = useRoutes(routes);

  return routeElments;
};

export default Routes;
