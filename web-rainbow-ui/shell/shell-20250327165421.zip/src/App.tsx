import Routes from "./routes";

import { HistoryRouter } from "./routes/HistoryRouter";
import { history } from "./routes/history";

function App() {
  return (
    <>
      <HistoryRouter history={history}>
        <Routes />
      </HistoryRouter>
    </>
  );
}

export default App;
