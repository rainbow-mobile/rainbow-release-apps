declare module "@app/*" {
  const App: React.ComponentType;
  export default App;
}
