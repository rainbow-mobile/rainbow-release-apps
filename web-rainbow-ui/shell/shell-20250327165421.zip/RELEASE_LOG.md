# Release log

## [shell-20250327105340] - 2025-03-27
- [App: shell, Version: shell-20250327105340] release 배포


## [shell-20250327101836] - 2025-03-27
- [App: shell, Version: shell-20250327101836] release 배포


## [shell-20250327101016] - 2025-03-27
- [App: shell, Version: shell-20250327101016] release 배포


## [shell-20250326213351] - 2025-03-26
- [App: shell, Version: shell-20250326213351] release 배포


## [shell-20250326193504] - 2025-03-26
- [App: shell, Version: shell-20250326193504] release 배포


## [shell-20250326193050] - 2025-03-26
- [App: shell, Version: shell-20250326193050] release 배포


## [shell-20250326192528] - 2025-03-26
- [App: shell, Version: shell-20250326192528] release 배포


## [shell-20250326191337] - 2025-03-26
- [App: shell, Version: shell-20250326191337] release 배포


## [shell-20250326190724] - 2025-03-26
- [App: shell, Version: shell-20250326190724] release 배포


## [shell-20250326185555] - 2025-03-26
- [App: shell, Version: shell-20250326185555] release 배포

