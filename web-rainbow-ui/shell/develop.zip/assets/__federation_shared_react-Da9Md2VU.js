import{r,g as t}from"./index-BP6BFPOo.js";var e=r();const o=t(e);export{o as default};
