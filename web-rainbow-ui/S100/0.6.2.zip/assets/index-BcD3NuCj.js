import{g as Rf}from"./_commonjsHelpers-Cpj98o6Y.js";import{u as Cf,Y as Pf,j as ra,b as xd,C as Lf,t as io,d as Df}from"./__federation_expose_App-BDvrqgYf.js";import{importShared as yd}from"./__federation_fn_import-Cb1Q6gyo.js";const If=()=>{const{data:r,loading:e}=Cf("lidarCloud",{defaultValue:{data:[],pose:{x:"0",y:"0",rz:"0"}}});return{...r,loading:e}};/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const _s="174",Ii={ROTATE:0,DOLLY:1,PAN:2},Ki={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Nf=0,nh=1,Uf=2,bd=1,Ff=2,Ri=3,Ui=0,Un=1,Wn=2,Qi=0,nr=1,ih=2,sh=3,rh=4,Of=5,fs=100,Bf=101,kf=102,zf=103,Hf=104,Vf=200,Gf=201,Wf=202,Xf=203,Pl=204,Ll=205,jf=206,qf=207,Yf=208,Zf=209,Kf=210,$f=211,Jf=212,Qf=213,ep=214,Dl=0,Il=1,Nl=2,or=3,Ul=4,Fl=5,Ol=6,Bl=7,ga=0,tp=1,np=2,es=0,ip=1,sp=2,rp=3,op=4,ap=5,lp=6,cp=7,oh="attached",hp="detached",Md=300,ar=301,lr=302,oa=303,kl=304,_a=306,Pi=1e3,Bn=1001,zl=1002,gn=1003,up=1004,so=1005,mn=1006,Na=1007,Li=1008,Fi=1009,Sd=1010,wd=1011,Fr=1012,Tc=1013,xs=1014,fi=1015,Xr=1016,Ac=1017,Rc=1018,cr=1020,Ed=35902,Td=1021,Ad=1022,Sn=1023,Rd=1024,Cd=1025,ir=1026,hr=1027,Pd=1028,Cc=1029,Ld=1030,Pc=1031,Lc=1033,$o=33776,Jo=33777,Qo=33778,ea=33779,Hl=35840,Vl=35841,Gl=35842,Wl=35843,Xl=36196,jl=37492,ql=37496,Yl=37808,Zl=37809,Kl=37810,$l=37811,Jl=37812,Ql=37813,ec=37814,tc=37815,nc=37816,ic=37817,sc=37818,rc=37819,oc=37820,ac=37821,ta=36492,lc=36494,cc=36495,Dd=36283,hc=36284,uc=36285,dc=36286,aa=2300,fc=2301,Ua=2302,ah=2400,lh=2401,ch=2402,dp=2500,fp=3200,pp=3201,Dc=0,mp=1,Zi="",xt="srgb",ur="srgb-linear",la="linear",Nt="srgb",Ls=7680,hh=519,gp=512,_p=513,vp=514,Id=515,xp=516,yp=517,bp=518,Mp=519,pc=35044,uh="300 es",Di=2e3,ca=2001;class Es{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const i=n[e];if(i!==void 0){const s=i.indexOf(t);s!==-1&&i.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const i=n.slice(0);for(let s=0,o=i.length;s<o;s++)i[s].call(this,e);e.target=null}}}const vn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let dh=1234567;const Ir=Math.PI/180,dr=180/Math.PI;function ri(){const r=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(vn[r&255]+vn[r>>8&255]+vn[r>>16&255]+vn[r>>24&255]+"-"+vn[e&255]+vn[e>>8&255]+"-"+vn[e>>16&15|64]+vn[e>>24&255]+"-"+vn[t&63|128]+vn[t>>8&255]+"-"+vn[t>>16&255]+vn[t>>24&255]+vn[n&255]+vn[n>>8&255]+vn[n>>16&255]+vn[n>>24&255]).toLowerCase()}function dt(r,e,t){return Math.max(e,Math.min(t,r))}function Ic(r,e){return(r%e+e)%e}function Sp(r,e,t,n,i){return n+(r-e)*(i-n)/(t-e)}function wp(r,e,t){return r!==e?(t-r)/(e-r):0}function Nr(r,e,t){return(1-t)*r+t*e}function Ep(r,e,t,n){return Nr(r,e,1-Math.exp(-t*n))}function Tp(r,e=1){return e-Math.abs(Ic(r,e*2)-e)}function Ap(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e),r*r*(3-2*r))}function Rp(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e),r*r*r*(r*(r*6-15)+10))}function Cp(r,e){return r+Math.floor(Math.random()*(e-r+1))}function Pp(r,e){return r+Math.random()*(e-r)}function Lp(r){return r*(.5-Math.random())}function Dp(r){r!==void 0&&(dh=r);let e=dh+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function Ip(r){return r*Ir}function Np(r){return r*dr}function Up(r){return(r&r-1)===0&&r!==0}function Fp(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))}function Op(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function Bp(r,e,t,n,i){const s=Math.cos,o=Math.sin,a=s(t/2),l=o(t/2),c=s((e+n)/2),h=o((e+n)/2),u=s((e-n)/2),d=o((e-n)/2),f=s((n-e)/2),m=o((n-e)/2);switch(i){case"XYX":r.set(a*h,l*u,l*d,a*c);break;case"YZY":r.set(l*d,a*h,l*u,a*c);break;case"ZXZ":r.set(l*u,l*d,a*h,a*c);break;case"XZX":r.set(a*h,l*m,l*f,a*c);break;case"YXY":r.set(l*f,a*h,l*m,a*c);break;case"ZYZ":r.set(l*m,l*f,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+i)}}function ii(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function It(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}const St={DEG2RAD:Ir,RAD2DEG:dr,generateUUID:ri,clamp:dt,euclideanModulo:Ic,mapLinear:Sp,inverseLerp:wp,lerp:Nr,damp:Ep,pingpong:Tp,smoothstep:Ap,smootherstep:Rp,randInt:Cp,randFloat:Pp,randFloatSpread:Lp,seededRandom:Dp,degToRad:Ip,radToDeg:Np,isPowerOfTwo:Up,ceilPowerOfTwo:Fp,floorPowerOfTwo:Op,setQuaternionFromProperEuler:Bp,normalize:It,denormalize:ii};class ye{constructor(e=0,t=0){ye.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6],this.y=i[1]*t+i[4]*n+i[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=dt(this.x,e.x,t.x),this.y=dt(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=dt(this.x,e,t),this.y=dt(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(dt(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(dt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),i=Math.sin(t),s=this.x-e.x,o=this.y-e.y;return this.x=s*n-o*i+e.x,this.y=s*i+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class lt{constructor(e,t,n,i,s,o,a,l,c){lt.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,i,s,o,a,l,c)}set(e,t,n,i,s,o,a,l,c){const h=this.elements;return h[0]=e,h[1]=i,h[2]=a,h[3]=t,h[4]=s,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,i=t.elements,s=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],m=n[8],v=i[0],g=i[3],p=i[6],M=i[1],x=i[4],b=i[7],D=i[2],R=i[5],P=i[8];return s[0]=o*v+a*M+l*D,s[3]=o*g+a*x+l*R,s[6]=o*p+a*b+l*P,s[1]=c*v+h*M+u*D,s[4]=c*g+h*x+u*R,s[7]=c*p+h*b+u*P,s[2]=d*v+f*M+m*D,s[5]=d*g+f*x+m*R,s[8]=d*p+f*b+m*P,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8];return t*o*h-t*a*c-n*s*h+n*a*l+i*s*c-i*o*l}invert(){const e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=h*o-a*c,d=a*l-h*s,f=c*s-o*l,m=t*u+n*d+i*f;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/m;return e[0]=u*v,e[1]=(i*c-h*n)*v,e[2]=(a*n-i*o)*v,e[3]=d*v,e[4]=(h*t-i*l)*v,e[5]=(i*s-a*t)*v,e[6]=f*v,e[7]=(n*l-c*t)*v,e[8]=(o*t-n*s)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,i,s,o,a){const l=Math.cos(s),c=Math.sin(s);return this.set(n*l,n*c,-n*(l*o+c*a)+o+e,-i*c,i*l,-i*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(Fa.makeScale(e,t)),this}rotate(e){return this.premultiply(Fa.makeRotation(-e)),this}translate(e,t){return this.premultiply(Fa.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let i=0;i<9;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Fa=new lt;function Nd(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function Or(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function kp(){const r=Or("canvas");return r.style.display="block",r}const fh={};function hs(r){r in fh||(fh[r]=!0,console.warn(r))}function zp(r,e,t){return new Promise(function(n,i){function s(){switch(r.clientWaitSync(e,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:i();break;case r.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}function Hp(r){const e=r.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function Vp(r){const e=r.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const ph=new lt().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),mh=new lt().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function Gp(){const r={enabled:!0,workingColorSpace:ur,spaces:{},convert:function(i,s,o){return this.enabled===!1||s===o||!s||!o||(this.spaces[s].transfer===Nt&&(i.r=Ni(i.r),i.g=Ni(i.g),i.b=Ni(i.b)),this.spaces[s].primaries!==this.spaces[o].primaries&&(i.applyMatrix3(this.spaces[s].toXYZ),i.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===Nt&&(i.r=sr(i.r),i.g=sr(i.g),i.b=sr(i.b))),i},fromWorkingColorSpace:function(i,s){return this.convert(i,this.workingColorSpace,s)},toWorkingColorSpace:function(i,s){return this.convert(i,s,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Zi?la:this.spaces[i].transfer},getLuminanceCoefficients:function(i,s=this.workingColorSpace){return i.fromArray(this.spaces[s].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,s,o){return i.copy(this.spaces[s].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return r.define({[ur]:{primaries:e,whitePoint:n,transfer:la,toXYZ:ph,fromXYZ:mh,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:xt},outputColorSpaceConfig:{drawingBufferColorSpace:xt}},[xt]:{primaries:e,whitePoint:n,transfer:Nt,toXYZ:ph,fromXYZ:mh,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:xt}}}),r}const rt=Gp();function Ni(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function sr(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Ds;class Wp{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Ds===void 0&&(Ds=Or("canvas")),Ds.width=e.width,Ds.height=e.height;const n=Ds.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=Ds}return t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=Or("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const i=n.getImageData(0,0,e.width,e.height),s=i.data;for(let o=0;o<s.length;o++)s[o]=Ni(s[o]/255)*255;return n.putImageData(i,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Ni(t[n]/255)*255):t[n]=Ni(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let Xp=0;class Nc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Xp++}),this.uuid=ri(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let o=0,a=i.length;o<a;o++)i[o].isDataTexture?s.push(Oa(i[o].image)):s.push(Oa(i[o]))}else s=Oa(i);n.url=s}return t||(e.images[this.uuid]=n),n}}function Oa(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?Wp.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let jp=0;class qt extends Es{constructor(e=qt.DEFAULT_IMAGE,t=qt.DEFAULT_MAPPING,n=Bn,i=Bn,s=mn,o=Li,a=Sn,l=Fi,c=qt.DEFAULT_ANISOTROPY,h=Zi){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:jp++}),this.uuid=ri(),this.name="",this.source=new Nc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new ye(0,0),this.repeat=new ye(1,1),this.center=new ye(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new lt,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Md)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Pi:e.x=e.x-Math.floor(e.x);break;case Bn:e.x=e.x<0?0:1;break;case zl:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Pi:e.y=e.y-Math.floor(e.y);break;case Bn:e.y=e.y<0?0:1;break;case zl:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}qt.DEFAULT_IMAGE=null;qt.DEFAULT_MAPPING=Md;qt.DEFAULT_ANISOTROPY=1;class ct{constructor(e=0,t=0,n=0,i=1){ct.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=i}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,i){return this.x=e,this.y=t,this.z=n,this.w=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,i=this.z,s=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*i+o[12]*s,this.y=o[1]*t+o[5]*n+o[9]*i+o[13]*s,this.z=o[2]*t+o[6]*n+o[10]*i+o[14]*s,this.w=o[3]*t+o[7]*n+o[11]*i+o[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,i,s;const l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],m=l[9],v=l[2],g=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-v)<.01&&Math.abs(m-g)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+v)<.1&&Math.abs(m+g)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const x=(c+1)/2,b=(f+1)/2,D=(p+1)/2,R=(h+d)/4,P=(u+v)/4,S=(m+g)/4;return x>b&&x>D?x<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(x),i=R/n,s=P/n):b>D?b<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(b),n=R/i,s=S/i):D<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(D),n=P/s,i=S/s),this.set(n,i,s,t),this}let M=Math.sqrt((g-m)*(g-m)+(u-v)*(u-v)+(d-h)*(d-h));return Math.abs(M)<.001&&(M=1),this.x=(g-m)/M,this.y=(u-v)/M,this.z=(d-h)/M,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=dt(this.x,e.x,t.x),this.y=dt(this.y,e.y,t.y),this.z=dt(this.z,e.z,t.z),this.w=dt(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=dt(this.x,e,t),this.y=dt(this.y,e,t),this.z=dt(this.z,e,t),this.w=dt(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(dt(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class qp extends Es{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new ct(0,0,e,t),this.scissorTest=!1,this.viewport=new ct(0,0,e,t);const i={width:e,height:t,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:mn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const s=new qt(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);s.flipY=!1,s.generateMipmaps=n.generateMipmaps,s.internalFormat=n.internalFormat,this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=s.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let i=0,s=this.textures.length;i<s;i++)this.textures[i].image.width=e,this.textures[i].image.height=t,this.textures[i].image.depth=n;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const i=Object.assign({},e.textures[t].image);this.textures[t].source=new Nc(i)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class ys extends qp{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Ud extends qt{constructor(e=null,t=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=gn,this.minFilter=gn,this.wrapR=Bn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class Yp extends qt{constructor(e=null,t=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=gn,this.minFilter=gn,this.wrapR=Bn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class Pt{constructor(e=0,t=0,n=0,i=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=i}static slerpFlat(e,t,n,i,s,o,a){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3];const d=s[o+0],f=s[o+1],m=s[o+2],v=s[o+3];if(a===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u;return}if(a===1){e[t+0]=d,e[t+1]=f,e[t+2]=m,e[t+3]=v;return}if(u!==v||l!==d||c!==f||h!==m){let g=1-a;const p=l*d+c*f+h*m+u*v,M=p>=0?1:-1,x=1-p*p;if(x>Number.EPSILON){const D=Math.sqrt(x),R=Math.atan2(D,p*M);g=Math.sin(g*R)/D,a=Math.sin(a*R)/D}const b=a*M;if(l=l*g+d*b,c=c*g+f*b,h=h*g+m*b,u=u*g+v*b,g===1-a){const D=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=D,c*=D,h*=D,u*=D}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,i,s,o){const a=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=s[o],d=s[o+1],f=s[o+2],m=s[o+3];return e[t]=a*m+h*u+l*f-c*d,e[t+1]=l*m+h*d+c*u-a*f,e[t+2]=c*m+h*f+a*d-l*u,e[t+3]=h*m-a*u-l*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,i){return this._x=e,this._y=t,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,i=e._y,s=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(i/2),u=a(s/2),d=l(n/2),f=l(i/2),m=l(s/2);switch(o){case"XYZ":this._x=d*h*u+c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u-d*f*m;break;case"YXZ":this._x=d*h*u+c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u+d*f*m;break;case"ZXY":this._x=d*h*u-c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u-d*f*m;break;case"ZYX":this._x=d*h*u-c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u+d*f*m;break;case"YZX":this._x=d*h*u+c*f*m,this._y=c*f*u+d*h*m,this._z=c*h*m-d*f*u,this._w=c*h*u-d*f*m;break;case"XZY":this._x=d*h*u-c*f*m,this._y=c*f*u-d*h*m,this._z=c*h*m+d*f*u,this._w=c*h*u+d*f*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,i=Math.sin(n);return this._x=e.x*i,this._y=e.y*i,this._z=e.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],i=t[4],s=t[8],o=t[1],a=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+a+u;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(s-c)*f,this._z=(o-i)*f}else if(n>a&&n>u){const f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(i+o)/f,this._z=(s+c)/f}else if(a>u){const f=2*Math.sqrt(1+a-n-u);this._w=(s-c)/f,this._x=(i+o)/f,this._y=.25*f,this._z=(l+h)/f}else{const f=2*Math.sqrt(1+u-n-a);this._w=(o-i)/f,this._x=(s+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(dt(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const i=Math.min(1,t/n);return this.slerp(e,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,i=e._y,s=e._z,o=e._w,a=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+o*a+i*c-s*l,this._y=i*h+o*l+s*a-n*c,this._z=s*h+o*c+n*l-i*a,this._w=o*h-n*a-i*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,i=this._y,s=this._z,o=this._w;let a=o*e._w+n*e._x+i*e._y+s*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=i,this._z=s,this;const l=1-a*a;if(l<=Number.EPSILON){const f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*i+t*this._y,this._z=f*s+t*this._z,this.normalize(),this}const c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=i*u+this._y*d,this._z=s*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(i*Math.sin(e),i*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class I{constructor(e=0,t=0,n=0){I.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(gh.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(gh.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*i,this.y=s[1]*t+s[4]*n+s[7]*i,this.z=s[2]*t+s[5]*n+s[8]*i,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,i=this.z,s=e.elements,o=1/(s[3]*t+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*i+s[12])*o,this.y=(s[1]*t+s[5]*n+s[9]*i+s[13])*o,this.z=(s[2]*t+s[6]*n+s[10]*i+s[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,i=this.z,s=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*i-a*n),h=2*(a*t-s*i),u=2*(s*n-o*t);return this.x=t+l*c+o*u-a*h,this.y=n+l*h+a*c-s*u,this.z=i+l*u+s*h-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*i,this.y=s[1]*t+s[5]*n+s[9]*i,this.z=s[2]*t+s[6]*n+s[10]*i,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=dt(this.x,e.x,t.x),this.y=dt(this.y,e.y,t.y),this.z=dt(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=dt(this.x,e,t),this.y=dt(this.y,e,t),this.z=dt(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(dt(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,i=e.y,s=e.z,o=t.x,a=t.y,l=t.z;return this.x=i*l-s*a,this.y=s*o-n*l,this.z=n*a-i*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Ba.copy(this).projectOnVector(e),this.sub(Ba)}reflect(e){return this.sub(Ba.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(dt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,i=this.z-e.z;return t*t+n*n+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const i=Math.sin(t)*e;return this.x=i*Math.sin(n),this.y=Math.cos(t)*e,this.z=i*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),i=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=i,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Ba=new I,gh=new Pt;class Cn{constructor(e=new I(1/0,1/0,1/0),t=new I(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint($n.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint($n.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=$n.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=s.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,$n):$n.fromBufferAttribute(s,o),$n.applyMatrix4(e.matrixWorld),this.expandByPoint($n);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),ro.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),ro.copy(n.boundingBox)),ro.applyMatrix4(e.matrixWorld),this.union(ro)}const i=e.children;for(let s=0,o=i.length;s<o;s++)this.expandByObject(i[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,$n),$n.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Mr),oo.subVectors(this.max,Mr),Is.subVectors(e.a,Mr),Ns.subVectors(e.b,Mr),Us.subVectors(e.c,Mr),Bi.subVectors(Ns,Is),ki.subVectors(Us,Ns),ns.subVectors(Is,Us);let t=[0,-Bi.z,Bi.y,0,-ki.z,ki.y,0,-ns.z,ns.y,Bi.z,0,-Bi.x,ki.z,0,-ki.x,ns.z,0,-ns.x,-Bi.y,Bi.x,0,-ki.y,ki.x,0,-ns.y,ns.x,0];return!ka(t,Is,Ns,Us,oo)||(t=[1,0,0,0,1,0,0,0,1],!ka(t,Is,Ns,Us,oo))?!1:(ao.crossVectors(Bi,ki),t=[ao.x,ao.y,ao.z],ka(t,Is,Ns,Us,oo))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,$n).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize($n).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(Mi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),Mi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),Mi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),Mi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),Mi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),Mi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),Mi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),Mi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(Mi),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const Mi=[new I,new I,new I,new I,new I,new I,new I,new I],$n=new I,ro=new Cn,Is=new I,Ns=new I,Us=new I,Bi=new I,ki=new I,ns=new I,Mr=new I,oo=new I,ao=new I,is=new I;function ka(r,e,t,n,i){for(let s=0,o=r.length-3;s<=o;s+=3){is.fromArray(r,s);const a=i.x*Math.abs(is.x)+i.y*Math.abs(is.y)+i.z*Math.abs(is.z),l=e.dot(is),c=t.dot(is),h=n.dot(is);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}const Zp=new Cn,Sr=new I,za=new I;class _i{constructor(e=new I,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):Zp.setFromPoints(e).getCenter(n);let i=0;for(let s=0,o=e.length;s<o;s++)i=Math.max(i,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(i),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Sr.subVectors(e,this.center);const t=Sr.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),i=(n-this.radius)*.5;this.center.addScaledVector(Sr,i/n),this.radius+=i}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(za.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Sr.copy(e.center).add(za)),this.expandByPoint(Sr.copy(e.center).sub(za))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const Si=new I,Ha=new I,lo=new I,zi=new I,Va=new I,co=new I,Ga=new I;class Ts{constructor(e=new I,t=new I(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Si)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Si.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Si.copy(this.origin).addScaledVector(this.direction,t),Si.distanceToSquared(e))}distanceSqToSegment(e,t,n,i){Ha.copy(e).add(t).multiplyScalar(.5),lo.copy(t).sub(e).normalize(),zi.copy(this.origin).sub(Ha);const s=e.distanceTo(t)*.5,o=-this.direction.dot(lo),a=zi.dot(this.direction),l=-zi.dot(lo),c=zi.lengthSq(),h=Math.abs(1-o*o);let u,d,f,m;if(h>0)if(u=o*l-a,d=o*a-l,m=s*h,u>=0)if(d>=-m)if(d<=m){const v=1/h;u*=v,d*=v,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-m?(u=Math.max(0,-(-o*s+a)),d=u>0?-s:Math.min(Math.max(-s,-l),s),f=-u*u+d*(d+2*l)+c):d<=m?(u=0,d=Math.min(Math.max(-s,-l),s),f=d*(d+2*l)+c):(u=Math.max(0,-(o*s+a)),d=u>0?s:Math.min(Math.max(-s,-l),s),f=-u*u+d*(d+2*l)+c);else d=o>0?-s:s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(Ha).addScaledVector(lo,d),f}intersectSphere(e,t){Si.subVectors(e.center,this.origin);const n=Si.dot(this.direction),i=Si.dot(Si)-n*n,s=e.radius*e.radius;if(i>s)return null;const o=Math.sqrt(s-i),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,i,s,o,a,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,i=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,i=(e.min.x-d.x)*c),h>=0?(s=(e.min.y-d.y)*h,o=(e.max.y-d.y)*h):(s=(e.max.y-d.y)*h,o=(e.min.y-d.y)*h),n>o||s>i||((s>n||isNaN(n))&&(n=s),(o<i||isNaN(i))&&(i=o),u>=0?(a=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(a=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||a>i)||((a>n||n!==n)&&(n=a),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,t)}intersectsBox(e){return this.intersectBox(e,Si)!==null}intersectTriangle(e,t,n,i,s){Va.subVectors(t,e),co.subVectors(n,e),Ga.crossVectors(Va,co);let o=this.direction.dot(Ga),a;if(o>0){if(i)return null;a=1}else if(o<0)a=-1,o=-o;else return null;zi.subVectors(this.origin,e);const l=a*this.direction.dot(co.crossVectors(zi,co));if(l<0)return null;const c=a*this.direction.dot(Va.cross(zi));if(c<0||l+c>o)return null;const h=-a*zi.dot(Ga);return h<0?null:this.at(h/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Te{constructor(e,t,n,i,s,o,a,l,c,h,u,d,f,m,v,g){Te.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,i,s,o,a,l,c,h,u,d,f,m,v,g)}set(e,t,n,i,s,o,a,l,c,h,u,d,f,m,v,g){const p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=i,p[1]=s,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=m,p[11]=v,p[15]=g,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Te().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,i=1/Fs.setFromMatrixColumn(e,0).length(),s=1/Fs.setFromMatrixColumn(e,1).length(),o=1/Fs.setFromMatrixColumn(e,2).length();return t[0]=n[0]*i,t[1]=n[1]*i,t[2]=n[2]*i,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,i=e.y,s=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const d=o*h,f=o*u,m=a*h,v=a*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=f+m*c,t[5]=d-v*c,t[9]=-a*l,t[2]=v-d*c,t[6]=m+f*c,t[10]=o*l}else if(e.order==="YXZ"){const d=l*h,f=l*u,m=c*h,v=c*u;t[0]=d+v*a,t[4]=m*a-f,t[8]=o*c,t[1]=o*u,t[5]=o*h,t[9]=-a,t[2]=f*a-m,t[6]=v+d*a,t[10]=o*l}else if(e.order==="ZXY"){const d=l*h,f=l*u,m=c*h,v=c*u;t[0]=d-v*a,t[4]=-o*u,t[8]=m+f*a,t[1]=f+m*a,t[5]=o*h,t[9]=v-d*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){const d=o*h,f=o*u,m=a*h,v=a*u;t[0]=l*h,t[4]=m*c-f,t[8]=d*c+v,t[1]=l*u,t[5]=v*c+d,t[9]=f*c-m,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){const d=o*l,f=o*c,m=a*l,v=a*c;t[0]=l*h,t[4]=v-d*u,t[8]=m*u+f,t[1]=u,t[5]=o*h,t[9]=-a*h,t[2]=-c*h,t[6]=f*u+m,t[10]=d-v*u}else if(e.order==="XZY"){const d=o*l,f=o*c,m=a*l,v=a*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+v,t[5]=o*h,t[9]=f*u-m,t[2]=m*u-f,t[6]=a*h,t[10]=v*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(Kp,e,$p)}lookAt(e,t,n){const i=this.elements;return Fn.subVectors(e,t),Fn.lengthSq()===0&&(Fn.z=1),Fn.normalize(),Hi.crossVectors(n,Fn),Hi.lengthSq()===0&&(Math.abs(n.z)===1?Fn.x+=1e-4:Fn.z+=1e-4,Fn.normalize(),Hi.crossVectors(n,Fn)),Hi.normalize(),ho.crossVectors(Fn,Hi),i[0]=Hi.x,i[4]=ho.x,i[8]=Fn.x,i[1]=Hi.y,i[5]=ho.y,i[9]=Fn.y,i[2]=Hi.z,i[6]=ho.z,i[10]=Fn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,i=t.elements,s=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],m=n[2],v=n[6],g=n[10],p=n[14],M=n[3],x=n[7],b=n[11],D=n[15],R=i[0],P=i[4],S=i[8],_=i[12],y=i[1],T=i[5],F=i[9],k=i[13],G=i[2],$=i[6],z=i[10],Y=i[14],H=i[3],q=i[7],ue=i[11],re=i[15];return s[0]=o*R+a*y+l*G+c*H,s[4]=o*P+a*T+l*$+c*q,s[8]=o*S+a*F+l*z+c*ue,s[12]=o*_+a*k+l*Y+c*re,s[1]=h*R+u*y+d*G+f*H,s[5]=h*P+u*T+d*$+f*q,s[9]=h*S+u*F+d*z+f*ue,s[13]=h*_+u*k+d*Y+f*re,s[2]=m*R+v*y+g*G+p*H,s[6]=m*P+v*T+g*$+p*q,s[10]=m*S+v*F+g*z+p*ue,s[14]=m*_+v*k+g*Y+p*re,s[3]=M*R+x*y+b*G+D*H,s[7]=M*P+x*T+b*$+D*q,s[11]=M*S+x*F+b*z+D*ue,s[15]=M*_+x*k+b*Y+D*re,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],i=e[8],s=e[12],o=e[1],a=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],f=e[14],m=e[3],v=e[7],g=e[11],p=e[15];return m*(+s*l*u-i*c*u-s*a*d+n*c*d+i*a*f-n*l*f)+v*(+t*l*f-t*c*d+s*o*d-i*o*f+i*c*h-s*l*h)+g*(+t*c*u-t*a*f-s*o*u+n*o*f+s*a*h-n*c*h)+p*(-i*a*h-t*l*u+t*a*d+i*o*u-n*o*d+n*l*h)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const i=this.elements;return e.isVector3?(i[12]=e.x,i[13]=e.y,i[14]=e.z):(i[12]=e,i[13]=t,i[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],f=e[11],m=e[12],v=e[13],g=e[14],p=e[15],M=u*g*c-v*d*c+v*l*f-a*g*f-u*l*p+a*d*p,x=m*d*c-h*g*c-m*l*f+o*g*f+h*l*p-o*d*p,b=h*v*c-m*u*c+m*a*f-o*v*f-h*a*p+o*u*p,D=m*u*l-h*v*l-m*a*d+o*v*d+h*a*g-o*u*g,R=t*M+n*x+i*b+s*D;if(R===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const P=1/R;return e[0]=M*P,e[1]=(v*d*s-u*g*s-v*i*f+n*g*f+u*i*p-n*d*p)*P,e[2]=(a*g*s-v*l*s+v*i*c-n*g*c-a*i*p+n*l*p)*P,e[3]=(u*l*s-a*d*s-u*i*c+n*d*c+a*i*f-n*l*f)*P,e[4]=x*P,e[5]=(h*g*s-m*d*s+m*i*f-t*g*f-h*i*p+t*d*p)*P,e[6]=(m*l*s-o*g*s-m*i*c+t*g*c+o*i*p-t*l*p)*P,e[7]=(o*d*s-h*l*s+h*i*c-t*d*c-o*i*f+t*l*f)*P,e[8]=b*P,e[9]=(m*u*s-h*v*s-m*n*f+t*v*f+h*n*p-t*u*p)*P,e[10]=(o*v*s-m*a*s+m*n*c-t*v*c-o*n*p+t*a*p)*P,e[11]=(h*a*s-o*u*s-h*n*c+t*u*c+o*n*f-t*a*f)*P,e[12]=D*P,e[13]=(h*v*i-m*u*i+m*n*d-t*v*d-h*n*g+t*u*g)*P,e[14]=(m*a*i-o*v*i-m*n*l+t*v*l+o*n*g-t*a*g)*P,e[15]=(o*u*i-h*a*i+h*n*l-t*u*l-o*n*d+t*a*d)*P,this}scale(e){const t=this.elements,n=e.x,i=e.y,s=e.z;return t[0]*=n,t[4]*=i,t[8]*=s,t[1]*=n,t[5]*=i,t[9]*=s,t[2]*=n,t[6]*=i,t[10]*=s,t[3]*=n,t[7]*=i,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],i=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,i))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),i=Math.sin(t),s=1-n,o=e.x,a=e.y,l=e.z,c=s*o,h=s*a;return this.set(c*o+n,c*a-i*l,c*l+i*a,0,c*a+i*l,h*a+n,h*l-i*o,0,c*l-i*a,h*l+i*o,s*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,i,s,o){return this.set(1,n,s,0,e,1,o,0,t,i,1,0,0,0,0,1),this}compose(e,t,n){const i=this.elements,s=t._x,o=t._y,a=t._z,l=t._w,c=s+s,h=o+o,u=a+a,d=s*c,f=s*h,m=s*u,v=o*h,g=o*u,p=a*u,M=l*c,x=l*h,b=l*u,D=n.x,R=n.y,P=n.z;return i[0]=(1-(v+p))*D,i[1]=(f+b)*D,i[2]=(m-x)*D,i[3]=0,i[4]=(f-b)*R,i[5]=(1-(d+p))*R,i[6]=(g+M)*R,i[7]=0,i[8]=(m+x)*P,i[9]=(g-M)*P,i[10]=(1-(d+v))*P,i[11]=0,i[12]=e.x,i[13]=e.y,i[14]=e.z,i[15]=1,this}decompose(e,t,n){const i=this.elements;let s=Fs.set(i[0],i[1],i[2]).length();const o=Fs.set(i[4],i[5],i[6]).length(),a=Fs.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),e.x=i[12],e.y=i[13],e.z=i[14],Jn.copy(this);const c=1/s,h=1/o,u=1/a;return Jn.elements[0]*=c,Jn.elements[1]*=c,Jn.elements[2]*=c,Jn.elements[4]*=h,Jn.elements[5]*=h,Jn.elements[6]*=h,Jn.elements[8]*=u,Jn.elements[9]*=u,Jn.elements[10]*=u,t.setFromRotationMatrix(Jn),n.x=s,n.y=o,n.z=a,this}makePerspective(e,t,n,i,s,o,a=Di){const l=this.elements,c=2*s/(t-e),h=2*s/(n-i),u=(t+e)/(t-e),d=(n+i)/(n-i);let f,m;if(a===Di)f=-(o+s)/(o-s),m=-2*o*s/(o-s);else if(a===ca)f=-o/(o-s),m=-o*s/(o-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=m,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,i,s,o,a=Di){const l=this.elements,c=1/(t-e),h=1/(n-i),u=1/(o-s),d=(t+e)*c,f=(n+i)*h;let m,v;if(a===Di)m=(o+s)*u,v=-2*u;else if(a===ca)m=s*u,v=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=v,l[14]=-m,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let i=0;i<16;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const Fs=new I,Jn=new Te,Kp=new I(0,0,0),$p=new I(1,1,1),Hi=new I,ho=new I,Fn=new I,_h=new Te,vh=new Pt;class Kt{constructor(e=0,t=0,n=0,i=Kt.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,i=this._order){return this._x=e,this._y=t,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const i=e.elements,s=i[0],o=i[4],a=i[8],l=i[1],c=i[5],h=i[9],u=i[2],d=i[6],f=i[10];switch(t){case"XYZ":this._y=Math.asin(dt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,s)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-dt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(dt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-dt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(dt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-dt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,s)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return _h.makeRotationFromQuaternion(e),this.setFromRotationMatrix(_h,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return vh.setFromEuler(this),this.setFromQuaternion(vh,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Kt.DEFAULT_ORDER="XYZ";class Uc{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let Jp=0;const xh=new I,Os=new Pt,wi=new Te,uo=new I,wr=new I,Qp=new I,em=new Pt,yh=new I(1,0,0),bh=new I(0,1,0),Mh=new I(0,0,1),Sh={type:"added"},tm={type:"removed"},Bs={type:"childadded",child:null},Wa={type:"childremoved",child:null};class Ct extends Es{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:Jp++}),this.uuid=ri(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Ct.DEFAULT_UP.clone();const e=new I,t=new Kt,n=new Pt,i=new I(1,1,1);function s(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Te},normalMatrix:{value:new lt}}),this.matrix=new Te,this.matrixWorld=new Te,this.matrixAutoUpdate=Ct.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Ct.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Uc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Os.setFromAxisAngle(e,t),this.quaternion.multiply(Os),this}rotateOnWorldAxis(e,t){return Os.setFromAxisAngle(e,t),this.quaternion.premultiply(Os),this}rotateX(e){return this.rotateOnAxis(yh,e)}rotateY(e){return this.rotateOnAxis(bh,e)}rotateZ(e){return this.rotateOnAxis(Mh,e)}translateOnAxis(e,t){return xh.copy(e).applyQuaternion(this.quaternion),this.position.add(xh.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(yh,e)}translateY(e){return this.translateOnAxis(bh,e)}translateZ(e){return this.translateOnAxis(Mh,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(wi.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?uo.copy(e):uo.set(e,t,n);const i=this.parent;this.updateWorldMatrix(!0,!1),wr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?wi.lookAt(wr,uo,this.up):wi.lookAt(uo,wr,this.up),this.quaternion.setFromRotationMatrix(wi),i&&(wi.extractRotation(i.matrixWorld),Os.setFromRotationMatrix(wi),this.quaternion.premultiply(Os.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Sh),Bs.child=e,this.dispatchEvent(Bs),Bs.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(tm),Wa.child=e,this.dispatchEvent(Wa),Wa.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),wi.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),wi.multiply(e.parent.matrixWorld)),e.applyMatrix4(wi),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Sh),Bs.child=e,this.dispatchEvent(Bs),Bs.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,i=this.children.length;n<i;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const i=this.children;for(let s=0,o=i.length;s<o;s++)i[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(wr,e,Qp),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(wr,em,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const i=this.children;for(let s=0,o=i.length;s<o;s++)i[s].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function s(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(s(e.materials,this.material[l]));i.material=a}else i.material=s(e.materials,this.material);if(this.children.length>0){i.children=[];for(let a=0;a<this.children.length;a++)i.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){i.animations=[];for(let a=0;a<this.animations.length;a++){const l=this.animations[a];i.animations.push(s(e.animations,l))}}if(t){const a=o(e.geometries),l=o(e.materials),c=o(e.textures),h=o(e.images),u=o(e.shapes),d=o(e.skeletons),f=o(e.animations),m=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),m.length>0&&(n.nodes=m)}return n.object=i,n;function o(a){const l=[];for(const c in a){const h=a[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const i=e.children[n];this.add(i.clone())}return this}}Ct.DEFAULT_UP=new I(0,1,0);Ct.DEFAULT_MATRIX_AUTO_UPDATE=!0;Ct.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const Qn=new I,Ei=new I,Xa=new I,Ti=new I,ks=new I,zs=new I,wh=new I,ja=new I,qa=new I,Ya=new I,Za=new ct,Ka=new ct,$a=new ct;class si{constructor(e=new I,t=new I,n=new I){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,i){i.subVectors(n,t),Qn.subVectors(e,t),i.cross(Qn);const s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(e,t,n,i,s){Qn.subVectors(i,t),Ei.subVectors(n,t),Xa.subVectors(e,t);const o=Qn.dot(Qn),a=Qn.dot(Ei),l=Qn.dot(Xa),c=Ei.dot(Ei),h=Ei.dot(Xa),u=o*c-a*a;if(u===0)return s.set(0,0,0),null;const d=1/u,f=(c*l-a*h)*d,m=(o*h-a*l)*d;return s.set(1-f-m,m,f)}static containsPoint(e,t,n,i){return this.getBarycoord(e,t,n,i,Ti)===null?!1:Ti.x>=0&&Ti.y>=0&&Ti.x+Ti.y<=1}static getInterpolation(e,t,n,i,s,o,a,l){return this.getBarycoord(e,t,n,i,Ti)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,Ti.x),l.addScaledVector(o,Ti.y),l.addScaledVector(a,Ti.z),l)}static getInterpolatedAttribute(e,t,n,i,s,o){return Za.setScalar(0),Ka.setScalar(0),$a.setScalar(0),Za.fromBufferAttribute(e,t),Ka.fromBufferAttribute(e,n),$a.fromBufferAttribute(e,i),o.setScalar(0),o.addScaledVector(Za,s.x),o.addScaledVector(Ka,s.y),o.addScaledVector($a,s.z),o}static isFrontFacing(e,t,n,i){return Qn.subVectors(n,t),Ei.subVectors(e,t),Qn.cross(Ei).dot(i)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,i){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[i]),this}setFromAttributeAndIndices(e,t,n,i){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return Qn.subVectors(this.c,this.b),Ei.subVectors(this.a,this.b),Qn.cross(Ei).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return si.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return si.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,i,s){return si.getInterpolation(e,this.a,this.b,this.c,t,n,i,s)}containsPoint(e){return si.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return si.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,i=this.b,s=this.c;let o,a;ks.subVectors(i,n),zs.subVectors(s,n),ja.subVectors(e,n);const l=ks.dot(ja),c=zs.dot(ja);if(l<=0&&c<=0)return t.copy(n);qa.subVectors(e,i);const h=ks.dot(qa),u=zs.dot(qa);if(h>=0&&u<=h)return t.copy(i);const d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),t.copy(n).addScaledVector(ks,o);Ya.subVectors(e,s);const f=ks.dot(Ya),m=zs.dot(Ya);if(m>=0&&f<=m)return t.copy(s);const v=f*c-l*m;if(v<=0&&c>=0&&m<=0)return a=c/(c-m),t.copy(n).addScaledVector(zs,a);const g=h*m-f*u;if(g<=0&&u-h>=0&&f-m>=0)return wh.subVectors(s,i),a=(u-h)/(u-h+(f-m)),t.copy(i).addScaledVector(wh,a);const p=1/(g+v+d);return o=v*p,a=d*p,t.copy(n).addScaledVector(ks,o).addScaledVector(zs,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const Fd={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Vi={h:0,s:0,l:0},fo={h:0,s:0,l:0};function Ja(r,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?r+(e-r)*6*t:t<1/2?e:t<2/3?r+(e-r)*6*(2/3-t):r}class Ge{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const i=e;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=xt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,rt.toWorkingColorSpace(this,t),this}setRGB(e,t,n,i=rt.workingColorSpace){return this.r=e,this.g=t,this.b=n,rt.toWorkingColorSpace(this,i),this}setHSL(e,t,n,i=rt.workingColorSpace){if(e=Ic(e,1),t=dt(t,0,1),n=dt(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,o=2*n-s;this.r=Ja(o,s,e+1/3),this.g=Ja(o,s,e),this.b=Ja(o,s,e-1/3)}return rt.toWorkingColorSpace(this,i),this}setStyle(e,t=xt){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const o=i[1],a=i[2];switch(o){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=i[1],o=s.length;if(o===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=xt){const n=Fd[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ni(e.r),this.g=Ni(e.g),this.b=Ni(e.b),this}copyLinearToSRGB(e){return this.r=sr(e.r),this.g=sr(e.g),this.b=sr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=xt){return rt.fromWorkingColorSpace(xn.copy(this),e),Math.round(dt(xn.r*255,0,255))*65536+Math.round(dt(xn.g*255,0,255))*256+Math.round(dt(xn.b*255,0,255))}getHexString(e=xt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=rt.workingColorSpace){rt.fromWorkingColorSpace(xn.copy(this),t);const n=xn.r,i=xn.g,s=xn.b,o=Math.max(n,i,s),a=Math.min(n,i,s);let l,c;const h=(a+o)/2;if(a===o)l=0,c=0;else{const u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(i-s)/u+(i<s?6:0);break;case i:l=(s-n)/u+2;break;case s:l=(n-i)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=rt.workingColorSpace){return rt.fromWorkingColorSpace(xn.copy(this),t),e.r=xn.r,e.g=xn.g,e.b=xn.b,e}getStyle(e=xt){rt.fromWorkingColorSpace(xn.copy(this),e);const t=xn.r,n=xn.g,i=xn.b;return e!==xt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(e,t,n){return this.getHSL(Vi),this.setHSL(Vi.h+e,Vi.s+t,Vi.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Vi),e.getHSL(fo);const n=Nr(Vi.h,fo.h,t),i=Nr(Vi.s,fo.s,t),s=Nr(Vi.l,fo.l,t);return this.setHSL(n,i,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,i=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*i,this.g=s[1]*t+s[4]*n+s[7]*i,this.b=s[2]*t+s[5]*n+s[8]*i,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const xn=new Ge;Ge.NAMES=Fd;let nm=0;class mi extends Es{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:nm++}),this.uuid=ri(),this.name="",this.type="Material",this.blending=nr,this.side=Ui,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Pl,this.blendDst=Ll,this.blendEquation=fs,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new Ge(0,0,0),this.blendAlpha=0,this.depthFunc=or,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=hh,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ls,this.stencilZFail=Ls,this.stencilZPass=Ls,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const i=this[t];if(i===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==nr&&(n.blending=this.blending),this.side!==Ui&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Pl&&(n.blendSrc=this.blendSrc),this.blendDst!==Ll&&(n.blendDst=this.blendDst),this.blendEquation!==fs&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==or&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==hh&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ls&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ls&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ls&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(s){const o=[];for(const a in s){const l=s[a];delete l.metadata,o.push(l)}return o}if(t){const s=i(e.textures),o=i(e.images);s.length>0&&(n.textures=s),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const i=t.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class qn extends mi{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new Ge(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Kt,this.combine=ga,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Jt=new I,po=new ye;let im=0;class Rn{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:im++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=pc,this.updateRanges=[],this.gpuType=fi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[e+i]=t.array[n+i];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)po.fromBufferAttribute(this,t),po.applyMatrix3(e),this.setXY(t,po.x,po.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.applyMatrix3(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.applyMatrix4(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.applyNormalMatrix(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.transformDirection(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=ii(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=It(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=ii(t,this.array)),t}setX(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=ii(t,this.array)),t}setY(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=ii(t,this.array)),t}setZ(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=ii(t,this.array)),t}setW(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=It(t,this.array),n=It(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,i){return e*=this.itemSize,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e*=this.itemSize,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array),s=It(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==pc&&(e.usage=this.usage),e}}class Fc extends Rn{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Oc extends Rn{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class Le extends Rn{constructor(e,t,n){super(new Float32Array(e),t,n)}}let sm=0;const zn=new Te,Qa=new Ct,Hs=new I,On=new Cn,Er=new Cn,ln=new I;class yt extends Es{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:sm++}),this.uuid=ri(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Nd(e)?Oc:Fc)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new lt().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(e),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return zn.makeRotationFromQuaternion(e),this.applyMatrix4(zn),this}rotateX(e){return zn.makeRotationX(e),this.applyMatrix4(zn),this}rotateY(e){return zn.makeRotationY(e),this.applyMatrix4(zn),this}rotateZ(e){return zn.makeRotationZ(e),this.applyMatrix4(zn),this}translate(e,t,n){return zn.makeTranslation(e,t,n),this.applyMatrix4(zn),this}scale(e,t,n){return zn.makeScale(e,t,n),this.applyMatrix4(zn),this}lookAt(e){return Qa.lookAt(e),Qa.updateMatrix(),this.applyMatrix4(Qa.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(Hs).negate(),this.translate(Hs.x,Hs.y,Hs.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let i=0,s=e.length;i<s;i++){const o=e[i];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Le(n,3))}else{const n=Math.min(e.length,t.count);for(let i=0;i<n;i++){const s=e[i];t.setXYZ(i,s.x,s.y,s.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Cn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new I(-1/0,-1/0,-1/0),new I(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,i=t.length;n<i;n++){const s=t[n];On.setFromBufferAttribute(s),this.morphTargetsRelative?(ln.addVectors(this.boundingBox.min,On.min),this.boundingBox.expandByPoint(ln),ln.addVectors(this.boundingBox.max,On.max),this.boundingBox.expandByPoint(ln)):(this.boundingBox.expandByPoint(On.min),this.boundingBox.expandByPoint(On.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new _i);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new I,1/0);return}if(e){const n=this.boundingSphere.center;if(On.setFromBufferAttribute(e),t)for(let s=0,o=t.length;s<o;s++){const a=t[s];Er.setFromBufferAttribute(a),this.morphTargetsRelative?(ln.addVectors(On.min,Er.min),On.expandByPoint(ln),ln.addVectors(On.max,Er.max),On.expandByPoint(ln)):(On.expandByPoint(Er.min),On.expandByPoint(Er.max))}On.getCenter(n);let i=0;for(let s=0,o=e.count;s<o;s++)ln.fromBufferAttribute(e,s),i=Math.max(i,n.distanceToSquared(ln));if(t)for(let s=0,o=t.length;s<o;s++){const a=t[s],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)ln.fromBufferAttribute(a,c),l&&(Hs.fromBufferAttribute(e,c),ln.add(Hs)),i=Math.max(i,n.distanceToSquared(ln))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,i=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Rn(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],l=[];for(let S=0;S<n.count;S++)a[S]=new I,l[S]=new I;const c=new I,h=new I,u=new I,d=new ye,f=new ye,m=new ye,v=new I,g=new I;function p(S,_,y){c.fromBufferAttribute(n,S),h.fromBufferAttribute(n,_),u.fromBufferAttribute(n,y),d.fromBufferAttribute(s,S),f.fromBufferAttribute(s,_),m.fromBufferAttribute(s,y),h.sub(c),u.sub(c),f.sub(d),m.sub(d);const T=1/(f.x*m.y-m.x*f.y);isFinite(T)&&(v.copy(h).multiplyScalar(m.y).addScaledVector(u,-f.y).multiplyScalar(T),g.copy(u).multiplyScalar(f.x).addScaledVector(h,-m.x).multiplyScalar(T),a[S].add(v),a[_].add(v),a[y].add(v),l[S].add(g),l[_].add(g),l[y].add(g))}let M=this.groups;M.length===0&&(M=[{start:0,count:e.count}]);for(let S=0,_=M.length;S<_;++S){const y=M[S],T=y.start,F=y.count;for(let k=T,G=T+F;k<G;k+=3)p(e.getX(k+0),e.getX(k+1),e.getX(k+2))}const x=new I,b=new I,D=new I,R=new I;function P(S){D.fromBufferAttribute(i,S),R.copy(D);const _=a[S];x.copy(_),x.sub(D.multiplyScalar(D.dot(_))).normalize(),b.crossVectors(R,_);const T=b.dot(l[S])<0?-1:1;o.setXYZW(S,x.x,x.y,x.z,T)}for(let S=0,_=M.length;S<_;++S){const y=M[S],T=y.start,F=y.count;for(let k=T,G=T+F;k<G;k+=3)P(e.getX(k+0)),P(e.getX(k+1)),P(e.getX(k+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Rn(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);const i=new I,s=new I,o=new I,a=new I,l=new I,c=new I,h=new I,u=new I;if(e)for(let d=0,f=e.count;d<f;d+=3){const m=e.getX(d+0),v=e.getX(d+1),g=e.getX(d+2);i.fromBufferAttribute(t,m),s.fromBufferAttribute(t,v),o.fromBufferAttribute(t,g),h.subVectors(o,s),u.subVectors(i,s),h.cross(u),a.fromBufferAttribute(n,m),l.fromBufferAttribute(n,v),c.fromBufferAttribute(n,g),a.add(h),l.add(h),c.add(h),n.setXYZ(m,a.x,a.y,a.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(g,c.x,c.y,c.z)}else for(let d=0,f=t.count;d<f;d+=3)i.fromBufferAttribute(t,d+0),s.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),h.subVectors(o,s),u.subVectors(i,s),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)ln.fromBufferAttribute(e,t),ln.normalize(),e.setXYZ(t,ln.x,ln.y,ln.z)}toNonIndexed(){function e(a,l){const c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h);let f=0,m=0;for(let v=0,g=l.length;v<g;v++){a.isInterleavedBufferAttribute?f=l[v]*a.data.stride+a.offset:f=l[v]*h;for(let p=0;p<h;p++)d[m++]=c[f++]}return new Rn(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new yt,n=this.index.array,i=this.attributes;for(const a in i){const l=i[a],c=e(l,n);t.setAttribute(a,c)}const s=this.morphAttributes;for(const a in s){const l=[],c=s[a];for(let h=0,u=c.length;h<u;h++){const d=c[h],f=e(d,n);l.push(f)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,l=o.length;a<l;a++){const c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const i={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){const f=c[u];h.push(f.toJSON(e.data))}h.length>0&&(i[l]=h,s=!0)}s&&(e.data.morphAttributes=i,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone(t));const i=e.attributes;for(const c in i){const h=i[c];this.setAttribute(c,h.clone(t))}const s=e.morphAttributes;for(const c in s){const h=[],u=s[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let c=0,h=o.length;c<h;c++){const u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Eh=new Te,ss=new Ts,mo=new _i,Th=new I,go=new I,_o=new I,vo=new I,el=new I,xo=new I,Ah=new I,yo=new I;class ve extends Ct{constructor(e=new yt,t=new qn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=i.length;s<o;s++){const a=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}getVertexPosition(e,t){const n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(i,e);const a=this.morphTargetInfluences;if(s&&a){xo.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const h=a[l],u=s[l];h!==0&&(el.fromBufferAttribute(u,e),o?xo.addScaledVector(el,h):xo.addScaledVector(el.sub(t),h))}t.add(xo)}return t}raycast(e,t){const n=this.geometry,i=this.material,s=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),mo.copy(n.boundingSphere),mo.applyMatrix4(s),ss.copy(e.ray).recast(e.near),!(mo.containsPoint(ss.origin)===!1&&(ss.intersectSphere(mo,Th)===null||ss.origin.distanceToSquared(Th)>(e.far-e.near)**2))&&(Eh.copy(s).invert(),ss.copy(e.ray).applyMatrix4(Eh),!(n.boundingBox!==null&&ss.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,ss)))}_computeIntersections(e,t,n){let i;const s=this.geometry,o=this.material,a=s.index,l=s.attributes.position,c=s.attributes.uv,h=s.attributes.uv1,u=s.attributes.normal,d=s.groups,f=s.drawRange;if(a!==null)if(Array.isArray(o))for(let m=0,v=d.length;m<v;m++){const g=d[m],p=o[g.materialIndex],M=Math.max(g.start,f.start),x=Math.min(a.count,Math.min(g.start+g.count,f.start+f.count));for(let b=M,D=x;b<D;b+=3){const R=a.getX(b),P=a.getX(b+1),S=a.getX(b+2);i=bo(this,p,e,n,c,h,u,R,P,S),i&&(i.faceIndex=Math.floor(b/3),i.face.materialIndex=g.materialIndex,t.push(i))}}else{const m=Math.max(0,f.start),v=Math.min(a.count,f.start+f.count);for(let g=m,p=v;g<p;g+=3){const M=a.getX(g),x=a.getX(g+1),b=a.getX(g+2);i=bo(this,o,e,n,c,h,u,M,x,b),i&&(i.faceIndex=Math.floor(g/3),t.push(i))}}else if(l!==void 0)if(Array.isArray(o))for(let m=0,v=d.length;m<v;m++){const g=d[m],p=o[g.materialIndex],M=Math.max(g.start,f.start),x=Math.min(l.count,Math.min(g.start+g.count,f.start+f.count));for(let b=M,D=x;b<D;b+=3){const R=b,P=b+1,S=b+2;i=bo(this,p,e,n,c,h,u,R,P,S),i&&(i.faceIndex=Math.floor(b/3),i.face.materialIndex=g.materialIndex,t.push(i))}}else{const m=Math.max(0,f.start),v=Math.min(l.count,f.start+f.count);for(let g=m,p=v;g<p;g+=3){const M=g,x=g+1,b=g+2;i=bo(this,o,e,n,c,h,u,M,x,b),i&&(i.faceIndex=Math.floor(g/3),t.push(i))}}}}function rm(r,e,t,n,i,s,o,a){let l;if(e.side===Un?l=n.intersectTriangle(o,s,i,!0,a):l=n.intersectTriangle(i,s,o,e.side===Ui,a),l===null)return null;yo.copy(a),yo.applyMatrix4(r.matrixWorld);const c=t.ray.origin.distanceTo(yo);return c<t.near||c>t.far?null:{distance:c,point:yo.clone(),object:r}}function bo(r,e,t,n,i,s,o,a,l,c){r.getVertexPosition(a,go),r.getVertexPosition(l,_o),r.getVertexPosition(c,vo);const h=rm(r,e,t,n,go,_o,vo,Ah);if(h){const u=new I;si.getBarycoord(Ah,go,_o,vo,u),i&&(h.uv=si.getInterpolatedAttribute(i,a,l,c,u,new ye)),s&&(h.uv1=si.getInterpolatedAttribute(s,a,l,c,u,new ye)),o&&(h.normal=si.getInterpolatedAttribute(o,a,l,c,u,new I),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a,b:l,c,normal:new I,materialIndex:0};si.getNormal(go,_o,vo,d.normal),h.face=d,h.barycoord=u}return h}class Yt extends yt{constructor(e=1,t=1,n=1,i=1,s=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:i,heightSegments:s,depthSegments:o};const a=this;i=Math.floor(i),s=Math.floor(s),o=Math.floor(o);const l=[],c=[],h=[],u=[];let d=0,f=0;m("z","y","x",-1,-1,n,t,e,o,s,0),m("z","y","x",1,-1,n,t,-e,o,s,1),m("x","z","y",1,1,e,n,t,i,o,2),m("x","z","y",1,-1,e,n,-t,i,o,3),m("x","y","z",1,-1,e,t,n,i,s,4),m("x","y","z",-1,-1,e,t,-n,i,s,5),this.setIndex(l),this.setAttribute("position",new Le(c,3)),this.setAttribute("normal",new Le(h,3)),this.setAttribute("uv",new Le(u,2));function m(v,g,p,M,x,b,D,R,P,S,_){const y=b/P,T=D/S,F=b/2,k=D/2,G=R/2,$=P+1,z=S+1;let Y=0,H=0;const q=new I;for(let ue=0;ue<z;ue++){const re=ue*T-k;for(let de=0;de<$;de++){const ie=de*y-F;q[v]=ie*M,q[g]=re*x,q[p]=G,c.push(q.x,q.y,q.z),q[v]=0,q[g]=0,q[p]=R>0?1:-1,h.push(q.x,q.y,q.z),u.push(de/P),u.push(1-ue/S),Y+=1}}for(let ue=0;ue<S;ue++)for(let re=0;re<P;re++){const de=d+re+$*ue,ie=d+re+$*(ue+1),W=d+(re+1)+$*(ue+1),Z=d+(re+1)+$*ue;l.push(de,ie,Z),l.push(ie,W,Z),H+=6}a.addGroup(f,H,_),f+=H,d+=Y}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Yt(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function fr(r){const e={};for(const t in r){e[t]={};for(const n in r[t]){const i=r[t][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=i.clone():Array.isArray(i)?e[t][n]=i.slice():e[t][n]=i}}return e}function Tn(r){const e={};for(let t=0;t<r.length;t++){const n=fr(r[t]);for(const i in n)e[i]=n[i]}return e}function om(r){const e=[];for(let t=0;t<r.length;t++)e.push(r[t].clone());return e}function Od(r){const e=r.getRenderTarget();return e===null?r.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:rt.workingColorSpace}const Bc={clone:fr,merge:Tn};var am=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,lm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class gi extends mi{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=am,this.fragmentShader=lm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=fr(e.uniforms),this.uniformsGroups=om(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const i in this.uniforms){const o=this.uniforms[i].value;o&&o.isTexture?t.uniforms[i]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[i]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[i]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[i]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[i]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[i]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[i]={type:"m4",value:o.toArray()}:t.uniforms[i]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class Bd extends Ct{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Te,this.projectionMatrix=new Te,this.projectionMatrixInverse=new Te,this.coordinateSystem=Di}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Gi=new I,Rh=new ye,Ch=new ye;class Qt extends Bd{constructor(e=50,t=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=dr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(Ir*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return dr*2*Math.atan(Math.tan(Ir*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Gi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Gi.x,Gi.y).multiplyScalar(-e/Gi.z),Gi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Gi.x,Gi.y).multiplyScalar(-e/Gi.z)}getViewSize(e,t){return this.getViewBounds(e,Rh,Ch),t.subVectors(Ch,Rh)}setViewOffset(e,t,n,i,s,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(Ir*.5*this.fov)/this.zoom,n=2*t,i=this.aspect*n,s=-.5*i;const o=this.view;if(this.view!==null&&this.view.enabled){const l=o.fullWidth,c=o.fullHeight;s+=o.offsetX*i/l,t-=o.offsetY*n/c,i*=o.width/l,n*=o.height/c}const a=this.filmOffset;a!==0&&(s+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Vs=-90,Gs=1;class cm extends Ct{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new Qt(Vs,Gs,e,t);i.layers=this.layers,this.add(i);const s=new Qt(Vs,Gs,e,t);s.layers=this.layers,this.add(s);const o=new Qt(Vs,Gs,e,t);o.layers=this.layers,this.add(o);const a=new Qt(Vs,Gs,e,t);a.layers=this.layers,this.add(a);const l=new Qt(Vs,Gs,e,t);l.layers=this.layers,this.add(l);const c=new Qt(Vs,Gs,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,i,s,o,a,l]=t;for(const c of t)this.remove(c);if(e===Di)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===ca)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,o,a,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,i),e.render(t,s),e.setRenderTarget(n,1,i),e.render(t,o),e.setRenderTarget(n,2,i),e.render(t,a),e.setRenderTarget(n,3,i),e.render(t,l),e.setRenderTarget(n,4,i),e.render(t,c),n.texture.generateMipmaps=v,e.setRenderTarget(n,5,i),e.render(t,h),e.setRenderTarget(u,d,f),e.xr.enabled=m,n.texture.needsPMREMUpdate=!0}}class kd extends qt{constructor(e,t,n,i,s,o,a,l,c,h){e=e!==void 0?e:[],t=t!==void 0?t:ar,super(e,t,n,i,s,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class hm extends ys{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},i=[n,n,n,n,n,n];this.texture=new kd(i,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:mn}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new Yt(5,5,5),s=new gi({name:"CubemapFromEquirect",uniforms:fr(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Un,blending:Qi});s.uniforms.tEquirect.value=t;const o=new ve(i,s),a=t.minFilter;return t.minFilter===Li&&(t.minFilter=mn),new cm(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,n,i){const s=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,i);e.setRenderTarget(s)}}class Mt extends Ct{constructor(){super(),this.isGroup=!0,this.type="Group"}}const um={type:"move"};class tl{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Mt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Mt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new I,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new I),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Mt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new I,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new I),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let i=null,s=null,o=null;const a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(const v of e.hand.values()){const g=t.getJointPose(v,n),p=this._getHandJoint(c,v);g!==null&&(p.matrix.fromArray(g.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=g.radius),p.visible=g!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,m=.005;c.inputState.pinching&&d>f+m?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=f-m&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(i=t.getPose(e.targetRaySpace,n),i===null&&s!==null&&(i=s),i!==null&&(a.matrix.fromArray(i.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,i.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(i.linearVelocity)):a.hasLinearVelocity=!1,i.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(i.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(um)))}return a!==null&&(a.visible=i!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new Mt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class mc extends Ct{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Kt,this.environmentIntensity=1,this.environmentRotation=new Kt,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class dm{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=pc,this.updateRanges=[],this.version=0,this.uuid=ri()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let i=0,s=this.stride;i<s;i++)this.array[e+i]=t.array[n+i];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ri()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ri()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const En=new I;class $i{constructor(e,t,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)En.fromBufferAttribute(this,t),En.applyMatrix4(e),this.setXYZ(t,En.x,En.y,En.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)En.fromBufferAttribute(this,t),En.applyNormalMatrix(e),this.setXYZ(t,En.x,En.y,En.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)En.fromBufferAttribute(this,t),En.transformDirection(e),this.setXYZ(t,En.x,En.y,En.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=ii(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=It(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=ii(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=ii(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=ii(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=ii(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=It(t,this.array),n=It(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array),s=It(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return new Rn(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new $i(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}const Ph=new I,Lh=new ct,Dh=new ct,fm=new I,Ih=new Te,Mo=new I,nl=new _i,Nh=new Te,il=new Ts;class zd extends ve{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=oh,this.bindMatrix=new Te,this.bindMatrixInverse=new Te,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new Cn),this.boundingBox.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Mo),this.boundingBox.expandByPoint(Mo)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new _i),this.boundingSphere.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Mo),this.boundingSphere.expandByPoint(Mo)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){const n=this.material,i=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),nl.copy(this.boundingSphere),nl.applyMatrix4(i),e.ray.intersectsSphere(nl)!==!1&&(Nh.copy(i).invert(),il.copy(e.ray).applyMatrix4(Nh),!(this.boundingBox!==null&&il.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,il)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new ct,t=this.geometry.attributes.skinWeight;for(let n=0,i=t.count;n<i;n++){e.fromBufferAttribute(t,n);const s=1/e.manhattanLength();s!==1/0?e.multiplyScalar(s):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===oh?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===hp?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){const n=this.skeleton,i=this.geometry;Lh.fromBufferAttribute(i.attributes.skinIndex,e),Dh.fromBufferAttribute(i.attributes.skinWeight,e),Ph.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let s=0;s<4;s++){const o=Dh.getComponent(s);if(o!==0){const a=Lh.getComponent(s);Ih.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(fm.copy(Ph).applyMatrix4(Ih),o)}}return t.applyMatrix4(this.bindMatrixInverse)}}class ha extends Ct{constructor(){super(),this.isBone=!0,this.type="Bone"}}class Hd extends qt{constructor(e=null,t=1,n=1,i,s,o,a,l,c=gn,h=gn,u,d){super(null,o,a,l,c,h,i,s,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Uh=new Te,pm=new Te;class va{constructor(e=[],t=[]){this.uuid=ri(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,i=this.bones.length;n<i;n++)this.boneInverses.push(new Te)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){const n=new Te;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){const e=this.bones,t=this.boneInverses,n=this.boneMatrices,i=this.boneTexture;for(let s=0,o=e.length;s<o;s++){const a=e[s]?e[s].matrixWorld:pm;Uh.multiplyMatrices(a,t[s]),Uh.toArray(n,s*16)}i!==null&&(i.needsUpdate=!0)}clone(){return new va(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const t=new Float32Array(e*e*4);t.set(this.boneMatrices);const n=new Hd(t,e,e,Sn,fi);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){const i=this.bones[t];if(i.name===e)return i}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,i=e.bones.length;n<i;n++){const s=e.bones[n];let o=t[s];o===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",s),o=new ha),this.bones.push(o),this.boneInverses.push(new Te().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){const e={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const t=this.bones,n=this.boneInverses;for(let i=0,s=t.length;i<s;i++){const o=t[i];e.bones.push(o.uuid);const a=n[i];e.boneInverses.push(a.toArray())}return e}}const sl=new I,mm=new I,gm=new lt;class Yi{constructor(e=new I(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,i){return this.normal.set(e,t,n),this.constant=i,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const i=sl.subVectors(n,t).cross(mm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(i,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(sl),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:t.copy(e.start).addScaledVector(n,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||gm.getNormalMatrix(e),i=this.coplanarPoint(sl).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const rs=new _i,So=new I;class xa{constructor(e=new Yi,t=new Yi,n=new Yi,i=new Yi,s=new Yi,o=new Yi){this.planes=[e,t,n,i,s,o]}set(e,t,n,i,s,o){const a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(i),a[4].copy(s),a[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Di){const n=this.planes,i=e.elements,s=i[0],o=i[1],a=i[2],l=i[3],c=i[4],h=i[5],u=i[6],d=i[7],f=i[8],m=i[9],v=i[10],g=i[11],p=i[12],M=i[13],x=i[14],b=i[15];if(n[0].setComponents(l-s,d-c,g-f,b-p).normalize(),n[1].setComponents(l+s,d+c,g+f,b+p).normalize(),n[2].setComponents(l+o,d+h,g+m,b+M).normalize(),n[3].setComponents(l-o,d-h,g-m,b-M).normalize(),n[4].setComponents(l-a,d-u,g-v,b-x).normalize(),t===Di)n[5].setComponents(l+a,d+u,g+v,b+x).normalize();else if(t===ca)n[5].setComponents(a,u,v,x).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),rs.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),rs.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(rs)}intersectsSprite(e){return rs.center.set(0,0,0),rs.radius=.7071067811865476,rs.applyMatrix4(e.matrixWorld),this.intersectsSphere(rs)}intersectsSphere(e){const t=this.planes,n=e.center,i=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const i=t[n];if(So.x=i.normal.x>0?e.max.x:e.min.x,So.y=i.normal.y>0?e.max.y:e.min.y,So.z=i.normal.z>0?e.max.z:e.min.z,i.distanceToPoint(So)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class jn extends mi{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new Ge(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const ua=new I,da=new I,Fh=new Te,Tr=new Ts,wo=new _i,rl=new I,Oh=new I;class Vn extends Ct{constructor(e=new yt,t=new jn){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let i=1,s=t.count;i<s;i++)ua.fromBufferAttribute(t,i-1),da.fromBufferAttribute(t,i),n[i]=n[i-1],n[i]+=ua.distanceTo(da);e.setAttribute("lineDistance",new Le(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,i=this.matrixWorld,s=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),wo.copy(n.boundingSphere),wo.applyMatrix4(i),wo.radius+=s,e.ray.intersectsSphere(wo)===!1)return;Fh.copy(i).invert(),Tr.copy(e.ray).applyMatrix4(Fh);const a=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){const f=Math.max(0,o.start),m=Math.min(h.count,o.start+o.count);for(let v=f,g=m-1;v<g;v+=c){const p=h.getX(v),M=h.getX(v+1),x=Eo(this,e,Tr,l,p,M,v);x&&t.push(x)}if(this.isLineLoop){const v=h.getX(m-1),g=h.getX(f),p=Eo(this,e,Tr,l,v,g,m-1);p&&t.push(p)}}else{const f=Math.max(0,o.start),m=Math.min(d.count,o.start+o.count);for(let v=f,g=m-1;v<g;v+=c){const p=Eo(this,e,Tr,l,v,v+1,v);p&&t.push(p)}if(this.isLineLoop){const v=Eo(this,e,Tr,l,m-1,f,m-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=i.length;s<o;s++){const a=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}}function Eo(r,e,t,n,i,s,o){const a=r.geometry.attributes.position;if(ua.fromBufferAttribute(a,i),da.fromBufferAttribute(a,s),t.distanceSqToSegment(ua,da,rl,Oh)>n)return;rl.applyMatrix4(r.matrixWorld);const c=e.ray.origin.distanceTo(rl);if(!(c<e.near||c>e.far))return{distance:c,point:Oh.clone().applyMatrix4(r.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:r}}const Bh=new I,kh=new I;class pr extends Vn{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let i=0,s=t.count;i<s;i+=2)Bh.fromBufferAttribute(t,i),kh.fromBufferAttribute(t,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+Bh.distanceTo(kh);e.setAttribute("lineDistance",new Le(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class Ji extends mi{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new Ge(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const zh=new Te,gc=new Ts,To=new _i,Ao=new I;class rr extends Ct{constructor(e=new yt,t=new Ji){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,i=this.matrixWorld,s=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),To.copy(n.boundingSphere),To.applyMatrix4(i),To.radius+=s,e.ray.intersectsSphere(To)===!1)return;zh.copy(i).invert(),gc.copy(e.ray).applyMatrix4(zh);const a=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,u=n.attributes.position;if(c!==null){const d=Math.max(0,o.start),f=Math.min(c.count,o.start+o.count);for(let m=d,v=f;m<v;m++){const g=c.getX(m);Ao.fromBufferAttribute(u,g),Hh(Ao,g,l,i,e,t,this)}}else{const d=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let m=d,v=f;m<v;m++)Ao.fromBufferAttribute(u,m),Hh(Ao,m,l,i,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=i.length;s<o;s++){const a=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}}function Hh(r,e,t,n,i,s,o){const a=gc.distanceSqToPoint(r);if(a<t){const l=new I;gc.closestPointToPoint(r,l),l.applyMatrix4(n);const c=i.ray.origin.distanceTo(l);if(c<i.near||c>i.far)return;s.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}class Vd extends qt{constructor(e,t,n,i,s,o,a,l,c,h=ir){if(h!==ir&&h!==hr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===ir&&(n=xs),n===void 0&&h===hr&&(n=cr),super(null,i,s,o,a,l,h,n,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:gn,this.minFilter=l!==void 0?l:gn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new Nc(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class _m{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){console.warn("THREE.Curve: .getPoint() not implemented.")}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,i=this.getPoint(0),s=0;t.push(0);for(let o=1;o<=e;o++)n=this.getPoint(o/e),s+=n.distanceTo(i),t.push(s),i=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const n=this.getLengths();let i=0;const s=n.length;let o;t?o=t:o=e*n[s-1];let a=0,l=s-1,c;for(;a<=l;)if(i=Math.floor(a+(l-a)/2),c=n[i]-o,c<0)a=i+1;else if(c>0)l=i-1;else{l=i;break}if(i=l,n[i]===o)return i/(s-1);const h=n[i],d=n[i+1]-h,f=(o-h)/d;return(i+f)/(s-1)}getTangent(e,t){let i=e-1e-4,s=e+1e-4;i<0&&(i=0),s>1&&(s=1);const o=this.getPoint(i),a=this.getPoint(s),l=t||(o.isVector2?new ye:new I);return l.copy(a).sub(o).normalize(),l}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){const n=new I,i=[],s=[],o=[],a=new I,l=new Te;for(let f=0;f<=e;f++){const m=f/e;i[f]=this.getTangentAt(m,new I)}s[0]=new I,o[0]=new I;let c=Number.MAX_VALUE;const h=Math.abs(i[0].x),u=Math.abs(i[0].y),d=Math.abs(i[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),a.crossVectors(i[0],n).normalize(),s[0].crossVectors(i[0],a),o[0].crossVectors(i[0],s[0]);for(let f=1;f<=e;f++){if(s[f]=s[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(i[f-1],i[f]),a.length()>Number.EPSILON){a.normalize();const m=Math.acos(dt(i[f-1].dot(i[f]),-1,1));s[f].applyMatrix4(l.makeRotationAxis(a,m))}o[f].crossVectors(i[f],s[f])}if(t===!0){let f=Math.acos(dt(s[0].dot(s[e]),-1,1));f/=e,i[0].dot(a.crossVectors(s[0],s[e]))>0&&(f=-f);for(let m=1;m<=e;m++)s[m].applyMatrix4(l.makeRotationAxis(i[m],f*m)),o[m].crossVectors(i[m],s[m])}return{tangents:i,normals:s,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class cn extends yt{constructor(e=1,t=1,n=1,i=32,s=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:i,heightSegments:s,openEnded:o,thetaStart:a,thetaLength:l};const c=this;i=Math.floor(i),s=Math.floor(s);const h=[],u=[],d=[],f=[];let m=0;const v=[],g=n/2;let p=0;M(),o===!1&&(e>0&&x(!0),t>0&&x(!1)),this.setIndex(h),this.setAttribute("position",new Le(u,3)),this.setAttribute("normal",new Le(d,3)),this.setAttribute("uv",new Le(f,2));function M(){const b=new I,D=new I;let R=0;const P=(t-e)/n;for(let S=0;S<=s;S++){const _=[],y=S/s,T=y*(t-e)+e;for(let F=0;F<=i;F++){const k=F/i,G=k*l+a,$=Math.sin(G),z=Math.cos(G);D.x=T*$,D.y=-y*n+g,D.z=T*z,u.push(D.x,D.y,D.z),b.set($,P,z).normalize(),d.push(b.x,b.y,b.z),f.push(k,1-y),_.push(m++)}v.push(_)}for(let S=0;S<i;S++)for(let _=0;_<s;_++){const y=v[_][S],T=v[_+1][S],F=v[_+1][S+1],k=v[_][S+1];(e>0||_!==0)&&(h.push(y,T,k),R+=3),(t>0||_!==s-1)&&(h.push(T,F,k),R+=3)}c.addGroup(p,R,0),p+=R}function x(b){const D=m,R=new ye,P=new I;let S=0;const _=b===!0?e:t,y=b===!0?1:-1;for(let F=1;F<=i;F++)u.push(0,g*y,0),d.push(0,y,0),f.push(.5,.5),m++;const T=m;for(let F=0;F<=i;F++){const G=F/i*l+a,$=Math.cos(G),z=Math.sin(G);P.x=_*z,P.y=g*y,P.z=_*$,u.push(P.x,P.y,P.z),d.push(0,y,0),R.x=$*.5+.5,R.y=z*.5*y+.5,f.push(R.x,R.y),m++}for(let F=0;F<i;F++){const k=D+F,G=T+F;b===!0?h.push(G,G+1,k):h.push(G+1,G,k),S+=3}c.addGroup(p,S,b===!0?1:2),p+=S}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new cn(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class kc extends yt{constructor(e=[],t=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:i};const s=[],o=[];a(i),c(n),h(),this.setAttribute("position",new Le(s,3)),this.setAttribute("normal",new Le(s.slice(),3)),this.setAttribute("uv",new Le(o,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function a(M){const x=new I,b=new I,D=new I;for(let R=0;R<t.length;R+=3)f(t[R+0],x),f(t[R+1],b),f(t[R+2],D),l(x,b,D,M)}function l(M,x,b,D){const R=D+1,P=[];for(let S=0;S<=R;S++){P[S]=[];const _=M.clone().lerp(b,S/R),y=x.clone().lerp(b,S/R),T=R-S;for(let F=0;F<=T;F++)F===0&&S===R?P[S][F]=_:P[S][F]=_.clone().lerp(y,F/T)}for(let S=0;S<R;S++)for(let _=0;_<2*(R-S)-1;_++){const y=Math.floor(_/2);_%2===0?(d(P[S][y+1]),d(P[S+1][y]),d(P[S][y])):(d(P[S][y+1]),d(P[S+1][y+1]),d(P[S+1][y]))}}function c(M){const x=new I;for(let b=0;b<s.length;b+=3)x.x=s[b+0],x.y=s[b+1],x.z=s[b+2],x.normalize().multiplyScalar(M),s[b+0]=x.x,s[b+1]=x.y,s[b+2]=x.z}function h(){const M=new I;for(let x=0;x<s.length;x+=3){M.x=s[x+0],M.y=s[x+1],M.z=s[x+2];const b=g(M)/2/Math.PI+.5,D=p(M)/Math.PI+.5;o.push(b,1-D)}m(),u()}function u(){for(let M=0;M<o.length;M+=6){const x=o[M+0],b=o[M+2],D=o[M+4],R=Math.max(x,b,D),P=Math.min(x,b,D);R>.9&&P<.1&&(x<.2&&(o[M+0]+=1),b<.2&&(o[M+2]+=1),D<.2&&(o[M+4]+=1))}}function d(M){s.push(M.x,M.y,M.z)}function f(M,x){const b=M*3;x.x=e[b+0],x.y=e[b+1],x.z=e[b+2]}function m(){const M=new I,x=new I,b=new I,D=new I,R=new ye,P=new ye,S=new ye;for(let _=0,y=0;_<s.length;_+=9,y+=6){M.set(s[_+0],s[_+1],s[_+2]),x.set(s[_+3],s[_+4],s[_+5]),b.set(s[_+6],s[_+7],s[_+8]),R.set(o[y+0],o[y+1]),P.set(o[y+2],o[y+3]),S.set(o[y+4],o[y+5]),D.copy(M).add(x).add(b).divideScalar(3);const T=g(D);v(R,y+0,M,T),v(P,y+2,x,T),v(S,y+4,b,T)}}function v(M,x,b,D){D<0&&M.x===1&&(o[x]=M.x-1),b.x===0&&b.z===0&&(o[x]=D/2/Math.PI+.5)}function g(M){return Math.atan2(M.z,-M.x)}function p(M){return Math.atan2(-M.y,Math.sqrt(M.x*M.x+M.z*M.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new kc(e.vertices,e.indices,e.radius,e.details)}}class vm{static triangulate(e,t,n=2){const i=t&&t.length,s=i?t[0]*n:e.length;let o=Gd(e,0,s,n,!0);const a=[];if(!o||o.next===o.prev)return a;let l,c,h,u,d,f,m;if(i&&(o=Sm(e,t,o,n)),e.length>80*n){l=h=e[0],c=u=e[1];for(let v=n;v<s;v+=n)d=e[v],f=e[v+1],d<l&&(l=d),f<c&&(c=f),d>h&&(h=d),f>u&&(u=f);m=Math.max(h-l,u-c),m=m!==0?32767/m:0}return Br(o,a,n,l,c,m,0),a}}function Gd(r,e,t,n,i){let s,o;if(i===Nm(r,e,t,n)>0)for(s=e;s<t;s+=n)o=Vh(s,r[s],r[s+1],o);else for(s=t-n;s>=e;s-=n)o=Vh(s,r[s],r[s+1],o);return o&&ya(o,o.next)&&(zr(o),o=o.next),o}function bs(r,e){if(!r)return r;e||(e=r);let t=r,n;do if(n=!1,!t.steiner&&(ya(t,t.next)||Xt(t.prev,t,t.next)===0)){if(zr(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function Br(r,e,t,n,i,s,o){if(!r)return;!o&&s&&Rm(r,n,i,s);let a=r,l,c;for(;r.prev!==r.next;){if(l=r.prev,c=r.next,s?ym(r,n,i,s):xm(r)){e.push(l.i/t|0),e.push(r.i/t|0),e.push(c.i/t|0),zr(r),r=c.next,a=c.next;continue}if(r=c,r===a){o?o===1?(r=bm(bs(r),e,t),Br(r,e,t,n,i,s,2)):o===2&&Mm(r,e,t,n,i,s):Br(bs(r),e,t,n,i,s,1);break}}}function xm(r){const e=r.prev,t=r,n=r.next;if(Xt(e,t,n)>=0)return!1;const i=e.x,s=t.x,o=n.x,a=e.y,l=t.y,c=n.y,h=i<s?i<o?i:o:s<o?s:o,u=a<l?a<c?a:c:l<c?l:c,d=i>s?i>o?i:o:s>o?s:o,f=a>l?a>c?a:c:l>c?l:c;let m=n.next;for(;m!==e;){if(m.x>=h&&m.x<=d&&m.y>=u&&m.y<=f&&Ks(i,a,s,l,o,c,m.x,m.y)&&Xt(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function ym(r,e,t,n){const i=r.prev,s=r,o=r.next;if(Xt(i,s,o)>=0)return!1;const a=i.x,l=s.x,c=o.x,h=i.y,u=s.y,d=o.y,f=a<l?a<c?a:c:l<c?l:c,m=h<u?h<d?h:d:u<d?u:d,v=a>l?a>c?a:c:l>c?l:c,g=h>u?h>d?h:d:u>d?u:d,p=_c(f,m,e,t,n),M=_c(v,g,e,t,n);let x=r.prevZ,b=r.nextZ;for(;x&&x.z>=p&&b&&b.z<=M;){if(x.x>=f&&x.x<=v&&x.y>=m&&x.y<=g&&x!==i&&x!==o&&Ks(a,h,l,u,c,d,x.x,x.y)&&Xt(x.prev,x,x.next)>=0||(x=x.prevZ,b.x>=f&&b.x<=v&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&Ks(a,h,l,u,c,d,b.x,b.y)&&Xt(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;x&&x.z>=p;){if(x.x>=f&&x.x<=v&&x.y>=m&&x.y<=g&&x!==i&&x!==o&&Ks(a,h,l,u,c,d,x.x,x.y)&&Xt(x.prev,x,x.next)>=0)return!1;x=x.prevZ}for(;b&&b.z<=M;){if(b.x>=f&&b.x<=v&&b.y>=m&&b.y<=g&&b!==i&&b!==o&&Ks(a,h,l,u,c,d,b.x,b.y)&&Xt(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function bm(r,e,t){let n=r;do{const i=n.prev,s=n.next.next;!ya(i,s)&&Wd(i,n,n.next,s)&&kr(i,s)&&kr(s,i)&&(e.push(i.i/t|0),e.push(n.i/t|0),e.push(s.i/t|0),zr(n),zr(n.next),n=r=s),n=n.next}while(n!==r);return bs(n)}function Mm(r,e,t,n,i,s){let o=r;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&Lm(o,a)){let l=Xd(o,a);o=bs(o,o.next),l=bs(l,l.next),Br(o,e,t,n,i,s,0),Br(l,e,t,n,i,s,0);return}a=a.next}o=o.next}while(o!==r)}function Sm(r,e,t,n){const i=[];let s,o,a,l,c;for(s=0,o=e.length;s<o;s++)a=e[s]*n,l=s<o-1?e[s+1]*n:r.length,c=Gd(r,a,l,n,!1),c===c.next&&(c.steiner=!0),i.push(Pm(c));for(i.sort(wm),s=0;s<i.length;s++)t=Em(i[s],t);return t}function wm(r,e){return r.x-e.x}function Em(r,e){const t=Tm(r,e);if(!t)return e;const n=Xd(t,r);return bs(n,n.next),bs(t,t.next)}function Tm(r,e){let t=e,n=-1/0,i;const s=r.x,o=r.y;do{if(o<=t.y&&o>=t.next.y&&t.next.y!==t.y){const d=t.x+(o-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(d<=s&&d>n&&(n=d,i=t.x<t.next.x?t:t.next,d===s))return i}t=t.next}while(t!==e);if(!i)return null;const a=i,l=i.x,c=i.y;let h=1/0,u;t=i;do s>=t.x&&t.x>=l&&s!==t.x&&Ks(o<c?s:n,o,l,c,o<c?n:s,o,t.x,t.y)&&(u=Math.abs(o-t.y)/(s-t.x),kr(t,r)&&(u<h||u===h&&(t.x>i.x||t.x===i.x&&Am(i,t)))&&(i=t,h=u)),t=t.next;while(t!==a);return i}function Am(r,e){return Xt(r.prev,r,e.prev)<0&&Xt(e.next,r,r.next)<0}function Rm(r,e,t,n){let i=r;do i.z===0&&(i.z=_c(i.x,i.y,e,t,n)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==r);i.prevZ.nextZ=null,i.prevZ=null,Cm(i)}function Cm(r){let e,t,n,i,s,o,a,l,c=1;do{for(t=r,r=null,s=null,o=0;t;){for(o++,n=t,a=0,e=0;e<c&&(a++,n=n.nextZ,!!n);e++);for(l=c;a>0||l>0&&n;)a!==0&&(l===0||!n||t.z<=n.z)?(i=t,t=t.nextZ,a--):(i=n,n=n.nextZ,l--),s?s.nextZ=i:r=i,i.prevZ=s,s=i;t=n}s.nextZ=null,c*=2}while(o>1);return r}function _c(r,e,t,n,i){return r=(r-t)*i|0,e=(e-n)*i|0,r=(r|r<<8)&16711935,r=(r|r<<4)&252645135,r=(r|r<<2)&858993459,r=(r|r<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,r|e<<1}function Pm(r){let e=r,t=r;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==r);return t}function Ks(r,e,t,n,i,s,o,a){return(i-o)*(e-a)>=(r-o)*(s-a)&&(r-o)*(n-a)>=(t-o)*(e-a)&&(t-o)*(s-a)>=(i-o)*(n-a)}function Lm(r,e){return r.next.i!==e.i&&r.prev.i!==e.i&&!Dm(r,e)&&(kr(r,e)&&kr(e,r)&&Im(r,e)&&(Xt(r.prev,r,e.prev)||Xt(r,e.prev,e))||ya(r,e)&&Xt(r.prev,r,r.next)>0&&Xt(e.prev,e,e.next)>0)}function Xt(r,e,t){return(e.y-r.y)*(t.x-e.x)-(e.x-r.x)*(t.y-e.y)}function ya(r,e){return r.x===e.x&&r.y===e.y}function Wd(r,e,t,n){const i=Co(Xt(r,e,t)),s=Co(Xt(r,e,n)),o=Co(Xt(t,n,r)),a=Co(Xt(t,n,e));return!!(i!==s&&o!==a||i===0&&Ro(r,t,e)||s===0&&Ro(r,n,e)||o===0&&Ro(t,r,n)||a===0&&Ro(t,e,n))}function Ro(r,e,t){return e.x<=Math.max(r.x,t.x)&&e.x>=Math.min(r.x,t.x)&&e.y<=Math.max(r.y,t.y)&&e.y>=Math.min(r.y,t.y)}function Co(r){return r>0?1:r<0?-1:0}function Dm(r,e){let t=r;do{if(t.i!==r.i&&t.next.i!==r.i&&t.i!==e.i&&t.next.i!==e.i&&Wd(t,t.next,r,e))return!0;t=t.next}while(t!==r);return!1}function kr(r,e){return Xt(r.prev,r,r.next)<0?Xt(r,e,r.next)>=0&&Xt(r,r.prev,e)>=0:Xt(r,e,r.prev)<0||Xt(r,r.next,e)<0}function Im(r,e){let t=r,n=!1;const i=(r.x+e.x)/2,s=(r.y+e.y)/2;do t.y>s!=t.next.y>s&&t.next.y!==t.y&&i<(t.next.x-t.x)*(s-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==r);return n}function Xd(r,e){const t=new vc(r.i,r.x,r.y),n=new vc(e.i,e.x,e.y),i=r.next,s=e.prev;return r.next=e,e.prev=r,t.next=i,i.prev=t,n.next=t,t.prev=n,s.next=n,n.prev=s,n}function Vh(r,e,t,n){const i=new vc(r,e,t);return n?(i.next=n.next,i.prev=n,n.next.prev=i,n.next=i):(i.prev=i,i.next=i),i}function zr(r){r.next.prev=r.prev,r.prev.next=r.next,r.prevZ&&(r.prevZ.nextZ=r.nextZ),r.nextZ&&(r.nextZ.prevZ=r.prevZ)}function vc(r,e,t){this.i=r,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function Nm(r,e,t,n){let i=0;for(let s=e,o=t-n;s<t;s+=n)i+=(r[o]-r[s])*(r[s+1]+r[o+1]),o=s;return i}class zc{static area(e){const t=e.length;let n=0;for(let i=t-1,s=0;s<t;i=s++)n+=e[i].x*e[s].y-e[s].x*e[i].y;return n*.5}static isClockWise(e){return zc.area(e)<0}static triangulateShape(e,t){const n=[],i=[],s=[];Gh(e),Wh(n,e);let o=e.length;t.forEach(Gh);for(let l=0;l<t.length;l++)i.push(o),o+=t[l].length,Wh(n,t[l]);const a=vm.triangulate(n,i);for(let l=0;l<a.length;l+=3)s.push(a.slice(l,l+3));return s}}function Gh(r){const e=r.length;e>2&&r[e-1].equals(r[0])&&r.pop()}function Wh(r,e){for(let t=0;t<e.length;t++)r.push(e[t].x),r.push(e[t].y)}class $s extends kc{constructor(e=1,t=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],i=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,i,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new $s(e.radius,e.detail)}}class mr extends yt{constructor(e=1,t=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:i};const s=e/2,o=t/2,a=Math.floor(n),l=Math.floor(i),c=a+1,h=l+1,u=e/a,d=t/l,f=[],m=[],v=[],g=[];for(let p=0;p<h;p++){const M=p*d-o;for(let x=0;x<c;x++){const b=x*u-s;m.push(b,-M,0),v.push(0,0,1),g.push(x/a),g.push(1-p/l)}}for(let p=0;p<l;p++)for(let M=0;M<a;M++){const x=M+c*p,b=M+c*(p+1),D=M+1+c*(p+1),R=M+1+c*p;f.push(x,b,R),f.push(b,D,R)}this.setIndex(f),this.setAttribute("position",new Le(m,3)),this.setAttribute("normal",new Le(v,3)),this.setAttribute("uv",new Le(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new mr(e.width,e.height,e.widthSegments,e.heightSegments)}}class jr extends yt{constructor(e=1,t=32,n=16,i=0,s=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:i,phiLength:s,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(o+a,Math.PI);let c=0;const h=[],u=new I,d=new I,f=[],m=[],v=[],g=[];for(let p=0;p<=n;p++){const M=[],x=p/n;let b=0;p===0&&o===0?b=.5/t:p===n&&l===Math.PI&&(b=-.5/t);for(let D=0;D<=t;D++){const R=D/t;u.x=-e*Math.cos(i+R*s)*Math.sin(o+x*a),u.y=e*Math.cos(o+x*a),u.z=e*Math.sin(i+R*s)*Math.sin(o+x*a),m.push(u.x,u.y,u.z),d.copy(u).normalize(),v.push(d.x,d.y,d.z),g.push(R+b,1-x),M.push(c++)}h.push(M)}for(let p=0;p<n;p++)for(let M=0;M<t;M++){const x=h[p][M+1],b=h[p][M],D=h[p+1][M],R=h[p+1][M+1];(p!==0||o>0)&&f.push(x,b,R),(p!==n-1||l<Math.PI)&&f.push(b,D,R)}this.setIndex(f),this.setAttribute("position",new Le(m,3)),this.setAttribute("normal",new Le(v,3)),this.setAttribute("uv",new Le(g,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new jr(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class ps extends yt{constructor(e=1,t=.4,n=12,i=48,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:i,arc:s},n=Math.floor(n),i=Math.floor(i);const o=[],a=[],l=[],c=[],h=new I,u=new I,d=new I;for(let f=0;f<=n;f++)for(let m=0;m<=i;m++){const v=m/i*s,g=f/n*Math.PI*2;u.x=(e+t*Math.cos(g))*Math.cos(v),u.y=(e+t*Math.cos(g))*Math.sin(v),u.z=t*Math.sin(g),a.push(u.x,u.y,u.z),h.x=e*Math.cos(v),h.y=e*Math.sin(v),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(m/i),c.push(f/n)}for(let f=1;f<=n;f++)for(let m=1;m<=i;m++){const v=(i+1)*f+m-1,g=(i+1)*(f-1)+m-1,p=(i+1)*(f-1)+m,M=(i+1)*f+m;o.push(v,g,M),o.push(g,p,M)}this.setIndex(o),this.setAttribute("position",new Le(a,3)),this.setAttribute("normal",new Le(l,3)),this.setAttribute("uv",new Le(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ps(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class Um extends yt{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){const t=[],n=new Set,i=new I,s=new I;if(e.index!==null){const o=e.attributes.position,a=e.index;let l=e.groups;l.length===0&&(l=[{start:0,count:a.count,materialIndex:0}]);for(let c=0,h=l.length;c<h;++c){const u=l[c],d=u.start,f=u.count;for(let m=d,v=d+f;m<v;m+=3)for(let g=0;g<3;g++){const p=a.getX(m+g),M=a.getX(m+(g+1)%3);i.fromBufferAttribute(o,p),s.fromBufferAttribute(o,M),Xh(i,s,n)===!0&&(t.push(i.x,i.y,i.z),t.push(s.x,s.y,s.z))}}}else{const o=e.attributes.position;for(let a=0,l=o.count/3;a<l;a++)for(let c=0;c<3;c++){const h=3*a+c,u=3*a+(c+1)%3;i.fromBufferAttribute(o,h),s.fromBufferAttribute(o,u),Xh(i,s,n)===!0&&(t.push(i.x,i.y,i.z),t.push(s.x,s.y,s.z))}}this.setAttribute("position",new Le(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}function Xh(r,e,t){const n=`${r.x},${r.y},${r.z}-${e.x},${e.y},${e.z}`,i=`${e.x},${e.y},${e.z}-${r.x},${r.y},${r.z}`;return t.has(n)===!0||t.has(i)===!0?!1:(t.add(n),t.add(i),!0)}class kn extends mi{constructor(e){super(),this.isMeshPhongMaterial=!0,this.type="MeshPhongMaterial",this.color=new Ge(16777215),this.specular=new Ge(1118481),this.shininess=30,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ge(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Dc,this.normalScale=new ye(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Kt,this.combine=ga,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.specular.copy(e.specular),this.shininess=e.shininess,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Hr extends mi{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new Ge(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new Ge(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Dc,this.normalScale=new ye(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Kt,this.combine=ga,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Fm extends mi{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=fp,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class Om extends mi{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function Po(r,e,t){return!r||!t&&r.constructor===e?r:typeof e.BYTES_PER_ELEMENT=="number"?new e(r):Array.prototype.slice.call(r)}function Bm(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}function km(r){function e(i,s){return r[i]-r[s]}const t=r.length,n=new Array(t);for(let i=0;i!==t;++i)n[i]=i;return n.sort(e),n}function jh(r,e,t){const n=r.length,i=new r.constructor(n);for(let s=0,o=0;o!==n;++s){const a=t[s]*e;for(let l=0;l!==e;++l)i[o++]=r[a+l]}return i}function jd(r,e,t,n){let i=1,s=r[0];for(;s!==void 0&&s[n]===void 0;)s=r[i++];if(s===void 0)return;let o=s[n];if(o!==void 0)if(Array.isArray(o))do o=s[n],o!==void 0&&(e.push(s.time),t.push(...o)),s=r[i++];while(s!==void 0);else if(o.toArray!==void 0)do o=s[n],o!==void 0&&(e.push(s.time),o.toArray(t,t.length)),s=r[i++];while(s!==void 0);else do o=s[n],o!==void 0&&(e.push(s.time),t.push(o)),s=r[i++];while(s!==void 0)}class ba{constructor(e,t,n,i){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){const t=this.parameterPositions;let n=this._cachedIndex,i=t[n],s=t[n-1];n:{e:{let o;t:{i:if(!(e<i)){for(let a=n+2;;){if(i===void 0){if(e<s)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(s=i,i=t[++n],e<i)break e}o=t.length;break t}if(!(e>=s)){const a=t[1];e<a&&(n=2,s=a);for(let l=n-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(i=s,s=t[--n-1],e>=s)break e}o=n,n=0;break t}break n}for(;n<o;){const a=n+o>>>1;e<t[a]?o=a:n=a+1}if(i=t[n],s=t[n-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,s,i)}return this.interpolate_(n,s,e,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,i=this.valueSize,s=e*i;for(let o=0;o!==i;++o)t[o]=n[s+o];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}}class zm extends ba{constructor(e,t,n,i){super(e,t,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:ah,endingEnd:ah}}intervalChanged_(e,t,n){const i=this.parameterPositions;let s=e-2,o=e+1,a=i[s],l=i[o];if(a===void 0)switch(this.getSettings_().endingStart){case lh:s=e,a=2*t-n;break;case ch:s=i.length-2,a=t+i[s]-i[s+1];break;default:s=e,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case lh:o=e,l=2*n-t;break;case ch:o=1,l=n+i[1]-i[0];break;default:o=e-1,l=t}const c=(n-t)*.5,h=this.valueSize;this._weightPrev=c/(t-a),this._weightNext=c/(l-n),this._offsetPrev=s*h,this._offsetNext=o*h}interpolate_(e,t,n,i){const s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,m=(n-t)/(i-t),v=m*m,g=v*m,p=-d*g+2*d*v-d*m,M=(1+d)*g+(-1.5-2*d)*v+(-.5+d)*m+1,x=(-1-f)*g+(1.5+f)*v+.5*m,b=f*g-f*v;for(let D=0;D!==a;++D)s[D]=p*o[h+D]+M*o[c+D]+x*o[l+D]+b*o[u+D];return s}}class Hm extends ba{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){const s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=(n-t)/(i-t),u=1-h;for(let d=0;d!==a;++d)s[d]=o[c+d]*u+o[l+d]*h;return s}}class Vm extends ba{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e){return this.copySampleValue_(e-1)}}class vi{constructor(e,t,n,i){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Po(t,this.TimeBufferType),this.values=Po(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(e){const t=e.constructor;let n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Po(e.times,Array),values:Po(e.values,Array)};const i=e.getInterpolation();i!==e.DefaultInterpolation&&(n.interpolation=i)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new Vm(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new Hm(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new zm(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case aa:t=this.InterpolantFactoryMethodDiscrete;break;case fc:t=this.InterpolantFactoryMethodLinear;break;case Ua:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){const n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return aa;case this.InterpolantFactoryMethodLinear:return fc;case this.InterpolantFactoryMethodSmooth:return Ua}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]+=e}return this}scale(e){if(e!==1){const t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]*=e}return this}trim(e,t){const n=this.times,i=n.length;let s=0,o=i-1;for(;s!==i&&n[s]<e;)++s;for(;o!==-1&&n[o]>t;)--o;if(++o,s!==0||o!==i){s>=o&&(o=Math.max(o,1),s=o-1);const a=this.getValueSize();this.times=n.slice(s,o),this.values=this.values.slice(s*a,o*a)}return this}validate(){let e=!0;const t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);const n=this.times,i=this.values,s=n.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==s;a++){const l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),e=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),e=!1;break}o=l}if(i!==void 0&&Bm(i))for(let a=0,l=i.length;a!==l;++a){const c=i[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),e=!1;break}}return e}optimize(){const e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===Ua,s=e.length-1;let o=1;for(let a=1;a<s;++a){let l=!1;const c=e[a],h=e[a+1];if(c!==h&&(a!==1||c!==e[0]))if(i)l=!0;else{const u=a*n,d=u-n,f=u+n;for(let m=0;m!==n;++m){const v=t[u+m];if(v!==t[d+m]||v!==t[f+m]){l=!0;break}}}if(l){if(a!==o){e[o]=e[a];const u=a*n,d=o*n;for(let f=0;f!==n;++f)t[d+f]=t[u+f]}++o}}if(s>0){e[o]=e[s];for(let a=s*n,l=o*n,c=0;c!==n;++c)t[l+c]=t[a+c];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*n)):(this.times=e,this.values=t),this}clone(){const e=this.times.slice(),t=this.values.slice(),n=this.constructor,i=new n(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}}vi.prototype.TimeBufferType=Float32Array;vi.prototype.ValueBufferType=Float32Array;vi.prototype.DefaultInterpolation=fc;class gr extends vi{constructor(e,t,n){super(e,t,n)}}gr.prototype.ValueTypeName="bool";gr.prototype.ValueBufferType=Array;gr.prototype.DefaultInterpolation=aa;gr.prototype.InterpolantFactoryMethodLinear=void 0;gr.prototype.InterpolantFactoryMethodSmooth=void 0;class qd extends vi{}qd.prototype.ValueTypeName="color";class Vr extends vi{}Vr.prototype.ValueTypeName="number";class Gm extends ba{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){const s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-t)/(i-t);let c=e*a;for(let h=c+a;c!==h;c+=4)Pt.slerpFlat(s,0,o,c-a,o,c,l);return s}}class Ms extends vi{InterpolantFactoryMethodLinear(e){return new Gm(this.times,this.values,this.getValueSize(),e)}}Ms.prototype.ValueTypeName="quaternion";Ms.prototype.InterpolantFactoryMethodSmooth=void 0;class _r extends vi{constructor(e,t,n){super(e,t,n)}}_r.prototype.ValueTypeName="string";_r.prototype.ValueBufferType=Array;_r.prototype.DefaultInterpolation=aa;_r.prototype.InterpolantFactoryMethodLinear=void 0;_r.prototype.InterpolantFactoryMethodSmooth=void 0;class Ss extends vi{}Ss.prototype.ValueTypeName="vector";class xc{constructor(e="",t=-1,n=[],i=dp){this.name=e,this.tracks=n,this.duration=t,this.blendMode=i,this.uuid=ri(),this.duration<0&&this.resetDuration()}static parse(e){const t=[],n=e.tracks,i=1/(e.fps||1);for(let o=0,a=n.length;o!==a;++o)t.push(Xm(n[o]).scale(i));const s=new this(e.name,e.duration,t,e.blendMode);return s.uuid=e.uuid,s}static toJSON(e){const t=[],n=e.tracks,i={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let s=0,o=n.length;s!==o;++s)t.push(vi.toJSON(n[s]));return i}static CreateFromMorphTargetSequence(e,t,n,i){const s=t.length,o=[];for(let a=0;a<s;a++){let l=[],c=[];l.push((a+s-1)%s,a,(a+1)%s),c.push(0,1,0);const h=km(l);l=jh(l,1,h),c=jh(c,1,h),!i&&l[0]===0&&(l.push(s),c.push(c[0])),o.push(new Vr(".morphTargetInfluences["+t[a].name+"]",l,c).scale(1/n))}return new this(e,-1,o)}static findByName(e,t){let n=e;if(!Array.isArray(e)){const i=e;n=i.geometry&&i.geometry.animations||i.animations}for(let i=0;i<n.length;i++)if(n[i].name===t)return n[i];return null}static CreateClipsFromMorphTargetSequences(e,t,n){const i={},s=/^([\w-]*?)([\d]+)$/;for(let a=0,l=e.length;a<l;a++){const c=e[a],h=c.name.match(s);if(h&&h.length>1){const u=h[1];let d=i[u];d||(i[u]=d=[]),d.push(c)}}const o=[];for(const a in i)o.push(this.CreateFromMorphTargetSequence(a,i[a],t,n));return o}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;const n=function(u,d,f,m,v){if(f.length!==0){const g=[],p=[];jd(f,g,p,m),g.length!==0&&v.push(new u(d,g,p))}},i=[],s=e.name||"default",o=e.fps||30,a=e.blendMode;let l=e.length||-1;const c=e.hierarchy||[];for(let u=0;u<c.length;u++){const d=c[u].keys;if(!(!d||d.length===0))if(d[0].morphTargets){const f={};let m;for(m=0;m<d.length;m++)if(d[m].morphTargets)for(let v=0;v<d[m].morphTargets.length;v++)f[d[m].morphTargets[v]]=-1;for(const v in f){const g=[],p=[];for(let M=0;M!==d[m].morphTargets.length;++M){const x=d[m];g.push(x.time),p.push(x.morphTarget===v?1:0)}i.push(new Vr(".morphTargetInfluence["+v+"]",g,p))}l=f.length*o}else{const f=".bones["+t[u].name+"]";n(Ss,f+".position",d,"pos",i),n(Ms,f+".quaternion",d,"rot",i),n(Ss,f+".scale",d,"scl",i)}}return i.length===0?null:new this(s,l,i,a)}resetDuration(){const e=this.tracks;let t=0;for(let n=0,i=e.length;n!==i;++n){const s=this.tracks[n];t=Math.max(t,s.times[s.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}}function Wm(r){switch(r.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return Vr;case"vector":case"vector2":case"vector3":case"vector4":return Ss;case"color":return qd;case"quaternion":return Ms;case"bool":case"boolean":return gr;case"string":return _r}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+r)}function Xm(r){if(r.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=Wm(r.type);if(r.times===void 0){const t=[],n=[];jd(r.keys,t,n,"value"),r.times=t,r.values=n}return e.parse!==void 0?e.parse(r):new e(r.name,r.times,r.values,r.interpolation)}const fa={enabled:!1,files:{},add:function(r,e){this.enabled!==!1&&(this.files[r]=e)},get:function(r){if(this.enabled!==!1)return this.files[r]},remove:function(r){delete this.files[r]},clear:function(){this.files={}}};class Yd{constructor(e,t,n){const i=this;let s=!1,o=0,a=0,l;const c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(h){a++,s===!1&&i.onStart!==void 0&&i.onStart(h,o,a),s=!0},this.itemEnd=function(h){o++,i.onProgress!==void 0&&i.onProgress(h,o,a),o===a&&(s=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(h){i.onError!==void 0&&i.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){const u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){const f=c[u],m=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return m}return null}}}const Zd=new Yd;class Yn{constructor(e){this.manager=e!==void 0?e:Zd,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(i,s){n.load(e,i,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}}Yn.DEFAULT_MATERIAL_NAME="__DEFAULT";const Ai={};class jm extends Error{constructor(e,t){super(e),this.response=t}}class qr extends Yn{constructor(e){super(e)}load(e,t,n,i){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=fa.get(e);if(s!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(s),this.manager.itemEnd(e)},0),s;if(Ai[e]!==void 0){Ai[e].push({onLoad:t,onProgress:n,onError:i});return}Ai[e]=[],Ai[e].push({onLoad:t,onProgress:n,onError:i});const o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),a=this.mimeType,l=this.responseType;fetch(o).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;const h=Ai[e],u=c.body.getReader(),d=c.headers.get("X-File-Size")||c.headers.get("Content-Length"),f=d?parseInt(d):0,m=f!==0;let v=0;const g=new ReadableStream({start(p){M();function M(){u.read().then(({done:x,value:b})=>{if(x)p.close();else{v+=b.byteLength;const D=new ProgressEvent("progress",{lengthComputable:m,loaded:v,total:f});for(let R=0,P=h.length;R<P;R++){const S=h[R];S.onProgress&&S.onProgress(D)}p.enqueue(b),M()}},x=>{p.error(x)})}}});return new Response(g)}else throw new jm(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(h=>new DOMParser().parseFromString(h,a));case"json":return c.json();default:if(a===void 0)return c.text();{const u=/charset="?([^;"\s]*)"?/i.exec(a),d=u&&u[1]?u[1].toLowerCase():void 0,f=new TextDecoder(d);return c.arrayBuffer().then(m=>f.decode(m))}}}).then(c=>{fa.add(e,c);const h=Ai[e];delete Ai[e];for(let u=0,d=h.length;u<d;u++){const f=h[u];f.onLoad&&f.onLoad(c)}}).catch(c=>{const h=Ai[e];if(h===void 0)throw this.manager.itemError(e),c;delete Ai[e];for(let u=0,d=h.length;u<d;u++){const f=h[u];f.onError&&f.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}}class qm extends Yn{constructor(e){super(e)}load(e,t,n,i){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=this,o=fa.get(e);if(o!==void 0)return s.manager.itemStart(e),setTimeout(function(){t&&t(o),s.manager.itemEnd(e)},0),o;const a=Or("img");function l(){h(),fa.add(e,this),t&&t(this),s.manager.itemEnd(e)}function c(u){h(),i&&i(u),s.manager.itemError(e),s.manager.itemEnd(e)}function h(){a.removeEventListener("load",l,!1),a.removeEventListener("error",c,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),s.manager.itemStart(e),a.src=e,a}}class Ym extends Yn{constructor(e){super(e)}load(e,t,n,i){const s=this,o=new Hd,a=new qr(this.manager);return a.setResponseType("arraybuffer"),a.setRequestHeader(this.requestHeader),a.setPath(this.path),a.setWithCredentials(s.withCredentials),a.load(e,function(l){let c;try{c=s.parse(l)}catch(h){if(i!==void 0)i(h);else{console.error(h);return}}c.image!==void 0?o.image=c.image:c.data!==void 0&&(o.image.width=c.width,o.image.height=c.height,o.image.data=c.data),o.wrapS=c.wrapS!==void 0?c.wrapS:Bn,o.wrapT=c.wrapT!==void 0?c.wrapT:Bn,o.magFilter=c.magFilter!==void 0?c.magFilter:mn,o.minFilter=c.minFilter!==void 0?c.minFilter:mn,o.anisotropy=c.anisotropy!==void 0?c.anisotropy:1,c.colorSpace!==void 0&&(o.colorSpace=c.colorSpace),c.flipY!==void 0&&(o.flipY=c.flipY),c.format!==void 0&&(o.format=c.format),c.type!==void 0&&(o.type=c.type),c.mipmaps!==void 0&&(o.mipmaps=c.mipmaps,o.minFilter=Li),c.mipmapCount===1&&(o.minFilter=mn),c.generateMipmaps!==void 0&&(o.generateMipmaps=c.generateMipmaps),o.needsUpdate=!0,t&&t(o,c)},n,i),o}}class Ma extends Yn{constructor(e){super(e)}load(e,t,n,i){const s=new qt,o=new qm(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){s.image=a,s.needsUpdate=!0,t!==void 0&&t(s)},n,i),s}}class Yr extends Ct{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new Ge(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class Zm extends Yr{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Ct.DEFAULT_UP),this.updateMatrix(),this.groundColor=new Ge(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const ol=new Te,qh=new I,Yh=new I;class Hc{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ye(512,512),this.map=null,this.mapPass=null,this.matrix=new Te,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new xa,this._frameExtents=new ye(1,1),this._viewportCount=1,this._viewports=[new ct(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;qh.setFromMatrixPosition(e.matrixWorld),t.position.copy(qh),Yh.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Yh),t.updateMatrixWorld(),ol.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(ol),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(ol)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class Km extends Hc{constructor(){super(new Qt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){const t=this.camera,n=dr*2*e.angle*this.focus,i=this.mapSize.width/this.mapSize.height,s=e.distance||t.far;(n!==t.fov||i!==t.aspect||s!==t.far)&&(t.fov=n,t.aspect=i,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class Kd extends Yr{constructor(e,t,n=0,i=Math.PI/3,s=0,o=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(Ct.DEFAULT_UP),this.updateMatrix(),this.target=new Ct,this.distance=n,this.angle=i,this.penumbra=s,this.decay=o,this.map=null,this.shadow=new Km}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}const Zh=new Te,Ar=new I,al=new I;class $m extends Hc{constructor(){super(new Qt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new ye(4,2),this._viewportCount=6,this._viewports=[new ct(2,1,1,1),new ct(0,1,1,1),new ct(3,1,1,1),new ct(1,1,1,1),new ct(3,0,1,1),new ct(1,0,1,1)],this._cubeDirections=[new I(1,0,0),new I(-1,0,0),new I(0,0,1),new I(0,0,-1),new I(0,1,0),new I(0,-1,0)],this._cubeUps=[new I(0,1,0),new I(0,1,0),new I(0,1,0),new I(0,1,0),new I(0,0,1),new I(0,0,-1)]}updateMatrices(e,t=0){const n=this.camera,i=this.matrix,s=e.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),Ar.setFromMatrixPosition(e.matrixWorld),n.position.copy(Ar),al.copy(n.position),al.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(al),n.updateMatrixWorld(),i.makeTranslation(-Ar.x,-Ar.y,-Ar.z),Zh.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(Zh)}}class yc extends Yr{constructor(e,t,n=0,i=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new $m}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Vc extends Bd{constructor(e=-1,t=1,n=1,i=-1,s=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=i,this.near=s,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,i,s,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let s=n-e,o=n+e,a=i+t,l=i-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,o=s+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(s,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class Jm extends Hc{constructor(){super(new Vc(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class pa extends Yr{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Ct.DEFAULT_UP),this.updateMatrix(),this.target=new Ct,this.shadow=new Jm}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class Gc extends Yr{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}class Wc{static decodeText(e){if(console.warn("THREE.LoaderUtils: decodeText() has been deprecated with r165 and will be removed with r175. Use TextDecoder instead."),typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let n=0,i=e.length;n<i;n++)t+=String.fromCharCode(e[n]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){const t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}}class Qm extends yt{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){const e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}}class eg extends Qt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e,this.index=0}}class $d{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=Kh(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=Kh();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}function Kh(){return performance.now()}const Xc="\\[\\]\\.:\\/",tg=new RegExp("["+Xc+"]","g"),jc="[^"+Xc+"]",ng="[^"+Xc.replace("\\.","")+"]",ig=/((?:WC+[\/:])*)/.source.replace("WC",jc),sg=/(WCOD+)?/.source.replace("WCOD",ng),rg=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",jc),og=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",jc),ag=new RegExp("^"+ig+sg+rg+og+"$"),lg=["material","materials","bones","map"];class cg{constructor(e,t,n){const i=n||Rt.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,i)}getValue(e,t){this.bind();const n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(e,t)}setValue(e,t){const n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,s=n.length;i!==s;++i)n[i].setValue(e,t)}bind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class Rt{constructor(e,t,n){this.path=t,this.parsedPath=n||Rt.parseTrackName(t),this.node=Rt.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new Rt.Composite(e,t,n):new Rt(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(tg,"")}static parseTrackName(e){const t=ag.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);const n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){const s=n.nodeName.substring(i+1);lg.indexOf(s)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=s)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){const n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){const n=function(s){for(let o=0;o<s.length;o++){const a=s[o];if(a.name===t||a.uuid===t)return a;const l=n(a.children);if(l)return l}return null},i=n(e.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)e[t++]=n[i]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++]}_setValue_array_setNeedsUpdate(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node;const t=this.parsedPath,n=t.objectName,i=t.propertyName;let s=t.propertyIndex;if(e||(e=Rt.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}const o=e[i];if(o===void 0){const c=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+i+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?a=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(s!==void 0){if(i==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=s}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}Rt.Composite=cg;Rt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Rt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Rt.prototype.GetterByBindingType=[Rt.prototype._getValue_direct,Rt.prototype._getValue_array,Rt.prototype._getValue_arrayElement,Rt.prototype._getValue_toArray];Rt.prototype.SetterByBindingTypeAndVersioning=[[Rt.prototype._setValue_direct,Rt.prototype._setValue_direct_setNeedsUpdate,Rt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Rt.prototype._setValue_array,Rt.prototype._setValue_array_setNeedsUpdate,Rt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Rt.prototype._setValue_arrayElement,Rt.prototype._setValue_arrayElement_setNeedsUpdate,Rt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Rt.prototype._setValue_fromArray,Rt.prototype._setValue_fromArray_setNeedsUpdate,Rt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];class bc extends dm{constructor(e,t,n=1){super(e,t),this.isInstancedInterleavedBuffer=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}clone(e){const t=super.clone(e);return t.meshPerAttribute=this.meshPerAttribute,t}toJSON(e){const t=super.toJSON(e);return t.isInstancedInterleavedBuffer=!0,t.meshPerAttribute=this.meshPerAttribute,t}}const $h=new Te;class qc{constructor(e,t,n=0,i=1/0){this.ray=new Ts(e,t),this.near=n,this.far=i,this.camera=null,this.layers=new Uc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return $h.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4($h),this}intersectObject(e,t=!0,n=[]){return Mc(e,this,n,t),n.sort(Jh),n}intersectObjects(e,t=!0,n=[]){for(let i=0,s=e.length;i<s;i++)Mc(e[i],this,n,t);return n.sort(Jh),n}}function Jh(r,e){return r.distance-e.distance}function Mc(r,e,t,n){let i=!0;if(r.layers.test(e.layers)&&r.raycast(e,t)===!1&&(i=!1),i===!0&&n===!0){const s=r.children;for(let o=0,a=s.length;o<a;o++)Mc(s[o],e,t,!0)}}class Qh{constructor(e=1,t=0,n=0){this.radius=e,this.phi=t,this.theta=n}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=dt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(dt(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const eu=new ye;class Js{constructor(e=new ye(1/0,1/0),t=new ye(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=eu.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,eu).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const tu=new I,Lo=new I;class hg{constructor(e=new I,t=new I){this.start=e,this.end=t}set(e,t){return this.start.copy(e),this.end.copy(t),this}copy(e){return this.start.copy(e.start),this.end.copy(e.end),this}getCenter(e){return e.addVectors(this.start,this.end).multiplyScalar(.5)}delta(e){return e.subVectors(this.end,this.start)}distanceSq(){return this.start.distanceToSquared(this.end)}distance(){return this.start.distanceTo(this.end)}at(e,t){return this.delta(t).multiplyScalar(e).add(this.start)}closestPointToPointParameter(e,t){tu.subVectors(e,this.start),Lo.subVectors(this.end,this.start);const n=Lo.dot(Lo);let s=Lo.dot(tu)/n;return t&&(s=dt(s,0,1)),s}closestPointToPoint(e,t,n){const i=this.closestPointToPointParameter(e,t);return this.delta(n).multiplyScalar(i).add(this.start)}applyMatrix4(e){return this.start.applyMatrix4(e),this.end.applyMatrix4(e),this}equals(e){return e.start.equals(this.start)&&e.end.equals(this.end)}clone(){return new this.constructor().copy(this)}}class nu extends pr{constructor(e=10,t=10,n=4473924,i=8947848){n=new Ge(n),i=new Ge(i);const s=t/2,o=e/t,a=e/2,l=[],c=[];for(let d=0,f=0,m=-a;d<=t;d++,m+=o){l.push(-a,0,m,a,0,m),l.push(m,0,-a,m,0,a);const v=d===s?n:i;v.toArray(c,f),f+=3,v.toArray(c,f),f+=3,v.toArray(c,f),f+=3,v.toArray(c,f),f+=3}const h=new yt;h.setAttribute("position",new Le(l,3)),h.setAttribute("color",new Le(c,3));const u=new jn({vertexColors:!0,toneMapped:!1});super(h,u),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}class ug extends pr{constructor(e,t=16776960){const n=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),i=[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,-1,-1,1,-1,-1,-1,-1,1,-1,-1],s=new yt;s.setIndex(new Rn(n,1)),s.setAttribute("position",new Le(i,3)),super(s,new jn({color:t,toneMapped:!1})),this.box=e,this.type="Box3Helper",this.geometry.computeBoundingSphere()}updateMatrixWorld(e){const t=this.box;t.isEmpty()||(t.getCenter(this.position),t.getSize(this.scale),this.scale.multiplyScalar(.5),super.updateMatrixWorld(e))}dispose(){this.geometry.dispose(),this.material.dispose()}}const iu=new I;let Do,ll;class Jd extends Ct{constructor(e=new I(0,0,1),t=new I(0,0,0),n=1,i=16776960,s=n*.2,o=s*.2){super(),this.type="ArrowHelper",Do===void 0&&(Do=new yt,Do.setAttribute("position",new Le([0,0,0,0,1,0],3)),ll=new cn(0,.5,1,5,1),ll.translate(0,-.5,0)),this.position.copy(t),this.line=new Vn(Do,new jn({color:i,toneMapped:!1})),this.line.matrixAutoUpdate=!1,this.add(this.line),this.cone=new ve(ll,new qn({color:i,toneMapped:!1})),this.cone.matrixAutoUpdate=!1,this.add(this.cone),this.setDirection(e),this.setLength(n,s,o)}setDirection(e){if(e.y>.99999)this.quaternion.set(0,0,0,1);else if(e.y<-.99999)this.quaternion.set(1,0,0,0);else{iu.set(e.z,0,-e.x).normalize();const t=Math.acos(e.y);this.quaternion.setFromAxisAngle(iu,t)}}setLength(e,t=e*.2,n=t*.2){this.line.scale.set(1,Math.max(1e-4,e-t),1),this.line.updateMatrix(),this.cone.scale.set(n,t,n),this.cone.position.y=e,this.cone.updateMatrix()}setColor(e){this.line.material.color.set(e),this.cone.material.color.set(e)}copy(e){return super.copy(e,!1),this.line.copy(e.line),this.cone.copy(e.cone),this}dispose(){this.line.geometry.dispose(),this.line.material.dispose(),this.cone.geometry.dispose(),this.cone.material.dispose()}}class Yc extends pr{constructor(e=1){const t=[0,0,0,e,0,0,0,0,0,0,e,0,0,0,0,0,0,e],n=[1,0,0,1,.6,0,0,1,0,.6,1,0,0,0,1,0,.6,1],i=new yt;i.setAttribute("position",new Le(t,3)),i.setAttribute("color",new Le(n,3));const s=new jn({vertexColors:!0,toneMapped:!1});super(i,s),this.type="AxesHelper"}setColors(e,t,n){const i=new Ge,s=this.geometry.attributes.color.array;return i.set(e),i.toArray(s,0),i.toArray(s,3),i.set(t),i.toArray(s,6),i.toArray(s,9),i.set(n),i.toArray(s,12),i.toArray(s,15),this.geometry.attributes.color.needsUpdate=!0,this}dispose(){this.geometry.dispose(),this.material.dispose()}}class Qd extends Es{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(){}disconnect(){}dispose(){}update(){}}function su(r,e,t,n){const i=dg(n);switch(t){case Td:return r*e;case Rd:return r*e;case Cd:return r*e*2;case Pd:return r*e/i.components*i.byteLength;case Cc:return r*e/i.components*i.byteLength;case Ld:return r*e*2/i.components*i.byteLength;case Pc:return r*e*2/i.components*i.byteLength;case Ad:return r*e*3/i.components*i.byteLength;case Sn:return r*e*4/i.components*i.byteLength;case Lc:return r*e*4/i.components*i.byteLength;case $o:case Jo:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case Qo:case ea:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Vl:case Wl:return Math.max(r,16)*Math.max(e,8)/4;case Hl:case Gl:return Math.max(r,8)*Math.max(e,8)/2;case Xl:case jl:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case ql:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Yl:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case Zl:return Math.floor((r+4)/5)*Math.floor((e+3)/4)*16;case Kl:return Math.floor((r+4)/5)*Math.floor((e+4)/5)*16;case $l:return Math.floor((r+5)/6)*Math.floor((e+4)/5)*16;case Jl:return Math.floor((r+5)/6)*Math.floor((e+5)/6)*16;case Ql:return Math.floor((r+7)/8)*Math.floor((e+4)/5)*16;case ec:return Math.floor((r+7)/8)*Math.floor((e+5)/6)*16;case tc:return Math.floor((r+7)/8)*Math.floor((e+7)/8)*16;case nc:return Math.floor((r+9)/10)*Math.floor((e+4)/5)*16;case ic:return Math.floor((r+9)/10)*Math.floor((e+5)/6)*16;case sc:return Math.floor((r+9)/10)*Math.floor((e+7)/8)*16;case rc:return Math.floor((r+9)/10)*Math.floor((e+9)/10)*16;case oc:return Math.floor((r+11)/12)*Math.floor((e+9)/10)*16;case ac:return Math.floor((r+11)/12)*Math.floor((e+11)/12)*16;case ta:case lc:case cc:return Math.ceil(r/4)*Math.ceil(e/4)*16;case Dd:case hc:return Math.ceil(r/4)*Math.ceil(e/4)*8;case uc:case dc:return Math.ceil(r/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function dg(r){switch(r){case Fi:case Sd:return{byteLength:1,components:1};case Fr:case wd:case Xr:return{byteLength:2,components:1};case Ac:case Rc:return{byteLength:2,components:4};case xs:case Tc:case fi:return{byteLength:4,components:1};case Ed:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:_s}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=_s);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function ef(){let r=null,e=!1,t=null,n=null;function i(s,o){t(s,o),n=r.requestAnimationFrame(i)}return{start:function(){e!==!0&&t!==null&&(n=r.requestAnimationFrame(i),e=!0)},stop:function(){r.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){r=s}}}function fg(r){const e=new WeakMap;function t(a,l){const c=a.array,h=a.usage,u=c.byteLength,d=r.createBuffer();r.bindBuffer(l,d),r.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=r.FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=r.HALF_FLOAT:f=r.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=r.SHORT;else if(c instanceof Uint32Array)f=r.UNSIGNED_INT;else if(c instanceof Int32Array)f=r.INT;else if(c instanceof Int8Array)f=r.BYTE;else if(c instanceof Uint8Array)f=r.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){const h=l.array,u=l.updateRanges;if(r.bindBuffer(c,a),u.length===0)r.bufferSubData(c,0,h);else{u.sort((f,m)=>f.start-m.start);let d=0;for(let f=1;f<u.length;f++){const m=u[d],v=u[f];v.start<=m.start+m.count+1?m.count=Math.max(m.count,v.start+v.count-m.start):(++d,u[d]=v)}u.length=d+1;for(let f=0,m=u.length;f<m;f++){const v=u[f];r.bufferSubData(c,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function i(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function s(a){a.isInterleavedBufferAttribute&&(a=a.data);const l=e.get(a);l&&(r.deleteBuffer(l.buffer),e.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=e.get(a);(!h||h.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const c=e.get(a);if(c===void 0)e.set(a,t(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:i,remove:s,update:o}}var pg=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,mg=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,gg=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,_g=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,vg=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,xg=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,yg=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,bg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Mg=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Sg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,wg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,Eg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Tg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Ag=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Rg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Cg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Pg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,Lg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,Dg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Ig=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Ng=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Ug=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,Fg=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Og=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Bg=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,kg=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,zg=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,Hg=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,Vg=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,Gg=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,Wg="gl_FragColor = linearToOutputTexel( gl_FragColor );",Xg=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,jg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,qg=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,Yg=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,Zg=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,Kg=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,$g=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,Jg=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,Qg=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,e0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,t0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,n0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,i0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,s0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,r0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,o0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,a0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,l0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,c0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,h0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,u0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,d0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,f0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,p0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,m0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,g0=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,_0=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,v0=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,x0=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,y0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,b0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,M0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,S0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,w0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,E0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,T0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,A0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,R0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,C0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,P0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,L0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,D0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,I0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,N0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,U0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,F0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,O0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,B0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,k0=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,z0=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,H0=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,V0=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,G0=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,W0=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,X0=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,j0=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,q0=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,Y0=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,Z0=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,K0=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,$0=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,J0=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,Q0=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,e_=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,t_=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,n_=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,i_=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,s_=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,r_=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,o_=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,a_=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,l_=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,c_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,h_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,u_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,d_=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const f_=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,p_=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,m_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,g_=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,__=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,v_=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,x_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,y_=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,b_=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,M_=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,S_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,w_=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,E_=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,T_=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,A_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,R_=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,C_=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,P_=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,L_=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,D_=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,I_=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,N_=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,U_=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,F_=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,O_=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,B_=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,k_=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,z_=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,H_=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,V_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,G_=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,W_=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,X_=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,j_=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,pt={alphahash_fragment:pg,alphahash_pars_fragment:mg,alphamap_fragment:gg,alphamap_pars_fragment:_g,alphatest_fragment:vg,alphatest_pars_fragment:xg,aomap_fragment:yg,aomap_pars_fragment:bg,batching_pars_vertex:Mg,batching_vertex:Sg,begin_vertex:wg,beginnormal_vertex:Eg,bsdfs:Tg,iridescence_fragment:Ag,bumpmap_pars_fragment:Rg,clipping_planes_fragment:Cg,clipping_planes_pars_fragment:Pg,clipping_planes_pars_vertex:Lg,clipping_planes_vertex:Dg,color_fragment:Ig,color_pars_fragment:Ng,color_pars_vertex:Ug,color_vertex:Fg,common:Og,cube_uv_reflection_fragment:Bg,defaultnormal_vertex:kg,displacementmap_pars_vertex:zg,displacementmap_vertex:Hg,emissivemap_fragment:Vg,emissivemap_pars_fragment:Gg,colorspace_fragment:Wg,colorspace_pars_fragment:Xg,envmap_fragment:jg,envmap_common_pars_fragment:qg,envmap_pars_fragment:Yg,envmap_pars_vertex:Zg,envmap_physical_pars_fragment:o0,envmap_vertex:Kg,fog_vertex:$g,fog_pars_vertex:Jg,fog_fragment:Qg,fog_pars_fragment:e0,gradientmap_pars_fragment:t0,lightmap_pars_fragment:n0,lights_lambert_fragment:i0,lights_lambert_pars_fragment:s0,lights_pars_begin:r0,lights_toon_fragment:a0,lights_toon_pars_fragment:l0,lights_phong_fragment:c0,lights_phong_pars_fragment:h0,lights_physical_fragment:u0,lights_physical_pars_fragment:d0,lights_fragment_begin:f0,lights_fragment_maps:p0,lights_fragment_end:m0,logdepthbuf_fragment:g0,logdepthbuf_pars_fragment:_0,logdepthbuf_pars_vertex:v0,logdepthbuf_vertex:x0,map_fragment:y0,map_pars_fragment:b0,map_particle_fragment:M0,map_particle_pars_fragment:S0,metalnessmap_fragment:w0,metalnessmap_pars_fragment:E0,morphinstance_vertex:T0,morphcolor_vertex:A0,morphnormal_vertex:R0,morphtarget_pars_vertex:C0,morphtarget_vertex:P0,normal_fragment_begin:L0,normal_fragment_maps:D0,normal_pars_fragment:I0,normal_pars_vertex:N0,normal_vertex:U0,normalmap_pars_fragment:F0,clearcoat_normal_fragment_begin:O0,clearcoat_normal_fragment_maps:B0,clearcoat_pars_fragment:k0,iridescence_pars_fragment:z0,opaque_fragment:H0,packing:V0,premultiplied_alpha_fragment:G0,project_vertex:W0,dithering_fragment:X0,dithering_pars_fragment:j0,roughnessmap_fragment:q0,roughnessmap_pars_fragment:Y0,shadowmap_pars_fragment:Z0,shadowmap_pars_vertex:K0,shadowmap_vertex:$0,shadowmask_pars_fragment:J0,skinbase_vertex:Q0,skinning_pars_vertex:e_,skinning_vertex:t_,skinnormal_vertex:n_,specularmap_fragment:i_,specularmap_pars_fragment:s_,tonemapping_fragment:r_,tonemapping_pars_fragment:o_,transmission_fragment:a_,transmission_pars_fragment:l_,uv_pars_fragment:c_,uv_pars_vertex:h_,uv_vertex:u_,worldpos_vertex:d_,background_vert:f_,background_frag:p_,backgroundCube_vert:m_,backgroundCube_frag:g_,cube_vert:__,cube_frag:v_,depth_vert:x_,depth_frag:y_,distanceRGBA_vert:b_,distanceRGBA_frag:M_,equirect_vert:S_,equirect_frag:w_,linedashed_vert:E_,linedashed_frag:T_,meshbasic_vert:A_,meshbasic_frag:R_,meshlambert_vert:C_,meshlambert_frag:P_,meshmatcap_vert:L_,meshmatcap_frag:D_,meshnormal_vert:I_,meshnormal_frag:N_,meshphong_vert:U_,meshphong_frag:F_,meshphysical_vert:O_,meshphysical_frag:B_,meshtoon_vert:k_,meshtoon_frag:z_,points_vert:H_,points_frag:V_,shadow_vert:G_,shadow_frag:W_,sprite_vert:X_,sprite_frag:j_},Se={common:{diffuse:{value:new Ge(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new lt},alphaMap:{value:null},alphaMapTransform:{value:new lt},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new lt}},envmap:{envMap:{value:null},envMapRotation:{value:new lt},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new lt}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new lt}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new lt},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new lt},normalScale:{value:new ye(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new lt},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new lt}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new lt}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new lt}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new Ge(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new Ge(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new lt},alphaTest:{value:0},uvTransform:{value:new lt}},sprite:{diffuse:{value:new Ge(16777215)},opacity:{value:1},center:{value:new ye(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new lt},alphaMap:{value:null},alphaMapTransform:{value:new lt},alphaTest:{value:0}}},Nn={basic:{uniforms:Tn([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.fog]),vertexShader:pt.meshbasic_vert,fragmentShader:pt.meshbasic_frag},lambert:{uniforms:Tn([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,Se.lights,{emissive:{value:new Ge(0)}}]),vertexShader:pt.meshlambert_vert,fragmentShader:pt.meshlambert_frag},phong:{uniforms:Tn([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,Se.lights,{emissive:{value:new Ge(0)},specular:{value:new Ge(1118481)},shininess:{value:30}}]),vertexShader:pt.meshphong_vert,fragmentShader:pt.meshphong_frag},standard:{uniforms:Tn([Se.common,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.roughnessmap,Se.metalnessmap,Se.fog,Se.lights,{emissive:{value:new Ge(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:pt.meshphysical_vert,fragmentShader:pt.meshphysical_frag},toon:{uniforms:Tn([Se.common,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.gradientmap,Se.fog,Se.lights,{emissive:{value:new Ge(0)}}]),vertexShader:pt.meshtoon_vert,fragmentShader:pt.meshtoon_frag},matcap:{uniforms:Tn([Se.common,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,{matcap:{value:null}}]),vertexShader:pt.meshmatcap_vert,fragmentShader:pt.meshmatcap_frag},points:{uniforms:Tn([Se.points,Se.fog]),vertexShader:pt.points_vert,fragmentShader:pt.points_frag},dashed:{uniforms:Tn([Se.common,Se.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:pt.linedashed_vert,fragmentShader:pt.linedashed_frag},depth:{uniforms:Tn([Se.common,Se.displacementmap]),vertexShader:pt.depth_vert,fragmentShader:pt.depth_frag},normal:{uniforms:Tn([Se.common,Se.bumpmap,Se.normalmap,Se.displacementmap,{opacity:{value:1}}]),vertexShader:pt.meshnormal_vert,fragmentShader:pt.meshnormal_frag},sprite:{uniforms:Tn([Se.sprite,Se.fog]),vertexShader:pt.sprite_vert,fragmentShader:pt.sprite_frag},background:{uniforms:{uvTransform:{value:new lt},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:pt.background_vert,fragmentShader:pt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new lt}},vertexShader:pt.backgroundCube_vert,fragmentShader:pt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:pt.cube_vert,fragmentShader:pt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:pt.equirect_vert,fragmentShader:pt.equirect_frag},distanceRGBA:{uniforms:Tn([Se.common,Se.displacementmap,{referencePosition:{value:new I},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:pt.distanceRGBA_vert,fragmentShader:pt.distanceRGBA_frag},shadow:{uniforms:Tn([Se.lights,Se.fog,{color:{value:new Ge(0)},opacity:{value:1}}]),vertexShader:pt.shadow_vert,fragmentShader:pt.shadow_frag}};Nn.physical={uniforms:Tn([Nn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new lt},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new lt},clearcoatNormalScale:{value:new ye(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new lt},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new lt},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new lt},sheen:{value:0},sheenColor:{value:new Ge(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new lt},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new lt},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new lt},transmissionSamplerSize:{value:new ye},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new lt},attenuationDistance:{value:0},attenuationColor:{value:new Ge(0)},specularColor:{value:new Ge(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new lt},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new lt},anisotropyVector:{value:new ye},anisotropyMap:{value:null},anisotropyMapTransform:{value:new lt}}]),vertexShader:pt.meshphysical_vert,fragmentShader:pt.meshphysical_frag};const Io={r:0,b:0,g:0},os=new Kt,q_=new Te;function Y_(r,e,t,n,i,s,o){const a=new Ge(0);let l=s===!0?0:1,c,h,u=null,d=0,f=null;function m(x){let b=x.isScene===!0?x.background:null;return b&&b.isTexture&&(b=(x.backgroundBlurriness>0?t:e).get(b)),b}function v(x){let b=!1;const D=m(x);D===null?p(a,l):D&&D.isColor&&(p(D,1),b=!0);const R=r.xr.getEnvironmentBlendMode();R==="additive"?n.buffers.color.setClear(0,0,0,1,o):R==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(r.autoClear||b)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function g(x,b){const D=m(b);D&&(D.isCubeTexture||D.mapping===_a)?(h===void 0&&(h=new ve(new Yt(1,1,1),new gi({name:"BackgroundCubeMaterial",uniforms:fr(Nn.backgroundCube.uniforms),vertexShader:Nn.backgroundCube.vertexShader,fragmentShader:Nn.backgroundCube.fragmentShader,side:Un,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(R,P,S){this.matrixWorld.copyPosition(S.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),os.copy(b.backgroundRotation),os.x*=-1,os.y*=-1,os.z*=-1,D.isCubeTexture&&D.isRenderTargetTexture===!1&&(os.y*=-1,os.z*=-1),h.material.uniforms.envMap.value=D,h.material.uniforms.flipEnvMap.value=D.isCubeTexture&&D.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=b.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(q_.makeRotationFromEuler(os)),h.material.toneMapped=rt.getTransfer(D.colorSpace)!==Nt,(u!==D||d!==D.version||f!==r.toneMapping)&&(h.material.needsUpdate=!0,u=D,d=D.version,f=r.toneMapping),h.layers.enableAll(),x.unshift(h,h.geometry,h.material,0,0,null)):D&&D.isTexture&&(c===void 0&&(c=new ve(new mr(2,2),new gi({name:"BackgroundMaterial",uniforms:fr(Nn.background.uniforms),vertexShader:Nn.background.vertexShader,fragmentShader:Nn.background.fragmentShader,side:Ui,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=D,c.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,c.material.toneMapped=rt.getTransfer(D.colorSpace)!==Nt,D.matrixAutoUpdate===!0&&D.updateMatrix(),c.material.uniforms.uvTransform.value.copy(D.matrix),(u!==D||d!==D.version||f!==r.toneMapping)&&(c.material.needsUpdate=!0,u=D,d=D.version,f=r.toneMapping),c.layers.enableAll(),x.unshift(c,c.geometry,c.material,0,0,null))}function p(x,b){x.getRGB(Io,Od(r)),n.buffers.color.setClear(Io.r,Io.g,Io.b,b,o)}function M(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return a},setClearColor:function(x,b=1){a.set(x),l=b,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(x){l=x,p(a,l)},render:v,addToRenderList:g,dispose:M}}function Z_(r,e){const t=r.getParameter(r.MAX_VERTEX_ATTRIBS),n={},i=d(null);let s=i,o=!1;function a(y,T,F,k,G){let $=!1;const z=u(k,F,T);s!==z&&(s=z,c(s.object)),$=f(y,k,F,G),$&&m(y,k,F,G),G!==null&&e.update(G,r.ELEMENT_ARRAY_BUFFER),($||o)&&(o=!1,b(y,T,F,k),G!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,e.get(G).buffer))}function l(){return r.createVertexArray()}function c(y){return r.bindVertexArray(y)}function h(y){return r.deleteVertexArray(y)}function u(y,T,F){const k=F.wireframe===!0;let G=n[y.id];G===void 0&&(G={},n[y.id]=G);let $=G[T.id];$===void 0&&($={},G[T.id]=$);let z=$[k];return z===void 0&&(z=d(l()),$[k]=z),z}function d(y){const T=[],F=[],k=[];for(let G=0;G<t;G++)T[G]=0,F[G]=0,k[G]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:T,enabledAttributes:F,attributeDivisors:k,object:y,attributes:{},index:null}}function f(y,T,F,k){const G=s.attributes,$=T.attributes;let z=0;const Y=F.getAttributes();for(const H in Y)if(Y[H].location>=0){const ue=G[H];let re=$[H];if(re===void 0&&(H==="instanceMatrix"&&y.instanceMatrix&&(re=y.instanceMatrix),H==="instanceColor"&&y.instanceColor&&(re=y.instanceColor)),ue===void 0||ue.attribute!==re||re&&ue.data!==re.data)return!0;z++}return s.attributesNum!==z||s.index!==k}function m(y,T,F,k){const G={},$=T.attributes;let z=0;const Y=F.getAttributes();for(const H in Y)if(Y[H].location>=0){let ue=$[H];ue===void 0&&(H==="instanceMatrix"&&y.instanceMatrix&&(ue=y.instanceMatrix),H==="instanceColor"&&y.instanceColor&&(ue=y.instanceColor));const re={};re.attribute=ue,ue&&ue.data&&(re.data=ue.data),G[H]=re,z++}s.attributes=G,s.attributesNum=z,s.index=k}function v(){const y=s.newAttributes;for(let T=0,F=y.length;T<F;T++)y[T]=0}function g(y){p(y,0)}function p(y,T){const F=s.newAttributes,k=s.enabledAttributes,G=s.attributeDivisors;F[y]=1,k[y]===0&&(r.enableVertexAttribArray(y),k[y]=1),G[y]!==T&&(r.vertexAttribDivisor(y,T),G[y]=T)}function M(){const y=s.newAttributes,T=s.enabledAttributes;for(let F=0,k=T.length;F<k;F++)T[F]!==y[F]&&(r.disableVertexAttribArray(F),T[F]=0)}function x(y,T,F,k,G,$,z){z===!0?r.vertexAttribIPointer(y,T,F,G,$):r.vertexAttribPointer(y,T,F,k,G,$)}function b(y,T,F,k){v();const G=k.attributes,$=F.getAttributes(),z=T.defaultAttributeValues;for(const Y in $){const H=$[Y];if(H.location>=0){let q=G[Y];if(q===void 0&&(Y==="instanceMatrix"&&y.instanceMatrix&&(q=y.instanceMatrix),Y==="instanceColor"&&y.instanceColor&&(q=y.instanceColor)),q!==void 0){const ue=q.normalized,re=q.itemSize,de=e.get(q);if(de===void 0)continue;const ie=de.buffer,W=de.type,Z=de.bytesPerElement,Q=W===r.INT||W===r.UNSIGNED_INT||q.gpuType===Tc;if(q.isInterleavedBufferAttribute){const ne=q.data,ce=ne.stride,Me=q.offset;if(ne.isInstancedInterleavedBuffer){for(let we=0;we<H.locationSize;we++)p(H.location+we,ne.meshPerAttribute);y.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=ne.meshPerAttribute*ne.count)}else for(let we=0;we<H.locationSize;we++)g(H.location+we);r.bindBuffer(r.ARRAY_BUFFER,ie);for(let we=0;we<H.locationSize;we++)x(H.location+we,re/H.locationSize,W,ue,ce*Z,(Me+re/H.locationSize*we)*Z,Q)}else{if(q.isInstancedBufferAttribute){for(let ne=0;ne<H.locationSize;ne++)p(H.location+ne,q.meshPerAttribute);y.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=q.meshPerAttribute*q.count)}else for(let ne=0;ne<H.locationSize;ne++)g(H.location+ne);r.bindBuffer(r.ARRAY_BUFFER,ie);for(let ne=0;ne<H.locationSize;ne++)x(H.location+ne,re/H.locationSize,W,ue,re*Z,re/H.locationSize*ne*Z,Q)}}else if(z!==void 0){const ue=z[Y];if(ue!==void 0)switch(ue.length){case 2:r.vertexAttrib2fv(H.location,ue);break;case 3:r.vertexAttrib3fv(H.location,ue);break;case 4:r.vertexAttrib4fv(H.location,ue);break;default:r.vertexAttrib1fv(H.location,ue)}}}}M()}function D(){S();for(const y in n){const T=n[y];for(const F in T){const k=T[F];for(const G in k)h(k[G].object),delete k[G];delete T[F]}delete n[y]}}function R(y){if(n[y.id]===void 0)return;const T=n[y.id];for(const F in T){const k=T[F];for(const G in k)h(k[G].object),delete k[G];delete T[F]}delete n[y.id]}function P(y){for(const T in n){const F=n[T];if(F[y.id]===void 0)continue;const k=F[y.id];for(const G in k)h(k[G].object),delete k[G];delete F[y.id]}}function S(){_(),o=!0,s!==i&&(s=i,c(s.object))}function _(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:a,reset:S,resetDefaultState:_,dispose:D,releaseStatesOfGeometry:R,releaseStatesOfProgram:P,initAttributes:v,enableAttribute:g,disableUnusedAttributes:M}}function K_(r,e,t){let n;function i(c){n=c}function s(c,h){r.drawArrays(n,c,h),t.update(h,n,1)}function o(c,h,u){u!==0&&(r.drawArraysInstanced(n,c,h,u),t.update(h,n,u))}function a(c,h,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let m=0;m<u;m++)f+=h[m];t.update(f,n,1)}function l(c,h,u,d){if(u===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let m=0;m<c.length;m++)o(c[m],h[m],d[m]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let m=0;for(let v=0;v<u;v++)m+=h[v]*d[v];t.update(m,n,1)}}this.setMode=i,this.render=s,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function $_(r,e,t,n){let i;function s(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){const P=e.get("EXT_texture_filter_anisotropic");i=r.getParameter(P.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(P){return!(P!==Sn&&n.convert(P)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(P){const S=P===Xr&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(P!==Fi&&n.convert(P)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&P!==fi&&!S)}function l(P){if(P==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";P="mediump"}return P==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const u=t.logarithmicDepthBuffer===!0,d=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),f=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),m=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=r.getParameter(r.MAX_TEXTURE_SIZE),g=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),p=r.getParameter(r.MAX_VERTEX_ATTRIBS),M=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),x=r.getParameter(r.MAX_VARYING_VECTORS),b=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),D=m>0,R=r.getParameter(r.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:m,maxTextureSize:v,maxCubemapSize:g,maxAttributes:p,maxVertexUniforms:M,maxVaryings:x,maxFragmentUniforms:b,vertexTextures:D,maxSamples:R}}function J_(r){const e=this;let t=null,n=0,i=!1,s=!1;const o=new Yi,a=new lt,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const f=u.length!==0||d||n!==0||i;return i=d,n=u.length,f},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,f){const m=u.clippingPlanes,v=u.clipIntersection,g=u.clipShadows,p=r.get(u);if(!i||m===null||m.length===0||s&&!g)s?h(null):c();else{const M=s?0:n,x=M*4;let b=p.clippingState||null;l.value=b,b=h(m,d,x,f);for(let D=0;D!==x;++D)b[D]=t[D];p.clippingState=b,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=M}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,f,m){const v=u!==null?u.length:0;let g=null;if(v!==0){if(g=l.value,m!==!0||g===null){const p=f+v*4,M=d.matrixWorldInverse;a.getNormalMatrix(M),(g===null||g.length<p)&&(g=new Float32Array(p));for(let x=0,b=f;x!==v;++x,b+=4)o.copy(u[x]).applyMatrix4(M,a),o.normal.toArray(g,b),g[b+3]=o.constant}l.value=g,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,g}}function Q_(r){let e=new WeakMap;function t(o,a){return a===oa?o.mapping=ar:a===kl&&(o.mapping=lr),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===oa||a===kl)if(e.has(o)){const l=e.get(o).texture;return t(l,o.mapping)}else{const l=o.image;if(l&&l.height>0){const c=new hm(l.height);return c.fromEquirectangularTexture(r,o),e.set(o,c),o.addEventListener("dispose",i),t(c.texture,o.mapping)}else return null}}return o}function i(o){const a=o.target;a.removeEventListener("dispose",i);const l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function s(){e=new WeakMap}return{get:n,dispose:s}}const Qs=4,ru=[.125,.215,.35,.446,.526,.582],ms=20,cl=new Vc,ou=new Ge;let hl=null,ul=0,dl=0,fl=!1;const us=(1+Math.sqrt(5))/2,Ws=1/us,au=[new I(-us,Ws,0),new I(us,Ws,0),new I(-Ws,0,us),new I(Ws,0,us),new I(0,us,-Ws),new I(0,us,Ws),new I(-1,1,-1),new I(1,1,-1),new I(-1,1,1),new I(1,1,1)],ev=new I;class lu{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,i=100,s={}){const{size:o=256,position:a=ev}=s;hl=this._renderer.getRenderTarget(),ul=this._renderer.getActiveCubeFace(),dl=this._renderer.getActiveMipmapLevel(),fl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,n,i,l,a),t>0&&this._blur(l,0,0,t),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=uu(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=hu(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(hl,ul,dl),this._renderer.xr.enabled=fl,e.scissorTest=!1,No(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===ar||e.mapping===lr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),hl=this._renderer.getRenderTarget(),ul=this._renderer.getActiveCubeFace(),dl=this._renderer.getActiveMipmapLevel(),fl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:mn,minFilter:mn,generateMipmaps:!1,type:Xr,format:Sn,colorSpace:ur,depthBuffer:!1},i=cu(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=cu(e,t,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=tv(s)),this._blurMaterial=nv(s,e,t)}return i}_compileMaterial(e){const t=new ve(this._lodPlanes[0],e);this._renderer.compile(t,cl)}_sceneToCubeUV(e,t,n,i,s){const l=new Qt(90,1,t,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(ou),u.toneMapping=es,u.autoClear=!1;const m=new qn({name:"PMREM.Background",side:Un,depthWrite:!1,depthTest:!1}),v=new ve(new Yt,m);let g=!1;const p=e.background;p?p.isColor&&(m.color.copy(p),e.background=null,g=!0):(m.color.copy(ou),g=!0);for(let M=0;M<6;M++){const x=M%3;x===0?(l.up.set(0,c[M],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x+h[M],s.y,s.z)):x===1?(l.up.set(0,0,c[M]),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y+h[M],s.z)):(l.up.set(0,c[M],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y,s.z+h[M]));const b=this._cubeSize;No(i,x*b,M>2?b:0,b,b),u.setRenderTarget(i),g&&u.render(v,l),u.render(e,l)}v.geometry.dispose(),v.material.dispose(),u.toneMapping=f,u.autoClear=d,e.background=p}_textureToCubeUV(e,t){const n=this._renderer,i=e.mapping===ar||e.mapping===lr;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=uu()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=hu());const s=i?this._cubemapMaterial:this._equirectMaterial,o=new ve(this._lodPlanes[0],s),a=s.uniforms;a.envMap.value=e;const l=this._cubeSize;No(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,cl)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const i=this._lodPlanes.length;for(let s=1;s<i;s++){const o=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=au[(i-s-1)%au.length];this._blur(e,s-1,s,o,a)}t.autoClear=n}_blur(e,t,n,i,s){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,i,"latitudinal",s),this._halfBlur(o,e,n,n,i,"longitudinal",s)}_halfBlur(e,t,n,i,s,o,a){const l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,u=new ve(this._lodPlanes[i],c),d=c.uniforms,f=this._sizeLods[n]-1,m=isFinite(s)?Math.PI/(2*f):2*Math.PI/(2*ms-1),v=s/m,g=isFinite(s)?1+Math.floor(h*v):ms;g>ms&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${g} samples when the maximum is set to ${ms}`);const p=[];let M=0;for(let P=0;P<ms;++P){const S=P/v,_=Math.exp(-S*S/2);p.push(_),P===0?M+=_:P<g&&(M+=2*_)}for(let P=0;P<p.length;P++)p[P]=p[P]/M;d.envMap.value=e.texture,d.samples.value=g,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);const{_lodMax:x}=this;d.dTheta.value=m,d.mipInt.value=x-n;const b=this._sizeLods[i],D=3*b*(i>x-Qs?i-x+Qs:0),R=4*(this._cubeSize-b);No(t,D,R,3*b,2*b),l.setRenderTarget(t),l.render(u,cl)}}function tv(r){const e=[],t=[],n=[];let i=r;const s=r-Qs+1+ru.length;for(let o=0;o<s;o++){const a=Math.pow(2,i);t.push(a);let l=1/a;o>r-Qs?l=ru[o-r+Qs-1]:o===0&&(l=0),n.push(l);const c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,m=6,v=3,g=2,p=1,M=new Float32Array(v*m*f),x=new Float32Array(g*m*f),b=new Float32Array(p*m*f);for(let R=0;R<f;R++){const P=R%3*2/3-1,S=R>2?0:-1,_=[P,S,0,P+2/3,S,0,P+2/3,S+1,0,P,S,0,P+2/3,S+1,0,P,S+1,0];M.set(_,v*m*R),x.set(d,g*m*R);const y=[R,R,R,R,R,R];b.set(y,p*m*R)}const D=new yt;D.setAttribute("position",new Rn(M,v)),D.setAttribute("uv",new Rn(x,g)),D.setAttribute("faceIndex",new Rn(b,p)),e.push(D),i>Qs&&i--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function cu(r,e,t){const n=new ys(r,e,t);return n.texture.mapping=_a,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function No(r,e,t,n,i){r.viewport.set(e,t,n,i),r.scissor.set(e,t,n,i)}function nv(r,e,t){const n=new Float32Array(ms),i=new I(0,1,0);return new gi({name:"SphericalGaussianBlur",defines:{n:ms,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:Zc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function hu(){return new gi({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Zc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function uu(){return new gi({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Zc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Qi,depthTest:!1,depthWrite:!1})}function Zc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function iv(r){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){const l=a.mapping,c=l===oa||l===kl,h=l===ar||l===lr;if(c||h){let u=e.get(a);const d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return t===null&&(t=new lu(r)),u=c?t.fromEquirectangular(a,u):t.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),u.texture;if(u!==void 0)return u.texture;{const f=a.image;return c&&f&&f.height>0||h&&f&&i(f)?(t===null&&(t=new lu(r)),u=c?t.fromEquirectangular(a):t.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),a.addEventListener("dispose",s),u.texture):null}}}return a}function i(a){let l=0;const c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function s(a){const l=a.target;l.removeEventListener("dispose",s);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function sv(r){const e={};function t(n){if(e[n]!==void 0)return e[n];let i;switch(n){case"WEBGL_depth_texture":i=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=r.getExtension(n)}return e[n]=i,i}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const i=t(n);return i===null&&hs("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function rv(r,e,t,n){const i={},s=new WeakMap;function o(u){const d=u.target;d.index!==null&&e.remove(d.index);for(const m in d.attributes)e.remove(d.attributes[m]);d.removeEventListener("dispose",o),delete i[d.id];const f=s.get(d);f&&(e.remove(f),s.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(u,d){return i[d.id]===!0||(d.addEventListener("dispose",o),i[d.id]=!0,t.memory.geometries++),d}function l(u){const d=u.attributes;for(const f in d)e.update(d[f],r.ARRAY_BUFFER)}function c(u){const d=[],f=u.index,m=u.attributes.position;let v=0;if(f!==null){const M=f.array;v=f.version;for(let x=0,b=M.length;x<b;x+=3){const D=M[x+0],R=M[x+1],P=M[x+2];d.push(D,R,R,P,P,D)}}else if(m!==void 0){const M=m.array;v=m.version;for(let x=0,b=M.length/3-1;x<b;x+=3){const D=x+0,R=x+1,P=x+2;d.push(D,R,R,P,P,D)}}else return;const g=new(Nd(d)?Oc:Fc)(d,1);g.version=v;const p=s.get(u);p&&e.remove(p),s.set(u,g)}function h(u){const d=s.get(u);if(d){const f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return s.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function ov(r,e,t){let n;function i(d){n=d}let s,o;function a(d){s=d.type,o=d.bytesPerElement}function l(d,f){r.drawElements(n,f,s,d*o),t.update(f,n,1)}function c(d,f,m){m!==0&&(r.drawElementsInstanced(n,f,s,d*o,m),t.update(f,n,m))}function h(d,f,m){if(m===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,s,d,0,m);let g=0;for(let p=0;p<m;p++)g+=f[p];t.update(g,n,1)}function u(d,f,m,v){if(m===0)return;const g=e.get("WEBGL_multi_draw");if(g===null)for(let p=0;p<d.length;p++)c(d[p]/o,f[p],v[p]);else{g.multiDrawElementsInstancedWEBGL(n,f,0,s,d,0,v,0,m);let p=0;for(let M=0;M<m;M++)p+=f[M]*v[M];t.update(p,n,1)}}this.setMode=i,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function av(r){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,o,a){switch(t.calls++,o){case r.TRIANGLES:t.triangles+=a*(s/3);break;case r.LINES:t.lines+=a*(s/2);break;case r.LINE_STRIP:t.lines+=a*(s-1);break;case r.LINE_LOOP:t.lines+=a*s;break;case r.POINTS:t.points+=a*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function i(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:i,update:n}}function lv(r,e,t){const n=new WeakMap,i=new ct;function s(o,a,l){const c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0;let d=n.get(a);if(d===void 0||d.count!==u){let _=function(){P.dispose(),n.delete(a),a.removeEventListener("dispose",_)};d!==void 0&&d.texture.dispose();const f=a.morphAttributes.position!==void 0,m=a.morphAttributes.normal!==void 0,v=a.morphAttributes.color!==void 0,g=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],M=a.morphAttributes.color||[];let x=0;f===!0&&(x=1),m===!0&&(x=2),v===!0&&(x=3);let b=a.attributes.position.count*x,D=1;b>e.maxTextureSize&&(D=Math.ceil(b/e.maxTextureSize),b=e.maxTextureSize);const R=new Float32Array(b*D*4*u),P=new Ud(R,b,D,u);P.type=fi,P.needsUpdate=!0;const S=x*4;for(let y=0;y<u;y++){const T=g[y],F=p[y],k=M[y],G=b*D*4*y;for(let $=0;$<T.count;$++){const z=$*S;f===!0&&(i.fromBufferAttribute(T,$),R[G+z+0]=i.x,R[G+z+1]=i.y,R[G+z+2]=i.z,R[G+z+3]=0),m===!0&&(i.fromBufferAttribute(F,$),R[G+z+4]=i.x,R[G+z+5]=i.y,R[G+z+6]=i.z,R[G+z+7]=0),v===!0&&(i.fromBufferAttribute(k,$),R[G+z+8]=i.x,R[G+z+9]=i.y,R[G+z+10]=i.z,R[G+z+11]=k.itemSize===4?i.w:1)}}d={count:u,texture:P,size:new ye(b,D)},n.set(a,d),a.addEventListener("dispose",_)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(r,"morphTexture",o.morphTexture,t);else{let f=0;for(let v=0;v<c.length;v++)f+=c[v];const m=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(r,"morphTargetBaseInfluence",m),l.getUniforms().setValue(r,"morphTargetInfluences",c)}l.getUniforms().setValue(r,"morphTargetsTexture",d.texture,t),l.getUniforms().setValue(r,"morphTargetsTextureSize",d.size)}return{update:s}}function cv(r,e,t,n){let i=new WeakMap;function s(l){const c=n.render.frame,h=l.geometry,u=e.get(l,h);if(i.get(u)!==c&&(e.update(u),i.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),i.get(l)!==c&&(t.update(l.instanceMatrix,r.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,r.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){const d=l.skeleton;i.get(d)!==c&&(d.update(),i.set(d,c))}return u}function o(){i=new WeakMap}function a(l){const c=l.target;c.removeEventListener("dispose",a),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:s,dispose:o}}const tf=new qt,du=new Vd(1,1),nf=new Ud,sf=new Yp,rf=new kd,fu=[],pu=[],mu=new Float32Array(16),gu=new Float32Array(9),_u=new Float32Array(4);function vr(r,e,t){const n=r[0];if(n<=0||n>0)return r;const i=e*t;let s=fu[i];if(s===void 0&&(s=new Float32Array(i),fu[i]=s),e!==0){n.toArray(s,0);for(let o=1,a=0;o!==e;++o)a+=t,r[o].toArray(s,a)}return s}function rn(r,e){if(r.length!==e.length)return!1;for(let t=0,n=r.length;t<n;t++)if(r[t]!==e[t])return!1;return!0}function on(r,e){for(let t=0,n=e.length;t<n;t++)r[t]=e[t]}function Sa(r,e){let t=pu[e];t===void 0&&(t=new Int32Array(e),pu[e]=t);for(let n=0;n!==e;++n)t[n]=r.allocateTextureUnit();return t}function hv(r,e){const t=this.cache;t[0]!==e&&(r.uniform1f(this.addr,e),t[0]=e)}function uv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(rn(t,e))return;r.uniform2fv(this.addr,e),on(t,e)}}function dv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(r.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(rn(t,e))return;r.uniform3fv(this.addr,e),on(t,e)}}function fv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(rn(t,e))return;r.uniform4fv(this.addr,e),on(t,e)}}function pv(r,e){const t=this.cache,n=e.elements;if(n===void 0){if(rn(t,e))return;r.uniformMatrix2fv(this.addr,!1,e),on(t,e)}else{if(rn(t,n))return;_u.set(n),r.uniformMatrix2fv(this.addr,!1,_u),on(t,n)}}function mv(r,e){const t=this.cache,n=e.elements;if(n===void 0){if(rn(t,e))return;r.uniformMatrix3fv(this.addr,!1,e),on(t,e)}else{if(rn(t,n))return;gu.set(n),r.uniformMatrix3fv(this.addr,!1,gu),on(t,n)}}function gv(r,e){const t=this.cache,n=e.elements;if(n===void 0){if(rn(t,e))return;r.uniformMatrix4fv(this.addr,!1,e),on(t,e)}else{if(rn(t,n))return;mu.set(n),r.uniformMatrix4fv(this.addr,!1,mu),on(t,n)}}function _v(r,e){const t=this.cache;t[0]!==e&&(r.uniform1i(this.addr,e),t[0]=e)}function vv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(rn(t,e))return;r.uniform2iv(this.addr,e),on(t,e)}}function xv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(rn(t,e))return;r.uniform3iv(this.addr,e),on(t,e)}}function yv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(rn(t,e))return;r.uniform4iv(this.addr,e),on(t,e)}}function bv(r,e){const t=this.cache;t[0]!==e&&(r.uniform1ui(this.addr,e),t[0]=e)}function Mv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(rn(t,e))return;r.uniform2uiv(this.addr,e),on(t,e)}}function Sv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(rn(t,e))return;r.uniform3uiv(this.addr,e),on(t,e)}}function wv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(rn(t,e))return;r.uniform4uiv(this.addr,e),on(t,e)}}function Ev(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i);let s;this.type===r.SAMPLER_2D_SHADOW?(du.compareFunction=Id,s=du):s=tf,t.setTexture2D(e||s,i)}function Tv(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTexture3D(e||sf,i)}function Av(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTextureCube(e||rf,i)}function Rv(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTexture2DArray(e||nf,i)}function Cv(r){switch(r){case 5126:return hv;case 35664:return uv;case 35665:return dv;case 35666:return fv;case 35674:return pv;case 35675:return mv;case 35676:return gv;case 5124:case 35670:return _v;case 35667:case 35671:return vv;case 35668:case 35672:return xv;case 35669:case 35673:return yv;case 5125:return bv;case 36294:return Mv;case 36295:return Sv;case 36296:return wv;case 35678:case 36198:case 36298:case 36306:case 35682:return Ev;case 35679:case 36299:case 36307:return Tv;case 35680:case 36300:case 36308:case 36293:return Av;case 36289:case 36303:case 36311:case 36292:return Rv}}function Pv(r,e){r.uniform1fv(this.addr,e)}function Lv(r,e){const t=vr(e,this.size,2);r.uniform2fv(this.addr,t)}function Dv(r,e){const t=vr(e,this.size,3);r.uniform3fv(this.addr,t)}function Iv(r,e){const t=vr(e,this.size,4);r.uniform4fv(this.addr,t)}function Nv(r,e){const t=vr(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,t)}function Uv(r,e){const t=vr(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,t)}function Fv(r,e){const t=vr(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,t)}function Ov(r,e){r.uniform1iv(this.addr,e)}function Bv(r,e){r.uniform2iv(this.addr,e)}function kv(r,e){r.uniform3iv(this.addr,e)}function zv(r,e){r.uniform4iv(this.addr,e)}function Hv(r,e){r.uniform1uiv(this.addr,e)}function Vv(r,e){r.uniform2uiv(this.addr,e)}function Gv(r,e){r.uniform3uiv(this.addr,e)}function Wv(r,e){r.uniform4uiv(this.addr,e)}function Xv(r,e,t){const n=this.cache,i=e.length,s=Sa(t,i);rn(n,s)||(r.uniform1iv(this.addr,s),on(n,s));for(let o=0;o!==i;++o)t.setTexture2D(e[o]||tf,s[o])}function jv(r,e,t){const n=this.cache,i=e.length,s=Sa(t,i);rn(n,s)||(r.uniform1iv(this.addr,s),on(n,s));for(let o=0;o!==i;++o)t.setTexture3D(e[o]||sf,s[o])}function qv(r,e,t){const n=this.cache,i=e.length,s=Sa(t,i);rn(n,s)||(r.uniform1iv(this.addr,s),on(n,s));for(let o=0;o!==i;++o)t.setTextureCube(e[o]||rf,s[o])}function Yv(r,e,t){const n=this.cache,i=e.length,s=Sa(t,i);rn(n,s)||(r.uniform1iv(this.addr,s),on(n,s));for(let o=0;o!==i;++o)t.setTexture2DArray(e[o]||nf,s[o])}function Zv(r){switch(r){case 5126:return Pv;case 35664:return Lv;case 35665:return Dv;case 35666:return Iv;case 35674:return Nv;case 35675:return Uv;case 35676:return Fv;case 5124:case 35670:return Ov;case 35667:case 35671:return Bv;case 35668:case 35672:return kv;case 35669:case 35673:return zv;case 5125:return Hv;case 36294:return Vv;case 36295:return Gv;case 36296:return Wv;case 35678:case 36198:case 36298:case 36306:case 35682:return Xv;case 35679:case 36299:case 36307:return jv;case 35680:case 36300:case 36308:case 36293:return qv;case 36289:case 36303:case 36311:case 36292:return Yv}}class Kv{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Cv(t.type)}}class $v{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=Zv(t.type)}}class Jv{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const i=this.seq;for(let s=0,o=i.length;s!==o;++s){const a=i[s];a.setValue(e,t[a.id],n)}}}const pl=/(\w+)(\])?(\[|\.)?/g;function vu(r,e){r.seq.push(e),r.map[e.id]=e}function Qv(r,e,t){const n=r.name,i=n.length;for(pl.lastIndex=0;;){const s=pl.exec(n),o=pl.lastIndex;let a=s[1];const l=s[2]==="]",c=s[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===i){vu(t,c===void 0?new Kv(a,r,e):new $v(a,r,e));break}else{let u=t.map[a];u===void 0&&(u=new Jv(a),vu(t,u)),t=u}}}class na{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const s=e.getActiveUniform(t,i),o=e.getUniformLocation(t,s.name);Qv(s,o,this)}}setValue(e,t,n,i){const s=this.map[t];s!==void 0&&s.setValue(e,n,i)}setOptional(e,t,n){const i=t[n];i!==void 0&&this.setValue(e,n,i)}static upload(e,t,n,i){for(let s=0,o=t.length;s!==o;++s){const a=t[s],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,i)}}static seqWithValue(e,t){const n=[];for(let i=0,s=e.length;i!==s;++i){const o=e[i];o.id in t&&n.push(o)}return n}}function xu(r,e,t){const n=r.createShader(e);return r.shaderSource(n,t),r.compileShader(n),n}const ex=37297;let tx=0;function nx(r,e){const t=r.split(`
`),n=[],i=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let o=i;o<s;o++){const a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}const yu=new lt;function ix(r){rt._getMatrix(yu,rt.workingColorSpace,r);const e=`mat3( ${yu.elements.map(t=>t.toFixed(4))} )`;switch(rt.getTransfer(r)){case la:return[e,"LinearTransferOETF"];case Nt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",r),[e,"LinearTransferOETF"]}}function bu(r,e,t){const n=r.getShaderParameter(e,r.COMPILE_STATUS),i=r.getShaderInfoLog(e).trim();if(n&&i==="")return"";const s=/ERROR: 0:(\d+)/.exec(i);if(s){const o=parseInt(s[1]);return t.toUpperCase()+`

`+i+`

`+nx(r.getShaderSource(e),o)}else return i}function sx(r,e){const t=ix(e);return[`vec4 ${r}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function rx(r,e){let t;switch(e){case ip:t="Linear";break;case sp:t="Reinhard";break;case rp:t="Cineon";break;case op:t="ACESFilmic";break;case lp:t="AgX";break;case cp:t="Neutral";break;case ap:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+r+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const Uo=new I;function ox(){rt.getLuminanceCoefficients(Uo);const r=Uo.x.toFixed(4),e=Uo.y.toFixed(4),t=Uo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function ax(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Pr).join(`
`)}function lx(r){const e=[];for(const t in r){const n=r[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function cx(r,e){const t={},n=r.getProgramParameter(e,r.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const s=r.getActiveAttrib(e,i),o=s.name;let a=1;s.type===r.FLOAT_MAT2&&(a=2),s.type===r.FLOAT_MAT3&&(a=3),s.type===r.FLOAT_MAT4&&(a=4),t[o]={type:s.type,location:r.getAttribLocation(e,o),locationSize:a}}return t}function Pr(r){return r!==""}function Mu(r,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Su(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const hx=/^[ \t]*#include +<([\w\d./]+)>/gm;function Sc(r){return r.replace(hx,dx)}const ux=new Map;function dx(r,e){let t=pt[e];if(t===void 0){const n=ux.get(e);if(n!==void 0)t=pt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Sc(t)}const fx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function wu(r){return r.replace(fx,px)}function px(r,e,t,n){let i="";for(let s=parseInt(e);s<parseInt(t);s++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return i}function Eu(r){let e=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function mx(r){let e="SHADOWMAP_TYPE_BASIC";return r.shadowMapType===bd?e="SHADOWMAP_TYPE_PCF":r.shadowMapType===Ff?e="SHADOWMAP_TYPE_PCF_SOFT":r.shadowMapType===Ri&&(e="SHADOWMAP_TYPE_VSM"),e}function gx(r){let e="ENVMAP_TYPE_CUBE";if(r.envMap)switch(r.envMapMode){case ar:case lr:e="ENVMAP_TYPE_CUBE";break;case _a:e="ENVMAP_TYPE_CUBE_UV";break}return e}function _x(r){let e="ENVMAP_MODE_REFLECTION";if(r.envMap)switch(r.envMapMode){case lr:e="ENVMAP_MODE_REFRACTION";break}return e}function vx(r){let e="ENVMAP_BLENDING_NONE";if(r.envMap)switch(r.combine){case ga:e="ENVMAP_BLENDING_MULTIPLY";break;case tp:e="ENVMAP_BLENDING_MIX";break;case np:e="ENVMAP_BLENDING_ADD";break}return e}function xx(r){const e=r.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:n,maxMip:t}}function yx(r,e,t,n){const i=r.getContext(),s=t.defines;let o=t.vertexShader,a=t.fragmentShader;const l=mx(t),c=gx(t),h=_x(t),u=vx(t),d=xx(t),f=ax(t),m=lx(s),v=i.createProgram();let g,p,M=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(g=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(Pr).join(`
`),g.length>0&&(g+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(Pr).join(`
`),p.length>0&&(p+=`
`)):(g=[Eu(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Pr).join(`
`),p=[Eu(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==es?"#define TONE_MAPPING":"",t.toneMapping!==es?pt.tonemapping_pars_fragment:"",t.toneMapping!==es?rx("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",pt.colorspace_pars_fragment,sx("linearToOutputTexel",t.outputColorSpace),ox(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Pr).join(`
`)),o=Sc(o),o=Mu(o,t),o=Su(o,t),a=Sc(a),a=Mu(a,t),a=Su(a,t),o=wu(o),a=wu(a),t.isRawShaderMaterial!==!0&&(M=`#version 300 es
`,g=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+g,p=["#define varying in",t.glslVersion===uh?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===uh?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const x=M+g+o,b=M+p+a,D=xu(i,i.VERTEX_SHADER,x),R=xu(i,i.FRAGMENT_SHADER,b);i.attachShader(v,D),i.attachShader(v,R),t.index0AttributeName!==void 0?i.bindAttribLocation(v,0,t.index0AttributeName):t.morphTargets===!0&&i.bindAttribLocation(v,0,"position"),i.linkProgram(v);function P(T){if(r.debug.checkShaderErrors){const F=i.getProgramInfoLog(v).trim(),k=i.getShaderInfoLog(D).trim(),G=i.getShaderInfoLog(R).trim();let $=!0,z=!0;if(i.getProgramParameter(v,i.LINK_STATUS)===!1)if($=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(i,v,D,R);else{const Y=bu(i,D,"vertex"),H=bu(i,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(v,i.VALIDATE_STATUS)+`

Material Name: `+T.name+`
Material Type: `+T.type+`

Program Info Log: `+F+`
`+Y+`
`+H)}else F!==""?console.warn("THREE.WebGLProgram: Program Info Log:",F):(k===""||G==="")&&(z=!1);z&&(T.diagnostics={runnable:$,programLog:F,vertexShader:{log:k,prefix:g},fragmentShader:{log:G,prefix:p}})}i.deleteShader(D),i.deleteShader(R),S=new na(i,v),_=cx(i,v)}let S;this.getUniforms=function(){return S===void 0&&P(this),S};let _;this.getAttributes=function(){return _===void 0&&P(this),_};let y=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return y===!1&&(y=i.getProgramParameter(v,ex)),y},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=tx++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=D,this.fragmentShader=R,this}let bx=0;class Mx{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,i=this._getShaderStage(t),s=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(i)===!1&&(o.add(i),i.usedTimes++),o.has(s)===!1&&(o.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new Sx(e),t.set(e,n)),n}}class Sx{constructor(e){this.id=bx++,this.code=e,this.usedTimes=0}}function wx(r,e,t,n,i,s,o){const a=new Uc,l=new Mx,c=new Set,h=[],u=i.logarithmicDepthBuffer,d=i.vertexTextures;let f=i.precision;const m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(_){return c.add(_),_===0?"uv":`uv${_}`}function g(_,y,T,F,k){const G=F.fog,$=k.geometry,z=_.isMeshStandardMaterial?F.environment:null,Y=(_.isMeshStandardMaterial?t:e).get(_.envMap||z),H=Y&&Y.mapping===_a?Y.image.height:null,q=m[_.type];_.precision!==null&&(f=i.getMaxPrecision(_.precision),f!==_.precision&&console.warn("THREE.WebGLProgram.getParameters:",_.precision,"not supported, using",f,"instead."));const ue=$.morphAttributes.position||$.morphAttributes.normal||$.morphAttributes.color,re=ue!==void 0?ue.length:0;let de=0;$.morphAttributes.position!==void 0&&(de=1),$.morphAttributes.normal!==void 0&&(de=2),$.morphAttributes.color!==void 0&&(de=3);let ie,W,Z,Q;if(q){const ut=Nn[q];ie=ut.vertexShader,W=ut.fragmentShader}else ie=_.vertexShader,W=_.fragmentShader,l.update(_),Z=l.getVertexShaderID(_),Q=l.getFragmentShaderID(_);const ne=r.getRenderTarget(),ce=r.state.buffers.depth.getReversed(),Me=k.isInstancedMesh===!0,we=k.isBatchedMesh===!0,Ne=!!_.map,Je=!!_.matcap,We=!!Y,B=!!_.aoMap,ht=!!_.lightMap,Pe=!!_.bumpMap,tt=!!_.normalMap,me=!!_.displacementMap,Qe=!!_.emissiveMap,ke=!!_.metalnessMap,O=!!_.roughnessMap,A=_.anisotropy>0,K=_.clearcoat>0,ae=_.dispersion>0,he=_.iridescence>0,se=_.sheen>0,Re=_.transmission>0,xe=A&&!!_.anisotropyMap,Fe=K&&!!_.clearcoatMap,gt=K&&!!_.clearcoatNormalMap,ge=K&&!!_.clearcoatRoughnessMap,Ee=he&&!!_.iridescenceMap,qe=he&&!!_.iridescenceThicknessMap,et=se&&!!_.sheenColorMap,ze=se&&!!_.sheenRoughnessMap,vt=!!_.specularMap,at=!!_.specularColorMap,Lt=!!_.specularIntensityMap,X=Re&&!!_.transmissionMap,Ce=Re&&!!_.thicknessMap,oe=!!_.gradientMap,fe=!!_.alphaMap,Ue=_.alphaTest>0,De=!!_.alphaHash,ot=!!_.extensions;let kt=es;_.toneMapped&&(ne===null||ne.isXRRenderTarget===!0)&&(kt=r.toneMapping);const an={shaderID:q,shaderType:_.type,shaderName:_.name,vertexShader:ie,fragmentShader:W,defines:_.defines,customVertexShaderID:Z,customFragmentShaderID:Q,isRawShaderMaterial:_.isRawShaderMaterial===!0,glslVersion:_.glslVersion,precision:f,batching:we,batchingColor:we&&k._colorsTexture!==null,instancing:Me,instancingColor:Me&&k.instanceColor!==null,instancingMorph:Me&&k.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:ne===null?r.outputColorSpace:ne.isXRRenderTarget===!0?ne.texture.colorSpace:ur,alphaToCoverage:!!_.alphaToCoverage,map:Ne,matcap:Je,envMap:We,envMapMode:We&&Y.mapping,envMapCubeUVHeight:H,aoMap:B,lightMap:ht,bumpMap:Pe,normalMap:tt,displacementMap:d&&me,emissiveMap:Qe,normalMapObjectSpace:tt&&_.normalMapType===mp,normalMapTangentSpace:tt&&_.normalMapType===Dc,metalnessMap:ke,roughnessMap:O,anisotropy:A,anisotropyMap:xe,clearcoat:K,clearcoatMap:Fe,clearcoatNormalMap:gt,clearcoatRoughnessMap:ge,dispersion:ae,iridescence:he,iridescenceMap:Ee,iridescenceThicknessMap:qe,sheen:se,sheenColorMap:et,sheenRoughnessMap:ze,specularMap:vt,specularColorMap:at,specularIntensityMap:Lt,transmission:Re,transmissionMap:X,thicknessMap:Ce,gradientMap:oe,opaque:_.transparent===!1&&_.blending===nr&&_.alphaToCoverage===!1,alphaMap:fe,alphaTest:Ue,alphaHash:De,combine:_.combine,mapUv:Ne&&v(_.map.channel),aoMapUv:B&&v(_.aoMap.channel),lightMapUv:ht&&v(_.lightMap.channel),bumpMapUv:Pe&&v(_.bumpMap.channel),normalMapUv:tt&&v(_.normalMap.channel),displacementMapUv:me&&v(_.displacementMap.channel),emissiveMapUv:Qe&&v(_.emissiveMap.channel),metalnessMapUv:ke&&v(_.metalnessMap.channel),roughnessMapUv:O&&v(_.roughnessMap.channel),anisotropyMapUv:xe&&v(_.anisotropyMap.channel),clearcoatMapUv:Fe&&v(_.clearcoatMap.channel),clearcoatNormalMapUv:gt&&v(_.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ge&&v(_.clearcoatRoughnessMap.channel),iridescenceMapUv:Ee&&v(_.iridescenceMap.channel),iridescenceThicknessMapUv:qe&&v(_.iridescenceThicknessMap.channel),sheenColorMapUv:et&&v(_.sheenColorMap.channel),sheenRoughnessMapUv:ze&&v(_.sheenRoughnessMap.channel),specularMapUv:vt&&v(_.specularMap.channel),specularColorMapUv:at&&v(_.specularColorMap.channel),specularIntensityMapUv:Lt&&v(_.specularIntensityMap.channel),transmissionMapUv:X&&v(_.transmissionMap.channel),thicknessMapUv:Ce&&v(_.thicknessMap.channel),alphaMapUv:fe&&v(_.alphaMap.channel),vertexTangents:!!$.attributes.tangent&&(tt||A),vertexColors:_.vertexColors,vertexAlphas:_.vertexColors===!0&&!!$.attributes.color&&$.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!$.attributes.uv&&(Ne||fe),fog:!!G,useFog:_.fog===!0,fogExp2:!!G&&G.isFogExp2,flatShading:_.flatShading===!0,sizeAttenuation:_.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:ce,skinning:k.isSkinnedMesh===!0,morphTargets:$.morphAttributes.position!==void 0,morphNormals:$.morphAttributes.normal!==void 0,morphColors:$.morphAttributes.color!==void 0,morphTargetsCount:re,morphTextureStride:de,numDirLights:y.directional.length,numPointLights:y.point.length,numSpotLights:y.spot.length,numSpotLightMaps:y.spotLightMap.length,numRectAreaLights:y.rectArea.length,numHemiLights:y.hemi.length,numDirLightShadows:y.directionalShadowMap.length,numPointLightShadows:y.pointShadowMap.length,numSpotLightShadows:y.spotShadowMap.length,numSpotLightShadowsWithMaps:y.numSpotLightShadowsWithMaps,numLightProbes:y.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:_.dithering,shadowMapEnabled:r.shadowMap.enabled&&T.length>0,shadowMapType:r.shadowMap.type,toneMapping:kt,decodeVideoTexture:Ne&&_.map.isVideoTexture===!0&&rt.getTransfer(_.map.colorSpace)===Nt,decodeVideoTextureEmissive:Qe&&_.emissiveMap.isVideoTexture===!0&&rt.getTransfer(_.emissiveMap.colorSpace)===Nt,premultipliedAlpha:_.premultipliedAlpha,doubleSided:_.side===Wn,flipSided:_.side===Un,useDepthPacking:_.depthPacking>=0,depthPacking:_.depthPacking||0,index0AttributeName:_.index0AttributeName,extensionClipCullDistance:ot&&_.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ot&&_.extensions.multiDraw===!0||we)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:_.customProgramCacheKey()};return an.vertexUv1s=c.has(1),an.vertexUv2s=c.has(2),an.vertexUv3s=c.has(3),c.clear(),an}function p(_){const y=[];if(_.shaderID?y.push(_.shaderID):(y.push(_.customVertexShaderID),y.push(_.customFragmentShaderID)),_.defines!==void 0)for(const T in _.defines)y.push(T),y.push(_.defines[T]);return _.isRawShaderMaterial===!1&&(M(y,_),x(y,_),y.push(r.outputColorSpace)),y.push(_.customProgramCacheKey),y.join()}function M(_,y){_.push(y.precision),_.push(y.outputColorSpace),_.push(y.envMapMode),_.push(y.envMapCubeUVHeight),_.push(y.mapUv),_.push(y.alphaMapUv),_.push(y.lightMapUv),_.push(y.aoMapUv),_.push(y.bumpMapUv),_.push(y.normalMapUv),_.push(y.displacementMapUv),_.push(y.emissiveMapUv),_.push(y.metalnessMapUv),_.push(y.roughnessMapUv),_.push(y.anisotropyMapUv),_.push(y.clearcoatMapUv),_.push(y.clearcoatNormalMapUv),_.push(y.clearcoatRoughnessMapUv),_.push(y.iridescenceMapUv),_.push(y.iridescenceThicknessMapUv),_.push(y.sheenColorMapUv),_.push(y.sheenRoughnessMapUv),_.push(y.specularMapUv),_.push(y.specularColorMapUv),_.push(y.specularIntensityMapUv),_.push(y.transmissionMapUv),_.push(y.thicknessMapUv),_.push(y.combine),_.push(y.fogExp2),_.push(y.sizeAttenuation),_.push(y.morphTargetsCount),_.push(y.morphAttributeCount),_.push(y.numDirLights),_.push(y.numPointLights),_.push(y.numSpotLights),_.push(y.numSpotLightMaps),_.push(y.numHemiLights),_.push(y.numRectAreaLights),_.push(y.numDirLightShadows),_.push(y.numPointLightShadows),_.push(y.numSpotLightShadows),_.push(y.numSpotLightShadowsWithMaps),_.push(y.numLightProbes),_.push(y.shadowMapType),_.push(y.toneMapping),_.push(y.numClippingPlanes),_.push(y.numClipIntersection),_.push(y.depthPacking)}function x(_,y){a.disableAll(),y.supportsVertexTextures&&a.enable(0),y.instancing&&a.enable(1),y.instancingColor&&a.enable(2),y.instancingMorph&&a.enable(3),y.matcap&&a.enable(4),y.envMap&&a.enable(5),y.normalMapObjectSpace&&a.enable(6),y.normalMapTangentSpace&&a.enable(7),y.clearcoat&&a.enable(8),y.iridescence&&a.enable(9),y.alphaTest&&a.enable(10),y.vertexColors&&a.enable(11),y.vertexAlphas&&a.enable(12),y.vertexUv1s&&a.enable(13),y.vertexUv2s&&a.enable(14),y.vertexUv3s&&a.enable(15),y.vertexTangents&&a.enable(16),y.anisotropy&&a.enable(17),y.alphaHash&&a.enable(18),y.batching&&a.enable(19),y.dispersion&&a.enable(20),y.batchingColor&&a.enable(21),_.push(a.mask),a.disableAll(),y.fog&&a.enable(0),y.useFog&&a.enable(1),y.flatShading&&a.enable(2),y.logarithmicDepthBuffer&&a.enable(3),y.reverseDepthBuffer&&a.enable(4),y.skinning&&a.enable(5),y.morphTargets&&a.enable(6),y.morphNormals&&a.enable(7),y.morphColors&&a.enable(8),y.premultipliedAlpha&&a.enable(9),y.shadowMapEnabled&&a.enable(10),y.doubleSided&&a.enable(11),y.flipSided&&a.enable(12),y.useDepthPacking&&a.enable(13),y.dithering&&a.enable(14),y.transmission&&a.enable(15),y.sheen&&a.enable(16),y.opaque&&a.enable(17),y.pointsUvs&&a.enable(18),y.decodeVideoTexture&&a.enable(19),y.decodeVideoTextureEmissive&&a.enable(20),y.alphaToCoverage&&a.enable(21),_.push(a.mask)}function b(_){const y=m[_.type];let T;if(y){const F=Nn[y];T=Bc.clone(F.uniforms)}else T=_.uniforms;return T}function D(_,y){let T;for(let F=0,k=h.length;F<k;F++){const G=h[F];if(G.cacheKey===y){T=G,++T.usedTimes;break}}return T===void 0&&(T=new yx(r,y,_,s),h.push(T)),T}function R(_){if(--_.usedTimes===0){const y=h.indexOf(_);h[y]=h[h.length-1],h.pop(),_.destroy()}}function P(_){l.remove(_)}function S(){l.dispose()}return{getParameters:g,getProgramCacheKey:p,getUniforms:b,acquireProgram:D,releaseProgram:R,releaseShaderCache:P,programs:h,dispose:S}}function Ex(){let r=new WeakMap;function e(o){return r.has(o)}function t(o){let a=r.get(o);return a===void 0&&(a={},r.set(o,a)),a}function n(o){r.delete(o)}function i(o,a,l){r.get(o)[a]=l}function s(){r=new WeakMap}return{has:e,get:t,remove:n,update:i,dispose:s}}function Tx(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.z!==e.z?r.z-e.z:r.id-e.id}function Tu(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function Au(){const r=[];let e=0;const t=[],n=[],i=[];function s(){e=0,t.length=0,n.length=0,i.length=0}function o(u,d,f,m,v,g){let p=r[e];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:m,renderOrder:u.renderOrder,z:v,group:g},r[e]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=m,p.renderOrder=u.renderOrder,p.z=v,p.group=g),e++,p}function a(u,d,f,m,v,g){const p=o(u,d,f,m,v,g);f.transmission>0?n.push(p):f.transparent===!0?i.push(p):t.push(p)}function l(u,d,f,m,v,g){const p=o(u,d,f,m,v,g);f.transmission>0?n.unshift(p):f.transparent===!0?i.unshift(p):t.unshift(p)}function c(u,d){t.length>1&&t.sort(u||Tx),n.length>1&&n.sort(d||Tu),i.length>1&&i.sort(d||Tu)}function h(){for(let u=e,d=r.length;u<d;u++){const f=r[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:i,init:s,push:a,unshift:l,finish:h,sort:c}}function Ax(){let r=new WeakMap;function e(n,i){const s=r.get(n);let o;return s===void 0?(o=new Au,r.set(n,[o])):i>=s.length?(o=new Au,s.push(o)):o=s[i],o}function t(){r=new WeakMap}return{get:e,dispose:t}}function Rx(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new I,color:new Ge};break;case"SpotLight":t={position:new I,direction:new I,color:new Ge,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new I,color:new Ge,distance:0,decay:0};break;case"HemisphereLight":t={direction:new I,skyColor:new Ge,groundColor:new Ge};break;case"RectAreaLight":t={color:new Ge,position:new I,halfWidth:new I,halfHeight:new I};break}return r[e.id]=t,t}}}function Cx(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ye};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ye};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ye,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[e.id]=t,t}}}let Px=0;function Lx(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function Dx(r){const e=new Rx,t=Cx(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new I);const i=new I,s=new Te,o=new Te;function a(c){let h=0,u=0,d=0;for(let _=0;_<9;_++)n.probe[_].set(0,0,0);let f=0,m=0,v=0,g=0,p=0,M=0,x=0,b=0,D=0,R=0,P=0;c.sort(Lx);for(let _=0,y=c.length;_<y;_++){const T=c[_],F=T.color,k=T.intensity,G=T.distance,$=T.shadow&&T.shadow.map?T.shadow.map.texture:null;if(T.isAmbientLight)h+=F.r*k,u+=F.g*k,d+=F.b*k;else if(T.isLightProbe){for(let z=0;z<9;z++)n.probe[z].addScaledVector(T.sh.coefficients[z],k);P++}else if(T.isDirectionalLight){const z=e.get(T);if(z.color.copy(T.color).multiplyScalar(T.intensity),T.castShadow){const Y=T.shadow,H=t.get(T);H.shadowIntensity=Y.intensity,H.shadowBias=Y.bias,H.shadowNormalBias=Y.normalBias,H.shadowRadius=Y.radius,H.shadowMapSize=Y.mapSize,n.directionalShadow[f]=H,n.directionalShadowMap[f]=$,n.directionalShadowMatrix[f]=T.shadow.matrix,M++}n.directional[f]=z,f++}else if(T.isSpotLight){const z=e.get(T);z.position.setFromMatrixPosition(T.matrixWorld),z.color.copy(F).multiplyScalar(k),z.distance=G,z.coneCos=Math.cos(T.angle),z.penumbraCos=Math.cos(T.angle*(1-T.penumbra)),z.decay=T.decay,n.spot[v]=z;const Y=T.shadow;if(T.map&&(n.spotLightMap[D]=T.map,D++,Y.updateMatrices(T),T.castShadow&&R++),n.spotLightMatrix[v]=Y.matrix,T.castShadow){const H=t.get(T);H.shadowIntensity=Y.intensity,H.shadowBias=Y.bias,H.shadowNormalBias=Y.normalBias,H.shadowRadius=Y.radius,H.shadowMapSize=Y.mapSize,n.spotShadow[v]=H,n.spotShadowMap[v]=$,b++}v++}else if(T.isRectAreaLight){const z=e.get(T);z.color.copy(F).multiplyScalar(k),z.halfWidth.set(T.width*.5,0,0),z.halfHeight.set(0,T.height*.5,0),n.rectArea[g]=z,g++}else if(T.isPointLight){const z=e.get(T);if(z.color.copy(T.color).multiplyScalar(T.intensity),z.distance=T.distance,z.decay=T.decay,T.castShadow){const Y=T.shadow,H=t.get(T);H.shadowIntensity=Y.intensity,H.shadowBias=Y.bias,H.shadowNormalBias=Y.normalBias,H.shadowRadius=Y.radius,H.shadowMapSize=Y.mapSize,H.shadowCameraNear=Y.camera.near,H.shadowCameraFar=Y.camera.far,n.pointShadow[m]=H,n.pointShadowMap[m]=$,n.pointShadowMatrix[m]=T.shadow.matrix,x++}n.point[m]=z,m++}else if(T.isHemisphereLight){const z=e.get(T);z.skyColor.copy(T.color).multiplyScalar(k),z.groundColor.copy(T.groundColor).multiplyScalar(k),n.hemi[p]=z,p++}}g>0&&(r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=Se.LTC_FLOAT_1,n.rectAreaLTC2=Se.LTC_FLOAT_2):(n.rectAreaLTC1=Se.LTC_HALF_1,n.rectAreaLTC2=Se.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;const S=n.hash;(S.directionalLength!==f||S.pointLength!==m||S.spotLength!==v||S.rectAreaLength!==g||S.hemiLength!==p||S.numDirectionalShadows!==M||S.numPointShadows!==x||S.numSpotShadows!==b||S.numSpotMaps!==D||S.numLightProbes!==P)&&(n.directional.length=f,n.spot.length=v,n.rectArea.length=g,n.point.length=m,n.hemi.length=p,n.directionalShadow.length=M,n.directionalShadowMap.length=M,n.pointShadow.length=x,n.pointShadowMap.length=x,n.spotShadow.length=b,n.spotShadowMap.length=b,n.directionalShadowMatrix.length=M,n.pointShadowMatrix.length=x,n.spotLightMatrix.length=b+D-R,n.spotLightMap.length=D,n.numSpotLightShadowsWithMaps=R,n.numLightProbes=P,S.directionalLength=f,S.pointLength=m,S.spotLength=v,S.rectAreaLength=g,S.hemiLength=p,S.numDirectionalShadows=M,S.numPointShadows=x,S.numSpotShadows=b,S.numSpotMaps=D,S.numLightProbes=P,n.version=Px++)}function l(c,h){let u=0,d=0,f=0,m=0,v=0;const g=h.matrixWorldInverse;for(let p=0,M=c.length;p<M;p++){const x=c[p];if(x.isDirectionalLight){const b=n.directional[u];b.direction.setFromMatrixPosition(x.matrixWorld),i.setFromMatrixPosition(x.target.matrixWorld),b.direction.sub(i),b.direction.transformDirection(g),u++}else if(x.isSpotLight){const b=n.spot[f];b.position.setFromMatrixPosition(x.matrixWorld),b.position.applyMatrix4(g),b.direction.setFromMatrixPosition(x.matrixWorld),i.setFromMatrixPosition(x.target.matrixWorld),b.direction.sub(i),b.direction.transformDirection(g),f++}else if(x.isRectAreaLight){const b=n.rectArea[m];b.position.setFromMatrixPosition(x.matrixWorld),b.position.applyMatrix4(g),o.identity(),s.copy(x.matrixWorld),s.premultiply(g),o.extractRotation(s),b.halfWidth.set(x.width*.5,0,0),b.halfHeight.set(0,x.height*.5,0),b.halfWidth.applyMatrix4(o),b.halfHeight.applyMatrix4(o),m++}else if(x.isPointLight){const b=n.point[d];b.position.setFromMatrixPosition(x.matrixWorld),b.position.applyMatrix4(g),d++}else if(x.isHemisphereLight){const b=n.hemi[v];b.direction.setFromMatrixPosition(x.matrixWorld),b.direction.transformDirection(g),v++}}}return{setup:a,setupView:l,state:n}}function Ru(r){const e=new Dx(r),t=[],n=[];function i(h){c.camera=h,t.length=0,n.length=0}function s(h){t.push(h)}function o(h){n.push(h)}function a(){e.setup(t)}function l(h){e.setupView(t,h)}const c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:i,state:c,setupLights:a,setupLightsView:l,pushLight:s,pushShadow:o}}function Ix(r){let e=new WeakMap;function t(i,s=0){const o=e.get(i);let a;return o===void 0?(a=new Ru(r),e.set(i,[a])):s>=o.length?(a=new Ru(r),o.push(a)):a=o[s],a}function n(){e=new WeakMap}return{get:t,dispose:n}}const Nx=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Ux=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function Fx(r,e,t){let n=new xa;const i=new ye,s=new ye,o=new ct,a=new Fm({depthPacking:pp}),l=new Om,c={},h=t.maxTextureSize,u={[Ui]:Un,[Un]:Ui,[Wn]:Wn},d=new gi({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ye},radius:{value:4}},vertexShader:Nx,fragmentShader:Ux}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const m=new yt;m.setAttribute("position",new Rn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new ve(m,d),g=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=bd;let p=this.type;this.render=function(R,P,S){if(g.enabled===!1||g.autoUpdate===!1&&g.needsUpdate===!1||R.length===0)return;const _=r.getRenderTarget(),y=r.getActiveCubeFace(),T=r.getActiveMipmapLevel(),F=r.state;F.setBlending(Qi),F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const k=p!==Ri&&this.type===Ri,G=p===Ri&&this.type!==Ri;for(let $=0,z=R.length;$<z;$++){const Y=R[$],H=Y.shadow;if(H===void 0){console.warn("THREE.WebGLShadowMap:",Y,"has no shadow.");continue}if(H.autoUpdate===!1&&H.needsUpdate===!1)continue;i.copy(H.mapSize);const q=H.getFrameExtents();if(i.multiply(q),s.copy(H.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(s.x=Math.floor(h/q.x),i.x=s.x*q.x,H.mapSize.x=s.x),i.y>h&&(s.y=Math.floor(h/q.y),i.y=s.y*q.y,H.mapSize.y=s.y)),H.map===null||k===!0||G===!0){const re=this.type!==Ri?{minFilter:gn,magFilter:gn}:{};H.map!==null&&H.map.dispose(),H.map=new ys(i.x,i.y,re),H.map.texture.name=Y.name+".shadowMap",H.camera.updateProjectionMatrix()}r.setRenderTarget(H.map),r.clear();const ue=H.getViewportCount();for(let re=0;re<ue;re++){const de=H.getViewport(re);o.set(s.x*de.x,s.y*de.y,s.x*de.z,s.y*de.w),F.viewport(o),H.updateMatrices(Y,re),n=H.getFrustum(),b(P,S,H.camera,Y,this.type)}H.isPointLightShadow!==!0&&this.type===Ri&&M(H,S),H.needsUpdate=!1}p=this.type,g.needsUpdate=!1,r.setRenderTarget(_,y,T)};function M(R,P){const S=e.update(v);d.defines.VSM_SAMPLES!==R.blurSamples&&(d.defines.VSM_SAMPLES=R.blurSamples,f.defines.VSM_SAMPLES=R.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),R.mapPass===null&&(R.mapPass=new ys(i.x,i.y)),d.uniforms.shadow_pass.value=R.map.texture,d.uniforms.resolution.value=R.mapSize,d.uniforms.radius.value=R.radius,r.setRenderTarget(R.mapPass),r.clear(),r.renderBufferDirect(P,null,S,d,v,null),f.uniforms.shadow_pass.value=R.mapPass.texture,f.uniforms.resolution.value=R.mapSize,f.uniforms.radius.value=R.radius,r.setRenderTarget(R.map),r.clear(),r.renderBufferDirect(P,null,S,f,v,null)}function x(R,P,S,_){let y=null;const T=S.isPointLight===!0?R.customDistanceMaterial:R.customDepthMaterial;if(T!==void 0)y=T;else if(y=S.isPointLight===!0?l:a,r.localClippingEnabled&&P.clipShadows===!0&&Array.isArray(P.clippingPlanes)&&P.clippingPlanes.length!==0||P.displacementMap&&P.displacementScale!==0||P.alphaMap&&P.alphaTest>0||P.map&&P.alphaTest>0){const F=y.uuid,k=P.uuid;let G=c[F];G===void 0&&(G={},c[F]=G);let $=G[k];$===void 0&&($=y.clone(),G[k]=$,P.addEventListener("dispose",D)),y=$}if(y.visible=P.visible,y.wireframe=P.wireframe,_===Ri?y.side=P.shadowSide!==null?P.shadowSide:P.side:y.side=P.shadowSide!==null?P.shadowSide:u[P.side],y.alphaMap=P.alphaMap,y.alphaTest=P.alphaTest,y.map=P.map,y.clipShadows=P.clipShadows,y.clippingPlanes=P.clippingPlanes,y.clipIntersection=P.clipIntersection,y.displacementMap=P.displacementMap,y.displacementScale=P.displacementScale,y.displacementBias=P.displacementBias,y.wireframeLinewidth=P.wireframeLinewidth,y.linewidth=P.linewidth,S.isPointLight===!0&&y.isMeshDistanceMaterial===!0){const F=r.properties.get(y);F.light=S}return y}function b(R,P,S,_,y){if(R.visible===!1)return;if(R.layers.test(P.layers)&&(R.isMesh||R.isLine||R.isPoints)&&(R.castShadow||R.receiveShadow&&y===Ri)&&(!R.frustumCulled||n.intersectsObject(R))){R.modelViewMatrix.multiplyMatrices(S.matrixWorldInverse,R.matrixWorld);const k=e.update(R),G=R.material;if(Array.isArray(G)){const $=k.groups;for(let z=0,Y=$.length;z<Y;z++){const H=$[z],q=G[H.materialIndex];if(q&&q.visible){const ue=x(R,q,_,y);R.onBeforeShadow(r,R,P,S,k,ue,H),r.renderBufferDirect(S,null,k,ue,R,H),R.onAfterShadow(r,R,P,S,k,ue,H)}}}else if(G.visible){const $=x(R,G,_,y);R.onBeforeShadow(r,R,P,S,k,$,null),r.renderBufferDirect(S,null,k,$,R,null),R.onAfterShadow(r,R,P,S,k,$,null)}}const F=R.children;for(let k=0,G=F.length;k<G;k++)b(F[k],P,S,_,y)}function D(R){R.target.removeEventListener("dispose",D);for(const S in c){const _=c[S],y=R.target.uuid;y in _&&(_[y].dispose(),delete _[y])}}}const Ox={[Dl]:Il,[Nl]:Ol,[Ul]:Bl,[or]:Fl,[Il]:Dl,[Ol]:Nl,[Bl]:Ul,[Fl]:or};function Bx(r,e){function t(){let X=!1;const Ce=new ct;let oe=null;const fe=new ct(0,0,0,0);return{setMask:function(Ue){oe!==Ue&&!X&&(r.colorMask(Ue,Ue,Ue,Ue),oe=Ue)},setLocked:function(Ue){X=Ue},setClear:function(Ue,De,ot,kt,an){an===!0&&(Ue*=kt,De*=kt,ot*=kt),Ce.set(Ue,De,ot,kt),fe.equals(Ce)===!1&&(r.clearColor(Ue,De,ot,kt),fe.copy(Ce))},reset:function(){X=!1,oe=null,fe.set(-1,0,0,0)}}}function n(){let X=!1,Ce=!1,oe=null,fe=null,Ue=null;return{setReversed:function(De){if(Ce!==De){const ot=e.get("EXT_clip_control");Ce?ot.clipControlEXT(ot.LOWER_LEFT_EXT,ot.ZERO_TO_ONE_EXT):ot.clipControlEXT(ot.LOWER_LEFT_EXT,ot.NEGATIVE_ONE_TO_ONE_EXT);const kt=Ue;Ue=null,this.setClear(kt)}Ce=De},getReversed:function(){return Ce},setTest:function(De){De?ne(r.DEPTH_TEST):ce(r.DEPTH_TEST)},setMask:function(De){oe!==De&&!X&&(r.depthMask(De),oe=De)},setFunc:function(De){if(Ce&&(De=Ox[De]),fe!==De){switch(De){case Dl:r.depthFunc(r.NEVER);break;case Il:r.depthFunc(r.ALWAYS);break;case Nl:r.depthFunc(r.LESS);break;case or:r.depthFunc(r.LEQUAL);break;case Ul:r.depthFunc(r.EQUAL);break;case Fl:r.depthFunc(r.GEQUAL);break;case Ol:r.depthFunc(r.GREATER);break;case Bl:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}fe=De}},setLocked:function(De){X=De},setClear:function(De){Ue!==De&&(Ce&&(De=1-De),r.clearDepth(De),Ue=De)},reset:function(){X=!1,oe=null,fe=null,Ue=null,Ce=!1}}}function i(){let X=!1,Ce=null,oe=null,fe=null,Ue=null,De=null,ot=null,kt=null,an=null;return{setTest:function(ut){X||(ut?ne(r.STENCIL_TEST):ce(r.STENCIL_TEST))},setMask:function(ut){Ce!==ut&&!X&&(r.stencilMask(ut),Ce=ut)},setFunc:function(ut,Pn,Kn){(oe!==ut||fe!==Pn||Ue!==Kn)&&(r.stencilFunc(ut,Pn,Kn),oe=ut,fe=Pn,Ue=Kn)},setOp:function(ut,Pn,Kn){(De!==ut||ot!==Pn||kt!==Kn)&&(r.stencilOp(ut,Pn,Kn),De=ut,ot=Pn,kt=Kn)},setLocked:function(ut){X=ut},setClear:function(ut){an!==ut&&(r.clearStencil(ut),an=ut)},reset:function(){X=!1,Ce=null,oe=null,fe=null,Ue=null,De=null,ot=null,kt=null,an=null}}}const s=new t,o=new n,a=new i,l=new WeakMap,c=new WeakMap;let h={},u={},d=new WeakMap,f=[],m=null,v=!1,g=null,p=null,M=null,x=null,b=null,D=null,R=null,P=new Ge(0,0,0),S=0,_=!1,y=null,T=null,F=null,k=null,G=null;const $=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,Y=0;const H=r.getParameter(r.VERSION);H.indexOf("WebGL")!==-1?(Y=parseFloat(/^WebGL (\d)/.exec(H)[1]),z=Y>=1):H.indexOf("OpenGL ES")!==-1&&(Y=parseFloat(/^OpenGL ES (\d)/.exec(H)[1]),z=Y>=2);let q=null,ue={};const re=r.getParameter(r.SCISSOR_BOX),de=r.getParameter(r.VIEWPORT),ie=new ct().fromArray(re),W=new ct().fromArray(de);function Z(X,Ce,oe,fe){const Ue=new Uint8Array(4),De=r.createTexture();r.bindTexture(X,De),r.texParameteri(X,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(X,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let ot=0;ot<oe;ot++)X===r.TEXTURE_3D||X===r.TEXTURE_2D_ARRAY?r.texImage3D(Ce,0,r.RGBA,1,1,fe,0,r.RGBA,r.UNSIGNED_BYTE,Ue):r.texImage2D(Ce+ot,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,Ue);return De}const Q={};Q[r.TEXTURE_2D]=Z(r.TEXTURE_2D,r.TEXTURE_2D,1),Q[r.TEXTURE_CUBE_MAP]=Z(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),Q[r.TEXTURE_2D_ARRAY]=Z(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),Q[r.TEXTURE_3D]=Z(r.TEXTURE_3D,r.TEXTURE_3D,1,1),s.setClear(0,0,0,1),o.setClear(1),a.setClear(0),ne(r.DEPTH_TEST),o.setFunc(or),Pe(!1),tt(nh),ne(r.CULL_FACE),B(Qi);function ne(X){h[X]!==!0&&(r.enable(X),h[X]=!0)}function ce(X){h[X]!==!1&&(r.disable(X),h[X]=!1)}function Me(X,Ce){return u[X]!==Ce?(r.bindFramebuffer(X,Ce),u[X]=Ce,X===r.DRAW_FRAMEBUFFER&&(u[r.FRAMEBUFFER]=Ce),X===r.FRAMEBUFFER&&(u[r.DRAW_FRAMEBUFFER]=Ce),!0):!1}function we(X,Ce){let oe=f,fe=!1;if(X){oe=d.get(Ce),oe===void 0&&(oe=[],d.set(Ce,oe));const Ue=X.textures;if(oe.length!==Ue.length||oe[0]!==r.COLOR_ATTACHMENT0){for(let De=0,ot=Ue.length;De<ot;De++)oe[De]=r.COLOR_ATTACHMENT0+De;oe.length=Ue.length,fe=!0}}else oe[0]!==r.BACK&&(oe[0]=r.BACK,fe=!0);fe&&r.drawBuffers(oe)}function Ne(X){return m!==X?(r.useProgram(X),m=X,!0):!1}const Je={[fs]:r.FUNC_ADD,[Bf]:r.FUNC_SUBTRACT,[kf]:r.FUNC_REVERSE_SUBTRACT};Je[zf]=r.MIN,Je[Hf]=r.MAX;const We={[Vf]:r.ZERO,[Gf]:r.ONE,[Wf]:r.SRC_COLOR,[Pl]:r.SRC_ALPHA,[Kf]:r.SRC_ALPHA_SATURATE,[Yf]:r.DST_COLOR,[jf]:r.DST_ALPHA,[Xf]:r.ONE_MINUS_SRC_COLOR,[Ll]:r.ONE_MINUS_SRC_ALPHA,[Zf]:r.ONE_MINUS_DST_COLOR,[qf]:r.ONE_MINUS_DST_ALPHA,[$f]:r.CONSTANT_COLOR,[Jf]:r.ONE_MINUS_CONSTANT_COLOR,[Qf]:r.CONSTANT_ALPHA,[ep]:r.ONE_MINUS_CONSTANT_ALPHA};function B(X,Ce,oe,fe,Ue,De,ot,kt,an,ut){if(X===Qi){v===!0&&(ce(r.BLEND),v=!1);return}if(v===!1&&(ne(r.BLEND),v=!0),X!==Of){if(X!==g||ut!==_){if((p!==fs||b!==fs)&&(r.blendEquation(r.FUNC_ADD),p=fs,b=fs),ut)switch(X){case nr:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case ih:r.blendFunc(r.ONE,r.ONE);break;case sh:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case rh:r.blendFuncSeparate(r.ZERO,r.SRC_COLOR,r.ZERO,r.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}else switch(X){case nr:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case ih:r.blendFunc(r.SRC_ALPHA,r.ONE);break;case sh:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case rh:r.blendFunc(r.ZERO,r.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}M=null,x=null,D=null,R=null,P.set(0,0,0),S=0,g=X,_=ut}return}Ue=Ue||Ce,De=De||oe,ot=ot||fe,(Ce!==p||Ue!==b)&&(r.blendEquationSeparate(Je[Ce],Je[Ue]),p=Ce,b=Ue),(oe!==M||fe!==x||De!==D||ot!==R)&&(r.blendFuncSeparate(We[oe],We[fe],We[De],We[ot]),M=oe,x=fe,D=De,R=ot),(kt.equals(P)===!1||an!==S)&&(r.blendColor(kt.r,kt.g,kt.b,an),P.copy(kt),S=an),g=X,_=!1}function ht(X,Ce){X.side===Wn?ce(r.CULL_FACE):ne(r.CULL_FACE);let oe=X.side===Un;Ce&&(oe=!oe),Pe(oe),X.blending===nr&&X.transparent===!1?B(Qi):B(X.blending,X.blendEquation,X.blendSrc,X.blendDst,X.blendEquationAlpha,X.blendSrcAlpha,X.blendDstAlpha,X.blendColor,X.blendAlpha,X.premultipliedAlpha),o.setFunc(X.depthFunc),o.setTest(X.depthTest),o.setMask(X.depthWrite),s.setMask(X.colorWrite);const fe=X.stencilWrite;a.setTest(fe),fe&&(a.setMask(X.stencilWriteMask),a.setFunc(X.stencilFunc,X.stencilRef,X.stencilFuncMask),a.setOp(X.stencilFail,X.stencilZFail,X.stencilZPass)),Qe(X.polygonOffset,X.polygonOffsetFactor,X.polygonOffsetUnits),X.alphaToCoverage===!0?ne(r.SAMPLE_ALPHA_TO_COVERAGE):ce(r.SAMPLE_ALPHA_TO_COVERAGE)}function Pe(X){y!==X&&(X?r.frontFace(r.CW):r.frontFace(r.CCW),y=X)}function tt(X){X!==Nf?(ne(r.CULL_FACE),X!==T&&(X===nh?r.cullFace(r.BACK):X===Uf?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):ce(r.CULL_FACE),T=X}function me(X){X!==F&&(z&&r.lineWidth(X),F=X)}function Qe(X,Ce,oe){X?(ne(r.POLYGON_OFFSET_FILL),(k!==Ce||G!==oe)&&(r.polygonOffset(Ce,oe),k=Ce,G=oe)):ce(r.POLYGON_OFFSET_FILL)}function ke(X){X?ne(r.SCISSOR_TEST):ce(r.SCISSOR_TEST)}function O(X){X===void 0&&(X=r.TEXTURE0+$-1),q!==X&&(r.activeTexture(X),q=X)}function A(X,Ce,oe){oe===void 0&&(q===null?oe=r.TEXTURE0+$-1:oe=q);let fe=ue[oe];fe===void 0&&(fe={type:void 0,texture:void 0},ue[oe]=fe),(fe.type!==X||fe.texture!==Ce)&&(q!==oe&&(r.activeTexture(oe),q=oe),r.bindTexture(X,Ce||Q[X]),fe.type=X,fe.texture=Ce)}function K(){const X=ue[q];X!==void 0&&X.type!==void 0&&(r.bindTexture(X.type,null),X.type=void 0,X.texture=void 0)}function ae(){try{r.compressedTexImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function he(){try{r.compressedTexImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function se(){try{r.texSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Re(){try{r.texSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function xe(){try{r.compressedTexSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Fe(){try{r.compressedTexSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function gt(){try{r.texStorage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function ge(){try{r.texStorage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Ee(){try{r.texImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function qe(){try{r.texImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function et(X){ie.equals(X)===!1&&(r.scissor(X.x,X.y,X.z,X.w),ie.copy(X))}function ze(X){W.equals(X)===!1&&(r.viewport(X.x,X.y,X.z,X.w),W.copy(X))}function vt(X,Ce){let oe=c.get(Ce);oe===void 0&&(oe=new WeakMap,c.set(Ce,oe));let fe=oe.get(X);fe===void 0&&(fe=r.getUniformBlockIndex(Ce,X.name),oe.set(X,fe))}function at(X,Ce){const fe=c.get(Ce).get(X);l.get(Ce)!==fe&&(r.uniformBlockBinding(Ce,fe,X.__bindingPointIndex),l.set(Ce,fe))}function Lt(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),o.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),h={},q=null,ue={},u={},d=new WeakMap,f=[],m=null,v=!1,g=null,p=null,M=null,x=null,b=null,D=null,R=null,P=new Ge(0,0,0),S=0,_=!1,y=null,T=null,F=null,k=null,G=null,ie.set(0,0,r.canvas.width,r.canvas.height),W.set(0,0,r.canvas.width,r.canvas.height),s.reset(),o.reset(),a.reset()}return{buffers:{color:s,depth:o,stencil:a},enable:ne,disable:ce,bindFramebuffer:Me,drawBuffers:we,useProgram:Ne,setBlending:B,setMaterial:ht,setFlipSided:Pe,setCullFace:tt,setLineWidth:me,setPolygonOffset:Qe,setScissorTest:ke,activeTexture:O,bindTexture:A,unbindTexture:K,compressedTexImage2D:ae,compressedTexImage3D:he,texImage2D:Ee,texImage3D:qe,updateUBOMapping:vt,uniformBlockBinding:at,texStorage2D:gt,texStorage3D:ge,texSubImage2D:se,texSubImage3D:Re,compressedTexSubImage2D:xe,compressedTexSubImage3D:Fe,scissor:et,viewport:ze,reset:Lt}}function kx(r,e,t,n,i,s,o){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new ye,h=new WeakMap;let u;const d=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(O,A){return f?new OffscreenCanvas(O,A):Or("canvas")}function v(O,A,K){let ae=1;const he=ke(O);if((he.width>K||he.height>K)&&(ae=K/Math.max(he.width,he.height)),ae<1)if(typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&O instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&O instanceof ImageBitmap||typeof VideoFrame<"u"&&O instanceof VideoFrame){const se=Math.floor(ae*he.width),Re=Math.floor(ae*he.height);u===void 0&&(u=m(se,Re));const xe=A?m(se,Re):u;return xe.width=se,xe.height=Re,xe.getContext("2d").drawImage(O,0,0,se,Re),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+he.width+"x"+he.height+") to ("+se+"x"+Re+")."),xe}else return"data"in O&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+he.width+"x"+he.height+")."),O;return O}function g(O){return O.generateMipmaps}function p(O){r.generateMipmap(O)}function M(O){return O.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:O.isWebGL3DRenderTarget?r.TEXTURE_3D:O.isWebGLArrayRenderTarget||O.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function x(O,A,K,ae,he=!1){if(O!==null){if(r[O]!==void 0)return r[O];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+O+"'")}let se=A;if(A===r.RED&&(K===r.FLOAT&&(se=r.R32F),K===r.HALF_FLOAT&&(se=r.R16F),K===r.UNSIGNED_BYTE&&(se=r.R8)),A===r.RED_INTEGER&&(K===r.UNSIGNED_BYTE&&(se=r.R8UI),K===r.UNSIGNED_SHORT&&(se=r.R16UI),K===r.UNSIGNED_INT&&(se=r.R32UI),K===r.BYTE&&(se=r.R8I),K===r.SHORT&&(se=r.R16I),K===r.INT&&(se=r.R32I)),A===r.RG&&(K===r.FLOAT&&(se=r.RG32F),K===r.HALF_FLOAT&&(se=r.RG16F),K===r.UNSIGNED_BYTE&&(se=r.RG8)),A===r.RG_INTEGER&&(K===r.UNSIGNED_BYTE&&(se=r.RG8UI),K===r.UNSIGNED_SHORT&&(se=r.RG16UI),K===r.UNSIGNED_INT&&(se=r.RG32UI),K===r.BYTE&&(se=r.RG8I),K===r.SHORT&&(se=r.RG16I),K===r.INT&&(se=r.RG32I)),A===r.RGB_INTEGER&&(K===r.UNSIGNED_BYTE&&(se=r.RGB8UI),K===r.UNSIGNED_SHORT&&(se=r.RGB16UI),K===r.UNSIGNED_INT&&(se=r.RGB32UI),K===r.BYTE&&(se=r.RGB8I),K===r.SHORT&&(se=r.RGB16I),K===r.INT&&(se=r.RGB32I)),A===r.RGBA_INTEGER&&(K===r.UNSIGNED_BYTE&&(se=r.RGBA8UI),K===r.UNSIGNED_SHORT&&(se=r.RGBA16UI),K===r.UNSIGNED_INT&&(se=r.RGBA32UI),K===r.BYTE&&(se=r.RGBA8I),K===r.SHORT&&(se=r.RGBA16I),K===r.INT&&(se=r.RGBA32I)),A===r.RGB&&K===r.UNSIGNED_INT_5_9_9_9_REV&&(se=r.RGB9_E5),A===r.RGBA){const Re=he?la:rt.getTransfer(ae);K===r.FLOAT&&(se=r.RGBA32F),K===r.HALF_FLOAT&&(se=r.RGBA16F),K===r.UNSIGNED_BYTE&&(se=Re===Nt?r.SRGB8_ALPHA8:r.RGBA8),K===r.UNSIGNED_SHORT_4_4_4_4&&(se=r.RGBA4),K===r.UNSIGNED_SHORT_5_5_5_1&&(se=r.RGB5_A1)}return(se===r.R16F||se===r.R32F||se===r.RG16F||se===r.RG32F||se===r.RGBA16F||se===r.RGBA32F)&&e.get("EXT_color_buffer_float"),se}function b(O,A){let K;return O?A===null||A===xs||A===cr?K=r.DEPTH24_STENCIL8:A===fi?K=r.DEPTH32F_STENCIL8:A===Fr&&(K=r.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===xs||A===cr?K=r.DEPTH_COMPONENT24:A===fi?K=r.DEPTH_COMPONENT32F:A===Fr&&(K=r.DEPTH_COMPONENT16),K}function D(O,A){return g(O)===!0||O.isFramebufferTexture&&O.minFilter!==gn&&O.minFilter!==mn?Math.log2(Math.max(A.width,A.height))+1:O.mipmaps!==void 0&&O.mipmaps.length>0?O.mipmaps.length:O.isCompressedTexture&&Array.isArray(O.image)?A.mipmaps.length:1}function R(O){const A=O.target;A.removeEventListener("dispose",R),S(A),A.isVideoTexture&&h.delete(A)}function P(O){const A=O.target;A.removeEventListener("dispose",P),y(A)}function S(O){const A=n.get(O);if(A.__webglInit===void 0)return;const K=O.source,ae=d.get(K);if(ae){const he=ae[A.__cacheKey];he.usedTimes--,he.usedTimes===0&&_(O),Object.keys(ae).length===0&&d.delete(K)}n.remove(O)}function _(O){const A=n.get(O);r.deleteTexture(A.__webglTexture);const K=O.source,ae=d.get(K);delete ae[A.__cacheKey],o.memory.textures--}function y(O){const A=n.get(O);if(O.depthTexture&&(O.depthTexture.dispose(),n.remove(O.depthTexture)),O.isWebGLCubeRenderTarget)for(let ae=0;ae<6;ae++){if(Array.isArray(A.__webglFramebuffer[ae]))for(let he=0;he<A.__webglFramebuffer[ae].length;he++)r.deleteFramebuffer(A.__webglFramebuffer[ae][he]);else r.deleteFramebuffer(A.__webglFramebuffer[ae]);A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer[ae])}else{if(Array.isArray(A.__webglFramebuffer))for(let ae=0;ae<A.__webglFramebuffer.length;ae++)r.deleteFramebuffer(A.__webglFramebuffer[ae]);else r.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&r.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let ae=0;ae<A.__webglColorRenderbuffer.length;ae++)A.__webglColorRenderbuffer[ae]&&r.deleteRenderbuffer(A.__webglColorRenderbuffer[ae]);A.__webglDepthRenderbuffer&&r.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const K=O.textures;for(let ae=0,he=K.length;ae<he;ae++){const se=n.get(K[ae]);se.__webglTexture&&(r.deleteTexture(se.__webglTexture),o.memory.textures--),n.remove(K[ae])}n.remove(O)}let T=0;function F(){T=0}function k(){const O=T;return O>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+O+" texture units while this GPU supports only "+i.maxTextures),T+=1,O}function G(O){const A=[];return A.push(O.wrapS),A.push(O.wrapT),A.push(O.wrapR||0),A.push(O.magFilter),A.push(O.minFilter),A.push(O.anisotropy),A.push(O.internalFormat),A.push(O.format),A.push(O.type),A.push(O.generateMipmaps),A.push(O.premultiplyAlpha),A.push(O.flipY),A.push(O.unpackAlignment),A.push(O.colorSpace),A.join()}function $(O,A){const K=n.get(O);if(O.isVideoTexture&&me(O),O.isRenderTargetTexture===!1&&O.version>0&&K.__version!==O.version){const ae=O.image;if(ae===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(ae.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{W(K,O,A);return}}t.bindTexture(r.TEXTURE_2D,K.__webglTexture,r.TEXTURE0+A)}function z(O,A){const K=n.get(O);if(O.version>0&&K.__version!==O.version){W(K,O,A);return}t.bindTexture(r.TEXTURE_2D_ARRAY,K.__webglTexture,r.TEXTURE0+A)}function Y(O,A){const K=n.get(O);if(O.version>0&&K.__version!==O.version){W(K,O,A);return}t.bindTexture(r.TEXTURE_3D,K.__webglTexture,r.TEXTURE0+A)}function H(O,A){const K=n.get(O);if(O.version>0&&K.__version!==O.version){Z(K,O,A);return}t.bindTexture(r.TEXTURE_CUBE_MAP,K.__webglTexture,r.TEXTURE0+A)}const q={[Pi]:r.REPEAT,[Bn]:r.CLAMP_TO_EDGE,[zl]:r.MIRRORED_REPEAT},ue={[gn]:r.NEAREST,[up]:r.NEAREST_MIPMAP_NEAREST,[so]:r.NEAREST_MIPMAP_LINEAR,[mn]:r.LINEAR,[Na]:r.LINEAR_MIPMAP_NEAREST,[Li]:r.LINEAR_MIPMAP_LINEAR},re={[gp]:r.NEVER,[Mp]:r.ALWAYS,[_p]:r.LESS,[Id]:r.LEQUAL,[vp]:r.EQUAL,[bp]:r.GEQUAL,[xp]:r.GREATER,[yp]:r.NOTEQUAL};function de(O,A){if(A.type===fi&&e.has("OES_texture_float_linear")===!1&&(A.magFilter===mn||A.magFilter===Na||A.magFilter===so||A.magFilter===Li||A.minFilter===mn||A.minFilter===Na||A.minFilter===so||A.minFilter===Li)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(O,r.TEXTURE_WRAP_S,q[A.wrapS]),r.texParameteri(O,r.TEXTURE_WRAP_T,q[A.wrapT]),(O===r.TEXTURE_3D||O===r.TEXTURE_2D_ARRAY)&&r.texParameteri(O,r.TEXTURE_WRAP_R,q[A.wrapR]),r.texParameteri(O,r.TEXTURE_MAG_FILTER,ue[A.magFilter]),r.texParameteri(O,r.TEXTURE_MIN_FILTER,ue[A.minFilter]),A.compareFunction&&(r.texParameteri(O,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(O,r.TEXTURE_COMPARE_FUNC,re[A.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===gn||A.minFilter!==so&&A.minFilter!==Li||A.type===fi&&e.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||n.get(A).__currentAnisotropy){const K=e.get("EXT_texture_filter_anisotropic");r.texParameterf(O,K.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,i.getMaxAnisotropy())),n.get(A).__currentAnisotropy=A.anisotropy}}}function ie(O,A){let K=!1;O.__webglInit===void 0&&(O.__webglInit=!0,A.addEventListener("dispose",R));const ae=A.source;let he=d.get(ae);he===void 0&&(he={},d.set(ae,he));const se=G(A);if(se!==O.__cacheKey){he[se]===void 0&&(he[se]={texture:r.createTexture(),usedTimes:0},o.memory.textures++,K=!0),he[se].usedTimes++;const Re=he[O.__cacheKey];Re!==void 0&&(he[O.__cacheKey].usedTimes--,Re.usedTimes===0&&_(A)),O.__cacheKey=se,O.__webglTexture=he[se].texture}return K}function W(O,A,K){let ae=r.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(ae=r.TEXTURE_2D_ARRAY),A.isData3DTexture&&(ae=r.TEXTURE_3D);const he=ie(O,A),se=A.source;t.bindTexture(ae,O.__webglTexture,r.TEXTURE0+K);const Re=n.get(se);if(se.version!==Re.__version||he===!0){t.activeTexture(r.TEXTURE0+K);const xe=rt.getPrimaries(rt.workingColorSpace),Fe=A.colorSpace===Zi?null:rt.getPrimaries(A.colorSpace),gt=A.colorSpace===Zi||xe===Fe?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,gt);let ge=v(A.image,!1,i.maxTextureSize);ge=Qe(A,ge);const Ee=s.convert(A.format,A.colorSpace),qe=s.convert(A.type);let et=x(A.internalFormat,Ee,qe,A.colorSpace,A.isVideoTexture);de(ae,A);let ze;const vt=A.mipmaps,at=A.isVideoTexture!==!0,Lt=Re.__version===void 0||he===!0,X=se.dataReady,Ce=D(A,ge);if(A.isDepthTexture)et=b(A.format===hr,A.type),Lt&&(at?t.texStorage2D(r.TEXTURE_2D,1,et,ge.width,ge.height):t.texImage2D(r.TEXTURE_2D,0,et,ge.width,ge.height,0,Ee,qe,null));else if(A.isDataTexture)if(vt.length>0){at&&Lt&&t.texStorage2D(r.TEXTURE_2D,Ce,et,vt[0].width,vt[0].height);for(let oe=0,fe=vt.length;oe<fe;oe++)ze=vt[oe],at?X&&t.texSubImage2D(r.TEXTURE_2D,oe,0,0,ze.width,ze.height,Ee,qe,ze.data):t.texImage2D(r.TEXTURE_2D,oe,et,ze.width,ze.height,0,Ee,qe,ze.data);A.generateMipmaps=!1}else at?(Lt&&t.texStorage2D(r.TEXTURE_2D,Ce,et,ge.width,ge.height),X&&t.texSubImage2D(r.TEXTURE_2D,0,0,0,ge.width,ge.height,Ee,qe,ge.data)):t.texImage2D(r.TEXTURE_2D,0,et,ge.width,ge.height,0,Ee,qe,ge.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){at&&Lt&&t.texStorage3D(r.TEXTURE_2D_ARRAY,Ce,et,vt[0].width,vt[0].height,ge.depth);for(let oe=0,fe=vt.length;oe<fe;oe++)if(ze=vt[oe],A.format!==Sn)if(Ee!==null)if(at){if(X)if(A.layerUpdates.size>0){const Ue=su(ze.width,ze.height,A.format,A.type);for(const De of A.layerUpdates){const ot=ze.data.subarray(De*Ue/ze.data.BYTES_PER_ELEMENT,(De+1)*Ue/ze.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,oe,0,0,De,ze.width,ze.height,1,Ee,ot)}A.clearLayerUpdates()}else t.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,oe,0,0,0,ze.width,ze.height,ge.depth,Ee,ze.data)}else t.compressedTexImage3D(r.TEXTURE_2D_ARRAY,oe,et,ze.width,ze.height,ge.depth,0,ze.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else at?X&&t.texSubImage3D(r.TEXTURE_2D_ARRAY,oe,0,0,0,ze.width,ze.height,ge.depth,Ee,qe,ze.data):t.texImage3D(r.TEXTURE_2D_ARRAY,oe,et,ze.width,ze.height,ge.depth,0,Ee,qe,ze.data)}else{at&&Lt&&t.texStorage2D(r.TEXTURE_2D,Ce,et,vt[0].width,vt[0].height);for(let oe=0,fe=vt.length;oe<fe;oe++)ze=vt[oe],A.format!==Sn?Ee!==null?at?X&&t.compressedTexSubImage2D(r.TEXTURE_2D,oe,0,0,ze.width,ze.height,Ee,ze.data):t.compressedTexImage2D(r.TEXTURE_2D,oe,et,ze.width,ze.height,0,ze.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):at?X&&t.texSubImage2D(r.TEXTURE_2D,oe,0,0,ze.width,ze.height,Ee,qe,ze.data):t.texImage2D(r.TEXTURE_2D,oe,et,ze.width,ze.height,0,Ee,qe,ze.data)}else if(A.isDataArrayTexture)if(at){if(Lt&&t.texStorage3D(r.TEXTURE_2D_ARRAY,Ce,et,ge.width,ge.height,ge.depth),X)if(A.layerUpdates.size>0){const oe=su(ge.width,ge.height,A.format,A.type);for(const fe of A.layerUpdates){const Ue=ge.data.subarray(fe*oe/ge.data.BYTES_PER_ELEMENT,(fe+1)*oe/ge.data.BYTES_PER_ELEMENT);t.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,fe,ge.width,ge.height,1,Ee,qe,Ue)}A.clearLayerUpdates()}else t.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,ge.width,ge.height,ge.depth,Ee,qe,ge.data)}else t.texImage3D(r.TEXTURE_2D_ARRAY,0,et,ge.width,ge.height,ge.depth,0,Ee,qe,ge.data);else if(A.isData3DTexture)at?(Lt&&t.texStorage3D(r.TEXTURE_3D,Ce,et,ge.width,ge.height,ge.depth),X&&t.texSubImage3D(r.TEXTURE_3D,0,0,0,0,ge.width,ge.height,ge.depth,Ee,qe,ge.data)):t.texImage3D(r.TEXTURE_3D,0,et,ge.width,ge.height,ge.depth,0,Ee,qe,ge.data);else if(A.isFramebufferTexture){if(Lt)if(at)t.texStorage2D(r.TEXTURE_2D,Ce,et,ge.width,ge.height);else{let oe=ge.width,fe=ge.height;for(let Ue=0;Ue<Ce;Ue++)t.texImage2D(r.TEXTURE_2D,Ue,et,oe,fe,0,Ee,qe,null),oe>>=1,fe>>=1}}else if(vt.length>0){if(at&&Lt){const oe=ke(vt[0]);t.texStorage2D(r.TEXTURE_2D,Ce,et,oe.width,oe.height)}for(let oe=0,fe=vt.length;oe<fe;oe++)ze=vt[oe],at?X&&t.texSubImage2D(r.TEXTURE_2D,oe,0,0,Ee,qe,ze):t.texImage2D(r.TEXTURE_2D,oe,et,Ee,qe,ze);A.generateMipmaps=!1}else if(at){if(Lt){const oe=ke(ge);t.texStorage2D(r.TEXTURE_2D,Ce,et,oe.width,oe.height)}X&&t.texSubImage2D(r.TEXTURE_2D,0,0,0,Ee,qe,ge)}else t.texImage2D(r.TEXTURE_2D,0,et,Ee,qe,ge);g(A)&&p(ae),Re.__version=se.version,A.onUpdate&&A.onUpdate(A)}O.__version=A.version}function Z(O,A,K){if(A.image.length!==6)return;const ae=ie(O,A),he=A.source;t.bindTexture(r.TEXTURE_CUBE_MAP,O.__webglTexture,r.TEXTURE0+K);const se=n.get(he);if(he.version!==se.__version||ae===!0){t.activeTexture(r.TEXTURE0+K);const Re=rt.getPrimaries(rt.workingColorSpace),xe=A.colorSpace===Zi?null:rt.getPrimaries(A.colorSpace),Fe=A.colorSpace===Zi||Re===xe?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,Fe);const gt=A.isCompressedTexture||A.image[0].isCompressedTexture,ge=A.image[0]&&A.image[0].isDataTexture,Ee=[];for(let fe=0;fe<6;fe++)!gt&&!ge?Ee[fe]=v(A.image[fe],!0,i.maxCubemapSize):Ee[fe]=ge?A.image[fe].image:A.image[fe],Ee[fe]=Qe(A,Ee[fe]);const qe=Ee[0],et=s.convert(A.format,A.colorSpace),ze=s.convert(A.type),vt=x(A.internalFormat,et,ze,A.colorSpace),at=A.isVideoTexture!==!0,Lt=se.__version===void 0||ae===!0,X=he.dataReady;let Ce=D(A,qe);de(r.TEXTURE_CUBE_MAP,A);let oe;if(gt){at&&Lt&&t.texStorage2D(r.TEXTURE_CUBE_MAP,Ce,vt,qe.width,qe.height);for(let fe=0;fe<6;fe++){oe=Ee[fe].mipmaps;for(let Ue=0;Ue<oe.length;Ue++){const De=oe[Ue];A.format!==Sn?et!==null?at?X&&t.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,0,0,De.width,De.height,et,De.data):t.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,vt,De.width,De.height,0,De.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):at?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,0,0,De.width,De.height,et,ze,De.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,vt,De.width,De.height,0,et,ze,De.data)}}}else{if(oe=A.mipmaps,at&&Lt){oe.length>0&&Ce++;const fe=ke(Ee[0]);t.texStorage2D(r.TEXTURE_CUBE_MAP,Ce,vt,fe.width,fe.height)}for(let fe=0;fe<6;fe++)if(ge){at?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,Ee[fe].width,Ee[fe].height,et,ze,Ee[fe].data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,vt,Ee[fe].width,Ee[fe].height,0,et,ze,Ee[fe].data);for(let Ue=0;Ue<oe.length;Ue++){const ot=oe[Ue].image[fe].image;at?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,0,0,ot.width,ot.height,et,ze,ot.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,vt,ot.width,ot.height,0,et,ze,ot.data)}}else{at?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,et,ze,Ee[fe]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,vt,et,ze,Ee[fe]);for(let Ue=0;Ue<oe.length;Ue++){const De=oe[Ue];at?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,0,0,et,ze,De.image[fe]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,vt,et,ze,De.image[fe])}}}g(A)&&p(r.TEXTURE_CUBE_MAP),se.__version=he.version,A.onUpdate&&A.onUpdate(A)}O.__version=A.version}function Q(O,A,K,ae,he,se){const Re=s.convert(K.format,K.colorSpace),xe=s.convert(K.type),Fe=x(K.internalFormat,Re,xe,K.colorSpace),gt=n.get(A),ge=n.get(K);if(ge.__renderTarget=A,!gt.__hasExternalTextures){const Ee=Math.max(1,A.width>>se),qe=Math.max(1,A.height>>se);he===r.TEXTURE_3D||he===r.TEXTURE_2D_ARRAY?t.texImage3D(he,se,Fe,Ee,qe,A.depth,0,Re,xe,null):t.texImage2D(he,se,Fe,Ee,qe,0,Re,xe,null)}t.bindFramebuffer(r.FRAMEBUFFER,O),tt(A)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,ae,he,ge.__webglTexture,0,Pe(A)):(he===r.TEXTURE_2D||he>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&he<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,ae,he,ge.__webglTexture,se),t.bindFramebuffer(r.FRAMEBUFFER,null)}function ne(O,A,K){if(r.bindRenderbuffer(r.RENDERBUFFER,O),A.depthBuffer){const ae=A.depthTexture,he=ae&&ae.isDepthTexture?ae.type:null,se=b(A.stencilBuffer,he),Re=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,xe=Pe(A);tt(A)?a.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,xe,se,A.width,A.height):K?r.renderbufferStorageMultisample(r.RENDERBUFFER,xe,se,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,se,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Re,r.RENDERBUFFER,O)}else{const ae=A.textures;for(let he=0;he<ae.length;he++){const se=ae[he],Re=s.convert(se.format,se.colorSpace),xe=s.convert(se.type),Fe=x(se.internalFormat,Re,xe,se.colorSpace),gt=Pe(A);K&&tt(A)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,gt,Fe,A.width,A.height):tt(A)?a.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,gt,Fe,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,Fe,A.width,A.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function ce(O,A){if(A&&A.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(r.FRAMEBUFFER,O),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const ae=n.get(A.depthTexture);ae.__renderTarget=A,(!ae.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),$(A.depthTexture,0);const he=ae.__webglTexture,se=Pe(A);if(A.depthTexture.format===ir)tt(A)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,he,0,se):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,he,0);else if(A.depthTexture.format===hr)tt(A)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,he,0,se):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,he,0);else throw new Error("Unknown depthTexture format")}function Me(O){const A=n.get(O),K=O.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==O.depthTexture){const ae=O.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),ae){const he=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,ae.removeEventListener("dispose",he)};ae.addEventListener("dispose",he),A.__depthDisposeCallback=he}A.__boundDepthTexture=ae}if(O.depthTexture&&!A.__autoAllocateDepthBuffer){if(K)throw new Error("target.depthTexture not supported in Cube render targets");ce(A.__webglFramebuffer,O)}else if(K){A.__webglDepthbuffer=[];for(let ae=0;ae<6;ae++)if(t.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer[ae]),A.__webglDepthbuffer[ae]===void 0)A.__webglDepthbuffer[ae]=r.createRenderbuffer(),ne(A.__webglDepthbuffer[ae],O,!1);else{const he=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,se=A.__webglDepthbuffer[ae];r.bindRenderbuffer(r.RENDERBUFFER,se),r.framebufferRenderbuffer(r.FRAMEBUFFER,he,r.RENDERBUFFER,se)}}else if(t.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=r.createRenderbuffer(),ne(A.__webglDepthbuffer,O,!1);else{const ae=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,he=A.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,he),r.framebufferRenderbuffer(r.FRAMEBUFFER,ae,r.RENDERBUFFER,he)}t.bindFramebuffer(r.FRAMEBUFFER,null)}function we(O,A,K){const ae=n.get(O);A!==void 0&&Q(ae.__webglFramebuffer,O,O.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),K!==void 0&&Me(O)}function Ne(O){const A=O.texture,K=n.get(O),ae=n.get(A);O.addEventListener("dispose",P);const he=O.textures,se=O.isWebGLCubeRenderTarget===!0,Re=he.length>1;if(Re||(ae.__webglTexture===void 0&&(ae.__webglTexture=r.createTexture()),ae.__version=A.version,o.memory.textures++),se){K.__webglFramebuffer=[];for(let xe=0;xe<6;xe++)if(A.mipmaps&&A.mipmaps.length>0){K.__webglFramebuffer[xe]=[];for(let Fe=0;Fe<A.mipmaps.length;Fe++)K.__webglFramebuffer[xe][Fe]=r.createFramebuffer()}else K.__webglFramebuffer[xe]=r.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){K.__webglFramebuffer=[];for(let xe=0;xe<A.mipmaps.length;xe++)K.__webglFramebuffer[xe]=r.createFramebuffer()}else K.__webglFramebuffer=r.createFramebuffer();if(Re)for(let xe=0,Fe=he.length;xe<Fe;xe++){const gt=n.get(he[xe]);gt.__webglTexture===void 0&&(gt.__webglTexture=r.createTexture(),o.memory.textures++)}if(O.samples>0&&tt(O)===!1){K.__webglMultisampledFramebuffer=r.createFramebuffer(),K.__webglColorRenderbuffer=[],t.bindFramebuffer(r.FRAMEBUFFER,K.__webglMultisampledFramebuffer);for(let xe=0;xe<he.length;xe++){const Fe=he[xe];K.__webglColorRenderbuffer[xe]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,K.__webglColorRenderbuffer[xe]);const gt=s.convert(Fe.format,Fe.colorSpace),ge=s.convert(Fe.type),Ee=x(Fe.internalFormat,gt,ge,Fe.colorSpace,O.isXRRenderTarget===!0),qe=Pe(O);r.renderbufferStorageMultisample(r.RENDERBUFFER,qe,Ee,O.width,O.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+xe,r.RENDERBUFFER,K.__webglColorRenderbuffer[xe])}r.bindRenderbuffer(r.RENDERBUFFER,null),O.depthBuffer&&(K.__webglDepthRenderbuffer=r.createRenderbuffer(),ne(K.__webglDepthRenderbuffer,O,!0)),t.bindFramebuffer(r.FRAMEBUFFER,null)}}if(se){t.bindTexture(r.TEXTURE_CUBE_MAP,ae.__webglTexture),de(r.TEXTURE_CUBE_MAP,A);for(let xe=0;xe<6;xe++)if(A.mipmaps&&A.mipmaps.length>0)for(let Fe=0;Fe<A.mipmaps.length;Fe++)Q(K.__webglFramebuffer[xe][Fe],O,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+xe,Fe);else Q(K.__webglFramebuffer[xe],O,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+xe,0);g(A)&&p(r.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Re){for(let xe=0,Fe=he.length;xe<Fe;xe++){const gt=he[xe],ge=n.get(gt);t.bindTexture(r.TEXTURE_2D,ge.__webglTexture),de(r.TEXTURE_2D,gt),Q(K.__webglFramebuffer,O,gt,r.COLOR_ATTACHMENT0+xe,r.TEXTURE_2D,0),g(gt)&&p(r.TEXTURE_2D)}t.unbindTexture()}else{let xe=r.TEXTURE_2D;if((O.isWebGL3DRenderTarget||O.isWebGLArrayRenderTarget)&&(xe=O.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),t.bindTexture(xe,ae.__webglTexture),de(xe,A),A.mipmaps&&A.mipmaps.length>0)for(let Fe=0;Fe<A.mipmaps.length;Fe++)Q(K.__webglFramebuffer[Fe],O,A,r.COLOR_ATTACHMENT0,xe,Fe);else Q(K.__webglFramebuffer,O,A,r.COLOR_ATTACHMENT0,xe,0);g(A)&&p(xe),t.unbindTexture()}O.depthBuffer&&Me(O)}function Je(O){const A=O.textures;for(let K=0,ae=A.length;K<ae;K++){const he=A[K];if(g(he)){const se=M(O),Re=n.get(he).__webglTexture;t.bindTexture(se,Re),p(se),t.unbindTexture()}}}const We=[],B=[];function ht(O){if(O.samples>0){if(tt(O)===!1){const A=O.textures,K=O.width,ae=O.height;let he=r.COLOR_BUFFER_BIT;const se=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Re=n.get(O),xe=A.length>1;if(xe)for(let Fe=0;Fe<A.length;Fe++)t.bindFramebuffer(r.FRAMEBUFFER,Re.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.RENDERBUFFER,null),t.bindFramebuffer(r.FRAMEBUFFER,Re.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.TEXTURE_2D,null,0);t.bindFramebuffer(r.READ_FRAMEBUFFER,Re.__webglMultisampledFramebuffer),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,Re.__webglFramebuffer);for(let Fe=0;Fe<A.length;Fe++){if(O.resolveDepthBuffer&&(O.depthBuffer&&(he|=r.DEPTH_BUFFER_BIT),O.stencilBuffer&&O.resolveStencilBuffer&&(he|=r.STENCIL_BUFFER_BIT)),xe){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Re.__webglColorRenderbuffer[Fe]);const gt=n.get(A[Fe]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,gt,0)}r.blitFramebuffer(0,0,K,ae,0,0,K,ae,he,r.NEAREST),l===!0&&(We.length=0,B.length=0,We.push(r.COLOR_ATTACHMENT0+Fe),O.depthBuffer&&O.resolveDepthBuffer===!1&&(We.push(se),B.push(se),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,B)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,We))}if(t.bindFramebuffer(r.READ_FRAMEBUFFER,null),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),xe)for(let Fe=0;Fe<A.length;Fe++){t.bindFramebuffer(r.FRAMEBUFFER,Re.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.RENDERBUFFER,Re.__webglColorRenderbuffer[Fe]);const gt=n.get(A[Fe]).__webglTexture;t.bindFramebuffer(r.FRAMEBUFFER,Re.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.TEXTURE_2D,gt,0)}t.bindFramebuffer(r.DRAW_FRAMEBUFFER,Re.__webglMultisampledFramebuffer)}else if(O.depthBuffer&&O.resolveDepthBuffer===!1&&l){const A=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[A])}}}function Pe(O){return Math.min(i.maxSamples,O.samples)}function tt(O){const A=n.get(O);return O.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function me(O){const A=o.render.frame;h.get(O)!==A&&(h.set(O,A),O.update())}function Qe(O,A){const K=O.colorSpace,ae=O.format,he=O.type;return O.isCompressedTexture===!0||O.isVideoTexture===!0||K!==ur&&K!==Zi&&(rt.getTransfer(K)===Nt?(ae!==Sn||he!==Fi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",K)),A}function ke(O){return typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement?(c.width=O.naturalWidth||O.width,c.height=O.naturalHeight||O.height):typeof VideoFrame<"u"&&O instanceof VideoFrame?(c.width=O.displayWidth,c.height=O.displayHeight):(c.width=O.width,c.height=O.height),c}this.allocateTextureUnit=k,this.resetTextureUnits=F,this.setTexture2D=$,this.setTexture2DArray=z,this.setTexture3D=Y,this.setTextureCube=H,this.rebindTextures=we,this.setupRenderTarget=Ne,this.updateRenderTargetMipmap=Je,this.updateMultisampleRenderTarget=ht,this.setupDepthRenderbuffer=Me,this.setupFrameBufferTexture=Q,this.useMultisampledRTT=tt}function zx(r,e){function t(n,i=Zi){let s;const o=rt.getTransfer(i);if(n===Fi)return r.UNSIGNED_BYTE;if(n===Ac)return r.UNSIGNED_SHORT_4_4_4_4;if(n===Rc)return r.UNSIGNED_SHORT_5_5_5_1;if(n===Ed)return r.UNSIGNED_INT_5_9_9_9_REV;if(n===Sd)return r.BYTE;if(n===wd)return r.SHORT;if(n===Fr)return r.UNSIGNED_SHORT;if(n===Tc)return r.INT;if(n===xs)return r.UNSIGNED_INT;if(n===fi)return r.FLOAT;if(n===Xr)return r.HALF_FLOAT;if(n===Td)return r.ALPHA;if(n===Ad)return r.RGB;if(n===Sn)return r.RGBA;if(n===Rd)return r.LUMINANCE;if(n===Cd)return r.LUMINANCE_ALPHA;if(n===ir)return r.DEPTH_COMPONENT;if(n===hr)return r.DEPTH_STENCIL;if(n===Pd)return r.RED;if(n===Cc)return r.RED_INTEGER;if(n===Ld)return r.RG;if(n===Pc)return r.RG_INTEGER;if(n===Lc)return r.RGBA_INTEGER;if(n===$o||n===Jo||n===Qo||n===ea)if(o===Nt)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===$o)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===Jo)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===Qo)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===ea)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===$o)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===Jo)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===Qo)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===ea)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===Hl||n===Vl||n===Gl||n===Wl)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===Hl)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===Vl)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===Gl)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===Wl)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===Xl||n===jl||n===ql)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===Xl||n===jl)return o===Nt?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===ql)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===Yl||n===Zl||n===Kl||n===$l||n===Jl||n===Ql||n===ec||n===tc||n===nc||n===ic||n===sc||n===rc||n===oc||n===ac)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===Yl)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===Zl)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===Kl)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===$l)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===Jl)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===Ql)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===ec)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===tc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===nc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===ic)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===sc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===rc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===oc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===ac)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===ta||n===lc||n===cc)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===ta)return o===Nt?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===lc)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===cc)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Dd||n===hc||n===uc||n===dc)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===ta)return s.COMPRESSED_RED_RGTC1_EXT;if(n===hc)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===uc)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===dc)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===cr?r.UNSIGNED_INT_24_8:r[n]!==void 0?r[n]:null}return{convert:t}}const Hx=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,Vx=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class Gx{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,n){if(this.texture===null){const i=new qt,s=e.properties.get(i);s.__webglTexture=t.texture,(t.depthNear!==n.depthNear||t.depthFar!==n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new gi({vertexShader:Hx,fragmentShader:Vx,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new ve(new mr(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class Wx extends Es{constructor(e,t){super();const n=this;let i=null,s=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,m=null;const v=new Gx,g=t.getContextAttributes();let p=null,M=null;const x=[],b=[],D=new ye;let R=null;const P=new Qt;P.viewport=new ct;const S=new Qt;S.viewport=new ct;const _=[P,S],y=new eg;let T=null,F=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(W){let Z=x[W];return Z===void 0&&(Z=new tl,x[W]=Z),Z.getTargetRaySpace()},this.getControllerGrip=function(W){let Z=x[W];return Z===void 0&&(Z=new tl,x[W]=Z),Z.getGripSpace()},this.getHand=function(W){let Z=x[W];return Z===void 0&&(Z=new tl,x[W]=Z),Z.getHandSpace()};function k(W){const Z=b.indexOf(W.inputSource);if(Z===-1)return;const Q=x[Z];Q!==void 0&&(Q.update(W.inputSource,W.frame,c||o),Q.dispatchEvent({type:W.type,data:W.inputSource}))}function G(){i.removeEventListener("select",k),i.removeEventListener("selectstart",k),i.removeEventListener("selectend",k),i.removeEventListener("squeeze",k),i.removeEventListener("squeezestart",k),i.removeEventListener("squeezeend",k),i.removeEventListener("end",G),i.removeEventListener("inputsourceschange",$);for(let W=0;W<x.length;W++){const Z=b[W];Z!==null&&(b[W]=null,x[W].disconnect(Z))}T=null,F=null,v.reset(),e.setRenderTarget(p),f=null,d=null,u=null,i=null,M=null,ie.stop(),n.isPresenting=!1,e.setPixelRatio(R),e.setSize(D.width,D.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(W){s=W,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(W){a=W,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(W){c=W},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return m},this.getSession=function(){return i},this.setSession=async function(W){if(i=W,i!==null){if(p=e.getRenderTarget(),i.addEventListener("select",k),i.addEventListener("selectstart",k),i.addEventListener("selectend",k),i.addEventListener("squeeze",k),i.addEventListener("squeezestart",k),i.addEventListener("squeezeend",k),i.addEventListener("end",G),i.addEventListener("inputsourceschange",$),g.xrCompatible!==!0&&await t.makeXRCompatible(),R=e.getPixelRatio(),e.getSize(D),typeof XRWebGLBinding<"u"&&"createProjectionLayer"in XRWebGLBinding.prototype){let Q=null,ne=null,ce=null;g.depth&&(ce=g.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,Q=g.stencil?hr:ir,ne=g.stencil?cr:xs);const Me={colorFormat:t.RGBA8,depthFormat:ce,scaleFactor:s};u=new XRWebGLBinding(i,t),d=u.createProjectionLayer(Me),i.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),M=new ys(d.textureWidth,d.textureHeight,{format:Sn,type:Fi,depthTexture:new Vd(d.textureWidth,d.textureHeight,ne,void 0,void 0,void 0,void 0,void 0,void 0,Q),stencilBuffer:g.stencil,colorSpace:e.outputColorSpace,samples:g.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{const Q={antialias:g.antialias,alpha:!0,depth:g.depth,stencil:g.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(i,t,Q),i.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),M=new ys(f.framebufferWidth,f.framebufferHeight,{format:Sn,type:Fi,colorSpace:e.outputColorSpace,stencilBuffer:g.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}M.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await i.requestReferenceSpace(a),ie.setContext(i),ie.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};function $(W){for(let Z=0;Z<W.removed.length;Z++){const Q=W.removed[Z],ne=b.indexOf(Q);ne>=0&&(b[ne]=null,x[ne].disconnect(Q))}for(let Z=0;Z<W.added.length;Z++){const Q=W.added[Z];let ne=b.indexOf(Q);if(ne===-1){for(let Me=0;Me<x.length;Me++)if(Me>=b.length){b.push(Q),ne=Me;break}else if(b[Me]===null){b[Me]=Q,ne=Me;break}if(ne===-1)break}const ce=x[ne];ce&&ce.connect(Q)}}const z=new I,Y=new I;function H(W,Z,Q){z.setFromMatrixPosition(Z.matrixWorld),Y.setFromMatrixPosition(Q.matrixWorld);const ne=z.distanceTo(Y),ce=Z.projectionMatrix.elements,Me=Q.projectionMatrix.elements,we=ce[14]/(ce[10]-1),Ne=ce[14]/(ce[10]+1),Je=(ce[9]+1)/ce[5],We=(ce[9]-1)/ce[5],B=(ce[8]-1)/ce[0],ht=(Me[8]+1)/Me[0],Pe=we*B,tt=we*ht,me=ne/(-B+ht),Qe=me*-B;if(Z.matrixWorld.decompose(W.position,W.quaternion,W.scale),W.translateX(Qe),W.translateZ(me),W.matrixWorld.compose(W.position,W.quaternion,W.scale),W.matrixWorldInverse.copy(W.matrixWorld).invert(),ce[10]===-1)W.projectionMatrix.copy(Z.projectionMatrix),W.projectionMatrixInverse.copy(Z.projectionMatrixInverse);else{const ke=we+me,O=Ne+me,A=Pe-Qe,K=tt+(ne-Qe),ae=Je*Ne/O*ke,he=We*Ne/O*ke;W.projectionMatrix.makePerspective(A,K,ae,he,ke,O),W.projectionMatrixInverse.copy(W.projectionMatrix).invert()}}function q(W,Z){Z===null?W.matrixWorld.copy(W.matrix):W.matrixWorld.multiplyMatrices(Z.matrixWorld,W.matrix),W.matrixWorldInverse.copy(W.matrixWorld).invert()}this.updateCamera=function(W){if(i===null)return;let Z=W.near,Q=W.far;v.texture!==null&&(v.depthNear>0&&(Z=v.depthNear),v.depthFar>0&&(Q=v.depthFar)),y.near=S.near=P.near=Z,y.far=S.far=P.far=Q,(T!==y.near||F!==y.far)&&(i.updateRenderState({depthNear:y.near,depthFar:y.far}),T=y.near,F=y.far),P.layers.mask=W.layers.mask|2,S.layers.mask=W.layers.mask|4,y.layers.mask=P.layers.mask|S.layers.mask;const ne=W.parent,ce=y.cameras;q(y,ne);for(let Me=0;Me<ce.length;Me++)q(ce[Me],ne);ce.length===2?H(y,P,S):y.projectionMatrix.copy(P.projectionMatrix),ue(W,y,ne)};function ue(W,Z,Q){Q===null?W.matrix.copy(Z.matrixWorld):(W.matrix.copy(Q.matrixWorld),W.matrix.invert(),W.matrix.multiply(Z.matrixWorld)),W.matrix.decompose(W.position,W.quaternion,W.scale),W.updateMatrixWorld(!0),W.projectionMatrix.copy(Z.projectionMatrix),W.projectionMatrixInverse.copy(Z.projectionMatrixInverse),W.isPerspectiveCamera&&(W.fov=dr*2*Math.atan(1/W.projectionMatrix.elements[5]),W.zoom=1)}this.getCamera=function(){return y},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(W){l=W,d!==null&&(d.fixedFoveation=W),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=W)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(y)};let re=null;function de(W,Z){if(h=Z.getViewerPose(c||o),m=Z,h!==null){const Q=h.views;f!==null&&(e.setRenderTargetFramebuffer(M,f.framebuffer),e.setRenderTarget(M));let ne=!1;Q.length!==y.cameras.length&&(y.cameras.length=0,ne=!0);for(let we=0;we<Q.length;we++){const Ne=Q[we];let Je=null;if(f!==null)Je=f.getViewport(Ne);else{const B=u.getViewSubImage(d,Ne);Je=B.viewport,we===0&&(e.setRenderTargetTextures(M,B.colorTexture,d.ignoreDepthValues?void 0:B.depthStencilTexture),e.setRenderTarget(M))}let We=_[we];We===void 0&&(We=new Qt,We.layers.enable(we),We.viewport=new ct,_[we]=We),We.matrix.fromArray(Ne.transform.matrix),We.matrix.decompose(We.position,We.quaternion,We.scale),We.projectionMatrix.fromArray(Ne.projectionMatrix),We.projectionMatrixInverse.copy(We.projectionMatrix).invert(),We.viewport.set(Je.x,Je.y,Je.width,Je.height),we===0&&(y.matrix.copy(We.matrix),y.matrix.decompose(y.position,y.quaternion,y.scale)),ne===!0&&y.cameras.push(We)}const ce=i.enabledFeatures;if(ce&&ce.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&u){const we=u.getDepthInformation(Q[0]);we&&we.isValid&&we.texture&&v.init(e,we,i.renderState)}}for(let Q=0;Q<x.length;Q++){const ne=b[Q],ce=x[Q];ne!==null&&ce!==void 0&&ce.update(ne,Z,c||o)}re&&re(W,Z),Z.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:Z}),m=null}const ie=new ef;ie.setAnimationLoop(de),this.setAnimationLoop=function(W){re=W},this.dispose=function(){}}}const as=new Kt,Xx=new Te;function jx(r,e){function t(g,p){g.matrixAutoUpdate===!0&&g.updateMatrix(),p.value.copy(g.matrix)}function n(g,p){p.color.getRGB(g.fogColor.value,Od(r)),p.isFog?(g.fogNear.value=p.near,g.fogFar.value=p.far):p.isFogExp2&&(g.fogDensity.value=p.density)}function i(g,p,M,x,b){p.isMeshBasicMaterial||p.isMeshLambertMaterial?s(g,p):p.isMeshToonMaterial?(s(g,p),u(g,p)):p.isMeshPhongMaterial?(s(g,p),h(g,p)):p.isMeshStandardMaterial?(s(g,p),d(g,p),p.isMeshPhysicalMaterial&&f(g,p,b)):p.isMeshMatcapMaterial?(s(g,p),m(g,p)):p.isMeshDepthMaterial?s(g,p):p.isMeshDistanceMaterial?(s(g,p),v(g,p)):p.isMeshNormalMaterial?s(g,p):p.isLineBasicMaterial?(o(g,p),p.isLineDashedMaterial&&a(g,p)):p.isPointsMaterial?l(g,p,M,x):p.isSpriteMaterial?c(g,p):p.isShadowMaterial?(g.color.value.copy(p.color),g.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(g,p){g.opacity.value=p.opacity,p.color&&g.diffuse.value.copy(p.color),p.emissive&&g.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(g.map.value=p.map,t(p.map,g.mapTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,t(p.alphaMap,g.alphaMapTransform)),p.bumpMap&&(g.bumpMap.value=p.bumpMap,t(p.bumpMap,g.bumpMapTransform),g.bumpScale.value=p.bumpScale,p.side===Un&&(g.bumpScale.value*=-1)),p.normalMap&&(g.normalMap.value=p.normalMap,t(p.normalMap,g.normalMapTransform),g.normalScale.value.copy(p.normalScale),p.side===Un&&g.normalScale.value.negate()),p.displacementMap&&(g.displacementMap.value=p.displacementMap,t(p.displacementMap,g.displacementMapTransform),g.displacementScale.value=p.displacementScale,g.displacementBias.value=p.displacementBias),p.emissiveMap&&(g.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,g.emissiveMapTransform)),p.specularMap&&(g.specularMap.value=p.specularMap,t(p.specularMap,g.specularMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest);const M=e.get(p),x=M.envMap,b=M.envMapRotation;x&&(g.envMap.value=x,as.copy(b),as.x*=-1,as.y*=-1,as.z*=-1,x.isCubeTexture&&x.isRenderTargetTexture===!1&&(as.y*=-1,as.z*=-1),g.envMapRotation.value.setFromMatrix4(Xx.makeRotationFromEuler(as)),g.flipEnvMap.value=x.isCubeTexture&&x.isRenderTargetTexture===!1?-1:1,g.reflectivity.value=p.reflectivity,g.ior.value=p.ior,g.refractionRatio.value=p.refractionRatio),p.lightMap&&(g.lightMap.value=p.lightMap,g.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,g.lightMapTransform)),p.aoMap&&(g.aoMap.value=p.aoMap,g.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,g.aoMapTransform))}function o(g,p){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,p.map&&(g.map.value=p.map,t(p.map,g.mapTransform))}function a(g,p){g.dashSize.value=p.dashSize,g.totalSize.value=p.dashSize+p.gapSize,g.scale.value=p.scale}function l(g,p,M,x){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,g.size.value=p.size*M,g.scale.value=x*.5,p.map&&(g.map.value=p.map,t(p.map,g.uvTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,t(p.alphaMap,g.alphaMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest)}function c(g,p){g.diffuse.value.copy(p.color),g.opacity.value=p.opacity,g.rotation.value=p.rotation,p.map&&(g.map.value=p.map,t(p.map,g.mapTransform)),p.alphaMap&&(g.alphaMap.value=p.alphaMap,t(p.alphaMap,g.alphaMapTransform)),p.alphaTest>0&&(g.alphaTest.value=p.alphaTest)}function h(g,p){g.specular.value.copy(p.specular),g.shininess.value=Math.max(p.shininess,1e-4)}function u(g,p){p.gradientMap&&(g.gradientMap.value=p.gradientMap)}function d(g,p){g.metalness.value=p.metalness,p.metalnessMap&&(g.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,g.metalnessMapTransform)),g.roughness.value=p.roughness,p.roughnessMap&&(g.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,g.roughnessMapTransform)),p.envMap&&(g.envMapIntensity.value=p.envMapIntensity)}function f(g,p,M){g.ior.value=p.ior,p.sheen>0&&(g.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),g.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(g.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,g.sheenColorMapTransform)),p.sheenRoughnessMap&&(g.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,g.sheenRoughnessMapTransform))),p.clearcoat>0&&(g.clearcoat.value=p.clearcoat,g.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(g.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,g.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(g.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,g.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(g.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,g.clearcoatNormalMapTransform),g.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Un&&g.clearcoatNormalScale.value.negate())),p.dispersion>0&&(g.dispersion.value=p.dispersion),p.iridescence>0&&(g.iridescence.value=p.iridescence,g.iridescenceIOR.value=p.iridescenceIOR,g.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],g.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(g.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,g.iridescenceMapTransform)),p.iridescenceThicknessMap&&(g.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,g.iridescenceThicknessMapTransform))),p.transmission>0&&(g.transmission.value=p.transmission,g.transmissionSamplerMap.value=M.texture,g.transmissionSamplerSize.value.set(M.width,M.height),p.transmissionMap&&(g.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,g.transmissionMapTransform)),g.thickness.value=p.thickness,p.thicknessMap&&(g.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,g.thicknessMapTransform)),g.attenuationDistance.value=p.attenuationDistance,g.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(g.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(g.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,g.anisotropyMapTransform))),g.specularIntensity.value=p.specularIntensity,g.specularColor.value.copy(p.specularColor),p.specularColorMap&&(g.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,g.specularColorMapTransform)),p.specularIntensityMap&&(g.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,g.specularIntensityMapTransform))}function m(g,p){p.matcap&&(g.matcap.value=p.matcap)}function v(g,p){const M=e.get(p).light;g.referencePosition.value.setFromMatrixPosition(M.matrixWorld),g.nearDistance.value=M.shadow.camera.near,g.farDistance.value=M.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function qx(r,e,t,n){let i={},s={},o=[];const a=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function l(M,x){const b=x.program;n.uniformBlockBinding(M,b)}function c(M,x){let b=i[M.id];b===void 0&&(m(M),b=h(M),i[M.id]=b,M.addEventListener("dispose",g));const D=x.program;n.updateUBOMapping(M,D);const R=e.render.frame;s[M.id]!==R&&(d(M),s[M.id]=R)}function h(M){const x=u();M.__bindingPointIndex=x;const b=r.createBuffer(),D=M.__size,R=M.usage;return r.bindBuffer(r.UNIFORM_BUFFER,b),r.bufferData(r.UNIFORM_BUFFER,D,R),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,x,b),b}function u(){for(let M=0;M<a;M++)if(o.indexOf(M)===-1)return o.push(M),M;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(M){const x=i[M.id],b=M.uniforms,D=M.__cache;r.bindBuffer(r.UNIFORM_BUFFER,x);for(let R=0,P=b.length;R<P;R++){const S=Array.isArray(b[R])?b[R]:[b[R]];for(let _=0,y=S.length;_<y;_++){const T=S[_];if(f(T,R,_,D)===!0){const F=T.__offset,k=Array.isArray(T.value)?T.value:[T.value];let G=0;for(let $=0;$<k.length;$++){const z=k[$],Y=v(z);typeof z=="number"||typeof z=="boolean"?(T.__data[0]=z,r.bufferSubData(r.UNIFORM_BUFFER,F+G,T.__data)):z.isMatrix3?(T.__data[0]=z.elements[0],T.__data[1]=z.elements[1],T.__data[2]=z.elements[2],T.__data[3]=0,T.__data[4]=z.elements[3],T.__data[5]=z.elements[4],T.__data[6]=z.elements[5],T.__data[7]=0,T.__data[8]=z.elements[6],T.__data[9]=z.elements[7],T.__data[10]=z.elements[8],T.__data[11]=0):(z.toArray(T.__data,G),G+=Y.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,F,T.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}function f(M,x,b,D){const R=M.value,P=x+"_"+b;if(D[P]===void 0)return typeof R=="number"||typeof R=="boolean"?D[P]=R:D[P]=R.clone(),!0;{const S=D[P];if(typeof R=="number"||typeof R=="boolean"){if(S!==R)return D[P]=R,!0}else if(S.equals(R)===!1)return S.copy(R),!0}return!1}function m(M){const x=M.uniforms;let b=0;const D=16;for(let P=0,S=x.length;P<S;P++){const _=Array.isArray(x[P])?x[P]:[x[P]];for(let y=0,T=_.length;y<T;y++){const F=_[y],k=Array.isArray(F.value)?F.value:[F.value];for(let G=0,$=k.length;G<$;G++){const z=k[G],Y=v(z),H=b%D,q=H%Y.boundary,ue=H+q;b+=q,ue!==0&&D-ue<Y.storage&&(b+=D-ue),F.__data=new Float32Array(Y.storage/Float32Array.BYTES_PER_ELEMENT),F.__offset=b,b+=Y.storage}}}const R=b%D;return R>0&&(b+=D-R),M.__size=b,M.__cache={},this}function v(M){const x={boundary:0,storage:0};return typeof M=="number"||typeof M=="boolean"?(x.boundary=4,x.storage=4):M.isVector2?(x.boundary=8,x.storage=8):M.isVector3||M.isColor?(x.boundary=16,x.storage=12):M.isVector4?(x.boundary=16,x.storage=16):M.isMatrix3?(x.boundary=48,x.storage=48):M.isMatrix4?(x.boundary=64,x.storage=64):M.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",M),x}function g(M){const x=M.target;x.removeEventListener("dispose",g);const b=o.indexOf(x.__bindingPointIndex);o.splice(b,1),r.deleteBuffer(i[x.id]),delete i[x.id],delete s[x.id]}function p(){for(const M in i)r.deleteBuffer(i[M]);o=[],i={},s={}}return{bind:l,update:c,dispose:p}}class Yx{constructor(e={}){const{canvas:t=kp(),context:n=null,depth:i=!0,stencil:s=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:d=!1}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;const m=new Uint32Array(4),v=new Int32Array(4);let g=null,p=null;const M=[],x=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=xt,this.toneMapping=es,this.toneMappingExposure=1;const b=this;let D=!1,R=0,P=0,S=null,_=-1,y=null;const T=new ct,F=new ct;let k=null;const G=new Ge(0);let $=0,z=t.width,Y=t.height,H=1,q=null,ue=null;const re=new ct(0,0,z,Y),de=new ct(0,0,z,Y);let ie=!1;const W=new xa;let Z=!1,Q=!1;this.transmissionResolutionScale=1;const ne=new Te,ce=new Te,Me=new I,we=new ct,Ne={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Je=!1;function We(){return S===null?H:1}let B=n;function ht(L,V){return t.getContext(L,V)}try{const L={alpha:!0,depth:i,stencil:s,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${_s}`),t.addEventListener("webglcontextlost",fe,!1),t.addEventListener("webglcontextrestored",Ue,!1),t.addEventListener("webglcontextcreationerror",De,!1),B===null){const V="webgl2";if(B=ht(V,L),B===null)throw ht(V)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(L){throw console.error("THREE.WebGLRenderer: "+L.message),L}let Pe,tt,me,Qe,ke,O,A,K,ae,he,se,Re,xe,Fe,gt,ge,Ee,qe,et,ze,vt,at,Lt,X;function Ce(){Pe=new sv(B),Pe.init(),at=new zx(B,Pe),tt=new $_(B,Pe,e,at),me=new Bx(B,Pe),tt.reverseDepthBuffer&&d&&me.buffers.depth.setReversed(!0),Qe=new av(B),ke=new Ex,O=new kx(B,Pe,me,ke,tt,at,Qe),A=new Q_(b),K=new iv(b),ae=new fg(B),Lt=new Z_(B,ae),he=new rv(B,ae,Qe,Lt),se=new cv(B,he,ae,Qe),et=new lv(B,tt,O),ge=new J_(ke),Re=new wx(b,A,K,Pe,tt,Lt,ge),xe=new jx(b,ke),Fe=new Ax,gt=new Ix(Pe),qe=new Y_(b,A,K,me,se,f,l),Ee=new Fx(b,se,tt),X=new qx(B,Qe,tt,me),ze=new K_(B,Pe,Qe),vt=new ov(B,Pe,Qe),Qe.programs=Re.programs,b.capabilities=tt,b.extensions=Pe,b.properties=ke,b.renderLists=Fe,b.shadowMap=Ee,b.state=me,b.info=Qe}Ce();const oe=new Wx(b,B);this.xr=oe,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){const L=Pe.get("WEBGL_lose_context");L&&L.loseContext()},this.forceContextRestore=function(){const L=Pe.get("WEBGL_lose_context");L&&L.restoreContext()},this.getPixelRatio=function(){return H},this.setPixelRatio=function(L){L!==void 0&&(H=L,this.setSize(z,Y,!1))},this.getSize=function(L){return L.set(z,Y)},this.setSize=function(L,V,J=!0){if(oe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}z=L,Y=V,t.width=Math.floor(L*H),t.height=Math.floor(V*H),J===!0&&(t.style.width=L+"px",t.style.height=V+"px"),this.setViewport(0,0,L,V)},this.getDrawingBufferSize=function(L){return L.set(z*H,Y*H).floor()},this.setDrawingBufferSize=function(L,V,J){z=L,Y=V,H=J,t.width=Math.floor(L*J),t.height=Math.floor(V*J),this.setViewport(0,0,L,V)},this.getCurrentViewport=function(L){return L.copy(T)},this.getViewport=function(L){return L.copy(re)},this.setViewport=function(L,V,J,ee){L.isVector4?re.set(L.x,L.y,L.z,L.w):re.set(L,V,J,ee),me.viewport(T.copy(re).multiplyScalar(H).round())},this.getScissor=function(L){return L.copy(de)},this.setScissor=function(L,V,J,ee){L.isVector4?de.set(L.x,L.y,L.z,L.w):de.set(L,V,J,ee),me.scissor(F.copy(de).multiplyScalar(H).round())},this.getScissorTest=function(){return ie},this.setScissorTest=function(L){me.setScissorTest(ie=L)},this.setOpaqueSort=function(L){q=L},this.setTransparentSort=function(L){ue=L},this.getClearColor=function(L){return L.copy(qe.getClearColor())},this.setClearColor=function(){qe.setClearColor(...arguments)},this.getClearAlpha=function(){return qe.getClearAlpha()},this.setClearAlpha=function(){qe.setClearAlpha(...arguments)},this.clear=function(L=!0,V=!0,J=!0){let ee=0;if(L){let j=!1;if(S!==null){const _e=S.texture.format;j=_e===Lc||_e===Pc||_e===Cc}if(j){const _e=S.texture.type,Ae=_e===Fi||_e===xs||_e===Fr||_e===cr||_e===Ac||_e===Rc,Oe=qe.getClearColor(),He=qe.getClearAlpha(),it=Oe.r,st=Oe.g,Ye=Oe.b;Ae?(m[0]=it,m[1]=st,m[2]=Ye,m[3]=He,B.clearBufferuiv(B.COLOR,0,m)):(v[0]=it,v[1]=st,v[2]=Ye,v[3]=He,B.clearBufferiv(B.COLOR,0,v))}else ee|=B.COLOR_BUFFER_BIT}V&&(ee|=B.DEPTH_BUFFER_BIT),J&&(ee|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),B.clear(ee)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",fe,!1),t.removeEventListener("webglcontextrestored",Ue,!1),t.removeEventListener("webglcontextcreationerror",De,!1),qe.dispose(),Fe.dispose(),gt.dispose(),ke.dispose(),A.dispose(),K.dispose(),se.dispose(),Lt.dispose(),X.dispose(),Re.dispose(),oe.dispose(),oe.removeEventListener("sessionstart",$r),oe.removeEventListener("sessionend",Jr),xi.stop()};function fe(L){L.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),D=!0}function Ue(){console.log("THREE.WebGLRenderer: Context Restored."),D=!1;const L=Qe.autoReset,V=Ee.enabled,J=Ee.autoUpdate,ee=Ee.needsUpdate,j=Ee.type;Ce(),Qe.autoReset=L,Ee.enabled=V,Ee.autoUpdate=J,Ee.needsUpdate=ee,Ee.type=j}function De(L){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",L.statusMessage)}function ot(L){const V=L.target;V.removeEventListener("dispose",ot),kt(V)}function kt(L){an(L),ke.remove(L)}function an(L){const V=ke.get(L).programs;V!==void 0&&(V.forEach(function(J){Re.releaseProgram(J)}),L.isShaderMaterial&&Re.releaseShaderCache(L))}this.renderBufferDirect=function(L,V,J,ee,j,_e){V===null&&(V=Ne);const Ae=j.isMesh&&j.matrixWorld.determinant()<0,Oe=Ra(L,V,J,ee,j);me.setMaterial(ee,Ae);let He=J.index,it=1;if(ee.wireframe===!0){if(He=he.getWireframeAttribute(J),He===void 0)return;it=2}const st=J.drawRange,Ye=J.attributes.position;let ft=st.start*it,wt=(st.start+st.count)*it;_e!==null&&(ft=Math.max(ft,_e.start*it),wt=Math.min(wt,(_e.start+_e.count)*it)),He!==null?(ft=Math.max(ft,0),wt=Math.min(wt,He.count)):Ye!=null&&(ft=Math.max(ft,0),wt=Math.min(wt,Ye.count));const Gt=wt-ft;if(Gt<0||Gt===1/0)return;Lt.setup(j,ee,Oe,J,He);let Ht,bt=ze;if(He!==null&&(Ht=ae.get(He),bt=vt,bt.setIndex(Ht)),j.isMesh)ee.wireframe===!0?(me.setLineWidth(ee.wireframeLinewidth*We()),bt.setMode(B.LINES)):bt.setMode(B.TRIANGLES);else if(j.isLine){let Ke=ee.linewidth;Ke===void 0&&(Ke=1),me.setLineWidth(Ke*We()),j.isLineSegments?bt.setMode(B.LINES):j.isLineLoop?bt.setMode(B.LINE_LOOP):bt.setMode(B.LINE_STRIP)}else j.isPoints?bt.setMode(B.POINTS):j.isSprite&&bt.setMode(B.TRIANGLES);if(j.isBatchedMesh)if(j._multiDrawInstances!==null)hs("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),bt.renderMultiDrawInstances(j._multiDrawStarts,j._multiDrawCounts,j._multiDrawCount,j._multiDrawInstances);else if(Pe.get("WEBGL_multi_draw"))bt.renderMultiDraw(j._multiDrawStarts,j._multiDrawCounts,j._multiDrawCount);else{const Ke=j._multiDrawStarts,en=j._multiDrawCounts,Et=j._multiDrawCount,Ln=He?ae.get(He).bytesPerElement:1,Bt=ke.get(ee).currentProgram.getUniforms();for(let hn=0;hn<Et;hn++)Bt.setValue(B,"_gl_DrawID",hn),bt.render(Ke[hn]/Ln,en[hn])}else if(j.isInstancedMesh)bt.renderInstances(ft,Gt,j.count);else if(J.isInstancedBufferGeometry){const Ke=J._maxInstanceCount!==void 0?J._maxInstanceCount:1/0,en=Math.min(J.instanceCount,Ke);bt.renderInstances(ft,Gt,en)}else bt.render(ft,Gt)};function ut(L,V,J){L.transparent===!0&&L.side===Wn&&L.forceSinglePass===!1?(L.side=Un,L.needsUpdate=!0,Rs(L,V,J),L.side=Ui,L.needsUpdate=!0,Rs(L,V,J),L.side=Wn):Rs(L,V,J)}this.compile=function(L,V,J=null){J===null&&(J=L),p=gt.get(J),p.init(V),x.push(p),J.traverseVisible(function(j){j.isLight&&j.layers.test(V.layers)&&(p.pushLight(j),j.castShadow&&p.pushShadow(j))}),L!==J&&L.traverseVisible(function(j){j.isLight&&j.layers.test(V.layers)&&(p.pushLight(j),j.castShadow&&p.pushShadow(j))}),p.setupLights();const ee=new Set;return L.traverse(function(j){if(!(j.isMesh||j.isPoints||j.isLine||j.isSprite))return;const _e=j.material;if(_e)if(Array.isArray(_e))for(let Ae=0;Ae<_e.length;Ae++){const Oe=_e[Ae];ut(Oe,J,j),ee.add(Oe)}else ut(_e,J,j),ee.add(_e)}),p=x.pop(),ee},this.compileAsync=function(L,V,J=null){const ee=this.compile(L,V,J);return new Promise(j=>{function _e(){if(ee.forEach(function(Ae){ke.get(Ae).currentProgram.isReady()&&ee.delete(Ae)}),ee.size===0){j(L);return}setTimeout(_e,10)}Pe.get("KHR_parallel_shader_compile")!==null?_e():setTimeout(_e,10)})};let Pn=null;function Kn(L){Pn&&Pn(L)}function $r(){xi.stop()}function Jr(){xi.start()}const xi=new ef;xi.setAnimationLoop(Kn),typeof self<"u"&&xi.setContext(self),this.setAnimationLoop=function(L){Pn=L,oe.setAnimationLoop(L),L===null?xi.stop():xi.start()},oe.addEventListener("sessionstart",$r),oe.addEventListener("sessionend",Jr),this.render=function(L,V){if(V!==void 0&&V.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(D===!0)return;if(L.matrixWorldAutoUpdate===!0&&L.updateMatrixWorld(),V.parent===null&&V.matrixWorldAutoUpdate===!0&&V.updateMatrixWorld(),oe.enabled===!0&&oe.isPresenting===!0&&(oe.cameraAutoUpdate===!0&&oe.updateCamera(V),V=oe.getCamera()),L.isScene===!0&&L.onBeforeRender(b,L,V,S),p=gt.get(L,x.length),p.init(V),x.push(p),ce.multiplyMatrices(V.projectionMatrix,V.matrixWorldInverse),W.setFromProjectionMatrix(ce),Q=this.localClippingEnabled,Z=ge.init(this.clippingPlanes,Q),g=Fe.get(L,M.length),g.init(),M.push(g),oe.enabled===!0&&oe.isPresenting===!0){const _e=b.xr.getDepthSensingMesh();_e!==null&&xr(_e,V,-1/0,b.sortObjects)}xr(L,V,0,b.sortObjects),g.finish(),b.sortObjects===!0&&g.sort(q,ue),Je=oe.enabled===!1||oe.isPresenting===!1||oe.hasDepthSensing()===!1,Je&&qe.addToRenderList(g,L),this.info.render.frame++,Z===!0&&ge.beginShadows();const J=p.state.shadowsArray;Ee.render(J,L,V),Z===!0&&ge.endShadows(),this.info.autoReset===!0&&this.info.reset();const ee=g.opaque,j=g.transmissive;if(p.setupLights(),V.isArrayCamera){const _e=V.cameras;if(j.length>0)for(let Ae=0,Oe=_e.length;Ae<Oe;Ae++){const He=_e[Ae];yr(ee,j,L,He)}Je&&qe.render(L);for(let Ae=0,Oe=_e.length;Ae<Oe;Ae++){const He=_e[Ae];Qr(g,L,He,He.viewport)}}else j.length>0&&yr(ee,j,L,V),Je&&qe.render(L),Qr(g,L,V);S!==null&&P===0&&(O.updateMultisampleRenderTarget(S),O.updateRenderTargetMipmap(S)),L.isScene===!0&&L.onAfterRender(b,L,V),Lt.resetDefaultState(),_=-1,y=null,x.pop(),x.length>0?(p=x[x.length-1],Z===!0&&ge.setGlobalState(b.clippingPlanes,p.state.camera)):p=null,M.pop(),M.length>0?g=M[M.length-1]:g=null};function xr(L,V,J,ee){if(L.visible===!1)return;if(L.layers.test(V.layers)){if(L.isGroup)J=L.renderOrder;else if(L.isLOD)L.autoUpdate===!0&&L.update(V);else if(L.isLight)p.pushLight(L),L.castShadow&&p.pushShadow(L);else if(L.isSprite){if(!L.frustumCulled||W.intersectsSprite(L)){ee&&we.setFromMatrixPosition(L.matrixWorld).applyMatrix4(ce);const Ae=se.update(L),Oe=L.material;Oe.visible&&g.push(L,Ae,Oe,J,we.z,null)}}else if((L.isMesh||L.isLine||L.isPoints)&&(!L.frustumCulled||W.intersectsObject(L))){const Ae=se.update(L),Oe=L.material;if(ee&&(L.boundingSphere!==void 0?(L.boundingSphere===null&&L.computeBoundingSphere(),we.copy(L.boundingSphere.center)):(Ae.boundingSphere===null&&Ae.computeBoundingSphere(),we.copy(Ae.boundingSphere.center)),we.applyMatrix4(L.matrixWorld).applyMatrix4(ce)),Array.isArray(Oe)){const He=Ae.groups;for(let it=0,st=He.length;it<st;it++){const Ye=He[it],ft=Oe[Ye.materialIndex];ft&&ft.visible&&g.push(L,Ae,ft,J,we.z,Ye)}}else Oe.visible&&g.push(L,Ae,Oe,J,we.z,null)}}const _e=L.children;for(let Ae=0,Oe=_e.length;Ae<Oe;Ae++)xr(_e[Ae],V,J,ee)}function Qr(L,V,J,ee){const j=L.opaque,_e=L.transmissive,Ae=L.transparent;p.setupLightsView(J),Z===!0&&ge.setGlobalState(b.clippingPlanes,J),ee&&me.viewport(T.copy(ee)),j.length>0&&As(j,V,J),_e.length>0&&As(_e,V,J),Ae.length>0&&As(Ae,V,J),me.buffers.depth.setTest(!0),me.buffers.depth.setMask(!0),me.buffers.color.setMask(!0),me.setPolygonOffset(!1)}function yr(L,V,J,ee){if((J.isScene===!0?J.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[ee.id]===void 0&&(p.state.transmissionRenderTarget[ee.id]=new ys(1,1,{generateMipmaps:!0,type:Pe.has("EXT_color_buffer_half_float")||Pe.has("EXT_color_buffer_float")?Xr:Fi,minFilter:Li,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:rt.workingColorSpace}));const _e=p.state.transmissionRenderTarget[ee.id],Ae=ee.viewport||T;_e.setSize(Ae.z*b.transmissionResolutionScale,Ae.w*b.transmissionResolutionScale);const Oe=b.getRenderTarget();b.setRenderTarget(_e),b.getClearColor(G),$=b.getClearAlpha(),$<1&&b.setClearColor(16777215,.5),b.clear(),Je&&qe.render(J);const He=b.toneMapping;b.toneMapping=es;const it=ee.viewport;if(ee.viewport!==void 0&&(ee.viewport=void 0),p.setupLightsView(ee),Z===!0&&ge.setGlobalState(b.clippingPlanes,ee),As(L,J,ee),O.updateMultisampleRenderTarget(_e),O.updateRenderTargetMipmap(_e),Pe.has("WEBGL_multisampled_render_to_texture")===!1){let st=!1;for(let Ye=0,ft=V.length;Ye<ft;Ye++){const wt=V[Ye],Gt=wt.object,Ht=wt.geometry,bt=wt.material,Ke=wt.group;if(bt.side===Wn&&Gt.layers.test(ee.layers)){const en=bt.side;bt.side=Un,bt.needsUpdate=!0,br(Gt,J,ee,Ht,bt,Ke),bt.side=en,bt.needsUpdate=!0,st=!0}}st===!0&&(O.updateMultisampleRenderTarget(_e),O.updateRenderTargetMipmap(_e))}b.setRenderTarget(Oe),b.setClearColor(G,$),it!==void 0&&(ee.viewport=it),b.toneMapping=He}function As(L,V,J){const ee=V.isScene===!0?V.overrideMaterial:null;for(let j=0,_e=L.length;j<_e;j++){const Ae=L[j],Oe=Ae.object,He=Ae.geometry,it=ee===null?Ae.material:ee,st=Ae.group;Oe.layers.test(J.layers)&&br(Oe,V,J,He,it,st)}}function br(L,V,J,ee,j,_e){L.onBeforeRender(b,V,J,ee,j,_e),L.modelViewMatrix.multiplyMatrices(J.matrixWorldInverse,L.matrixWorld),L.normalMatrix.getNormalMatrix(L.modelViewMatrix),j.onBeforeRender(b,V,J,ee,L,_e),j.transparent===!0&&j.side===Wn&&j.forceSinglePass===!1?(j.side=Un,j.needsUpdate=!0,b.renderBufferDirect(J,V,ee,j,L,_e),j.side=Ui,j.needsUpdate=!0,b.renderBufferDirect(J,V,ee,j,L,_e),j.side=Wn):b.renderBufferDirect(J,V,ee,j,L,_e),L.onAfterRender(b,V,J,ee,j,_e)}function Rs(L,V,J){V.isScene!==!0&&(V=Ne);const ee=ke.get(L),j=p.state.lights,_e=p.state.shadowsArray,Ae=j.state.version,Oe=Re.getParameters(L,j.state,_e,V,J),He=Re.getProgramCacheKey(Oe);let it=ee.programs;ee.environment=L.isMeshStandardMaterial?V.environment:null,ee.fog=V.fog,ee.envMap=(L.isMeshStandardMaterial?K:A).get(L.envMap||ee.environment),ee.envMapRotation=ee.environment!==null&&L.envMap===null?V.environmentRotation:L.envMapRotation,it===void 0&&(L.addEventListener("dispose",ot),it=new Map,ee.programs=it);let st=it.get(He);if(st!==void 0){if(ee.currentProgram===st&&ee.lightsStateVersion===Ae)return to(L,Oe),st}else Oe.uniforms=Re.getUniforms(L),L.onBeforeCompile(Oe,b),st=Re.acquireProgram(Oe,He),it.set(He,st),ee.uniforms=Oe.uniforms;const Ye=ee.uniforms;return(!L.isShaderMaterial&&!L.isRawShaderMaterial||L.clipping===!0)&&(Ye.clippingPlanes=ge.uniform),to(L,Oe),ee.needsLights=Pa(L),ee.lightsStateVersion=Ae,ee.needsLights&&(Ye.ambientLightColor.value=j.state.ambient,Ye.lightProbe.value=j.state.probe,Ye.directionalLights.value=j.state.directional,Ye.directionalLightShadows.value=j.state.directionalShadow,Ye.spotLights.value=j.state.spot,Ye.spotLightShadows.value=j.state.spotShadow,Ye.rectAreaLights.value=j.state.rectArea,Ye.ltc_1.value=j.state.rectAreaLTC1,Ye.ltc_2.value=j.state.rectAreaLTC2,Ye.pointLights.value=j.state.point,Ye.pointLightShadows.value=j.state.pointShadow,Ye.hemisphereLights.value=j.state.hemi,Ye.directionalShadowMap.value=j.state.directionalShadowMap,Ye.directionalShadowMatrix.value=j.state.directionalShadowMatrix,Ye.spotShadowMap.value=j.state.spotShadowMap,Ye.spotLightMatrix.value=j.state.spotLightMatrix,Ye.spotLightMap.value=j.state.spotLightMap,Ye.pointShadowMap.value=j.state.pointShadowMap,Ye.pointShadowMatrix.value=j.state.pointShadowMatrix),ee.currentProgram=st,ee.uniformsList=null,st}function eo(L){if(L.uniformsList===null){const V=L.currentProgram.getUniforms();L.uniformsList=na.seqWithValue(V.seq,L.uniforms)}return L.uniformsList}function to(L,V){const J=ke.get(L);J.outputColorSpace=V.outputColorSpace,J.batching=V.batching,J.batchingColor=V.batchingColor,J.instancing=V.instancing,J.instancingColor=V.instancingColor,J.instancingMorph=V.instancingMorph,J.skinning=V.skinning,J.morphTargets=V.morphTargets,J.morphNormals=V.morphNormals,J.morphColors=V.morphColors,J.morphTargetsCount=V.morphTargetsCount,J.numClippingPlanes=V.numClippingPlanes,J.numIntersection=V.numClipIntersection,J.vertexAlphas=V.vertexAlphas,J.vertexTangents=V.vertexTangents,J.toneMapping=V.toneMapping}function Ra(L,V,J,ee,j){V.isScene!==!0&&(V=Ne),O.resetTextureUnits();const _e=V.fog,Ae=ee.isMeshStandardMaterial?V.environment:null,Oe=S===null?b.outputColorSpace:S.isXRRenderTarget===!0?S.texture.colorSpace:ur,He=(ee.isMeshStandardMaterial?K:A).get(ee.envMap||Ae),it=ee.vertexColors===!0&&!!J.attributes.color&&J.attributes.color.itemSize===4,st=!!J.attributes.tangent&&(!!ee.normalMap||ee.anisotropy>0),Ye=!!J.morphAttributes.position,ft=!!J.morphAttributes.normal,wt=!!J.morphAttributes.color;let Gt=es;ee.toneMapped&&(S===null||S.isXRRenderTarget===!0)&&(Gt=b.toneMapping);const Ht=J.morphAttributes.position||J.morphAttributes.normal||J.morphAttributes.color,bt=Ht!==void 0?Ht.length:0,Ke=ke.get(ee),en=p.state.lights;if(Z===!0&&(Q===!0||L!==y)){const $t=L===y&&ee.id===_;ge.setState(ee,L,$t)}let Et=!1;ee.version===Ke.__version?(Ke.needsLights&&Ke.lightsStateVersion!==en.state.version||Ke.outputColorSpace!==Oe||j.isBatchedMesh&&Ke.batching===!1||!j.isBatchedMesh&&Ke.batching===!0||j.isBatchedMesh&&Ke.batchingColor===!0&&j.colorTexture===null||j.isBatchedMesh&&Ke.batchingColor===!1&&j.colorTexture!==null||j.isInstancedMesh&&Ke.instancing===!1||!j.isInstancedMesh&&Ke.instancing===!0||j.isSkinnedMesh&&Ke.skinning===!1||!j.isSkinnedMesh&&Ke.skinning===!0||j.isInstancedMesh&&Ke.instancingColor===!0&&j.instanceColor===null||j.isInstancedMesh&&Ke.instancingColor===!1&&j.instanceColor!==null||j.isInstancedMesh&&Ke.instancingMorph===!0&&j.morphTexture===null||j.isInstancedMesh&&Ke.instancingMorph===!1&&j.morphTexture!==null||Ke.envMap!==He||ee.fog===!0&&Ke.fog!==_e||Ke.numClippingPlanes!==void 0&&(Ke.numClippingPlanes!==ge.numPlanes||Ke.numIntersection!==ge.numIntersection)||Ke.vertexAlphas!==it||Ke.vertexTangents!==st||Ke.morphTargets!==Ye||Ke.morphNormals!==ft||Ke.morphColors!==wt||Ke.toneMapping!==Gt||Ke.morphTargetsCount!==bt)&&(Et=!0):(Et=!0,Ke.__version=ee.version);let Ln=Ke.currentProgram;Et===!0&&(Ln=Rs(ee,V,j));let Bt=!1,hn=!1,ts=!1;const Ft=Ln.getUniforms(),wn=Ke.uniforms;if(me.useProgram(Ln.program)&&(Bt=!0,hn=!0,ts=!0),ee.id!==_&&(_=ee.id,hn=!0),Bt||y!==L){me.buffers.depth.getReversed()?(ne.copy(L.projectionMatrix),Hp(ne),Vp(ne),Ft.setValue(B,"projectionMatrix",ne)):Ft.setValue(B,"projectionMatrix",L.projectionMatrix),Ft.setValue(B,"viewMatrix",L.matrixWorldInverse);const tn=Ft.map.cameraPosition;tn!==void 0&&tn.setValue(B,Me.setFromMatrixPosition(L.matrixWorld)),tt.logarithmicDepthBuffer&&Ft.setValue(B,"logDepthBufFC",2/(Math.log(L.far+1)/Math.LN2)),(ee.isMeshPhongMaterial||ee.isMeshToonMaterial||ee.isMeshLambertMaterial||ee.isMeshBasicMaterial||ee.isMeshStandardMaterial||ee.isShaderMaterial)&&Ft.setValue(B,"isOrthographic",L.isOrthographicCamera===!0),y!==L&&(y=L,hn=!0,ts=!0)}if(j.isSkinnedMesh){Ft.setOptional(B,j,"bindMatrix"),Ft.setOptional(B,j,"bindMatrixInverse");const $t=j.skeleton;$t&&($t.boneTexture===null&&$t.computeBoneTexture(),Ft.setValue(B,"boneTexture",$t.boneTexture,O))}j.isBatchedMesh&&(Ft.setOptional(B,j,"batchingTexture"),Ft.setValue(B,"batchingTexture",j._matricesTexture,O),Ft.setOptional(B,j,"batchingIdTexture"),Ft.setValue(B,"batchingIdTexture",j._indirectTexture,O),Ft.setOptional(B,j,"batchingColorTexture"),j._colorsTexture!==null&&Ft.setValue(B,"batchingColorTexture",j._colorsTexture,O));const _n=J.morphAttributes;if((_n.position!==void 0||_n.normal!==void 0||_n.color!==void 0)&&et.update(j,J,Ln),(hn||Ke.receiveShadow!==j.receiveShadow)&&(Ke.receiveShadow=j.receiveShadow,Ft.setValue(B,"receiveShadow",j.receiveShadow)),ee.isMeshGouraudMaterial&&ee.envMap!==null&&(wn.envMap.value=He,wn.flipEnvMap.value=He.isCubeTexture&&He.isRenderTargetTexture===!1?-1:1),ee.isMeshStandardMaterial&&ee.envMap===null&&V.environment!==null&&(wn.envMapIntensity.value=V.environmentIntensity),hn&&(Ft.setValue(B,"toneMappingExposure",b.toneMappingExposure),Ke.needsLights&&Ca(wn,ts),_e&&ee.fog===!0&&xe.refreshFogUniforms(wn,_e),xe.refreshMaterialUniforms(wn,ee,H,Y,p.state.transmissionRenderTarget[L.id]),na.upload(B,eo(Ke),wn,O)),ee.isShaderMaterial&&ee.uniformsNeedUpdate===!0&&(na.upload(B,eo(Ke),wn,O),ee.uniformsNeedUpdate=!1),ee.isSpriteMaterial&&Ft.setValue(B,"center",j.center),Ft.setValue(B,"modelViewMatrix",j.modelViewMatrix),Ft.setValue(B,"normalMatrix",j.normalMatrix),Ft.setValue(B,"modelMatrix",j.matrixWorld),ee.isShaderMaterial||ee.isRawShaderMaterial){const $t=ee.uniformsGroups;for(let tn=0,Cs=$t.length;tn<Cs;tn++){const yi=$t[tn];X.update(yi,Ln),X.bind(yi,Ln)}}return Ln}function Ca(L,V){L.ambientLightColor.needsUpdate=V,L.lightProbe.needsUpdate=V,L.directionalLights.needsUpdate=V,L.directionalLightShadows.needsUpdate=V,L.pointLights.needsUpdate=V,L.pointLightShadows.needsUpdate=V,L.spotLights.needsUpdate=V,L.spotLightShadows.needsUpdate=V,L.rectAreaLights.needsUpdate=V,L.hemisphereLights.needsUpdate=V}function Pa(L){return L.isMeshLambertMaterial||L.isMeshToonMaterial||L.isMeshPhongMaterial||L.isMeshStandardMaterial||L.isShadowMaterial||L.isShaderMaterial&&L.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return P},this.getRenderTarget=function(){return S},this.setRenderTargetTextures=function(L,V,J){ke.get(L.texture).__webglTexture=V,ke.get(L.depthTexture).__webglTexture=J;const ee=ke.get(L);ee.__hasExternalTextures=!0,ee.__autoAllocateDepthBuffer=J===void 0,ee.__autoAllocateDepthBuffer||Pe.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),ee.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(L,V){const J=ke.get(L);J.__webglFramebuffer=V,J.__useDefaultFramebuffer=V===void 0};const La=B.createFramebuffer();this.setRenderTarget=function(L,V=0,J=0){S=L,R=V,P=J;let ee=!0,j=null,_e=!1,Ae=!1;if(L){const He=ke.get(L);if(He.__useDefaultFramebuffer!==void 0)me.bindFramebuffer(B.FRAMEBUFFER,null),ee=!1;else if(He.__webglFramebuffer===void 0)O.setupRenderTarget(L);else if(He.__hasExternalTextures)O.rebindTextures(L,ke.get(L.texture).__webglTexture,ke.get(L.depthTexture).__webglTexture);else if(L.depthBuffer){const Ye=L.depthTexture;if(He.__boundDepthTexture!==Ye){if(Ye!==null&&ke.has(Ye)&&(L.width!==Ye.image.width||L.height!==Ye.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");O.setupDepthRenderbuffer(L)}}const it=L.texture;(it.isData3DTexture||it.isDataArrayTexture||it.isCompressedArrayTexture)&&(Ae=!0);const st=ke.get(L).__webglFramebuffer;L.isWebGLCubeRenderTarget?(Array.isArray(st[V])?j=st[V][J]:j=st[V],_e=!0):L.samples>0&&O.useMultisampledRTT(L)===!1?j=ke.get(L).__webglMultisampledFramebuffer:Array.isArray(st)?j=st[J]:j=st,T.copy(L.viewport),F.copy(L.scissor),k=L.scissorTest}else T.copy(re).multiplyScalar(H).floor(),F.copy(de).multiplyScalar(H).floor(),k=ie;if(J!==0&&(j=La),me.bindFramebuffer(B.FRAMEBUFFER,j)&&ee&&me.drawBuffers(L,j),me.viewport(T),me.scissor(F),me.setScissorTest(k),_e){const He=ke.get(L.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+V,He.__webglTexture,J)}else if(Ae){const He=ke.get(L.texture),it=V;B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,He.__webglTexture,J,it)}else if(L!==null&&J!==0){const He=ke.get(L.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,He.__webglTexture,J)}_=-1},this.readRenderTargetPixels=function(L,V,J,ee,j,_e,Ae){if(!(L&&L.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Oe=ke.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&Ae!==void 0&&(Oe=Oe[Ae]),Oe){me.bindFramebuffer(B.FRAMEBUFFER,Oe);try{const He=L.texture,it=He.format,st=He.type;if(!tt.textureFormatReadable(it)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!tt.textureTypeReadable(st)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}V>=0&&V<=L.width-ee&&J>=0&&J<=L.height-j&&B.readPixels(V,J,ee,j,at.convert(it),at.convert(st),_e)}finally{const He=S!==null?ke.get(S).__webglFramebuffer:null;me.bindFramebuffer(B.FRAMEBUFFER,He)}}},this.readRenderTargetPixelsAsync=async function(L,V,J,ee,j,_e,Ae){if(!(L&&L.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Oe=ke.get(L).__webglFramebuffer;if(L.isWebGLCubeRenderTarget&&Ae!==void 0&&(Oe=Oe[Ae]),Oe){const He=L.texture,it=He.format,st=He.type;if(!tt.textureFormatReadable(it))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!tt.textureTypeReadable(st))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(V>=0&&V<=L.width-ee&&J>=0&&J<=L.height-j){me.bindFramebuffer(B.FRAMEBUFFER,Oe);const Ye=B.createBuffer();B.bindBuffer(B.PIXEL_PACK_BUFFER,Ye),B.bufferData(B.PIXEL_PACK_BUFFER,_e.byteLength,B.STREAM_READ),B.readPixels(V,J,ee,j,at.convert(it),at.convert(st),0);const ft=S!==null?ke.get(S).__webglFramebuffer:null;me.bindFramebuffer(B.FRAMEBUFFER,ft);const wt=B.fenceSync(B.SYNC_GPU_COMMANDS_COMPLETE,0);return B.flush(),await zp(B,wt,4),B.bindBuffer(B.PIXEL_PACK_BUFFER,Ye),B.getBufferSubData(B.PIXEL_PACK_BUFFER,0,_e),B.deleteBuffer(Ye),B.deleteSync(wt),_e}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(L,V=null,J=0){L.isTexture!==!0&&(hs("WebGLRenderer: copyFramebufferToTexture function signature has changed."),V=arguments[0]||null,L=arguments[1]);const ee=Math.pow(2,-J),j=Math.floor(L.image.width*ee),_e=Math.floor(L.image.height*ee),Ae=V!==null?V.x:0,Oe=V!==null?V.y:0;O.setTexture2D(L,0),B.copyTexSubImage2D(B.TEXTURE_2D,J,0,0,Ae,Oe,j,_e),me.unbindTexture()};const Da=B.createFramebuffer(),Ia=B.createFramebuffer();this.copyTextureToTexture=function(L,V,J=null,ee=null,j=0,_e=null){L.isTexture!==!0&&(hs("WebGLRenderer: copyTextureToTexture function signature has changed."),ee=arguments[0]||null,L=arguments[1],V=arguments[2],_e=arguments[3]||0,J=null),_e===null&&(j!==0?(hs("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),_e=j,j=0):_e=0);let Ae,Oe,He,it,st,Ye,ft,wt,Gt;const Ht=L.isCompressedTexture?L.mipmaps[_e]:L.image;if(J!==null)Ae=J.max.x-J.min.x,Oe=J.max.y-J.min.y,He=J.isBox3?J.max.z-J.min.z:1,it=J.min.x,st=J.min.y,Ye=J.isBox3?J.min.z:0;else{const _n=Math.pow(2,-j);Ae=Math.floor(Ht.width*_n),Oe=Math.floor(Ht.height*_n),L.isDataArrayTexture?He=Ht.depth:L.isData3DTexture?He=Math.floor(Ht.depth*_n):He=1,it=0,st=0,Ye=0}ee!==null?(ft=ee.x,wt=ee.y,Gt=ee.z):(ft=0,wt=0,Gt=0);const bt=at.convert(V.format),Ke=at.convert(V.type);let en;V.isData3DTexture?(O.setTexture3D(V,0),en=B.TEXTURE_3D):V.isDataArrayTexture||V.isCompressedArrayTexture?(O.setTexture2DArray(V,0),en=B.TEXTURE_2D_ARRAY):(O.setTexture2D(V,0),en=B.TEXTURE_2D),B.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,V.flipY),B.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,V.premultiplyAlpha),B.pixelStorei(B.UNPACK_ALIGNMENT,V.unpackAlignment);const Et=B.getParameter(B.UNPACK_ROW_LENGTH),Ln=B.getParameter(B.UNPACK_IMAGE_HEIGHT),Bt=B.getParameter(B.UNPACK_SKIP_PIXELS),hn=B.getParameter(B.UNPACK_SKIP_ROWS),ts=B.getParameter(B.UNPACK_SKIP_IMAGES);B.pixelStorei(B.UNPACK_ROW_LENGTH,Ht.width),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,Ht.height),B.pixelStorei(B.UNPACK_SKIP_PIXELS,it),B.pixelStorei(B.UNPACK_SKIP_ROWS,st),B.pixelStorei(B.UNPACK_SKIP_IMAGES,Ye);const Ft=L.isDataArrayTexture||L.isData3DTexture,wn=V.isDataArrayTexture||V.isData3DTexture;if(L.isDepthTexture){const _n=ke.get(L),$t=ke.get(V),tn=ke.get(_n.__renderTarget),Cs=ke.get($t.__renderTarget);me.bindFramebuffer(B.READ_FRAMEBUFFER,tn.__webglFramebuffer),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,Cs.__webglFramebuffer);for(let yi=0;yi<He;yi++)Ft&&(B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,ke.get(L).__webglTexture,j,Ye+yi),B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,ke.get(V).__webglTexture,_e,Gt+yi)),B.blitFramebuffer(it,st,Ae,Oe,ft,wt,Ae,Oe,B.DEPTH_BUFFER_BIT,B.NEAREST);me.bindFramebuffer(B.READ_FRAMEBUFFER,null),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else if(j!==0||L.isRenderTargetTexture||ke.has(L)){const _n=ke.get(L),$t=ke.get(V);me.bindFramebuffer(B.READ_FRAMEBUFFER,Da),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,Ia);for(let tn=0;tn<He;tn++)Ft?B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,_n.__webglTexture,j,Ye+tn):B.framebufferTexture2D(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,_n.__webglTexture,j),wn?B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,$t.__webglTexture,_e,Gt+tn):B.framebufferTexture2D(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,$t.__webglTexture,_e),j!==0?B.blitFramebuffer(it,st,Ae,Oe,ft,wt,Ae,Oe,B.COLOR_BUFFER_BIT,B.NEAREST):wn?B.copyTexSubImage3D(en,_e,ft,wt,Gt+tn,it,st,Ae,Oe):B.copyTexSubImage2D(en,_e,ft,wt,it,st,Ae,Oe);me.bindFramebuffer(B.READ_FRAMEBUFFER,null),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else wn?L.isDataTexture||L.isData3DTexture?B.texSubImage3D(en,_e,ft,wt,Gt,Ae,Oe,He,bt,Ke,Ht.data):V.isCompressedArrayTexture?B.compressedTexSubImage3D(en,_e,ft,wt,Gt,Ae,Oe,He,bt,Ht.data):B.texSubImage3D(en,_e,ft,wt,Gt,Ae,Oe,He,bt,Ke,Ht):L.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,_e,ft,wt,Ae,Oe,bt,Ke,Ht.data):L.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,_e,ft,wt,Ht.width,Ht.height,bt,Ht.data):B.texSubImage2D(B.TEXTURE_2D,_e,ft,wt,Ae,Oe,bt,Ke,Ht);B.pixelStorei(B.UNPACK_ROW_LENGTH,Et),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,Ln),B.pixelStorei(B.UNPACK_SKIP_PIXELS,Bt),B.pixelStorei(B.UNPACK_SKIP_ROWS,hn),B.pixelStorei(B.UNPACK_SKIP_IMAGES,ts),_e===0&&V.generateMipmaps&&B.generateMipmap(en),me.unbindTexture()},this.copyTextureToTexture3D=function(L,V,J=null,ee=null,j=0){return L.isTexture!==!0&&(hs("WebGLRenderer: copyTextureToTexture3D function signature has changed."),J=arguments[0]||null,ee=arguments[1]||null,L=arguments[2],V=arguments[3],j=arguments[4]||0),hs('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(L,V,J,ee,j)},this.initRenderTarget=function(L){ke.get(L).__webglFramebuffer===void 0&&O.setupRenderTarget(L)},this.initTexture=function(L){L.isCubeTexture?O.setTextureCube(L,0):L.isData3DTexture?O.setTexture3D(L,0):L.isDataArrayTexture||L.isCompressedArrayTexture?O.setTexture2DArray(L,0):O.setTexture2D(L,0),me.unbindTexture()},this.resetState=function(){R=0,P=0,S=null,me.reset(),Lt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Di}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorspace=rt._getDrawingBufferColorSpace(e),t.unpackColorSpace=rt._getUnpackColorSpace()}}const Cu={type:"change"},Kc={type:"start"},of={type:"end"},Fo=new Ts,Pu=new Yi,Zx=Math.cos(70*St.DEG2RAD),nn=new I,In=2*Math.PI,Ut={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},ml=1e-6;class Kx extends Qd{constructor(e,t=null){super(e,t),this.state=Ut.NONE,this.enabled=!0,this.target=new I,this.cursor=new I,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Ii.ROTATE,MIDDLE:Ii.DOLLY,RIGHT:Ii.PAN},this.touches={ONE:Ki.ROTATE,TWO:Ki.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new I,this._lastQuaternion=new Pt,this._lastTargetPosition=new I,this._quat=new Pt().setFromUnitVectors(e.up,new I(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new Qh,this._sphericalDelta=new Qh,this._scale=1,this._panOffset=new I,this._rotateStart=new ye,this._rotateEnd=new ye,this._rotateDelta=new ye,this._panStart=new ye,this._panEnd=new ye,this._panDelta=new ye,this._dollyStart=new ye,this._dollyEnd=new ye,this._dollyDelta=new ye,this._dollyDirection=new I,this._mouse=new ye,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=Jx.bind(this),this._onPointerDown=$x.bind(this),this._onPointerUp=Qx.bind(this),this._onContextMenu=oy.bind(this),this._onMouseWheel=ny.bind(this),this._onKeyDown=iy.bind(this),this._onTouchStart=sy.bind(this),this._onTouchMove=ry.bind(this),this._onMouseDown=ey.bind(this),this._onMouseMove=ty.bind(this),this._interceptControlDown=ay.bind(this),this._interceptControlUp=ly.bind(this),this.domElement!==null&&this.connect(),this.update()}connect(){this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Cu),this.update(),this.state=Ut.NONE}update(e=null){const t=this.object.position;nn.copy(t).sub(this.target),nn.applyQuaternion(this._quat),this._spherical.setFromVector3(nn),this.autoRotate&&this.state===Ut.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,i=this.maxAzimuthAngle;isFinite(n)&&isFinite(i)&&(n<-Math.PI?n+=In:n>Math.PI&&(n-=In),i<-Math.PI?i+=In:i>Math.PI&&(i-=In),n<=i?this._spherical.theta=Math.max(n,Math.min(i,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+i)/2?Math.max(n,this._spherical.theta):Math.min(i,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let s=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),s=o!=this._spherical.radius}if(nn.setFromSpherical(this._spherical),nn.applyQuaternion(this._quatInverse),t.copy(this.target).add(nn),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const a=nn.length();o=this._clampDistance(a*this._scale);const l=a-o;this.object.position.addScaledVector(this._dollyDirection,l),this.object.updateMatrixWorld(),s=!!l}else if(this.object.isOrthographicCamera){const a=new I(this._mouse.x,this._mouse.y,0);a.unproject(this.object);const l=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),s=l!==this.object.zoom;const c=new I(this._mouse.x,this._mouse.y,0);c.unproject(this.object),this.object.position.sub(c).add(a),this.object.updateMatrixWorld(),o=nn.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(Fo.origin.copy(this.object.position),Fo.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(Fo.direction))<Zx?this.object.lookAt(this.target):(Pu.setFromNormalAndCoplanarPoint(this.object.up,this.target),Fo.intersectPlane(Pu,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),s=!0)}return this._scale=1,this._performCursorZoom=!1,s||this._lastPosition.distanceToSquared(this.object.position)>ml||8*(1-this._lastQuaternion.dot(this.object.quaternion))>ml||this._lastTargetPosition.distanceToSquared(this.target)>ml?(this.dispatchEvent(Cu),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?In/60*this.autoRotateSpeed*e:In/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){nn.setFromMatrixColumn(t,0),nn.multiplyScalar(-e),this._panOffset.add(nn)}_panUp(e,t){this.screenSpacePanning===!0?nn.setFromMatrixColumn(t,1):(nn.setFromMatrixColumn(t,0),nn.crossVectors(this.object.up,nn)),nn.multiplyScalar(e),this._panOffset.add(nn)}_pan(e,t){const n=this.domElement;if(this.object.isPerspectiveCamera){const i=this.object.position;nn.copy(i).sub(this.target);let s=nn.length();s*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*s/n.clientHeight,this.object.matrix),this._panUp(2*t*s/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const n=this.domElement.getBoundingClientRect(),i=e-n.left,s=t-n.top,o=n.width,a=n.height;this._mouse.x=i/o*2-1,this._mouse.y=-(s/a)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(In*this._rotateDelta.x/t.clientHeight),this._rotateUp(In*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),i=.5*(e.pageY+t.y);this._rotateStart.set(n,i)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),i=.5*(e.pageY+t.y);this._panStart.set(n,i)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,i=e.pageY-t.y,s=Math.sqrt(n*n+i*i);this._dollyStart.set(0,s)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const n=this._getSecondPointerPosition(e),i=.5*(e.pageX+n.x),s=.5*(e.pageY+n.y);this._rotateEnd.set(i,s)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(In*this._rotateDelta.x/t.clientHeight),this._rotateUp(In*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),i=.5*(e.pageY+t.y);this._panEnd.set(n,i)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,i=e.pageY-t.y,s=Math.sqrt(n*n+i*i);this._dollyEnd.set(0,s),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(e.pageX+t.x)*.5,a=(e.pageY+t.y)*.5;this._updateZoomParameters(o,a)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new ye,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,n={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}}function $x(r){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(r.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(r)&&(this._addPointer(r),r.pointerType==="touch"?this._onTouchStart(r):this._onMouseDown(r)))}function Jx(r){this.enabled!==!1&&(r.pointerType==="touch"?this._onTouchMove(r):this._onMouseMove(r))}function Qx(r){switch(this._removePointer(r),this._pointers.length){case 0:this.domElement.releasePointerCapture(r.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(of),this.state=Ut.NONE;break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function ey(r){let e;switch(r.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Ii.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(r),this.state=Ut.DOLLY;break;case Ii.ROTATE:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=Ut.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=Ut.ROTATE}break;case Ii.PAN:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=Ut.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=Ut.PAN}break;default:this.state=Ut.NONE}this.state!==Ut.NONE&&this.dispatchEvent(Kc)}function ty(r){switch(this.state){case Ut.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(r);break;case Ut.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(r);break;case Ut.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(r);break}}function ny(r){this.enabled===!1||this.enableZoom===!1||this.state!==Ut.NONE||(r.preventDefault(),this.dispatchEvent(Kc),this._handleMouseWheel(this._customWheelEvent(r)),this.dispatchEvent(of))}function iy(r){this.enabled!==!1&&this._handleKeyDown(r)}function sy(r){switch(this._trackPointer(r),this._pointers.length){case 1:switch(this.touches.ONE){case Ki.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(r),this.state=Ut.TOUCH_ROTATE;break;case Ki.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(r),this.state=Ut.TOUCH_PAN;break;default:this.state=Ut.NONE}break;case 2:switch(this.touches.TWO){case Ki.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(r),this.state=Ut.TOUCH_DOLLY_PAN;break;case Ki.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(r),this.state=Ut.TOUCH_DOLLY_ROTATE;break;default:this.state=Ut.NONE}break;default:this.state=Ut.NONE}this.state!==Ut.NONE&&this.dispatchEvent(Kc)}function ry(r){switch(this._trackPointer(r),this.state){case Ut.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(r),this.update();break;case Ut.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(r),this.update();break;case Ut.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(r),this.update();break;case Ut.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(r),this.update();break;default:this.state=Ut.NONE}}function oy(r){this.enabled!==!1&&r.preventDefault()}function ay(r){r.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function ly(r){r.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const ls=new qc,yn=new I,Wi=new I,Vt=new Pt,Lu={X:new I(1,0,0),Y:new I(0,1,0),Z:new I(0,0,1)},gl={type:"change"},Du={type:"mouseDown",mode:null},Iu={type:"mouseUp",mode:null},Nu={type:"objectChange"};class cy extends Qd{constructor(e,t=null){super(void 0,t);const n=new my(this);this._root=n;const i=new gy;this._gizmo=i,n.add(i);const s=new _y;this._plane=s,n.add(s);const o=this;function a(x,b){let D=b;Object.defineProperty(o,x,{get:function(){return D!==void 0?D:b},set:function(R){D!==R&&(D=R,s[x]=R,i[x]=R,o.dispatchEvent({type:x+"-changed",value:R}),o.dispatchEvent(gl))}}),o[x]=b,s[x]=b,i[x]=b}a("camera",e),a("object",void 0),a("enabled",!0),a("axis",null),a("mode","translate"),a("translationSnap",null),a("rotationSnap",null),a("scaleSnap",null),a("space","world"),a("size",1),a("dragging",!1),a("showX",!0),a("showY",!0),a("showZ",!0),a("minX",-1/0),a("maxX",1/0),a("minY",-1/0),a("maxY",1/0),a("minZ",-1/0),a("maxZ",1/0);const l=new I,c=new I,h=new Pt,u=new Pt,d=new I,f=new Pt,m=new I,v=new I,g=new I,p=0,M=new I;a("worldPosition",l),a("worldPositionStart",c),a("worldQuaternion",h),a("worldQuaternionStart",u),a("cameraPosition",d),a("cameraQuaternion",f),a("pointStart",m),a("pointEnd",v),a("rotationAxis",g),a("rotationAngle",p),a("eye",M),this._offset=new I,this._startNorm=new I,this._endNorm=new I,this._cameraScale=new I,this._parentPosition=new I,this._parentQuaternion=new Pt,this._parentQuaternionInv=new Pt,this._parentScale=new I,this._worldScaleStart=new I,this._worldQuaternionInv=new Pt,this._worldScale=new I,this._positionStart=new I,this._quaternionStart=new Pt,this._scaleStart=new I,this._getPointer=hy.bind(this),this._onPointerDown=dy.bind(this),this._onPointerHover=uy.bind(this),this._onPointerMove=fy.bind(this),this._onPointerUp=py.bind(this),t!==null&&this.connect()}connect(){this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointermove",this._onPointerHover),this.domElement.addEventListener("pointerup",this._onPointerUp),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerHover),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.style.touchAction="auto"}getHelper(){return this._root}pointerHover(e){if(this.object===void 0||this.dragging===!0)return;e!==null&&ls.setFromCamera(e,this.camera);const t=_l(this._gizmo.picker[this.mode],ls);t?this.axis=t.object.name:this.axis=null}pointerDown(e){if(!(this.object===void 0||this.dragging===!0||e!=null&&e.button!==0)&&this.axis!==null){e!==null&&ls.setFromCamera(e,this.camera);const t=_l(this._plane,ls,!0);t&&(this.object.updateMatrixWorld(),this.object.parent.updateMatrixWorld(),this._positionStart.copy(this.object.position),this._quaternionStart.copy(this.object.quaternion),this._scaleStart.copy(this.object.scale),this.object.matrixWorld.decompose(this.worldPositionStart,this.worldQuaternionStart,this._worldScaleStart),this.pointStart.copy(t.point).sub(this.worldPositionStart)),this.dragging=!0,Du.mode=this.mode,this.dispatchEvent(Du)}}pointerMove(e){const t=this.axis,n=this.mode,i=this.object;let s=this.space;if(n==="scale"?s="local":(t==="E"||t==="XYZE"||t==="XYZ")&&(s="world"),i===void 0||t===null||this.dragging===!1||e!==null&&e.button!==-1)return;e!==null&&ls.setFromCamera(e,this.camera);const o=_l(this._plane,ls,!0);if(o){if(this.pointEnd.copy(o.point).sub(this.worldPositionStart),n==="translate")this._offset.copy(this.pointEnd).sub(this.pointStart),s==="local"&&t!=="XYZ"&&this._offset.applyQuaternion(this._worldQuaternionInv),t.indexOf("X")===-1&&(this._offset.x=0),t.indexOf("Y")===-1&&(this._offset.y=0),t.indexOf("Z")===-1&&(this._offset.z=0),s==="local"&&t!=="XYZ"?this._offset.applyQuaternion(this._quaternionStart).divide(this._parentScale):this._offset.applyQuaternion(this._parentQuaternionInv).divide(this._parentScale),i.position.copy(this._offset).add(this._positionStart),this.translationSnap&&(s==="local"&&(i.position.applyQuaternion(Vt.copy(this._quaternionStart).invert()),t.search("X")!==-1&&(i.position.x=Math.round(i.position.x/this.translationSnap)*this.translationSnap),t.search("Y")!==-1&&(i.position.y=Math.round(i.position.y/this.translationSnap)*this.translationSnap),t.search("Z")!==-1&&(i.position.z=Math.round(i.position.z/this.translationSnap)*this.translationSnap),i.position.applyQuaternion(this._quaternionStart)),s==="world"&&(i.parent&&i.position.add(yn.setFromMatrixPosition(i.parent.matrixWorld)),t.search("X")!==-1&&(i.position.x=Math.round(i.position.x/this.translationSnap)*this.translationSnap),t.search("Y")!==-1&&(i.position.y=Math.round(i.position.y/this.translationSnap)*this.translationSnap),t.search("Z")!==-1&&(i.position.z=Math.round(i.position.z/this.translationSnap)*this.translationSnap),i.parent&&i.position.sub(yn.setFromMatrixPosition(i.parent.matrixWorld)))),i.position.x=Math.max(this.minX,Math.min(this.maxX,i.position.x)),i.position.y=Math.max(this.minY,Math.min(this.maxY,i.position.y)),i.position.z=Math.max(this.minZ,Math.min(this.maxZ,i.position.z));else if(n==="scale"){if(t.search("XYZ")!==-1){let a=this.pointEnd.length()/this.pointStart.length();this.pointEnd.dot(this.pointStart)<0&&(a*=-1),Wi.set(a,a,a)}else yn.copy(this.pointStart),Wi.copy(this.pointEnd),yn.applyQuaternion(this._worldQuaternionInv),Wi.applyQuaternion(this._worldQuaternionInv),Wi.divide(yn),t.search("X")===-1&&(Wi.x=1),t.search("Y")===-1&&(Wi.y=1),t.search("Z")===-1&&(Wi.z=1);i.scale.copy(this._scaleStart).multiply(Wi),this.scaleSnap&&(t.search("X")!==-1&&(i.scale.x=Math.round(i.scale.x/this.scaleSnap)*this.scaleSnap||this.scaleSnap),t.search("Y")!==-1&&(i.scale.y=Math.round(i.scale.y/this.scaleSnap)*this.scaleSnap||this.scaleSnap),t.search("Z")!==-1&&(i.scale.z=Math.round(i.scale.z/this.scaleSnap)*this.scaleSnap||this.scaleSnap))}else if(n==="rotate"){this._offset.copy(this.pointEnd).sub(this.pointStart);const a=20/this.worldPosition.distanceTo(yn.setFromMatrixPosition(this.camera.matrixWorld));let l=!1;t==="XYZE"?(this.rotationAxis.copy(this._offset).cross(this.eye).normalize(),this.rotationAngle=this._offset.dot(yn.copy(this.rotationAxis).cross(this.eye))*a):(t==="X"||t==="Y"||t==="Z")&&(this.rotationAxis.copy(Lu[t]),yn.copy(Lu[t]),s==="local"&&yn.applyQuaternion(this.worldQuaternion),yn.cross(this.eye),yn.length()===0?l=!0:this.rotationAngle=this._offset.dot(yn.normalize())*a),(t==="E"||l)&&(this.rotationAxis.copy(this.eye),this.rotationAngle=this.pointEnd.angleTo(this.pointStart),this._startNorm.copy(this.pointStart).normalize(),this._endNorm.copy(this.pointEnd).normalize(),this.rotationAngle*=this._endNorm.cross(this._startNorm).dot(this.eye)<0?1:-1),this.rotationSnap&&(this.rotationAngle=Math.round(this.rotationAngle/this.rotationSnap)*this.rotationSnap),s==="local"&&t!=="E"&&t!=="XYZE"?(i.quaternion.copy(this._quaternionStart),i.quaternion.multiply(Vt.setFromAxisAngle(this.rotationAxis,this.rotationAngle)).normalize()):(this.rotationAxis.applyQuaternion(this._parentQuaternionInv),i.quaternion.copy(Vt.setFromAxisAngle(this.rotationAxis,this.rotationAngle)),i.quaternion.multiply(this._quaternionStart).normalize())}this.dispatchEvent(gl),this.dispatchEvent(Nu)}}pointerUp(e){e!==null&&e.button!==0||(this.dragging&&this.axis!==null&&(Iu.mode=this.mode,this.dispatchEvent(Iu)),this.dragging=!1,this.axis=null)}dispose(){this.disconnect(),this._root.dispose()}attach(e){return this.object=e,this._root.visible=!0,this}detach(){return this.object=void 0,this.axis=null,this._root.visible=!1,this}reset(){this.enabled&&this.dragging&&(this.object.position.copy(this._positionStart),this.object.quaternion.copy(this._quaternionStart),this.object.scale.copy(this._scaleStart),this.dispatchEvent(gl),this.dispatchEvent(Nu),this.pointStart.copy(this.pointEnd))}getRaycaster(){return ls}getMode(){return this.mode}setMode(e){this.mode=e}setTranslationSnap(e){this.translationSnap=e}setRotationSnap(e){this.rotationSnap=e}setScaleSnap(e){this.scaleSnap=e}setSize(e){this.size=e}setSpace(e){this.space=e}}function hy(r){if(this.domElement.ownerDocument.pointerLockElement)return{x:0,y:0,button:r.button};{const e=this.domElement.getBoundingClientRect();return{x:(r.clientX-e.left)/e.width*2-1,y:-(r.clientY-e.top)/e.height*2+1,button:r.button}}}function uy(r){if(this.enabled)switch(r.pointerType){case"mouse":case"pen":this.pointerHover(this._getPointer(r));break}}function dy(r){this.enabled&&(document.pointerLockElement||this.domElement.setPointerCapture(r.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.pointerHover(this._getPointer(r)),this.pointerDown(this._getPointer(r)))}function fy(r){this.enabled&&this.pointerMove(this._getPointer(r))}function py(r){this.enabled&&(this.domElement.releasePointerCapture(r.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.pointerUp(this._getPointer(r)))}function _l(r,e,t){const n=e.intersectObject(r,!0);for(let i=0;i<n.length;i++)if(n[i].object.visible||t)return n[i];return!1}const Oo=new Kt,Ot=new I(0,1,0),Uu=new I(0,0,0),Fu=new Te,Bo=new Pt,ia=new Pt,ai=new I,Ou=new Te,Lr=new I(1,0,0),ds=new I(0,1,0),Dr=new I(0,0,1),ko=new I,Rr=new I,Cr=new I;class my extends Ct{constructor(e){super(),this.isTransformControlsRoot=!0,this.controls=e,this.visible=!1}updateMatrixWorld(e){const t=this.controls;t.object!==void 0&&(t.object.updateMatrixWorld(),t.object.parent===null?console.error("TransformControls: The attached 3D object must be a part of the scene graph."):t.object.parent.matrixWorld.decompose(t._parentPosition,t._parentQuaternion,t._parentScale),t.object.matrixWorld.decompose(t.worldPosition,t.worldQuaternion,t._worldScale),t._parentQuaternionInv.copy(t._parentQuaternion).invert(),t._worldQuaternionInv.copy(t.worldQuaternion).invert()),t.camera.updateMatrixWorld(),t.camera.matrixWorld.decompose(t.cameraPosition,t.cameraQuaternion,t._cameraScale),t.camera.isOrthographicCamera?t.camera.getWorldDirection(t.eye).negate():t.eye.copy(t.cameraPosition).sub(t.worldPosition).normalize(),super.updateMatrixWorld(e)}dispose(){this.traverse(function(e){e.geometry&&e.geometry.dispose(),e.material&&e.material.dispose()})}}class gy extends Ct{constructor(){super(),this.isTransformControlsGizmo=!0,this.type="TransformControlsGizmo";const e=new qn({depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1,transparent:!0}),t=new jn({depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1,transparent:!0}),n=e.clone();n.opacity=.15;const i=t.clone();i.opacity=.5;const s=e.clone();s.color.setHex(16711680);const o=e.clone();o.color.setHex(65280);const a=e.clone();a.color.setHex(255);const l=e.clone();l.color.setHex(16711680),l.opacity=.5;const c=e.clone();c.color.setHex(65280),c.opacity=.5;const h=e.clone();h.color.setHex(255),h.opacity=.5;const u=e.clone();u.opacity=.25;const d=e.clone();d.color.setHex(16776960),d.opacity=.25,e.clone().color.setHex(16776960);const m=e.clone();m.color.setHex(7895160);const v=new cn(0,.04,.1,12);v.translate(0,.05,0);const g=new Yt(.08,.08,.08);g.translate(0,.04,0);const p=new yt;p.setAttribute("position",new Le([0,0,0,1,0,0],3));const M=new cn(.0075,.0075,.5,3);M.translate(0,.25,0);function x($,z){const Y=new ps($,.0075,3,64,z*Math.PI*2);return Y.rotateY(Math.PI/2),Y.rotateX(Math.PI/2),Y}function b(){const $=new yt;return $.setAttribute("position",new Le([0,0,0,1,1,1],3)),$}const D={X:[[new ve(v,s),[.5,0,0],[0,0,-Math.PI/2]],[new ve(v,s),[-.5,0,0],[0,0,Math.PI/2]],[new ve(M,s),[0,0,0],[0,0,-Math.PI/2]]],Y:[[new ve(v,o),[0,.5,0]],[new ve(v,o),[0,-.5,0],[Math.PI,0,0]],[new ve(M,o)]],Z:[[new ve(v,a),[0,0,.5],[Math.PI/2,0,0]],[new ve(v,a),[0,0,-.5],[-Math.PI/2,0,0]],[new ve(M,a),null,[Math.PI/2,0,0]]],XYZ:[[new ve(new $s(.1,0),u.clone()),[0,0,0]]],XY:[[new ve(new Yt(.15,.15,.01),h.clone()),[.15,.15,0]]],YZ:[[new ve(new Yt(.15,.15,.01),l.clone()),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Yt(.15,.15,.01),c.clone()),[.15,0,.15],[-Math.PI/2,0,0]]]},R={X:[[new ve(new cn(.2,0,.6,4),n),[.3,0,0],[0,0,-Math.PI/2]],[new ve(new cn(.2,0,.6,4),n),[-.3,0,0],[0,0,Math.PI/2]]],Y:[[new ve(new cn(.2,0,.6,4),n),[0,.3,0]],[new ve(new cn(.2,0,.6,4),n),[0,-.3,0],[0,0,Math.PI]]],Z:[[new ve(new cn(.2,0,.6,4),n),[0,0,.3],[Math.PI/2,0,0]],[new ve(new cn(.2,0,.6,4),n),[0,0,-.3],[-Math.PI/2,0,0]]],XYZ:[[new ve(new $s(.2,0),n)]],XY:[[new ve(new Yt(.2,.2,.01),n),[.15,.15,0]]],YZ:[[new ve(new Yt(.2,.2,.01),n),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Yt(.2,.2,.01),n),[.15,0,.15],[-Math.PI/2,0,0]]]},P={START:[[new ve(new $s(.01,2),i),null,null,null,"helper"]],END:[[new ve(new $s(.01,2),i),null,null,null,"helper"]],DELTA:[[new Vn(b(),i),null,null,null,"helper"]],X:[[new Vn(p,i.clone()),[-1e3,0,0],null,[1e6,1,1],"helper"]],Y:[[new Vn(p,i.clone()),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],"helper"]],Z:[[new Vn(p,i.clone()),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],"helper"]]},S={XYZE:[[new ve(x(.5,1),m),null,[0,Math.PI/2,0]]],X:[[new ve(x(.5,.5),s)]],Y:[[new ve(x(.5,.5),o),null,[0,0,-Math.PI/2]]],Z:[[new ve(x(.5,.5),a),null,[0,Math.PI/2,0]]],E:[[new ve(x(.75,1),d),null,[0,Math.PI/2,0]]]},_={AXIS:[[new Vn(p,i.clone()),[-1e3,0,0],null,[1e6,1,1],"helper"]]},y={XYZE:[[new ve(new jr(.25,10,8),n)]],X:[[new ve(new ps(.5,.1,4,24),n),[0,0,0],[0,-Math.PI/2,-Math.PI/2]]],Y:[[new ve(new ps(.5,.1,4,24),n),[0,0,0],[Math.PI/2,0,0]]],Z:[[new ve(new ps(.5,.1,4,24),n),[0,0,0],[0,0,-Math.PI/2]]],E:[[new ve(new ps(.75,.1,2,24),n)]]},T={X:[[new ve(g,s),[.5,0,0],[0,0,-Math.PI/2]],[new ve(M,s),[0,0,0],[0,0,-Math.PI/2]],[new ve(g,s),[-.5,0,0],[0,0,Math.PI/2]]],Y:[[new ve(g,o),[0,.5,0]],[new ve(M,o)],[new ve(g,o),[0,-.5,0],[0,0,Math.PI]]],Z:[[new ve(g,a),[0,0,.5],[Math.PI/2,0,0]],[new ve(M,a),[0,0,0],[Math.PI/2,0,0]],[new ve(g,a),[0,0,-.5],[-Math.PI/2,0,0]]],XY:[[new ve(new Yt(.15,.15,.01),h),[.15,.15,0]]],YZ:[[new ve(new Yt(.15,.15,.01),l),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Yt(.15,.15,.01),c),[.15,0,.15],[-Math.PI/2,0,0]]],XYZ:[[new ve(new Yt(.1,.1,.1),u.clone())]]},F={X:[[new ve(new cn(.2,0,.6,4),n),[.3,0,0],[0,0,-Math.PI/2]],[new ve(new cn(.2,0,.6,4),n),[-.3,0,0],[0,0,Math.PI/2]]],Y:[[new ve(new cn(.2,0,.6,4),n),[0,.3,0]],[new ve(new cn(.2,0,.6,4),n),[0,-.3,0],[0,0,Math.PI]]],Z:[[new ve(new cn(.2,0,.6,4),n),[0,0,.3],[Math.PI/2,0,0]],[new ve(new cn(.2,0,.6,4),n),[0,0,-.3],[-Math.PI/2,0,0]]],XY:[[new ve(new Yt(.2,.2,.01),n),[.15,.15,0]]],YZ:[[new ve(new Yt(.2,.2,.01),n),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Yt(.2,.2,.01),n),[.15,0,.15],[-Math.PI/2,0,0]]],XYZ:[[new ve(new Yt(.2,.2,.2),n),[0,0,0]]]},k={X:[[new Vn(p,i.clone()),[-1e3,0,0],null,[1e6,1,1],"helper"]],Y:[[new Vn(p,i.clone()),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],"helper"]],Z:[[new Vn(p,i.clone()),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],"helper"]]};function G($){const z=new Ct;for(const Y in $)for(let H=$[Y].length;H--;){const q=$[Y][H][0].clone(),ue=$[Y][H][1],re=$[Y][H][2],de=$[Y][H][3],ie=$[Y][H][4];q.name=Y,q.tag=ie,ue&&q.position.set(ue[0],ue[1],ue[2]),re&&q.rotation.set(re[0],re[1],re[2]),de&&q.scale.set(de[0],de[1],de[2]),q.updateMatrix();const W=q.geometry.clone();W.applyMatrix4(q.matrix),q.geometry=W,q.renderOrder=1/0,q.position.set(0,0,0),q.rotation.set(0,0,0),q.scale.set(1,1,1),z.add(q)}return z}this.gizmo={},this.picker={},this.helper={},this.add(this.gizmo.translate=G(D)),this.add(this.gizmo.rotate=G(S)),this.add(this.gizmo.scale=G(T)),this.add(this.picker.translate=G(R)),this.add(this.picker.rotate=G(y)),this.add(this.picker.scale=G(F)),this.add(this.helper.translate=G(P)),this.add(this.helper.rotate=G(_)),this.add(this.helper.scale=G(k)),this.picker.translate.visible=!1,this.picker.rotate.visible=!1,this.picker.scale.visible=!1}updateMatrixWorld(e){const n=(this.mode==="scale"?"local":this.space)==="local"?this.worldQuaternion:ia;this.gizmo.translate.visible=this.mode==="translate",this.gizmo.rotate.visible=this.mode==="rotate",this.gizmo.scale.visible=this.mode==="scale",this.helper.translate.visible=this.mode==="translate",this.helper.rotate.visible=this.mode==="rotate",this.helper.scale.visible=this.mode==="scale";let i=[];i=i.concat(this.picker[this.mode].children),i=i.concat(this.gizmo[this.mode].children),i=i.concat(this.helper[this.mode].children);for(let s=0;s<i.length;s++){const o=i[s];o.visible=!0,o.rotation.set(0,0,0),o.position.copy(this.worldPosition);let a;if(this.camera.isOrthographicCamera?a=(this.camera.top-this.camera.bottom)/this.camera.zoom:a=this.worldPosition.distanceTo(this.cameraPosition)*Math.min(1.9*Math.tan(Math.PI*this.camera.fov/360)/this.camera.zoom,7),o.scale.set(1,1,1).multiplyScalar(a*this.size/4),o.tag==="helper"){o.visible=!1,o.name==="AXIS"?(o.visible=!!this.axis,this.axis==="X"&&(Vt.setFromEuler(Oo.set(0,0,0)),o.quaternion.copy(n).multiply(Vt),Math.abs(Ot.copy(Lr).applyQuaternion(n).dot(this.eye))>.9&&(o.visible=!1)),this.axis==="Y"&&(Vt.setFromEuler(Oo.set(0,0,Math.PI/2)),o.quaternion.copy(n).multiply(Vt),Math.abs(Ot.copy(ds).applyQuaternion(n).dot(this.eye))>.9&&(o.visible=!1)),this.axis==="Z"&&(Vt.setFromEuler(Oo.set(0,Math.PI/2,0)),o.quaternion.copy(n).multiply(Vt),Math.abs(Ot.copy(Dr).applyQuaternion(n).dot(this.eye))>.9&&(o.visible=!1)),this.axis==="XYZE"&&(Vt.setFromEuler(Oo.set(0,Math.PI/2,0)),Ot.copy(this.rotationAxis),o.quaternion.setFromRotationMatrix(Fu.lookAt(Uu,Ot,ds)),o.quaternion.multiply(Vt),o.visible=this.dragging),this.axis==="E"&&(o.visible=!1)):o.name==="START"?(o.position.copy(this.worldPositionStart),o.visible=this.dragging):o.name==="END"?(o.position.copy(this.worldPosition),o.visible=this.dragging):o.name==="DELTA"?(o.position.copy(this.worldPositionStart),o.quaternion.copy(this.worldQuaternionStart),yn.set(1e-10,1e-10,1e-10).add(this.worldPositionStart).sub(this.worldPosition).multiplyScalar(-1),yn.applyQuaternion(this.worldQuaternionStart.clone().invert()),o.scale.copy(yn),o.visible=this.dragging):(o.quaternion.copy(n),this.dragging?o.position.copy(this.worldPositionStart):o.position.copy(this.worldPosition),this.axis&&(o.visible=this.axis.search(o.name)!==-1));continue}o.quaternion.copy(n),this.mode==="translate"||this.mode==="scale"?(o.name==="X"&&Math.abs(Ot.copy(Lr).applyQuaternion(n).dot(this.eye))>.99&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="Y"&&Math.abs(Ot.copy(ds).applyQuaternion(n).dot(this.eye))>.99&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="Z"&&Math.abs(Ot.copy(Dr).applyQuaternion(n).dot(this.eye))>.99&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="XY"&&Math.abs(Ot.copy(Dr).applyQuaternion(n).dot(this.eye))<.2&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="YZ"&&Math.abs(Ot.copy(Lr).applyQuaternion(n).dot(this.eye))<.2&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="XZ"&&Math.abs(Ot.copy(ds).applyQuaternion(n).dot(this.eye))<.2&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1)):this.mode==="rotate"&&(Bo.copy(n),Ot.copy(this.eye).applyQuaternion(Vt.copy(n).invert()),o.name.search("E")!==-1&&o.quaternion.setFromRotationMatrix(Fu.lookAt(this.eye,Uu,ds)),o.name==="X"&&(Vt.setFromAxisAngle(Lr,Math.atan2(-Ot.y,Ot.z)),Vt.multiplyQuaternions(Bo,Vt),o.quaternion.copy(Vt)),o.name==="Y"&&(Vt.setFromAxisAngle(ds,Math.atan2(Ot.x,Ot.z)),Vt.multiplyQuaternions(Bo,Vt),o.quaternion.copy(Vt)),o.name==="Z"&&(Vt.setFromAxisAngle(Dr,Math.atan2(Ot.y,Ot.x)),Vt.multiplyQuaternions(Bo,Vt),o.quaternion.copy(Vt))),o.visible=o.visible&&(o.name.indexOf("X")===-1||this.showX),o.visible=o.visible&&(o.name.indexOf("Y")===-1||this.showY),o.visible=o.visible&&(o.name.indexOf("Z")===-1||this.showZ),o.visible=o.visible&&(o.name.indexOf("E")===-1||this.showX&&this.showY&&this.showZ),o.material._color=o.material._color||o.material.color.clone(),o.material._opacity=o.material._opacity||o.material.opacity,o.material.color.copy(o.material._color),o.material.opacity=o.material._opacity,this.enabled&&this.axis&&(o.name===this.axis||this.axis.split("").some(function(l){return o.name===l}))&&(o.material.color.setHex(16776960),o.material.opacity=1)}super.updateMatrixWorld(e)}}class _y extends ve{constructor(){super(new mr(1e5,1e5,2,2),new qn({visible:!1,wireframe:!0,side:Wn,transparent:!0,opacity:.1,toneMapped:!1})),this.isTransformControlsPlane=!0,this.type="TransformControlsPlane"}updateMatrixWorld(e){let t=this.space;switch(this.position.copy(this.worldPosition),this.mode==="scale"&&(t="local"),ko.copy(Lr).applyQuaternion(t==="local"?this.worldQuaternion:ia),Rr.copy(ds).applyQuaternion(t==="local"?this.worldQuaternion:ia),Cr.copy(Dr).applyQuaternion(t==="local"?this.worldQuaternion:ia),Ot.copy(Rr),this.mode){case"translate":case"scale":switch(this.axis){case"X":Ot.copy(this.eye).cross(ko),ai.copy(ko).cross(Ot);break;case"Y":Ot.copy(this.eye).cross(Rr),ai.copy(Rr).cross(Ot);break;case"Z":Ot.copy(this.eye).cross(Cr),ai.copy(Cr).cross(Ot);break;case"XY":ai.copy(Cr);break;case"YZ":ai.copy(ko);break;case"XZ":Ot.copy(Cr),ai.copy(Rr);break;case"XYZ":case"E":ai.set(0,0,0);break}break;case"rotate":default:ai.set(0,0,0)}ai.length()===0?this.quaternion.copy(this.cameraQuaternion):(Ou.lookAt(yn.set(0,0,0),ai,Ot),this.quaternion.setFromRotationMatrix(Ou)),super.updateMatrixWorld(e)}}function af(r,e,t){const n=t.length-r-1;if(e>=t[n])return n-1;if(e<=t[r])return r;let i=r,s=n,o=Math.floor((i+s)/2);for(;e<t[o]||e>=t[o+1];)e<t[o]?s=o:i=o,o=Math.floor((i+s)/2);return o}function vy(r,e,t,n){const i=[],s=[],o=[];i[0]=1;for(let a=1;a<=t;++a){s[a]=e-n[r+1-a],o[a]=n[r+a]-e;let l=0;for(let c=0;c<a;++c){const h=o[c+1],u=s[a-c],d=i[c]/(h+u);i[c]=l+h*d,l=u*d}i[a]=l}return i}function xy(r,e,t,n){const i=af(r,n,e),s=vy(i,n,r,e),o=new ct(0,0,0,0);for(let a=0;a<=r;++a){const l=t[i-r+a],c=s[a],h=l.w*c;o.x+=l.x*h,o.y+=l.y*h,o.z+=l.z*h,o.w+=l.w*c}return o}function yy(r,e,t,n,i){const s=[];for(let u=0;u<=t;++u)s[u]=0;const o=[];for(let u=0;u<=n;++u)o[u]=s.slice(0);const a=[];for(let u=0;u<=t;++u)a[u]=s.slice(0);a[0][0]=1;const l=s.slice(0),c=s.slice(0);for(let u=1;u<=t;++u){l[u]=e-i[r+1-u],c[u]=i[r+u]-e;let d=0;for(let f=0;f<u;++f){const m=c[f+1],v=l[u-f];a[u][f]=m+v;const g=a[f][u-1]/a[u][f];a[f][u]=d+m*g,d=v*g}a[u][u]=d}for(let u=0;u<=t;++u)o[0][u]=a[u][t];for(let u=0;u<=t;++u){let d=0,f=1;const m=[];for(let v=0;v<=t;++v)m[v]=s.slice(0);m[0][0]=1;for(let v=1;v<=n;++v){let g=0;const p=u-v,M=t-v;u>=v&&(m[f][0]=m[d][0]/a[M+1][p],g=m[f][0]*a[p][M]);const x=p>=-1?1:-p,b=u-1<=M?v-1:t-u;for(let R=x;R<=b;++R)m[f][R]=(m[d][R]-m[d][R-1])/a[M+1][p+R],g+=m[f][R]*a[p+R][M];u<=M&&(m[f][v]=-m[d][v-1]/a[M+1][u],g+=m[f][v]*a[u][M]),o[v][u]=g;const D=d;d=f,f=D}}let h=t;for(let u=1;u<=n;++u){for(let d=0;d<=t;++d)o[u][d]*=h;h*=t-u}return o}function by(r,e,t,n,i){const s=i<r?i:r,o=[],a=af(r,n,e),l=yy(a,n,r,s,e),c=[];for(let h=0;h<t.length;++h){const u=t[h].clone(),d=u.w;u.x*=d,u.y*=d,u.z*=d,c[h]=u}for(let h=0;h<=s;++h){const u=c[a-r].clone().multiplyScalar(l[h][0]);for(let d=1;d<=r;++d)u.add(c[a-r+d].clone().multiplyScalar(l[h][d]));o[h]=u}for(let h=s+1;h<=i+1;++h)o[h]=new ct(0,0,0);return o}function My(r,e){let t=1;for(let i=2;i<=r;++i)t*=i;let n=1;for(let i=2;i<=e;++i)n*=i;for(let i=2;i<=r-e;++i)n*=i;return t/n}function Sy(r){const e=r.length,t=[],n=[];for(let s=0;s<e;++s){const o=r[s];t[s]=new I(o.x,o.y,o.z),n[s]=o.w}const i=[];for(let s=0;s<e;++s){const o=t[s].clone();for(let a=1;a<=s;++a)o.sub(i[s-a].clone().multiplyScalar(My(s,a)*n[a]));i[s]=o.divideScalar(n[0])}return i}function wy(r,e,t,n,i){const s=by(r,e,t,n,i);return Sy(s)}class Ey extends _m{constructor(e,t,n,i,s){super();const o=t?t.length-1:0,a=n?n.length:0;this.degree=e,this.knots=t,this.controlPoints=[],this.startKnot=i||0,this.endKnot=s||o;for(let l=0;l<a;++l){const c=n[l];this.controlPoints[l]=new ct(c.x,c.y,c.z,c.w)}}getPoint(e,t=new I){const n=t,i=this.knots[this.startKnot]+e*(this.knots[this.endKnot]-this.knots[this.startKnot]),s=xy(this.degree,this.knots,this.controlPoints,i);return s.w!==1&&s.divideScalar(s.w),n.set(s.x,s.y,s.z)}getTangent(e,t=new I){const n=t,i=this.knots[0]+e*(this.knots[this.knots.length-1]-this.knots[0]),s=wy(this.degree,this.knots,this.controlPoints,i,1);return n.copy(s[1]).normalize(),n}toJSON(){const e=super.toJSON();return e.degree=this.degree,e.knots=[...this.knots],e.controlPoints=this.controlPoints.map(t=>t.toArray()),e.startKnot=this.startKnot,e.endKnot=this.endKnot,e}fromJSON(e){return super.fromJSON(e),this.degree=e.degree,this.knots=[...e.knots],this.controlPoints=e.controlPoints.map(t=>new ct(t[0],t[1],t[2],t[3])),this.startKnot=e.startKnot,this.endKnot=e.endKnot,this}}/*!
fflate - fast JavaScript compression/decompression
<https://101arrowz.github.io/fflate>
Licensed under MIT. https://github.com/101arrowz/fflate/blob/master/LICENSE
version 0.8.2
*/var Xn=Uint8Array,er=Uint16Array,Ty=Int32Array,lf=new Xn([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),cf=new Xn([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Ay=new Xn([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),hf=function(r,e){for(var t=new er(31),n=0;n<31;++n)t[n]=e+=1<<r[n-1];for(var i=new Ty(t[30]),n=1;n<30;++n)for(var s=t[n];s<t[n+1];++s)i[s]=s-t[n]<<5|n;return{b:t,r:i}},uf=hf(lf,2),df=uf.b,Ry=uf.r;df[28]=258,Ry[258]=28;var Cy=hf(cf,0),Py=Cy.b,wc=new er(32768);for(var zt=0;zt<32768;++zt){var Xi=(zt&43690)>>1|(zt&21845)<<1;Xi=(Xi&52428)>>2|(Xi&13107)<<2,Xi=(Xi&61680)>>4|(Xi&3855)<<4,wc[zt]=((Xi&65280)>>8|(Xi&255)<<8)>>1}var Ur=function(r,e,t){for(var n=r.length,i=0,s=new er(e);i<n;++i)r[i]&&++s[r[i]-1];var o=new er(e);for(i=1;i<e;++i)o[i]=o[i-1]+s[i-1]<<1;var a;if(t){a=new er(1<<e);var l=15-e;for(i=0;i<n;++i)if(r[i])for(var c=i<<4|r[i],h=e-r[i],u=o[r[i]-1]++<<h,d=u|(1<<h)-1;u<=d;++u)a[wc[u]>>l]=c}else for(a=new er(n),i=0;i<n;++i)r[i]&&(a[i]=wc[o[r[i]-1]++]>>15-r[i]);return a},Zr=new Xn(288);for(var zt=0;zt<144;++zt)Zr[zt]=8;for(var zt=144;zt<256;++zt)Zr[zt]=9;for(var zt=256;zt<280;++zt)Zr[zt]=7;for(var zt=280;zt<288;++zt)Zr[zt]=8;var ff=new Xn(32);for(var zt=0;zt<32;++zt)ff[zt]=5;var Ly=Ur(Zr,9,1),Dy=Ur(ff,5,1),vl=function(r){for(var e=r[0],t=1;t<r.length;++t)r[t]>e&&(e=r[t]);return e},ei=function(r,e,t){var n=e/8|0;return(r[n]|r[n+1]<<8)>>(e&7)&t},xl=function(r,e){var t=e/8|0;return(r[t]|r[t+1]<<8|r[t+2]<<16)>>(e&7)},Iy=function(r){return(r+7)/8|0},Ny=function(r,e,t){return(t==null||t>r.length)&&(t=r.length),new Xn(r.subarray(e,t))},Uy=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],ni=function(r,e,t){var n=new Error(e||Uy[r]);if(n.code=r,Error.captureStackTrace&&Error.captureStackTrace(n,ni),!t)throw n;return n},Fy=function(r,e,t,n){var i=r.length,s=0;if(!i||e.f&&!e.l)return t||new Xn(0);var o=!t,a=o||e.i!=2,l=e.i;o&&(t=new Xn(i*3));var c=function(Ne){var Je=t.length;if(Ne>Je){var We=new Xn(Math.max(Je*2,Ne));We.set(t),t=We}},h=e.f||0,u=e.p||0,d=e.b||0,f=e.l,m=e.d,v=e.m,g=e.n,p=i*8;do{if(!f){h=ei(r,u,1);var M=ei(r,u+1,3);if(u+=3,M)if(M==1)f=Ly,m=Dy,v=9,g=5;else if(M==2){var R=ei(r,u,31)+257,P=ei(r,u+10,15)+4,S=R+ei(r,u+5,31)+1;u+=14;for(var _=new Xn(S),y=new Xn(19),T=0;T<P;++T)y[Ay[T]]=ei(r,u+T*3,7);u+=P*3;for(var F=vl(y),k=(1<<F)-1,G=Ur(y,F,1),T=0;T<S;){var $=G[ei(r,u,k)];u+=$&15;var x=$>>4;if(x<16)_[T++]=x;else{var z=0,Y=0;for(x==16?(Y=3+ei(r,u,3),u+=2,z=_[T-1]):x==17?(Y=3+ei(r,u,7),u+=3):x==18&&(Y=11+ei(r,u,127),u+=7);Y--;)_[T++]=z}}var H=_.subarray(0,R),q=_.subarray(R);v=vl(H),g=vl(q),f=Ur(H,v,1),m=Ur(q,g,1)}else ni(1);else{var x=Iy(u)+4,b=r[x-4]|r[x-3]<<8,D=x+b;if(D>i){l&&ni(0);break}a&&c(d+b),t.set(r.subarray(x,D),d),e.b=d+=b,e.p=u=D*8,e.f=h;continue}if(u>p){l&&ni(0);break}}a&&c(d+131072);for(var ue=(1<<v)-1,re=(1<<g)-1,de=u;;de=u){var z=f[xl(r,u)&ue],ie=z>>4;if(u+=z&15,u>p){l&&ni(0);break}if(z||ni(2),ie<256)t[d++]=ie;else if(ie==256){de=u,f=null;break}else{var W=ie-254;if(ie>264){var T=ie-257,Z=lf[T];W=ei(r,u,(1<<Z)-1)+df[T],u+=Z}var Q=m[xl(r,u)&re],ne=Q>>4;Q||ni(3),u+=Q&15;var q=Py[ne];if(ne>3){var Z=cf[ne];q+=xl(r,u)&(1<<Z)-1,u+=Z}if(u>p){l&&ni(0);break}a&&c(d+131072);var ce=d+W;if(d<q){var Me=s-q,we=Math.min(q,ce);for(Me+d<0&&ni(3);d<we;++d)t[d]=n[Me+d]}for(;d<ce;++d)t[d]=t[d-q]}}e.l=f,e.p=de,e.b=d,e.f=h,f&&(h=1,e.m=v,e.d=m,e.n=g)}while(!h);return d!=t.length&&o?Ny(t,0,d):t.subarray(0,d)},Oy=new Xn(0),By=function(r,e){return((r[0]&15)!=8||r[0]>>4>7||(r[0]<<8|r[1])%31)&&ni(6,"invalid zlib data"),(r[1]>>5&1)==1&&ni(6,"invalid zlib data: "+(r[1]&32?"need":"unexpected")+" dictionary"),(r[1]>>3&4)+2};function ky(r,e){return Fy(r.subarray(By(r),-4),{i:2},e,e)}var zy=typeof TextDecoder<"u"&&new TextDecoder,Hy=0;try{zy.decode(Oy,{stream:!0}),Hy=1}catch{}const Bu=new Cn,zo=new I;class pf extends Qm{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry";const e=[-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],t=[-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],n=[0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5];this.setIndex(n),this.setAttribute("position",new Le(e,3)),this.setAttribute("uv",new Le(t,2))}applyMatrix4(e){const t=this.attributes.instanceStart,n=this.attributes.instanceEnd;return t!==void 0&&(t.applyMatrix4(e),n.applyMatrix4(e),t.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));const n=new bc(t,6,1);return this.setAttribute("instanceStart",new $i(n,3,0)),this.setAttribute("instanceEnd",new $i(n,3,3)),this.instanceCount=this.attributes.instanceStart.count,this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));const n=new bc(t,6,1);return this.setAttribute("instanceColorStart",new $i(n,3,0)),this.setAttribute("instanceColorEnd",new $i(n,3,3)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new Um(e.geometry)),this}fromLineSegments(e){const t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Cn);const e=this.attributes.instanceStart,t=this.attributes.instanceEnd;e!==void 0&&t!==void 0&&(this.boundingBox.setFromBufferAttribute(e),Bu.setFromBufferAttribute(t),this.boundingBox.union(Bu))}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new _i),this.boundingBox===null&&this.computeBoundingBox();const e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(e!==void 0&&t!==void 0){const n=this.boundingSphere.center;this.boundingBox.getCenter(n);let i=0;for(let s=0,o=e.count;s<o;s++)zo.fromBufferAttribute(e,s),i=Math.max(i,n.distanceToSquared(zo)),zo.fromBufferAttribute(t,s),i=Math.max(i,n.distanceToSquared(zo));this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}Se.line={worldUnits:{value:1},linewidth:{value:1},resolution:{value:new ye(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}};Nn.line={uniforms:Bc.merge([Se.common,Se.fog,Se.line]),vertexShader:`
		#include <common>
		#include <color_pars_vertex>
		#include <fog_pars_vertex>
		#include <logdepthbuf_pars_vertex>
		#include <clipping_planes_pars_vertex>

		uniform float linewidth;
		uniform vec2 resolution;

		attribute vec3 instanceStart;
		attribute vec3 instanceEnd;

		attribute vec3 instanceColorStart;
		attribute vec3 instanceColorEnd;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#ifdef USE_DASH

			uniform float dashScale;
			attribute float instanceDistanceStart;
			attribute float instanceDistanceEnd;
			varying float vLineDistance;

		#endif

		void trimSegment( const in vec4 start, inout vec4 end ) {

			// trim end segment so it terminates between the camera plane and the near plane

			// conservative estimate of the near plane
			float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
			float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
			float nearEstimate = - 0.5 * b / a;

			float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

			end.xyz = mix( start.xyz, end.xyz, alpha );

		}

		void main() {

			#ifdef USE_COLOR

				vColor.xyz = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

			#endif

			#ifdef USE_DASH

				vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
				vUv = uv;

			#endif

			float aspect = resolution.x / resolution.y;

			// camera space
			vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
			vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

			#ifdef WORLD_UNITS

				worldStart = start.xyz;
				worldEnd = end.xyz;

			#else

				vUv = uv;

			#endif

			// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
			// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
			// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
			// perhaps there is a more elegant solution -- WestLangley

			bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

			if ( perspective ) {

				if ( start.z < 0.0 && end.z >= 0.0 ) {

					trimSegment( start, end );

				} else if ( end.z < 0.0 && start.z >= 0.0 ) {

					trimSegment( end, start );

				}

			}

			// clip space
			vec4 clipStart = projectionMatrix * start;
			vec4 clipEnd = projectionMatrix * end;

			// ndc space
			vec3 ndcStart = clipStart.xyz / clipStart.w;
			vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

			// direction
			vec2 dir = ndcEnd.xy - ndcStart.xy;

			// account for clip-space aspect ratio
			dir.x *= aspect;
			dir = normalize( dir );

			#ifdef WORLD_UNITS

				vec3 worldDir = normalize( end.xyz - start.xyz );
				vec3 tmpFwd = normalize( mix( start.xyz, end.xyz, 0.5 ) );
				vec3 worldUp = normalize( cross( worldDir, tmpFwd ) );
				vec3 worldFwd = cross( worldDir, worldUp );
				worldPos = position.y < 0.5 ? start: end;

				// height offset
				float hw = linewidth * 0.5;
				worldPos.xyz += position.x < 0.0 ? hw * worldUp : - hw * worldUp;

				// don't extend the line if we're rendering dashes because we
				// won't be rendering the endcaps
				#ifndef USE_DASH

					// cap extension
					worldPos.xyz += position.y < 0.5 ? - hw * worldDir : hw * worldDir;

					// add width to the box
					worldPos.xyz += worldFwd * hw;

					// endcaps
					if ( position.y > 1.0 || position.y < 0.0 ) {

						worldPos.xyz -= worldFwd * 2.0 * hw;

					}

				#endif

				// project the worldpos
				vec4 clip = projectionMatrix * worldPos;

				// shift the depth of the projected points so the line
				// segments overlap neatly
				vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
				clip.z = clipPose.z * clip.w;

			#else

				vec2 offset = vec2( dir.y, - dir.x );
				// undo aspect ratio adjustment
				dir.x /= aspect;
				offset.x /= aspect;

				// sign flip
				if ( position.x < 0.0 ) offset *= - 1.0;

				// endcaps
				if ( position.y < 0.0 ) {

					offset += - dir;

				} else if ( position.y > 1.0 ) {

					offset += dir;

				}

				// adjust for linewidth
				offset *= linewidth;

				// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
				offset /= resolution.y;

				// select end
				vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

				// back to clip space
				offset *= clip.w;

				clip.xy += offset;

			#endif

			gl_Position = clip;

			vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

			#include <logdepthbuf_vertex>
			#include <clipping_planes_vertex>
			#include <fog_vertex>

		}
		`,fragmentShader:`
		uniform vec3 diffuse;
		uniform float opacity;
		uniform float linewidth;

		#ifdef USE_DASH

			uniform float dashOffset;
			uniform float dashSize;
			uniform float gapSize;

		#endif

		varying float vLineDistance;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#include <common>
		#include <color_pars_fragment>
		#include <fog_pars_fragment>
		#include <logdepthbuf_pars_fragment>
		#include <clipping_planes_pars_fragment>

		vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

			float mua;
			float mub;

			vec3 p13 = p1 - p3;
			vec3 p43 = p4 - p3;

			vec3 p21 = p2 - p1;

			float d1343 = dot( p13, p43 );
			float d4321 = dot( p43, p21 );
			float d1321 = dot( p13, p21 );
			float d4343 = dot( p43, p43 );
			float d2121 = dot( p21, p21 );

			float denom = d2121 * d4343 - d4321 * d4321;

			float numer = d1343 * d4321 - d1321 * d4343;

			mua = numer / denom;
			mua = clamp( mua, 0.0, 1.0 );
			mub = ( d1343 + d4321 * ( mua ) ) / d4343;
			mub = clamp( mub, 0.0, 1.0 );

			return vec2( mua, mub );

		}

		void main() {

			#include <clipping_planes_fragment>

			#ifdef USE_DASH

				if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

				if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

			#endif

			float alpha = opacity;

			#ifdef WORLD_UNITS

				// Find the closest points on the view ray and the line segment
				vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
				vec3 lineDir = worldEnd - worldStart;
				vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

				vec3 p1 = worldStart + lineDir * params.x;
				vec3 p2 = rayEnd * params.y;
				vec3 delta = p1 - p2;
				float len = length( delta );
				float norm = len / linewidth;

				#ifndef USE_DASH

					#ifdef USE_ALPHA_TO_COVERAGE

						float dnorm = fwidth( norm );
						alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

					#else

						if ( norm > 0.5 ) {

							discard;

						}

					#endif

				#endif

			#else

				#ifdef USE_ALPHA_TO_COVERAGE

					// artifacts appear on some hardware if a derivative is taken within a conditional
					float a = vUv.x;
					float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
					float len2 = a * a + b * b;
					float dlen = fwidth( len2 );

					if ( abs( vUv.y ) > 1.0 ) {

						alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

					}

				#else

					if ( abs( vUv.y ) > 1.0 ) {

						float a = vUv.x;
						float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
						float len2 = a * a + b * b;

						if ( len2 > 1.0 ) discard;

					}

				#endif

			#endif

			vec4 diffuseColor = vec4( diffuse, alpha );

			#include <logdepthbuf_fragment>
			#include <color_fragment>

			gl_FragColor = vec4( diffuseColor.rgb, alpha );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>
			#include <fog_fragment>
			#include <premultiplied_alpha_fragment>

		}
		`};class ma extends gi{constructor(e){super({type:"LineMaterial",uniforms:Bc.clone(Nn.line.uniforms),vertexShader:Nn.line.vertexShader,fragmentShader:Nn.line.fragmentShader,clipping:!0}),this.isLineMaterial=!0,this.setValues(e)}get color(){return this.uniforms.diffuse.value}set color(e){this.uniforms.diffuse.value=e}get worldUnits(){return"WORLD_UNITS"in this.defines}set worldUnits(e){e===!0?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}get linewidth(){return this.uniforms.linewidth.value}set linewidth(e){this.uniforms.linewidth&&(this.uniforms.linewidth.value=e)}get dashed(){return"USE_DASH"in this.defines}set dashed(e){e===!0!==this.dashed&&(this.needsUpdate=!0),e===!0?this.defines.USE_DASH="":delete this.defines.USE_DASH}get dashScale(){return this.uniforms.dashScale.value}set dashScale(e){this.uniforms.dashScale.value=e}get dashSize(){return this.uniforms.dashSize.value}set dashSize(e){this.uniforms.dashSize.value=e}get dashOffset(){return this.uniforms.dashOffset.value}set dashOffset(e){this.uniforms.dashOffset.value=e}get gapSize(){return this.uniforms.gapSize.value}set gapSize(e){this.uniforms.gapSize.value=e}get opacity(){return this.uniforms.opacity.value}set opacity(e){this.uniforms&&(this.uniforms.opacity.value=e)}get resolution(){return this.uniforms.resolution.value}set resolution(e){this.uniforms.resolution.value.copy(e)}get alphaToCoverage(){return"USE_ALPHA_TO_COVERAGE"in this.defines}set alphaToCoverage(e){this.defines&&(e===!0!==this.alphaToCoverage&&(this.needsUpdate=!0),e===!0?this.defines.USE_ALPHA_TO_COVERAGE="":delete this.defines.USE_ALPHA_TO_COVERAGE)}}const yl=new ct,ku=new I,zu=new I,un=new ct,dn=new ct,li=new ct,bl=new I,Ml=new Te,fn=new hg,Hu=new I,Ho=new Cn,Vo=new _i,ci=new ct;let di,vs;function Vu(r,e,t){return ci.set(0,0,-e,1).applyMatrix4(r.projectionMatrix),ci.multiplyScalar(1/ci.w),ci.x=vs/t.width,ci.y=vs/t.height,ci.applyMatrix4(r.projectionMatrixInverse),ci.multiplyScalar(1/ci.w),Math.abs(Math.max(ci.x,ci.y))}function Vy(r,e){const t=r.matrixWorld,n=r.geometry,i=n.attributes.instanceStart,s=n.attributes.instanceEnd,o=Math.min(n.instanceCount,i.count);for(let a=0,l=o;a<l;a++){fn.start.fromBufferAttribute(i,a),fn.end.fromBufferAttribute(s,a),fn.applyMatrix4(t);const c=new I,h=new I;di.distanceSqToSegment(fn.start,fn.end,h,c),h.distanceTo(c)<vs*.5&&e.push({point:h,pointOnLine:c,distance:di.origin.distanceTo(h),object:r,face:null,faceIndex:a,uv:null,uv1:null})}}function Gy(r,e,t){const n=e.projectionMatrix,s=r.material.resolution,o=r.matrixWorld,a=r.geometry,l=a.attributes.instanceStart,c=a.attributes.instanceEnd,h=Math.min(a.instanceCount,l.count),u=-e.near;di.at(1,li),li.w=1,li.applyMatrix4(e.matrixWorldInverse),li.applyMatrix4(n),li.multiplyScalar(1/li.w),li.x*=s.x/2,li.y*=s.y/2,li.z=0,bl.copy(li),Ml.multiplyMatrices(e.matrixWorldInverse,o);for(let d=0,f=h;d<f;d++){if(un.fromBufferAttribute(l,d),dn.fromBufferAttribute(c,d),un.w=1,dn.w=1,un.applyMatrix4(Ml),dn.applyMatrix4(Ml),un.z>u&&dn.z>u)continue;if(un.z>u){const x=un.z-dn.z,b=(un.z-u)/x;un.lerp(dn,b)}else if(dn.z>u){const x=dn.z-un.z,b=(dn.z-u)/x;dn.lerp(un,b)}un.applyMatrix4(n),dn.applyMatrix4(n),un.multiplyScalar(1/un.w),dn.multiplyScalar(1/dn.w),un.x*=s.x/2,un.y*=s.y/2,dn.x*=s.x/2,dn.y*=s.y/2,fn.start.copy(un),fn.start.z=0,fn.end.copy(dn),fn.end.z=0;const v=fn.closestPointToPointParameter(bl,!0);fn.at(v,Hu);const g=St.lerp(un.z,dn.z,v),p=g>=-1&&g<=1,M=bl.distanceTo(Hu)<vs*.5;if(p&&M){fn.start.fromBufferAttribute(l,d),fn.end.fromBufferAttribute(c,d),fn.start.applyMatrix4(o),fn.end.applyMatrix4(o);const x=new I,b=new I;di.distanceSqToSegment(fn.start,fn.end,b,x),t.push({point:b,pointOnLine:x,distance:di.origin.distanceTo(b),object:r,face:null,faceIndex:d,uv:null,uv1:null})}}}class Wy extends ve{constructor(e=new pf,t=new ma({color:Math.random()*16777215})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){const e=this.geometry,t=e.attributes.instanceStart,n=e.attributes.instanceEnd,i=new Float32Array(2*t.count);for(let o=0,a=0,l=t.count;o<l;o++,a+=2)ku.fromBufferAttribute(t,o),zu.fromBufferAttribute(n,o),i[a]=a===0?0:i[a-1],i[a+1]=i[a]+ku.distanceTo(zu);const s=new bc(i,2,1);return e.setAttribute("instanceDistanceStart",new $i(s,1,0)),e.setAttribute("instanceDistanceEnd",new $i(s,1,1)),this}raycast(e,t){const n=this.material.worldUnits,i=e.camera;i===null&&!n&&console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');const s=e.params.Line2!==void 0&&e.params.Line2.threshold||0;di=e.ray;const o=this.matrixWorld,a=this.geometry,l=this.material;vs=l.linewidth+s,a.boundingSphere===null&&a.computeBoundingSphere(),Vo.copy(a.boundingSphere).applyMatrix4(o);let c;if(n)c=vs*.5;else{const u=Math.max(i.near,Vo.distanceToPoint(di.origin));c=Vu(i,u,l.resolution)}if(Vo.radius+=c,di.intersectsSphere(Vo)===!1)return;a.boundingBox===null&&a.computeBoundingBox(),Ho.copy(a.boundingBox).applyMatrix4(o);let h;if(n)h=vs*.5;else{const u=Math.max(i.near,Ho.distanceToPoint(di.origin));h=Vu(i,u,l.resolution)}Ho.expandByScalar(h),di.intersectsBox(Ho)!==!1&&(n?Vy(this,t):Gy(this,i,t))}onBeforeRender(e){const t=this.material.uniforms;t&&t.resolution&&(e.getViewport(yl),this.material.uniforms.resolution.value.set(yl.z,yl.w))}}class Ec extends pf{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){const t=e.length-3,n=new Float32Array(2*t);for(let i=0;i<t;i+=3)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5];return super.setPositions(n),this}setColors(e){const t=e.length-3,n=new Float32Array(2*t);for(let i=0;i<t;i+=3)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5];return super.setColors(n),this}setFromPoints(e){const t=e.length-1,n=new Float32Array(6*t);for(let i=0;i<t;i++)n[6*i]=e[i].x,n[6*i+1]=e[i].y,n[6*i+2]=e[i].z||0,n[6*i+3]=e[i+1].x,n[6*i+4]=e[i+1].y,n[6*i+5]=e[i+1].z||0;return super.setPositions(n),this}fromLine(e){const t=e.geometry;return this.setPositions(t.attributes.position.array),this}}class Gu extends Wy{constructor(e=new Ec,t=new ma({color:Math.random()*16777215})){super(e,t),this.isLine2=!0,this.type="Line2"}}class Wu extends Ym{constructor(e){super(e)}parse(e){function t(z){switch(z.image_type){case d:case v:if(z.colormap_length>256||z.colormap_size!==24||z.colormap_type!==1)throw new Error("THREE.TGALoader: Invalid type colormap data for indexed type.");break;case f:case m:case g:case p:if(z.colormap_type)throw new Error("THREE.TGALoader: Invalid type colormap data for colormap type.");break;case u:throw new Error("THREE.TGALoader: No data.");default:throw new Error("THREE.TGALoader: Invalid type "+z.image_type)}if(z.width<=0||z.height<=0)throw new Error("THREE.TGALoader: Invalid image size.");if(z.pixel_size!==8&&z.pixel_size!==16&&z.pixel_size!==24&&z.pixel_size!==32)throw new Error("THREE.TGALoader: Invalid pixel size "+z.pixel_size)}function n(z,Y,H,q,ue){let re,de;const ie=H.pixel_size>>3,W=H.width*H.height*ie;if(Y&&(de=ue.subarray(q,q+=H.colormap_length*(H.colormap_size>>3))),z){re=new Uint8Array(W);let Z,Q,ne,ce=0;const Me=new Uint8Array(ie);for(;ce<W;)if(Z=ue[q++],Q=(Z&127)+1,Z&128){for(ne=0;ne<ie;++ne)Me[ne]=ue[q++];for(ne=0;ne<Q;++ne)re.set(Me,ce+ne*ie);ce+=ie*Q}else{for(Q*=ie,ne=0;ne<Q;++ne)re[ce+ne]=ue[q++];ce+=Q}}else re=ue.subarray(q,q+=Y?H.width*H.height:W);return{pixel_data:re,palettes:de}}function i(z,Y,H,q,ue,re,de,ie,W){const Z=W;let Q,ne=0,ce,Me;const we=y.width;for(Me=Y;Me!==q;Me+=H)for(ce=ue;ce!==de;ce+=re,ne++)Q=ie[ne],z[(ce+we*Me)*4+3]=255,z[(ce+we*Me)*4+2]=Z[Q*3+0],z[(ce+we*Me)*4+1]=Z[Q*3+1],z[(ce+we*Me)*4+0]=Z[Q*3+2];return z}function s(z,Y,H,q,ue,re,de,ie){let W,Z=0,Q,ne;const ce=y.width;for(ne=Y;ne!==q;ne+=H)for(Q=ue;Q!==de;Q+=re,Z+=2)W=ie[Z+0]+(ie[Z+1]<<8),z[(Q+ce*ne)*4+0]=(W&31744)>>7,z[(Q+ce*ne)*4+1]=(W&992)>>2,z[(Q+ce*ne)*4+2]=(W&31)<<3,z[(Q+ce*ne)*4+3]=W&32768?0:255;return z}function o(z,Y,H,q,ue,re,de,ie){let W=0,Z,Q;const ne=y.width;for(Q=Y;Q!==q;Q+=H)for(Z=ue;Z!==de;Z+=re,W+=3)z[(Z+ne*Q)*4+3]=255,z[(Z+ne*Q)*4+2]=ie[W+0],z[(Z+ne*Q)*4+1]=ie[W+1],z[(Z+ne*Q)*4+0]=ie[W+2];return z}function a(z,Y,H,q,ue,re,de,ie){let W=0,Z,Q;const ne=y.width;for(Q=Y;Q!==q;Q+=H)for(Z=ue;Z!==de;Z+=re,W+=4)z[(Z+ne*Q)*4+2]=ie[W+0],z[(Z+ne*Q)*4+1]=ie[W+1],z[(Z+ne*Q)*4+0]=ie[W+2],z[(Z+ne*Q)*4+3]=ie[W+3];return z}function l(z,Y,H,q,ue,re,de,ie){let W,Z=0,Q,ne;const ce=y.width;for(ne=Y;ne!==q;ne+=H)for(Q=ue;Q!==de;Q+=re,Z++)W=ie[Z],z[(Q+ce*ne)*4+0]=W,z[(Q+ce*ne)*4+1]=W,z[(Q+ce*ne)*4+2]=W,z[(Q+ce*ne)*4+3]=255;return z}function c(z,Y,H,q,ue,re,de,ie){let W=0,Z,Q;const ne=y.width;for(Q=Y;Q!==q;Q+=H)for(Z=ue;Z!==de;Z+=re,W+=2)z[(Z+ne*Q)*4+0]=ie[W+0],z[(Z+ne*Q)*4+1]=ie[W+0],z[(Z+ne*Q)*4+2]=ie[W+0],z[(Z+ne*Q)*4+3]=ie[W+1];return z}function h(z,Y,H,q,ue){let re,de,ie,W,Z,Q;switch((y.flags&M)>>x){default:case R:re=0,ie=1,Z=Y,de=0,W=1,Q=H;break;case b:re=0,ie=1,Z=Y,de=H-1,W=-1,Q=-1;break;case P:re=Y-1,ie=-1,Z=-1,de=0,W=1,Q=H;break;case D:re=Y-1,ie=-1,Z=-1,de=H-1,W=-1,Q=-1;break}if(k)switch(y.pixel_size){case 8:l(z,de,W,Q,re,ie,Z,q);break;case 16:c(z,de,W,Q,re,ie,Z,q);break;default:throw new Error("THREE.TGALoader: Format not supported.")}else switch(y.pixel_size){case 8:i(z,de,W,Q,re,ie,Z,q,ue);break;case 16:s(z,de,W,Q,re,ie,Z,q);break;case 24:o(z,de,W,Q,re,ie,Z,q);break;case 32:a(z,de,W,Q,re,ie,Z,q);break;default:throw new Error("THREE.TGALoader: Format not supported.")}return z}const u=0,d=1,f=2,m=3,v=9,g=10,p=11,M=48,x=4,b=0,D=1,R=2,P=3;if(e.length<19)throw new Error("THREE.TGALoader: Not enough data to contain header.");let S=0;const _=new Uint8Array(e),y={id_length:_[S++],colormap_type:_[S++],image_type:_[S++],colormap_index:_[S++]|_[S++]<<8,colormap_length:_[S++]|_[S++]<<8,colormap_size:_[S++],origin:[_[S++]|_[S++]<<8,_[S++]|_[S++]<<8],width:_[S++]|_[S++]<<8,height:_[S++]|_[S++]<<8,pixel_size:_[S++],flags:_[S++]};if(t(y),y.id_length+S>e.length)throw new Error("THREE.TGALoader: No data.");S+=y.id_length;let T=!1,F=!1,k=!1;switch(y.image_type){case v:T=!0,F=!0;break;case d:F=!0;break;case g:T=!0;break;case f:break;case p:T=!0,k=!0;break;case m:k=!0;break}const G=new Uint8Array(y.width*y.height*4),$=n(T,F,y,S,_);return h(G,y.width,y.height,$.pixel_data,$.palettes),{data:G,width:y.width,height:y.height,flipY:!0,generateMipmaps:!0,minFilter:Li}}}class Xy extends Yn{load(e,t,n,i){const s=this,o=s.path===""?Wc.extractUrlBase(e):s.path,a=new qr(s.manager);a.setPath(s.path),a.setRequestHeader(s.requestHeader),a.setWithCredentials(s.withCredentials),a.load(e,function(l){try{t(s.parse(l,o))}catch(c){i?i(c):console.error(c),s.manager.itemError(e)}},n,i)}parse(e,t){function n(E,w){const N=[],C=E.childNodes;for(let U=0,te=C.length;U<te;U++){const le=C[U];le.nodeName===w&&N.push(le)}return N}function i(E){if(E.length===0)return[];const w=E.trim().split(/\s+/),N=new Array(w.length);for(let C=0,U=w.length;C<U;C++)N[C]=w[C];return N}function s(E){if(E.length===0)return[];const w=E.trim().split(/\s+/),N=new Array(w.length);for(let C=0,U=w.length;C<U;C++)N[C]=parseFloat(w[C]);return N}function o(E){if(E.length===0)return[];const w=E.trim().split(/\s+/),N=new Array(w.length);for(let C=0,U=w.length;C<U;C++)N[C]=parseInt(w[C]);return N}function a(E){return E.substring(1)}function l(){return"three_default_"+yi++}function c(E){return Object.keys(E).length===0}function h(E){return{unit:u(n(E,"unit")[0]),upAxis:d(n(E,"up_axis")[0])}}function u(E){return E!==void 0&&E.hasAttribute("meter")===!0?parseFloat(E.getAttribute("meter")):1}function d(E){return E!==void 0?E.textContent:"Y_UP"}function f(E,w,N,C){const U=n(E,w)[0];if(U!==void 0){const te=n(U,N);for(let le=0;le<te.length;le++)C(te[le])}}function m(E,w){for(const N in E){const C=E[N];C.build=w(E[N])}}function v(E,w){return E.build!==void 0||(E.build=w(E)),E.build}function g(E){const w={sources:{},samplers:{},channels:{}};let N=!1;for(let C=0,U=E.childNodes.length;C<U;C++){const te=E.childNodes[C];if(te.nodeType!==1)continue;let le;switch(te.nodeName){case"source":le=te.getAttribute("id"),w.sources[le]=oe(te);break;case"sampler":le=te.getAttribute("id"),w.samplers[le]=p(te);break;case"channel":le=te.getAttribute("target"),w.channels[le]=M(te);break;case"animation":g(te),N=!0;break;default:console.log(te)}}N===!1&&(nt.animations[E.getAttribute("id")||St.generateUUID()]=w)}function p(E){const w={inputs:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const te=a(U.getAttribute("source")),le=U.getAttribute("semantic");w.inputs[le]=te;break}}return w}function M(E){const w={};let C=E.getAttribute("target").split("/");const U=C.shift();let te=C.shift();const le=te.indexOf("(")!==-1,Be=te.indexOf(".")!==-1;if(Be)C=te.split("."),te=C.shift(),w.member=C.shift();else if(le){const be=te.split("(");te=be.shift();for(let Ie=0;Ie<be.length;Ie++)be[Ie]=parseInt(be[Ie].replace(/\)/,""));w.indices=be}return w.id=U,w.sid=te,w.arraySyntax=le,w.memberSyntax=Be,w.sampler=a(E.getAttribute("source")),w}function x(E){const w=[],N=E.channels,C=E.samplers,U=E.sources;for(const te in N)if(N.hasOwnProperty(te)){const le=N[te],Be=C[le.sampler],be=Be.inputs.INPUT,Ie=Be.inputs.OUTPUT,je=U[be],pe=U[Ie],Xe=D(le,je,pe);y(Xe,w)}return w}function b(E){return v(nt.animations[E],x)}function D(E,w,N){const C=nt.nodes[E.id],U=ft(C.id),te=C.transforms[E.sid],le=C.matrix.clone().transpose();let Be,be,Ie,je,pe,Xe;const Ve={};switch(te){case"matrix":for(Ie=0,je=w.array.length;Ie<je;Ie++)if(Be=w.array[Ie],be=Ie*N.stride,Ve[Be]===void 0&&(Ve[Be]={}),E.arraySyntax===!0){const Wt=N.array[be],Dt=E.indices[0]+4*E.indices[1];Ve[Be][Dt]=Wt}else for(pe=0,Xe=N.stride;pe<Xe;pe++)Ve[Be][pe]=N.array[be+pe];break;case"translate":console.warn('THREE.ColladaLoader: Animation transform type "%s" not yet implemented.',te);break;case"rotate":console.warn('THREE.ColladaLoader: Animation transform type "%s" not yet implemented.',te);break;case"scale":console.warn('THREE.ColladaLoader: Animation transform type "%s" not yet implemented.',te);break}const $e=R(Ve,le);return{name:U.uuid,keyframes:$e}}function R(E,w){const N=[];for(const U in E)N.push({time:parseFloat(U),value:E[U]});N.sort(C);for(let U=0;U<16;U++)T(N,U,w.elements[U]);return N;function C(U,te){return U.time-te.time}}const P=new I,S=new I,_=new Pt;function y(E,w){const N=E.keyframes,C=E.name,U=[],te=[],le=[],Be=[];for(let be=0,Ie=N.length;be<Ie;be++){const je=N[be],pe=je.time,Xe=je.value;V.fromArray(Xe).transpose(),V.decompose(P,_,S),U.push(pe),te.push(P.x,P.y,P.z),le.push(_.x,_.y,_.z,_.w),Be.push(S.x,S.y,S.z)}return te.length>0&&w.push(new Ss(C+".position",U,te)),le.length>0&&w.push(new Ms(C+".quaternion",U,le)),Be.length>0&&w.push(new Ss(C+".scale",U,Be)),w}function T(E,w,N){let C,U=!0,te,le;for(te=0,le=E.length;te<le;te++)C=E[te],C.value[w]===void 0?C.value[w]=null:U=!1;if(U===!0)for(te=0,le=E.length;te<le;te++)C=E[te],C.value[w]=N;else F(E,w)}function F(E,w){let N,C;for(let U=0,te=E.length;U<te;U++){const le=E[U];if(le.value[w]===null){if(N=k(E,U,w),C=G(E,U,w),N===null){le.value[w]=C.value[w];continue}if(C===null){le.value[w]=N.value[w];continue}$(le,N,C,w)}}}function k(E,w,N){for(;w>=0;){const C=E[w];if(C.value[N]!==null)return C;w--}return null}function G(E,w,N){for(;w<E.length;){const C=E[w];if(C.value[N]!==null)return C;w++}return null}function $(E,w,N,C){if(N.time-w.time===0){E.value[C]=w.value[C];return}E.value[C]=(E.time-w.time)*(N.value[C]-w.value[C])/(N.time-w.time)+w.value[C]}function z(E){const w={name:E.getAttribute("id")||"default",start:parseFloat(E.getAttribute("start")||0),end:parseFloat(E.getAttribute("end")||0),animations:[]};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"instance_animation":w.animations.push(a(U.getAttribute("url")));break}}nt.clips[E.getAttribute("id")]=w}function Y(E){const w=[],N=E.name,C=E.end-E.start||-1,U=E.animations;for(let te=0,le=U.length;te<le;te++){const Be=b(U[te]);for(let be=0,Ie=Be.length;be<Ie;be++)w.push(Be[be])}return new xc(N,C,w)}function H(E){return v(nt.clips[E],Y)}function q(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"skin":w.id=a(U.getAttribute("source")),w.skin=ue(U);break;case"morph":w.id=a(U.getAttribute("source")),console.warn("THREE.ColladaLoader: Morph target animation not supported yet.");break}}nt.controllers[E.getAttribute("id")]=w}function ue(E){const w={sources:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"bind_shape_matrix":w.bindShapeMatrix=s(U.textContent);break;case"source":const te=U.getAttribute("id");w.sources[te]=oe(U);break;case"joints":w.joints=re(U);break;case"vertex_weights":w.vertexWeights=de(U);break}}return w}function re(E){const w={inputs:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const te=U.getAttribute("semantic"),le=a(U.getAttribute("source"));w.inputs[te]=le;break}}return w}function de(E){const w={inputs:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const te=U.getAttribute("semantic"),le=a(U.getAttribute("source")),Be=parseInt(U.getAttribute("offset"));w.inputs[te]={id:le,offset:Be};break;case"vcount":w.vcount=o(U.textContent);break;case"v":w.v=o(U.textContent);break}}return w}function ie(E){const w={id:E.id},N=nt.geometries[w.id];return E.skin!==void 0&&(w.skin=W(E.skin),N.sources.skinIndices=w.skin.indices,N.sources.skinWeights=w.skin.weights),w}function W(E){const N={joints:[],indices:{array:[],stride:4},weights:{array:[],stride:4}},C=E.sources,U=E.vertexWeights,te=U.vcount,le=U.v,Be=U.inputs.JOINT.offset,be=U.inputs.WEIGHT.offset,Ie=E.sources[E.joints.inputs.JOINT],je=E.sources[E.joints.inputs.INV_BIND_MATRIX],pe=C[U.inputs.WEIGHT.id].array;let Xe=0,Ve,$e,Ze;for(Ve=0,Ze=te.length;Ve<Ze;Ve++){const Dt=te[Ve],Tt=[];for($e=0;$e<Dt;$e++){const At=le[Xe+Be],bi=le[Xe+be],Dn=pe[bi];Tt.push({index:At,weight:Dn}),Xe+=2}for(Tt.sort(Wt),$e=0;$e<4;$e++){const At=Tt[$e];At!==void 0?(N.indices.array.push(At.index),N.weights.array.push(At.weight)):(N.indices.array.push(0),N.weights.array.push(0))}}for(E.bindShapeMatrix?N.bindMatrix=new Te().fromArray(E.bindShapeMatrix).transpose():N.bindMatrix=new Te().identity(),Ve=0,Ze=Ie.array.length;Ve<Ze;Ve++){const Dt=Ie.array[Ve],Tt=new Te().fromArray(je.array,Ve*je.stride).transpose();N.joints.push({name:Dt,boneInverse:Tt})}return N;function Wt(Dt,Tt){return Tt.weight-Dt.weight}}function Z(E){return v(nt.controllers[E],ie)}function Q(E){const w={init_from:n(E,"init_from")[0].textContent};nt.images[E.getAttribute("id")]=w}function ne(E){return E.build!==void 0?E.build:E.init_from}function ce(E){const w=nt.images[E];return w!==void 0?v(w,ne):(console.warn("THREE.ColladaLoader: Couldn't find image with ID:",E),null)}function Me(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"profile_COMMON":w.profile=we(U);break}}nt.effects[E.getAttribute("id")]=w}function we(E){const w={surfaces:{},samplers:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"newparam":Ne(U,w);break;case"technique":w.technique=B(U);break;case"extra":w.extra=ke(U);break}}return w}function Ne(E,w){const N=E.getAttribute("sid");for(let C=0,U=E.childNodes.length;C<U;C++){const te=E.childNodes[C];if(te.nodeType===1)switch(te.nodeName){case"surface":w.surfaces[N]=Je(te);break;case"sampler2D":w.samplers[N]=We(te);break}}}function Je(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"init_from":w.init_from=U.textContent;break}}return w}function We(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"source":w.source=U.textContent;break}}return w}function B(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"constant":case"lambert":case"blinn":case"phong":w.type=U.nodeName,w.parameters=ht(U);break;case"extra":w.extra=ke(U);break}}return w}function ht(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"emission":case"diffuse":case"specular":case"bump":case"ambient":case"shininess":case"transparency":w[U.nodeName]=Pe(U);break;case"transparent":w[U.nodeName]={opaque:U.hasAttribute("opaque")?U.getAttribute("opaque"):"A_ONE",data:Pe(U)};break}}return w}function Pe(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"color":w[U.nodeName]=s(U.textContent);break;case"float":w[U.nodeName]=parseFloat(U.textContent);break;case"texture":w[U.nodeName]={id:U.getAttribute("texture"),extra:tt(U)};break}}return w}function tt(E){const w={technique:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"extra":me(U,w);break}}return w}function me(E,w){for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"technique":Qe(U,w);break}}}function Qe(E,w){for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"repeatU":case"repeatV":case"offsetU":case"offsetV":w.technique[U.nodeName]=parseFloat(U.textContent);break;case"wrapU":case"wrapV":U.textContent.toUpperCase()==="TRUE"?w.technique[U.nodeName]=1:U.textContent.toUpperCase()==="FALSE"?w.technique[U.nodeName]=0:w.technique[U.nodeName]=parseInt(U.textContent);break;case"bump":w[U.nodeName]=A(U);break}}}function ke(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"technique":w.technique=O(U);break}}return w}function O(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"double_sided":w[U.nodeName]=parseInt(U.textContent);break;case"bump":w[U.nodeName]=A(U);break}}return w}function A(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"texture":w[U.nodeName]={id:U.getAttribute("texture"),texcoord:U.getAttribute("texcoord"),extra:tt(U)};break}}return w}function K(E){return E}function ae(E){return v(nt.effects[E],K)}function he(E){const w={name:E.getAttribute("name")};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"instance_effect":w.url=a(U.getAttribute("url"));break}}nt.materials[E.getAttribute("id")]=w}function se(E){let w,N=E.slice((E.lastIndexOf(".")-1>>>0)+2);switch(N=N.toLowerCase(),N){case"tga":w=_n;break;default:w=wn}return w}function Re(E){const w=ae(E.url),N=w.profile.technique;let C;switch(N.type){case"phong":case"blinn":C=new kn;break;case"lambert":C=new Hr;break;default:C=new qn;break}C.name=E.name||"";function U(be,Ie=null){const je=w.profile.samplers[be.id];let pe=null;if(je!==void 0){const Xe=w.profile.surfaces[je.source];pe=ce(Xe.init_from)}else console.warn("THREE.ColladaLoader: Undefined sampler. Access image directly (see #12530)."),pe=ce(be.id);if(pe!==null){const Xe=se(pe);if(Xe!==void 0){const Ve=Xe.load(pe),$e=be.extra;if($e!==void 0&&$e.technique!==void 0&&c($e.technique)===!1){const Ze=$e.technique;Ve.wrapS=Ze.wrapU?Pi:Bn,Ve.wrapT=Ze.wrapV?Pi:Bn,Ve.offset.set(Ze.offsetU||0,Ze.offsetV||0),Ve.repeat.set(Ze.repeatU||1,Ze.repeatV||1)}else Ve.wrapS=Pi,Ve.wrapT=Pi;return Ie!==null&&(Ve.colorSpace=Ie),Ve}else return console.warn("THREE.ColladaLoader: Loader for texture %s not found.",pe),null}else return console.warn("THREE.ColladaLoader: Couldn't create texture with ID:",be.id),null}const te=N.parameters;for(const be in te){const Ie=te[be];switch(be){case"diffuse":Ie.color&&C.color.fromArray(Ie.color),Ie.texture&&(C.map=U(Ie.texture,xt));break;case"specular":Ie.color&&C.specular&&C.specular.fromArray(Ie.color),Ie.texture&&(C.specularMap=U(Ie.texture));break;case"bump":Ie.texture&&(C.normalMap=U(Ie.texture));break;case"ambient":Ie.texture&&(C.lightMap=U(Ie.texture,xt));break;case"shininess":Ie.float&&C.shininess&&(C.shininess=Ie.float);break;case"emission":Ie.color&&C.emissive&&C.emissive.fromArray(Ie.color),Ie.texture&&(C.emissiveMap=U(Ie.texture,xt));break}}rt.toWorkingColorSpace(C.color,xt),C.specular&&rt.toWorkingColorSpace(C.specular,xt),C.emissive&&rt.toWorkingColorSpace(C.emissive,xt);let le=te.transparent,Be=te.transparency;if(Be===void 0&&le&&(Be={float:1}),le===void 0&&Be&&(le={opaque:"A_ONE",data:{color:[1,1,1,1]}}),le&&Be)if(le.data.texture)C.transparent=!0;else{const be=le.data.color;switch(le.opaque){case"A_ONE":C.opacity=be[3]*Be.float;break;case"RGB_ZERO":C.opacity=1-be[0]*Be.float;break;case"A_ZERO":C.opacity=1-be[3]*Be.float;break;case"RGB_ONE":C.opacity=be[0]*Be.float;break;default:console.warn('THREE.ColladaLoader: Invalid opaque type "%s" of transparent tag.',le.opaque)}C.opacity<1&&(C.transparent=!0)}if(N.extra!==void 0&&N.extra.technique!==void 0){const be=N.extra.technique;for(const Ie in be){const je=be[Ie];switch(Ie){case"double_sided":C.side=je===1?Wn:Ui;break;case"bump":C.normalMap=U(je.texture),C.normalScale=new ye(1,1);break}}}return C}function xe(E){return v(nt.materials[E],Re)}function Fe(E){const w={name:E.getAttribute("name")};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"optics":w.optics=gt(U);break}}nt.cameras[E.getAttribute("id")]=w}function gt(E){for(let w=0;w<E.childNodes.length;w++){const N=E.childNodes[w];switch(N.nodeName){case"technique_common":return ge(N)}}return{}}function ge(E){const w={};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];switch(C.nodeName){case"perspective":case"orthographic":w.technique=C.nodeName,w.parameters=Ee(C);break}}return w}function Ee(E){const w={};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];switch(C.nodeName){case"xfov":case"yfov":case"xmag":case"ymag":case"znear":case"zfar":case"aspect_ratio":w[C.nodeName]=parseFloat(C.textContent);break}}return w}function qe(E){let w;switch(E.optics.technique){case"perspective":w=new Qt(E.optics.parameters.yfov,E.optics.parameters.aspect_ratio,E.optics.parameters.znear,E.optics.parameters.zfar);break;case"orthographic":let N=E.optics.parameters.ymag,C=E.optics.parameters.xmag;const U=E.optics.parameters.aspect_ratio;C=C===void 0?N*U:C,N=N===void 0?C/U:N,C*=.5,N*=.5,w=new Vc(-C,C,N,-N,E.optics.parameters.znear,E.optics.parameters.zfar);break;default:w=new Qt;break}return w.name=E.name||"",w}function et(E){const w=nt.cameras[E];return w!==void 0?v(w,qe):(console.warn("THREE.ColladaLoader: Couldn't find camera with ID:",E),null)}function ze(E){let w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"technique_common":w=vt(U);break}}nt.lights[E.getAttribute("id")]=w}function vt(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"directional":case"point":case"spot":case"ambient":w.technique=U.nodeName,w.parameters=at(U)}}return w}function at(E){const w={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"color":const te=s(U.textContent);w.color=new Ge().fromArray(te),rt.toWorkingColorSpace(w.color,xt);break;case"falloff_angle":w.falloffAngle=parseFloat(U.textContent);break;case"quadratic_attenuation":const le=parseFloat(U.textContent);w.distance=le?Math.sqrt(1/le):0;break}}return w}function Lt(E){let w;switch(E.technique){case"directional":w=new pa;break;case"point":w=new yc;break;case"spot":w=new Kd;break;case"ambient":w=new Gc;break}return E.parameters.color&&w.color.copy(E.parameters.color),E.parameters.distance&&(w.distance=E.parameters.distance),w}function X(E){const w=nt.lights[E];return w!==void 0?v(w,Lt):(console.warn("THREE.ColladaLoader: Couldn't find light with ID:",E),null)}function Ce(E){const w={name:E.getAttribute("name"),sources:{},vertices:{},primitives:[]},N=n(E,"mesh")[0];if(N!==void 0){for(let C=0;C<N.childNodes.length;C++){const U=N.childNodes[C];if(U.nodeType!==1)continue;const te=U.getAttribute("id");switch(U.nodeName){case"source":w.sources[te]=oe(U);break;case"vertices":w.vertices=fe(U);break;case"polygons":console.warn("THREE.ColladaLoader: Unsupported primitive type: ",U.nodeName);break;case"lines":case"linestrips":case"polylist":case"triangles":w.primitives.push(Ue(U));break;default:console.log(U)}}nt.geometries[E.getAttribute("id")]=w}}function oe(E){const w={array:[],stride:3};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"float_array":w.array=s(C.textContent);break;case"Name_array":w.array=i(C.textContent);break;case"technique_common":const U=n(C,"accessor")[0];U!==void 0&&(w.stride=parseInt(U.getAttribute("stride")));break}}return w}function fe(E){const w={};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];C.nodeType===1&&(w[C.getAttribute("semantic")]=a(C.getAttribute("source")))}return w}function Ue(E){const w={type:E.nodeName,material:E.getAttribute("material"),count:parseInt(E.getAttribute("count")),inputs:{},stride:0,hasUV:!1};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const te=a(U.getAttribute("source")),le=U.getAttribute("semantic"),Be=parseInt(U.getAttribute("offset")),be=parseInt(U.getAttribute("set")),Ie=be>0?le+be:le;w.inputs[Ie]={id:te,offset:Be},w.stride=Math.max(w.stride,Be+1),le==="TEXCOORD"&&(w.hasUV=!0);break;case"vcount":w.vcount=o(U.textContent);break;case"p":w.p=o(U.textContent);break}}return w}function De(E){const w={};for(let N=0;N<E.length;N++){const C=E[N];w[C.type]===void 0&&(w[C.type]=[]),w[C.type].push(C)}return w}function ot(E){let w=0;for(let N=0,C=E.length;N<C;N++)E[N].hasUV===!0&&w++;w>0&&w<E.length&&(E.uvsNeedsFix=!0)}function kt(E){const w={},N=E.sources,C=E.vertices,U=E.primitives;if(U.length===0)return{};const te=De(U);for(const le in te){const Be=te[le];ot(Be),w[le]=an(Be,N,C)}return w}function an(E,w,N){const C={},U={array:[],stride:0},te={array:[],stride:0},le={array:[],stride:0},Be={array:[],stride:0},be={array:[],stride:0},Ie={array:[],stride:4},je={array:[],stride:4},pe=new yt,Xe=[];let Ve=0;for(let $e=0;$e<E.length;$e++){const Ze=E[$e],Wt=Ze.inputs;let Dt=0;switch(Ze.type){case"lines":case"linestrips":Dt=Ze.count*2;break;case"triangles":Dt=Ze.count*3;break;case"polylist":for(let Tt=0;Tt<Ze.count;Tt++){const At=Ze.vcount[Tt];switch(At){case 3:Dt+=3;break;case 4:Dt+=6;break;default:Dt+=(At-2)*3;break}}break;default:console.warn("THREE.ColladaLoader: Unknown primitive type:",Ze.type)}pe.addGroup(Ve,Dt,$e),Ve+=Dt,Ze.material&&Xe.push(Ze.material);for(const Tt in Wt){const At=Wt[Tt];switch(Tt){case"VERTEX":for(const bi in N){const Dn=N[bi];switch(bi){case"POSITION":const Ps=U.array.length;if(ut(Ze,w[Dn],At.offset,U.array),U.stride=w[Dn].stride,w.skinWeights&&w.skinIndices&&(ut(Ze,w.skinIndices,At.offset,Ie.array),ut(Ze,w.skinWeights,At.offset,je.array)),Ze.hasUV===!1&&E.uvsNeedsFix===!0){const Af=(U.array.length-Ps)/U.stride;for(let th=0;th<Af;th++)le.array.push(0,0)}break;case"NORMAL":ut(Ze,w[Dn],At.offset,te.array),te.stride=w[Dn].stride;break;case"COLOR":ut(Ze,w[Dn],At.offset,be.array),be.stride=w[Dn].stride;break;case"TEXCOORD":ut(Ze,w[Dn],At.offset,le.array),le.stride=w[Dn].stride;break;case"TEXCOORD1":ut(Ze,w[Dn],At.offset,Be.array),le.stride=w[Dn].stride;break;default:console.warn('THREE.ColladaLoader: Semantic "%s" not handled in geometry build process.',bi)}}break;case"NORMAL":ut(Ze,w[At.id],At.offset,te.array),te.stride=w[At.id].stride;break;case"COLOR":ut(Ze,w[At.id],At.offset,be.array,!0),be.stride=w[At.id].stride;break;case"TEXCOORD":ut(Ze,w[At.id],At.offset,le.array),le.stride=w[At.id].stride;break;case"TEXCOORD1":ut(Ze,w[At.id],At.offset,Be.array),Be.stride=w[At.id].stride;break}}}return U.array.length>0&&pe.setAttribute("position",new Le(U.array,U.stride)),te.array.length>0&&pe.setAttribute("normal",new Le(te.array,te.stride)),be.array.length>0&&pe.setAttribute("color",new Le(be.array,be.stride)),le.array.length>0&&pe.setAttribute("uv",new Le(le.array,le.stride)),Be.array.length>0&&pe.setAttribute("uv1",new Le(Be.array,Be.stride)),Ie.array.length>0&&pe.setAttribute("skinIndex",new Le(Ie.array,Ie.stride)),je.array.length>0&&pe.setAttribute("skinWeight",new Le(je.array,je.stride)),C.data=pe,C.type=E[0].type,C.materialKeys=Xe,C}function ut(E,w,N,C,U=!1){const te=E.p,le=E.stride,Be=E.vcount;function be(pe){let Xe=te[pe+N]*je;const Ve=Xe+je;for(;Xe<Ve;Xe++)C.push(Ie[Xe]);if(U){const $e=C.length-je-1;$t.setRGB(C[$e+0],C[$e+1],C[$e+2],xt),C[$e+0]=$t.r,C[$e+1]=$t.g,C[$e+2]=$t.b}}const Ie=w.array,je=w.stride;if(E.vcount!==void 0){let pe=0;for(let Xe=0,Ve=Be.length;Xe<Ve;Xe++){const $e=Be[Xe];if($e===4){const Ze=pe+le*0,Wt=pe+le*1,Dt=pe+le*2,Tt=pe+le*3;be(Ze),be(Wt),be(Tt),be(Wt),be(Dt),be(Tt)}else if($e===3){const Ze=pe+le*0,Wt=pe+le*1,Dt=pe+le*2;be(Ze),be(Wt),be(Dt)}else if($e>4)for(let Ze=1,Wt=$e-2;Ze<=Wt;Ze++){const Dt=pe+le*0,Tt=pe+le*Ze,At=pe+le*(Ze+1);be(Dt),be(Tt),be(At)}pe+=le*$e}}else for(let pe=0,Xe=te.length;pe<Xe;pe+=le)be(pe)}function Pn(E){return v(nt.geometries[E],kt)}function Kn(E){const w={name:E.getAttribute("name")||"",joints:{},links:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"technique_common":xi(C,w);break}}nt.kinematicsModels[E.getAttribute("id")]=w}function $r(E){return E.build!==void 0?E.build:E}function Jr(E){return v(nt.kinematicsModels[E],$r)}function xi(E,w){for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"joint":w.joints[C.getAttribute("sid")]=xr(C);break;case"link":w.links.push(yr(C));break}}}function xr(E){let w;for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"prismatic":case"revolute":w=Qr(C);break}}return w}function Qr(E){const w={sid:E.getAttribute("sid"),name:E.getAttribute("name")||"",axis:new I,limits:{min:0,max:0},type:E.nodeName,static:!1,zeroPosition:0,middlePosition:0};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"axis":const U=s(C.textContent);w.axis.fromArray(U);break;case"limits":const te=C.getElementsByTagName("max")[0],le=C.getElementsByTagName("min")[0];w.limits.max=parseFloat(te.textContent),w.limits.min=parseFloat(le.textContent);break}}return w.limits.min>=w.limits.max&&(w.static=!0),w.middlePosition=(w.limits.min+w.limits.max)/2,w}function yr(E){const w={sid:E.getAttribute("sid"),name:E.getAttribute("name")||"",attachments:[],transforms:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"attachment_full":w.attachments.push(As(C));break;case"matrix":case"translate":case"rotate":w.transforms.push(br(C));break}}return w}function As(E){const w={joint:E.getAttribute("joint").split("/").pop(),transforms:[],links:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"link":w.links.push(yr(C));break;case"matrix":case"translate":case"rotate":w.transforms.push(br(C));break}}return w}function br(E){const w={type:E.nodeName},N=s(E.textContent);switch(w.type){case"matrix":w.obj=new Te,w.obj.fromArray(N).transpose();break;case"translate":w.obj=new I,w.obj.fromArray(N);break;case"rotate":w.obj=new I,w.obj.fromArray(N),w.angle=St.degToRad(N[3]);break}return w}function Rs(E){const w={name:E.getAttribute("name")||"",rigidBodies:{}};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"rigid_body":w.rigidBodies[C.getAttribute("name")]={},eo(C,w.rigidBodies[C.getAttribute("name")]);break}}nt.physicsModels[E.getAttribute("id")]=w}function eo(E,w){for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"technique_common":to(C,w);break}}}function to(E,w){for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"inertia":w.inertia=s(C.textContent);break;case"mass":w.mass=s(C.textContent)[0];break}}}function Ra(E){const w={bindJointAxis:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"bind_joint_axis":w.bindJointAxis.push(Ca(C));break}}nt.kinematicsScenes[a(E.getAttribute("url"))]=w}function Ca(E){const w={target:E.getAttribute("target").split("/").pop()};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"axis":const U=C.getElementsByTagName("param")[0];w.axis=U.textContent;const te=w.axis.split("inst_").pop().split("axis")[0];w.jointIndex=te.substring(0,te.length-1);break}}return w}function Pa(E){return E.build!==void 0?E.build:E}function La(E){return v(nt.kinematicsScenes[E],Pa)}function Da(){const E=Object.keys(nt.kinematicsModels)[0],w=Object.keys(nt.kinematicsScenes)[0],N=Object.keys(nt.visualScenes)[0];if(E===void 0||w===void 0)return;const C=Jr(E),U=La(w),te=bt(N),le=U.bindJointAxis,Be={};for(let je=0,pe=le.length;je<pe;je++){const Xe=le[je],Ve=Bt.querySelector('[sid="'+Xe.target+'"]');if(Ve){const $e=Ve.parentElement;be(Xe.jointIndex,$e)}}function be(je,pe){const Xe=pe.getAttribute("name"),Ve=C.joints[je];te.traverse(function($e){$e.name===Xe&&(Be[je]={object:$e,transforms:Ia(pe),joint:Ve,position:Ve.zeroPosition})})}const Ie=new Te;Cs={joints:C&&C.joints,getJointValue:function(je){const pe=Be[je];if(pe)return pe.position;console.warn("THREE.ColladaLoader: Joint "+je+" doesn't exist.")},setJointValue:function(je,pe){const Xe=Be[je];if(Xe){const Ve=Xe.joint;if(pe>Ve.limits.max||pe<Ve.limits.min)console.warn("THREE.ColladaLoader: Joint "+je+" value "+pe+" outside of limits (min: "+Ve.limits.min+", max: "+Ve.limits.max+").");else if(Ve.static)console.warn("THREE.ColladaLoader: Joint "+je+" is static.");else{const $e=Xe.object,Ze=Ve.axis,Wt=Xe.transforms;V.identity();for(let Dt=0;Dt<Wt.length;Dt++){const Tt=Wt[Dt];if(Tt.sid&&Tt.sid.indexOf(je)!==-1)switch(Ve.type){case"revolute":V.multiply(Ie.makeRotationAxis(Ze,St.degToRad(pe)));break;case"prismatic":V.multiply(Ie.makeTranslation(Ze.x*pe,Ze.y*pe,Ze.z*pe));break;default:console.warn("THREE.ColladaLoader: Unknown joint type: "+Ve.type);break}else switch(Tt.type){case"matrix":V.multiply(Tt.obj);break;case"translate":V.multiply(Ie.makeTranslation(Tt.obj.x,Tt.obj.y,Tt.obj.z));break;case"scale":V.scale(Tt.obj);break;case"rotate":V.multiply(Ie.makeRotationAxis(Tt.obj,Tt.angle));break}}$e.matrix.copy(V),$e.matrix.decompose($e.position,$e.quaternion,$e.scale),Be[je].position=pe}}else console.log("THREE.ColladaLoader: "+je+" does not exist.")}}}function Ia(E){const w=[],N=Bt.querySelector('[id="'+E.id+'"]');for(let C=0;C<N.childNodes.length;C++){const U=N.childNodes[C];if(U.nodeType!==1)continue;let te,le;switch(U.nodeName){case"matrix":te=s(U.textContent);const Be=new Te().fromArray(te).transpose();w.push({sid:U.getAttribute("sid"),type:U.nodeName,obj:Be});break;case"translate":case"scale":te=s(U.textContent),le=new I().fromArray(te),w.push({sid:U.getAttribute("sid"),type:U.nodeName,obj:le});break;case"rotate":te=s(U.textContent),le=new I().fromArray(te);const be=St.degToRad(te[3]);w.push({sid:U.getAttribute("sid"),type:U.nodeName,obj:le,angle:be});break}}return w}function L(E){const w=E.getElementsByTagName("node");for(let N=0;N<w.length;N++){const C=w[N];C.hasAttribute("id")===!1&&C.setAttribute("id",l())}}const V=new Te,J=new I;function ee(E){const w={name:E.getAttribute("name")||"",type:E.getAttribute("type"),id:E.getAttribute("id"),sid:E.getAttribute("sid"),matrix:new Te,nodes:[],instanceCameras:[],instanceControllers:[],instanceLights:[],instanceGeometries:[],instanceNodes:[],transforms:{}};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType!==1)continue;let U;switch(C.nodeName){case"node":w.nodes.push(C.getAttribute("id")),ee(C);break;case"instance_camera":w.instanceCameras.push(a(C.getAttribute("url")));break;case"instance_controller":w.instanceControllers.push(j(C));break;case"instance_light":w.instanceLights.push(a(C.getAttribute("url")));break;case"instance_geometry":w.instanceGeometries.push(j(C));break;case"instance_node":w.instanceNodes.push(a(C.getAttribute("url")));break;case"matrix":U=s(C.textContent),w.matrix.multiply(V.fromArray(U).transpose()),w.transforms[C.getAttribute("sid")]=C.nodeName;break;case"translate":U=s(C.textContent),J.fromArray(U),w.matrix.multiply(V.makeTranslation(J.x,J.y,J.z)),w.transforms[C.getAttribute("sid")]=C.nodeName;break;case"rotate":U=s(C.textContent);const te=St.degToRad(U[3]);w.matrix.multiply(V.makeRotationAxis(J.fromArray(U),te)),w.transforms[C.getAttribute("sid")]=C.nodeName;break;case"scale":U=s(C.textContent),w.matrix.scale(J.fromArray(U)),w.transforms[C.getAttribute("sid")]=C.nodeName;break;case"extra":break;default:console.log(C)}}return Ye(w.id)?console.warn("THREE.ColladaLoader: There is already a node with ID %s. Exclude current node from further processing.",w.id):nt.nodes[w.id]=w,w}function j(E){const w={id:a(E.getAttribute("url")),materials:{},skeletons:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];switch(C.nodeName){case"bind_material":const U=C.getElementsByTagName("instance_material");for(let te=0;te<U.length;te++){const le=U[te],Be=le.getAttribute("symbol"),be=le.getAttribute("target");w.materials[Be]=a(be)}break;case"skeleton":w.skeletons.push(a(C.textContent));break}}return w}function _e(E,w){const N=[],C=[];let U,te,le;for(U=0;U<E.length;U++){const Ie=E[U];let je;if(Ye(Ie))je=ft(Ie),Ae(je,w,N);else if(Ht(Ie)){const Xe=nt.visualScenes[Ie].children;for(let Ve=0;Ve<Xe.length;Ve++){const $e=Xe[Ve];if($e.type==="JOINT"){const Ze=ft($e.id);Ae(Ze,w,N)}}}else console.error("THREE.ColladaLoader: Unable to find root bone of skeleton with ID:",Ie)}for(U=0;U<w.length;U++)for(te=0;te<N.length;te++)if(le=N[te],le.bone.name===w[U].name){C[U]=le,le.processed=!0;break}for(U=0;U<N.length;U++)le=N[U],le.processed===!1&&(C.push(le),le.processed=!0);const Be=[],be=[];for(U=0;U<C.length;U++)le=C[U],Be.push(le.bone),be.push(le.boneInverse);return new va(Be,be)}function Ae(E,w,N){E.traverse(function(C){if(C.isBone===!0){let U;for(let te=0;te<w.length;te++){const le=w[te];if(le.name===C.name){U=le.boneInverse;break}}U===void 0&&(U=new Te),N.push({bone:C,boneInverse:U,processed:!1})}})}function Oe(E){const w=[],N=E.matrix,C=E.nodes,U=E.type,te=E.instanceCameras,le=E.instanceControllers,Be=E.instanceLights,be=E.instanceGeometries,Ie=E.instanceNodes;for(let pe=0,Xe=C.length;pe<Xe;pe++)w.push(ft(C[pe]));for(let pe=0,Xe=te.length;pe<Xe;pe++){const Ve=et(te[pe]);Ve!==null&&w.push(Ve.clone())}for(let pe=0,Xe=le.length;pe<Xe;pe++){const Ve=le[pe],$e=Z(Ve.id),Ze=Pn($e.id),Wt=st(Ze,Ve.materials),Dt=Ve.skeletons,Tt=$e.skin.joints,At=_e(Dt,Tt);for(let bi=0,Dn=Wt.length;bi<Dn;bi++){const Ps=Wt[bi];Ps.isSkinnedMesh&&(Ps.bind(At,$e.skin.bindMatrix),Ps.normalizeSkinWeights()),w.push(Ps)}}for(let pe=0,Xe=Be.length;pe<Xe;pe++){const Ve=X(Be[pe]);Ve!==null&&w.push(Ve.clone())}for(let pe=0,Xe=be.length;pe<Xe;pe++){const Ve=be[pe],$e=Pn(Ve.id),Ze=st($e,Ve.materials);for(let Wt=0,Dt=Ze.length;Wt<Dt;Wt++)w.push(Ze[Wt])}for(let pe=0,Xe=Ie.length;pe<Xe;pe++)w.push(ft(Ie[pe]).clone());let je;if(C.length===0&&w.length===1)je=w[0];else{je=U==="JOINT"?new ha:new Mt;for(let pe=0;pe<w.length;pe++)je.add(w[pe])}return je.name=U==="JOINT"?E.sid:E.name,je.matrix.copy(N),je.matrix.decompose(je.position,je.quaternion,je.scale),je}const He=new qn({name:Yn.DEFAULT_MATERIAL_NAME,color:16711935});function it(E,w){const N=[];for(let C=0,U=E.length;C<U;C++){const te=w[E[C]];te===void 0?(console.warn("THREE.ColladaLoader: Material with key %s not found. Apply fallback material.",E[C]),N.push(He)):N.push(xe(te))}return N}function st(E,w){const N=[];for(const C in E){const U=E[C],te=it(U.materialKeys,w);if(te.length===0&&(C==="lines"||C==="linestrips"?te.push(new jn):te.push(new kn)),C==="lines"||C==="linestrips")for(let Ie=0,je=te.length;Ie<je;Ie++){const pe=te[Ie];if(pe.isMeshPhongMaterial===!0||pe.isMeshLambertMaterial===!0){const Xe=new jn;Xe.color.copy(pe.color),Xe.opacity=pe.opacity,Xe.transparent=pe.transparent,te[Ie]=Xe}}const le=U.data.attributes.skinIndex!==void 0,Be=te.length===1?te[0]:te;let be;switch(C){case"lines":be=new pr(U.data,Be);break;case"linestrips":be=new Vn(U.data,Be);break;case"triangles":case"polylist":le?be=new zd(U.data,Be):be=new ve(U.data,Be);break}N.push(be)}return N}function Ye(E){return nt.nodes[E]!==void 0}function ft(E){return v(nt.nodes[E],Oe)}function wt(E){const w={name:E.getAttribute("name"),children:[]};L(E);const N=n(E,"node");for(let C=0;C<N.length;C++)w.children.push(ee(N[C]));nt.visualScenes[E.getAttribute("id")]=w}function Gt(E){const w=new Mt;w.name=E.name;const N=E.children;for(let C=0;C<N.length;C++){const U=N[C];w.add(ft(U.id))}return w}function Ht(E){return nt.visualScenes[E]!==void 0}function bt(E){return v(nt.visualScenes[E],Gt)}function Ke(E){const w=n(E,"instance_visual_scene")[0];return bt(a(w.getAttribute("url")))}function en(){const E=nt.clips;if(c(E)===!0){if(c(nt.animations)===!1){const w=[];for(const N in nt.animations){const C=b(N);for(let U=0,te=C.length;U<te;U++)w.push(C[U])}tn.push(new xc("default",-1,w))}}else for(const w in E)tn.push(H(w))}function Et(E){let w="";const N=[E];for(;N.length;){const C=N.shift();C.nodeType===Node.TEXT_NODE?w+=C.textContent:(w+=`
`,N.push(...C.childNodes))}return w.trim()}if(e.length===0)return{scene:new mc};const Ln=new DOMParser().parseFromString(e,"application/xml"),Bt=n(Ln,"COLLADA")[0],hn=Ln.getElementsByTagName("parsererror")[0];if(hn!==void 0){const E=n(hn,"div")[0];let w;return E?w=E.textContent:w=Et(hn),console.error(`THREE.ColladaLoader: Failed to parse collada file.
`,w),null}const ts=Bt.getAttribute("version");console.debug("THREE.ColladaLoader: File version",ts);const Ft=h(n(Bt,"asset")[0]),wn=new Ma(this.manager);wn.setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin);let _n;Wu&&(_n=new Wu(this.manager),_n.setPath(this.resourcePath||t));const $t=new Ge,tn=[];let Cs={},yi=0;const nt={animations:{},clips:{},controllers:{},images:{},effects:{},materials:{},cameras:{},lights:{},geometries:{},nodes:{},visualScenes:{},kinematicsModels:{},physicsModels:{},kinematicsScenes:{}};f(Bt,"library_animations","animation",g),f(Bt,"library_animation_clips","animation_clip",z),f(Bt,"library_controllers","controller",q),f(Bt,"library_images","image",Q),f(Bt,"library_effects","effect",Me),f(Bt,"library_materials","material",he),f(Bt,"library_cameras","camera",Fe),f(Bt,"library_lights","light",ze),f(Bt,"library_geometries","geometry",Ce),f(Bt,"library_nodes","node",ee),f(Bt,"library_visual_scenes","visual_scene",wt),f(Bt,"library_kinematics_models","kinematics_model",Kn),f(Bt,"library_physics_models","physics_model",Rs),f(Bt,"scene","instance_kinematics_scene",Ra),m(nt.animations,x),m(nt.clips,Y),m(nt.controllers,ie),m(nt.images,ne),m(nt.effects,K),m(nt.materials,Re),m(nt.cameras,qe),m(nt.lights,Lt),m(nt.geometries,kt),m(nt.visualScenes,Gt),en(),Da();const no=Ke(n(Bt,"scene")[0]);return no.animations=tn,Ft.upAxis==="Z_UP"&&(console.warn("THREE.ColladaLoader: You are loading an asset with a Z-UP coordinate system. The loader just rotates the asset to transform it into Y-UP. The vertex data are not converted, see #24289."),no.rotation.set(-Math.PI/2,0,0)),no.scale.multiplyScalar(Ft.unit),{get animations(){return console.warn("THREE.ColladaLoader: Please access animations over scene.animations now."),tn},kinematics:Cs,library:nt,scene:no}}}let mt,Zt,An;class mf extends Yn{constructor(e){super(e)}load(e,t,n,i){const s=this,o=s.path===""?Wc.extractUrlBase(e):s.path,a=new qr(this.manager);a.setPath(s.path),a.setResponseType("arraybuffer"),a.setRequestHeader(s.requestHeader),a.setWithCredentials(s.withCredentials),a.load(e,function(l){try{t(s.parse(l,o))}catch(c){i?i(c):console.error(c),s.manager.itemError(e)}},n,i)}parse(e,t){if($y(e))mt=new Ky().parse(e);else{const i=vf(e);if(!Jy(i))throw new Error("THREE.FBXLoader: Unknown format.");if(ju(i)<7e3)throw new Error("THREE.FBXLoader: FBX version not supported, FileVersion: "+ju(i));mt=new Zy().parse(i)}const n=new Ma(this.manager).setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin);return new jy(n,this.manager).parse(mt)}}class jy{constructor(e,t){this.textureLoader=e,this.manager=t}parse(){Zt=this.parseConnections();const e=this.parseImages(),t=this.parseTextures(e),n=this.parseMaterials(t),i=this.parseDeformers(),s=new qy().parse(i);return this.parseScene(i,s,n),An}parseConnections(){const e=new Map;return"Connections"in mt&&mt.Connections.connections.forEach(function(n){const i=n[0],s=n[1],o=n[2];e.has(i)||e.set(i,{parents:[],children:[]});const a={ID:s,relationship:o};e.get(i).parents.push(a),e.has(s)||e.set(s,{parents:[],children:[]});const l={ID:i,relationship:o};e.get(s).children.push(l)}),e}parseImages(){const e={},t={};if("Video"in mt.Objects){const n=mt.Objects.Video;for(const i in n){const s=n[i],o=parseInt(i);if(e[o]=s.RelativeFilename||s.Filename,"Content"in s){const a=s.Content instanceof ArrayBuffer&&s.Content.byteLength>0,l=typeof s.Content=="string"&&s.Content!=="";if(a||l){const c=this.parseImage(n[i]);t[s.RelativeFilename||s.Filename]=c}}}}for(const n in e){const i=e[n];t[i]!==void 0?e[n]=t[i]:e[n]=e[n].split("\\").pop()}return e}parseImage(e){const t=e.Content,n=e.RelativeFilename||e.Filename,i=n.slice(n.lastIndexOf(".")+1).toLowerCase();let s;switch(i){case"bmp":s="image/bmp";break;case"jpg":case"jpeg":s="image/jpeg";break;case"png":s="image/png";break;case"tif":s="image/tiff";break;case"tga":this.manager.getHandler(".tga")===null&&console.warn("FBXLoader: TGA loader not found, skipping ",n),s="image/tga";break;default:console.warn('FBXLoader: Image type "'+i+'" is not supported.');return}if(typeof t=="string")return"data:"+s+";base64,"+t;{const o=new Uint8Array(t);return window.URL.createObjectURL(new Blob([o],{type:s}))}}parseTextures(e){const t=new Map;if("Texture"in mt.Objects){const n=mt.Objects.Texture;for(const i in n){const s=this.parseTexture(n[i],e);t.set(parseInt(i),s)}}return t}parseTexture(e,t){const n=this.loadTexture(e,t);n.ID=e.id,n.name=e.attrName;const i=e.WrapModeU,s=e.WrapModeV,o=i!==void 0?i.value:0,a=s!==void 0?s.value:0;if(n.wrapS=o===0?Pi:Bn,n.wrapT=a===0?Pi:Bn,"Scaling"in e){const l=e.Scaling.value;n.repeat.x=l[0],n.repeat.y=l[1]}if("Translation"in e){const l=e.Translation.value;n.offset.x=l[0],n.offset.y=l[1]}return n}loadTexture(e,t){const n=new Set(["tga","tif","tiff","exr","dds","hdr","ktx2"]),i=e.FileName.split(".").pop().toLowerCase(),s=n.has(i)?this.manager.getHandler(`.${i}`):this.textureLoader;if(!s)return console.warn(`FBXLoader: ${i.toUpperCase()} loader not found, creating placeholder texture for`,e.RelativeFilename),new qt;const o=s.path;o||s.setPath(this.textureLoader.path);const a=Zt.get(e.id).children;let l;a!==void 0&&a.length>0&&t[a[0].ID]!==void 0&&(l=t[a[0].ID],(l.indexOf("blob:")===0||l.indexOf("data:")===0)&&s.setPath(void 0));const c=s.load(l);return s.setPath(o),c}parseMaterials(e){const t=new Map;if("Material"in mt.Objects){const n=mt.Objects.Material;for(const i in n){const s=this.parseMaterial(n[i],e);s!==null&&t.set(parseInt(i),s)}}return t}parseMaterial(e,t){const n=e.id,i=e.attrName;let s=e.ShadingModel;if(typeof s=="object"&&(s=s.value),!Zt.has(n))return null;const o=this.parseParameters(e,t,n);let a;switch(s.toLowerCase()){case"phong":a=new kn;break;case"lambert":a=new Hr;break;default:console.warn('THREE.FBXLoader: unknown material type "%s". Defaulting to MeshPhongMaterial.',s),a=new kn;break}return a.setValues(o),a.name=i,a}parseParameters(e,t,n){const i={};e.BumpFactor&&(i.bumpScale=e.BumpFactor.value),e.Diffuse?i.color=rt.toWorkingColorSpace(new Ge().fromArray(e.Diffuse.value),xt):e.DiffuseColor&&(e.DiffuseColor.type==="Color"||e.DiffuseColor.type==="ColorRGB")&&(i.color=rt.toWorkingColorSpace(new Ge().fromArray(e.DiffuseColor.value),xt)),e.DisplacementFactor&&(i.displacementScale=e.DisplacementFactor.value),e.Emissive?i.emissive=rt.toWorkingColorSpace(new Ge().fromArray(e.Emissive.value),xt):e.EmissiveColor&&(e.EmissiveColor.type==="Color"||e.EmissiveColor.type==="ColorRGB")&&(i.emissive=rt.toWorkingColorSpace(new Ge().fromArray(e.EmissiveColor.value),xt)),e.EmissiveFactor&&(i.emissiveIntensity=parseFloat(e.EmissiveFactor.value)),i.opacity=1-(e.TransparencyFactor?parseFloat(e.TransparencyFactor.value):0),(i.opacity===1||i.opacity===0)&&(i.opacity=e.Opacity?parseFloat(e.Opacity.value):null,i.opacity===null&&(i.opacity=1-(e.TransparentColor?parseFloat(e.TransparentColor.value[0]):0))),i.opacity<1&&(i.transparent=!0),e.ReflectionFactor&&(i.reflectivity=e.ReflectionFactor.value),e.Shininess&&(i.shininess=e.Shininess.value),e.Specular?i.specular=rt.toWorkingColorSpace(new Ge().fromArray(e.Specular.value),xt):e.SpecularColor&&e.SpecularColor.type==="Color"&&(i.specular=rt.toWorkingColorSpace(new Ge().fromArray(e.SpecularColor.value),xt));const s=this;return Zt.get(n).children.forEach(function(o){const a=o.relationship;switch(a){case"Bump":i.bumpMap=s.getTexture(t,o.ID);break;case"Maya|TEX_ao_map":i.aoMap=s.getTexture(t,o.ID);break;case"DiffuseColor":case"Maya|TEX_color_map":i.map=s.getTexture(t,o.ID),i.map!==void 0&&(i.map.colorSpace=xt);break;case"DisplacementColor":i.displacementMap=s.getTexture(t,o.ID);break;case"EmissiveColor":i.emissiveMap=s.getTexture(t,o.ID),i.emissiveMap!==void 0&&(i.emissiveMap.colorSpace=xt);break;case"NormalMap":case"Maya|TEX_normal_map":i.normalMap=s.getTexture(t,o.ID);break;case"ReflectionColor":i.envMap=s.getTexture(t,o.ID),i.envMap!==void 0&&(i.envMap.mapping=oa,i.envMap.colorSpace=xt);break;case"SpecularColor":i.specularMap=s.getTexture(t,o.ID),i.specularMap!==void 0&&(i.specularMap.colorSpace=xt);break;case"TransparentColor":case"TransparencyFactor":i.alphaMap=s.getTexture(t,o.ID),i.transparent=!0;break;case"AmbientColor":case"ShininessExponent":case"SpecularFactor":case"VectorDisplacementColor":default:console.warn("THREE.FBXLoader: %s map is not supported in three.js, skipping texture.",a);break}}),i}getTexture(e,t){return"LayeredTexture"in mt.Objects&&t in mt.Objects.LayeredTexture&&(console.warn("THREE.FBXLoader: layered textures are not supported in three.js. Discarding all but first layer."),t=Zt.get(t).children[0].ID),e.get(t)}parseDeformers(){const e={},t={};if("Deformer"in mt.Objects){const n=mt.Objects.Deformer;for(const i in n){const s=n[i],o=Zt.get(parseInt(i));if(s.attrType==="Skin"){const a=this.parseSkeleton(o,n);a.ID=i,o.parents.length>1&&console.warn("THREE.FBXLoader: skeleton attached to more than one geometry is not supported."),a.geometryID=o.parents[0].ID,e[i]=a}else if(s.attrType==="BlendShape"){const a={id:i};a.rawTargets=this.parseMorphTargets(o,n),a.id=i,o.parents.length>1&&console.warn("THREE.FBXLoader: morph target attached to more than one geometry is not supported."),t[i]=a}}}return{skeletons:e,morphTargets:t}}parseSkeleton(e,t){const n=[];return e.children.forEach(function(i){const s=t[i.ID];if(s.attrType!=="Cluster")return;const o={ID:i.ID,indices:[],weights:[],transformLink:new Te().fromArray(s.TransformLink.a)};"Indexes"in s&&(o.indices=s.Indexes.a,o.weights=s.Weights.a),n.push(o)}),{rawBones:n,bones:[]}}parseMorphTargets(e,t){const n=[];for(let i=0;i<e.children.length;i++){const s=e.children[i],o=t[s.ID],a={name:o.attrName,initialWeight:o.DeformPercent,id:o.id,fullWeights:o.FullWeights.a};if(o.attrType!=="BlendShapeChannel")return;a.geoID=Zt.get(parseInt(s.ID)).children.filter(function(l){return l.relationship===void 0})[0].ID,n.push(a)}return n}parseScene(e,t,n){An=new Mt;const i=this.parseModels(e.skeletons,t,n),s=mt.Objects.Model,o=this;i.forEach(function(l){const c=s[l.ID];o.setLookAtProperties(l,c),Zt.get(l.ID).parents.forEach(function(u){const d=i.get(u.ID);d!==void 0&&d.add(l)}),l.parent===null&&An.add(l)}),this.bindSkeleton(e.skeletons,t,i),this.addGlobalSceneSettings(),An.traverse(function(l){if(l.userData.transformData){l.parent&&(l.userData.transformData.parentMatrix=l.parent.matrix,l.userData.transformData.parentMatrixWorld=l.parent.matrixWorld);const c=_f(l.userData.transformData);l.applyMatrix4(c),l.updateWorldMatrix()}});const a=new Yy().parse();An.children.length===1&&An.children[0].isGroup&&(An.children[0].animations=a,An=An.children[0]),An.animations=a}parseModels(e,t,n){const i=new Map,s=mt.Objects.Model;for(const o in s){const a=parseInt(o),l=s[o],c=Zt.get(a);let h=this.buildSkeleton(c,e,a,l.attrName);if(!h){switch(l.attrType){case"Camera":h=this.createCamera(c);break;case"Light":h=this.createLight(c);break;case"Mesh":h=this.createMesh(c,t,n);break;case"NurbsCurve":h=this.createCurve(c,t);break;case"LimbNode":case"Root":h=new ha;break;case"Null":default:h=new Mt;break}h.name=l.attrName?Rt.sanitizeNodeName(l.attrName):"",h.userData.originalName=l.attrName,h.ID=a}this.getTransformData(h,l),i.set(a,h)}return i}buildSkeleton(e,t,n,i){let s=null;return e.parents.forEach(function(o){for(const a in t){const l=t[a];l.rawBones.forEach(function(c,h){if(c.ID===o.ID){const u=s;s=new ha,s.matrixWorld.copy(c.transformLink),s.name=i?Rt.sanitizeNodeName(i):"",s.userData.originalName=i,s.ID=n,l.bones[h]=s,u!==null&&s.add(u)}})}}),s}createCamera(e){let t,n;if(e.children.forEach(function(i){const s=mt.Objects.NodeAttribute[i.ID];s!==void 0&&(n=s)}),n===void 0)t=new Ct;else{let i=0;n.CameraProjectionType!==void 0&&n.CameraProjectionType.value===1&&(i=1);let s=1;n.NearPlane!==void 0&&(s=n.NearPlane.value/1e3);let o=1e3;n.FarPlane!==void 0&&(o=n.FarPlane.value/1e3);let a=window.innerWidth,l=window.innerHeight;n.AspectWidth!==void 0&&n.AspectHeight!==void 0&&(a=n.AspectWidth.value,l=n.AspectHeight.value);const c=a/l;let h=45;n.FieldOfView!==void 0&&(h=n.FieldOfView.value);const u=n.FocalLength?n.FocalLength.value:null;switch(i){case 0:t=new Qt(h,c,s,o),u!==null&&t.setFocalLength(u);break;case 1:console.warn("THREE.FBXLoader: Orthographic cameras not supported yet."),t=new Ct;break;default:console.warn("THREE.FBXLoader: Unknown camera type "+i+"."),t=new Ct;break}}return t}createLight(e){let t,n;if(e.children.forEach(function(i){const s=mt.Objects.NodeAttribute[i.ID];s!==void 0&&(n=s)}),n===void 0)t=new Ct;else{let i;n.LightType===void 0?i=0:i=n.LightType.value;let s=16777215;n.Color!==void 0&&(s=rt.toWorkingColorSpace(new Ge().fromArray(n.Color.value),xt));let o=n.Intensity===void 0?1:n.Intensity.value/100;n.CastLightOnObject!==void 0&&n.CastLightOnObject.value===0&&(o=0);let a=0;n.FarAttenuationEnd!==void 0&&(n.EnableFarAttenuation!==void 0&&n.EnableFarAttenuation.value===0?a=0:a=n.FarAttenuationEnd.value);const l=1;switch(i){case 0:t=new yc(s,o,a,l);break;case 1:t=new pa(s,o);break;case 2:let c=Math.PI/3;n.InnerAngle!==void 0&&(c=St.degToRad(n.InnerAngle.value));let h=0;n.OuterAngle!==void 0&&(h=St.degToRad(n.OuterAngle.value),h=Math.max(h,1)),t=new Kd(s,o,a,c,h,l);break;default:console.warn("THREE.FBXLoader: Unknown light type "+n.LightType.value+", defaulting to a PointLight."),t=new yc(s,o);break}n.CastShadows!==void 0&&n.CastShadows.value===1&&(t.castShadow=!0)}return t}createMesh(e,t,n){let i,s=null,o=null;const a=[];if(e.children.forEach(function(l){t.has(l.ID)&&(s=t.get(l.ID)),n.has(l.ID)&&a.push(n.get(l.ID))}),a.length>1?o=a:a.length>0?o=a[0]:(o=new kn({name:Yn.DEFAULT_MATERIAL_NAME,color:13421772}),a.push(o)),"color"in s.attributes&&a.forEach(function(l){l.vertexColors=!0}),s.groups.length>0){let l=!1;for(let c=0,h=s.groups.length;c<h;c++){const u=s.groups[c];(u.materialIndex<0||u.materialIndex>=a.length)&&(u.materialIndex=a.length,l=!0)}if(l){const c=new kn;a.push(c)}}return s.FBX_Deformer?(i=new zd(s,o),i.normalizeSkinWeights()):i=new ve(s,o),i}createCurve(e,t){const n=e.children.reduce(function(s,o){return t.has(o.ID)&&(s=t.get(o.ID)),s},null),i=new jn({name:Yn.DEFAULT_MATERIAL_NAME,color:3342591,linewidth:1});return new Vn(n,i)}getTransformData(e,t){const n={};"InheritType"in t&&(n.inheritType=parseInt(t.InheritType.value)),"RotationOrder"in t?n.eulerOrder=Gr(t.RotationOrder.value):n.eulerOrder=Gr(0),"Lcl_Translation"in t&&(n.translation=t.Lcl_Translation.value),"PreRotation"in t&&(n.preRotation=t.PreRotation.value),"Lcl_Rotation"in t&&(n.rotation=t.Lcl_Rotation.value),"PostRotation"in t&&(n.postRotation=t.PostRotation.value),"Lcl_Scaling"in t&&(n.scale=t.Lcl_Scaling.value),"ScalingOffset"in t&&(n.scalingOffset=t.ScalingOffset.value),"ScalingPivot"in t&&(n.scalingPivot=t.ScalingPivot.value),"RotationOffset"in t&&(n.rotationOffset=t.RotationOffset.value),"RotationPivot"in t&&(n.rotationPivot=t.RotationPivot.value),e.userData.transformData=n}setLookAtProperties(e,t){"LookAtProperty"in t&&Zt.get(e.ID).children.forEach(function(i){if(i.relationship==="LookAtProperty"){const s=mt.Objects.Model[i.ID];if("Lcl_Translation"in s){const o=s.Lcl_Translation.value;e.target!==void 0?(e.target.position.fromArray(o),An.add(e.target)):e.lookAt(new I().fromArray(o))}}})}bindSkeleton(e,t,n){const i=this.parsePoseNodes();for(const s in e){const o=e[s];Zt.get(parseInt(o.ID)).parents.forEach(function(l){if(t.has(l.ID)){const c=l.ID;Zt.get(c).parents.forEach(function(u){n.has(u.ID)&&n.get(u.ID).bind(new va(o.bones),i[u.ID])})}})}}parsePoseNodes(){const e={};if("Pose"in mt.Objects){const t=mt.Objects.Pose;for(const n in t)if(t[n].attrType==="BindPose"&&t[n].NbPoseNodes>0){const i=t[n].PoseNode;Array.isArray(i)?i.forEach(function(s){e[s.Node]=new Te().fromArray(s.Matrix.a)}):e[i.Node]=new Te().fromArray(i.Matrix.a)}}return e}addGlobalSceneSettings(){if("GlobalSettings"in mt){if("AmbientColor"in mt.GlobalSettings){const e=mt.GlobalSettings.AmbientColor.value,t=e[0],n=e[1],i=e[2];if(t!==0||n!==0||i!==0){const s=new Ge().setRGB(t,n,i,xt);An.add(new Gc(s,1))}}"UnitScaleFactor"in mt.GlobalSettings&&(An.userData.unitScaleFactor=mt.GlobalSettings.UnitScaleFactor.value)}}}class qy{constructor(){this.negativeMaterialIndices=!1}parse(e){const t=new Map;if("Geometry"in mt.Objects){const n=mt.Objects.Geometry;for(const i in n){const s=Zt.get(parseInt(i)),o=this.parseGeometry(s,n[i],e);t.set(parseInt(i),o)}}return this.negativeMaterialIndices===!0&&console.warn("THREE.FBXLoader: The FBX file contains invalid (negative) material indices. The asset might not render as expected."),t}parseGeometry(e,t,n){switch(t.attrType){case"Mesh":return this.parseMeshGeometry(e,t,n);case"NurbsCurve":return this.parseNurbsGeometry(t)}}parseMeshGeometry(e,t,n){const i=n.skeletons,s=[],o=e.parents.map(function(u){return mt.Objects.Model[u.ID]});if(o.length===0)return;const a=e.children.reduce(function(u,d){return i[d.ID]!==void 0&&(u=i[d.ID]),u},null);e.children.forEach(function(u){n.morphTargets[u.ID]!==void 0&&s.push(n.morphTargets[u.ID])});const l=o[0],c={};"RotationOrder"in l&&(c.eulerOrder=Gr(l.RotationOrder.value)),"InheritType"in l&&(c.inheritType=parseInt(l.InheritType.value)),"GeometricTranslation"in l&&(c.translation=l.GeometricTranslation.value),"GeometricRotation"in l&&(c.rotation=l.GeometricRotation.value),"GeometricScaling"in l&&(c.scale=l.GeometricScaling.value);const h=_f(c);return this.genGeometry(t,a,s,h)}genGeometry(e,t,n,i){const s=new yt;e.attrName&&(s.name=e.attrName);const o=this.parseGeoNode(e,t),a=this.genBuffers(o),l=new Le(a.vertex,3);if(l.applyMatrix4(i),s.setAttribute("position",l),a.colors.length>0&&s.setAttribute("color",new Le(a.colors,3)),t&&(s.setAttribute("skinIndex",new Fc(a.weightsIndices,4)),s.setAttribute("skinWeight",new Le(a.vertexWeights,4)),s.FBX_Deformer=t),a.normal.length>0){const c=new lt().getNormalMatrix(i),h=new Le(a.normal,3);h.applyNormalMatrix(c),s.setAttribute("normal",h)}if(a.uvs.forEach(function(c,h){const u=h===0?"uv":`uv${h}`;s.setAttribute(u,new Le(a.uvs[h],2))}),o.material&&o.material.mappingType!=="AllSame"){let c=a.materialIndex[0],h=0;if(a.materialIndex.forEach(function(u,d){u!==c&&(s.addGroup(h,d-h,c),c=u,h=d)}),s.groups.length>0){const u=s.groups[s.groups.length-1],d=u.start+u.count;d!==a.materialIndex.length&&s.addGroup(d,a.materialIndex.length-d,c)}s.groups.length===0&&s.addGroup(0,a.materialIndex.length,a.materialIndex[0])}return this.addMorphTargets(s,e,n,i),s}parseGeoNode(e,t){const n={};if(n.vertexPositions=e.Vertices!==void 0?e.Vertices.a:[],n.vertexIndices=e.PolygonVertexIndex!==void 0?e.PolygonVertexIndex.a:[],e.LayerElementColor&&(n.color=this.parseVertexColors(e.LayerElementColor[0])),e.LayerElementMaterial&&(n.material=this.parseMaterialIndices(e.LayerElementMaterial[0])),e.LayerElementNormal&&(n.normal=this.parseNormals(e.LayerElementNormal[0])),e.LayerElementUV){n.uv=[];let i=0;for(;e.LayerElementUV[i];)e.LayerElementUV[i].UV&&n.uv.push(this.parseUVs(e.LayerElementUV[i])),i++}return n.weightTable={},t!==null&&(n.skeleton=t,t.rawBones.forEach(function(i,s){i.indices.forEach(function(o,a){n.weightTable[o]===void 0&&(n.weightTable[o]=[]),n.weightTable[o].push({id:s,weight:i.weights[a]})})})),n}genBuffers(e){const t={vertex:[],normal:[],colors:[],uvs:[],materialIndex:[],vertexWeights:[],weightsIndices:[]};let n=0,i=0,s=!1,o=[],a=[],l=[],c=[],h=[],u=[];const d=this;return e.vertexIndices.forEach(function(f,m){let v,g=!1;f<0&&(f=f^-1,g=!0);let p=[],M=[];if(o.push(f*3,f*3+1,f*3+2),e.color){const x=Go(m,n,f,e.color);l.push(x[0],x[1],x[2])}if(e.skeleton){if(e.weightTable[f]!==void 0&&e.weightTable[f].forEach(function(x){M.push(x.weight),p.push(x.id)}),M.length>4){s||(console.warn("THREE.FBXLoader: Vertex has more than 4 skinning weights assigned to vertex. Deleting additional weights."),s=!0);const x=[0,0,0,0],b=[0,0,0,0];M.forEach(function(D,R){let P=D,S=p[R];b.forEach(function(_,y,T){if(P>_){T[y]=P,P=_;const F=x[y];x[y]=S,S=F}})}),p=x,M=b}for(;M.length<4;)M.push(0),p.push(0);for(let x=0;x<4;++x)h.push(M[x]),u.push(p[x])}if(e.normal){const x=Go(m,n,f,e.normal);a.push(x[0],x[1],x[2])}e.material&&e.material.mappingType!=="AllSame"&&(v=Go(m,n,f,e.material)[0],v<0&&(d.negativeMaterialIndices=!0,v=0)),e.uv&&e.uv.forEach(function(x,b){const D=Go(m,n,f,x);c[b]===void 0&&(c[b]=[]),c[b].push(D[0]),c[b].push(D[1])}),i++,g&&(d.genFace(t,e,o,v,a,l,c,h,u,i),n++,i=0,o=[],a=[],l=[],c=[],h=[],u=[])}),t}getNormalNewell(e){const t=new I(0,0,0);for(let n=0;n<e.length;n++){const i=e[n],s=e[(n+1)%e.length];t.x+=(i.y-s.y)*(i.z+s.z),t.y+=(i.z-s.z)*(i.x+s.x),t.z+=(i.x-s.x)*(i.y+s.y)}return t.normalize(),t}getNormalTangentAndBitangent(e){const t=this.getNormalNewell(e),i=(Math.abs(t.z)>.5?new I(0,1,0):new I(0,0,1)).cross(t).normalize(),s=t.clone().cross(i).normalize();return{normal:t,tangent:i,bitangent:s}}flattenVertex(e,t,n){return new ye(e.dot(t),e.dot(n))}genFace(e,t,n,i,s,o,a,l,c,h){let u;if(h>3){const d=[],f=t.baseVertexPositions||t.vertexPositions;for(let p=0;p<n.length;p+=3)d.push(new I(f[n[p]],f[n[p+1]],f[n[p+2]]));const{tangent:m,bitangent:v}=this.getNormalTangentAndBitangent(d),g=[];for(const p of d)g.push(this.flattenVertex(p,m,v));u=zc.triangulateShape(g,[])}else u=[[0,1,2]];for(const[d,f,m]of u)e.vertex.push(t.vertexPositions[n[d*3]]),e.vertex.push(t.vertexPositions[n[d*3+1]]),e.vertex.push(t.vertexPositions[n[d*3+2]]),e.vertex.push(t.vertexPositions[n[f*3]]),e.vertex.push(t.vertexPositions[n[f*3+1]]),e.vertex.push(t.vertexPositions[n[f*3+2]]),e.vertex.push(t.vertexPositions[n[m*3]]),e.vertex.push(t.vertexPositions[n[m*3+1]]),e.vertex.push(t.vertexPositions[n[m*3+2]]),t.skeleton&&(e.vertexWeights.push(l[d*4]),e.vertexWeights.push(l[d*4+1]),e.vertexWeights.push(l[d*4+2]),e.vertexWeights.push(l[d*4+3]),e.vertexWeights.push(l[f*4]),e.vertexWeights.push(l[f*4+1]),e.vertexWeights.push(l[f*4+2]),e.vertexWeights.push(l[f*4+3]),e.vertexWeights.push(l[m*4]),e.vertexWeights.push(l[m*4+1]),e.vertexWeights.push(l[m*4+2]),e.vertexWeights.push(l[m*4+3]),e.weightsIndices.push(c[d*4]),e.weightsIndices.push(c[d*4+1]),e.weightsIndices.push(c[d*4+2]),e.weightsIndices.push(c[d*4+3]),e.weightsIndices.push(c[f*4]),e.weightsIndices.push(c[f*4+1]),e.weightsIndices.push(c[f*4+2]),e.weightsIndices.push(c[f*4+3]),e.weightsIndices.push(c[m*4]),e.weightsIndices.push(c[m*4+1]),e.weightsIndices.push(c[m*4+2]),e.weightsIndices.push(c[m*4+3])),t.color&&(e.colors.push(o[d*3]),e.colors.push(o[d*3+1]),e.colors.push(o[d*3+2]),e.colors.push(o[f*3]),e.colors.push(o[f*3+1]),e.colors.push(o[f*3+2]),e.colors.push(o[m*3]),e.colors.push(o[m*3+1]),e.colors.push(o[m*3+2])),t.material&&t.material.mappingType!=="AllSame"&&(e.materialIndex.push(i),e.materialIndex.push(i),e.materialIndex.push(i)),t.normal&&(e.normal.push(s[d*3]),e.normal.push(s[d*3+1]),e.normal.push(s[d*3+2]),e.normal.push(s[f*3]),e.normal.push(s[f*3+1]),e.normal.push(s[f*3+2]),e.normal.push(s[m*3]),e.normal.push(s[m*3+1]),e.normal.push(s[m*3+2])),t.uv&&t.uv.forEach(function(v,g){e.uvs[g]===void 0&&(e.uvs[g]=[]),e.uvs[g].push(a[g][d*2]),e.uvs[g].push(a[g][d*2+1]),e.uvs[g].push(a[g][f*2]),e.uvs[g].push(a[g][f*2+1]),e.uvs[g].push(a[g][m*2]),e.uvs[g].push(a[g][m*2+1])})}addMorphTargets(e,t,n,i){if(n.length===0)return;e.morphTargetsRelative=!0,e.morphAttributes.position=[];const s=this;n.forEach(function(o){o.rawTargets.forEach(function(a){const l=mt.Objects.Geometry[a.geoID];l!==void 0&&s.genMorphGeometry(e,t,l,i,a.name)})})}genMorphGeometry(e,t,n,i,s){const o=t.Vertices!==void 0?t.Vertices.a:[],a=t.PolygonVertexIndex!==void 0?t.PolygonVertexIndex.a:[],l=n.Vertices!==void 0?n.Vertices.a:[],c=n.Indexes!==void 0?n.Indexes.a:[],h=e.attributes.position.count*3,u=new Float32Array(h);for(let v=0;v<c.length;v++){const g=c[v]*3;u[g]=l[v*3],u[g+1]=l[v*3+1],u[g+2]=l[v*3+2]}const d={vertexIndices:a,vertexPositions:u,baseVertexPositions:o},f=this.genBuffers(d),m=new Le(f.vertex,3);m.name=s||n.attrName,m.applyMatrix4(i),e.morphAttributes.position.push(m)}parseNormals(e){const t=e.MappingInformationType,n=e.ReferenceInformationType,i=e.Normals.a;let s=[];return n==="IndexToDirect"&&("NormalIndex"in e?s=e.NormalIndex.a:"NormalsIndex"in e&&(s=e.NormalsIndex.a)),{dataSize:3,buffer:i,indices:s,mappingType:t,referenceType:n}}parseUVs(e){const t=e.MappingInformationType,n=e.ReferenceInformationType,i=e.UV.a;let s=[];return n==="IndexToDirect"&&(s=e.UVIndex.a),{dataSize:2,buffer:i,indices:s,mappingType:t,referenceType:n}}parseVertexColors(e){const t=e.MappingInformationType,n=e.ReferenceInformationType,i=e.Colors.a;let s=[];n==="IndexToDirect"&&(s=e.ColorIndex.a);for(let o=0,a=new Ge;o<i.length;o+=4)a.fromArray(i,o),rt.toWorkingColorSpace(a,xt),a.toArray(i,o);return{dataSize:4,buffer:i,indices:s,mappingType:t,referenceType:n}}parseMaterialIndices(e){const t=e.MappingInformationType,n=e.ReferenceInformationType;if(t==="NoMappingInformation")return{dataSize:1,buffer:[0],indices:[0],mappingType:"AllSame",referenceType:n};const i=e.Materials.a,s=[];for(let o=0;o<i.length;++o)s.push(o);return{dataSize:1,buffer:i,indices:s,mappingType:t,referenceType:n}}parseNurbsGeometry(e){const t=parseInt(e.Order);if(isNaN(t))return console.error("THREE.FBXLoader: Invalid Order %s given for geometry ID: %s",e.Order,e.id),new yt;const n=t-1,i=e.KnotVector.a,s=[],o=e.Points.a;for(let u=0,d=o.length;u<d;u+=4)s.push(new ct().fromArray(o,u));let a,l;if(e.Form==="Closed")s.push(s[0]);else if(e.Form==="Periodic"){a=n,l=i.length-1-a;for(let u=0;u<n;++u)s.push(s[u])}const h=new Ey(n,i,s,a,l).getPoints(s.length*12);return new yt().setFromPoints(h)}}class Yy{parse(){const e=[],t=this.parseClips();if(t!==void 0)for(const n in t){const i=t[n],s=this.addClip(i);e.push(s)}return e}parseClips(){if(mt.Objects.AnimationCurve===void 0)return;const e=this.parseAnimationCurveNodes();this.parseAnimationCurves(e);const t=this.parseAnimationLayers(e);return this.parseAnimStacks(t)}parseAnimationCurveNodes(){const e=mt.Objects.AnimationCurveNode,t=new Map;for(const n in e){const i=e[n];if(i.attrName.match(/S|R|T|DeformPercent/)!==null){const s={id:i.id,attr:i.attrName,curves:{}};t.set(s.id,s)}}return t}parseAnimationCurves(e){const t=mt.Objects.AnimationCurve;for(const n in t){const i={id:t[n].id,times:t[n].KeyTime.a.map(Qy),values:t[n].KeyValueFloat.a},s=Zt.get(i.id);if(s!==void 0){const o=s.parents[0].ID,a=s.parents[0].relationship;a.match(/X/)?e.get(o).curves.x=i:a.match(/Y/)?e.get(o).curves.y=i:a.match(/Z/)?e.get(o).curves.z=i:a.match(/DeformPercent/)&&e.has(o)&&(e.get(o).curves.morph=i)}}}parseAnimationLayers(e){const t=mt.Objects.AnimationLayer,n=new Map;for(const i in t){const s=[],o=Zt.get(parseInt(i));o!==void 0&&(o.children.forEach(function(l,c){if(e.has(l.ID)){const h=e.get(l.ID);if(h.curves.x!==void 0||h.curves.y!==void 0||h.curves.z!==void 0){if(s[c]===void 0){const u=Zt.get(l.ID).parents.filter(function(d){return d.relationship!==void 0})[0].ID;if(u!==void 0){const d=mt.Objects.Model[u.toString()];if(d===void 0){console.warn("THREE.FBXLoader: Encountered a unused curve.",l);return}const f={modelName:d.attrName?Rt.sanitizeNodeName(d.attrName):"",ID:d.id,initialPosition:[0,0,0],initialRotation:[0,0,0],initialScale:[1,1,1]};An.traverse(function(m){m.ID===d.id&&(f.transform=m.matrix,m.userData.transformData&&(f.eulerOrder=m.userData.transformData.eulerOrder))}),f.transform||(f.transform=new Te),"PreRotation"in d&&(f.preRotation=d.PreRotation.value),"PostRotation"in d&&(f.postRotation=d.PostRotation.value),s[c]=f}}s[c]&&(s[c][h.attr]=h)}else if(h.curves.morph!==void 0){if(s[c]===void 0){const u=Zt.get(l.ID).parents.filter(function(p){return p.relationship!==void 0})[0].ID,d=Zt.get(u).parents[0].ID,f=Zt.get(d).parents[0].ID,m=Zt.get(f).parents[0].ID,v=mt.Objects.Model[m],g={modelName:v.attrName?Rt.sanitizeNodeName(v.attrName):"",morphName:mt.Objects.Deformer[u].attrName};s[c]=g}s[c][h.attr]=h}}}),n.set(parseInt(i),s))}return n}parseAnimStacks(e){const t=mt.Objects.AnimationStack,n={};for(const i in t){const s=Zt.get(parseInt(i)).children;s.length>1&&console.warn("THREE.FBXLoader: Encountered an animation stack with multiple layers, this is currently not supported. Ignoring subsequent layers.");const o=e.get(s[0].ID);n[i]={name:t[i].attrName,layer:o}}return n}addClip(e){let t=[];const n=this;return e.layer.forEach(function(i){t=t.concat(n.generateTracks(i))}),new xc(e.name,-1,t)}generateTracks(e){const t=[];let n=new I,i=new I;if(e.transform&&e.transform.decompose(n,new Pt,i),n=n.toArray(),i=i.toArray(),e.T!==void 0&&Object.keys(e.T.curves).length>0){const s=this.generateVectorTrack(e.modelName,e.T.curves,n,"position");s!==void 0&&t.push(s)}if(e.R!==void 0&&Object.keys(e.R.curves).length>0){const s=this.generateRotationTrack(e.modelName,e.R.curves,e.preRotation,e.postRotation,e.eulerOrder);s!==void 0&&t.push(s)}if(e.S!==void 0&&Object.keys(e.S.curves).length>0){const s=this.generateVectorTrack(e.modelName,e.S.curves,i,"scale");s!==void 0&&t.push(s)}if(e.DeformPercent!==void 0){const s=this.generateMorphTrack(e);s!==void 0&&t.push(s)}return t}generateVectorTrack(e,t,n,i){const s=this.getTimesForAllAxes(t),o=this.getKeyframeTrackValues(s,t,n);return new Ss(e+"."+i,s,o)}generateRotationTrack(e,t,n,i,s){let o,a;if(t.x!==void 0&&t.y!==void 0&&t.z!==void 0){const d=this.interpolateRotations(t.x,t.y,t.z,s);o=d[0],a=d[1]}const l=Gr(0);n!==void 0&&(n=n.map(St.degToRad),n.push(l),n=new Kt().fromArray(n),n=new Pt().setFromEuler(n)),i!==void 0&&(i=i.map(St.degToRad),i.push(l),i=new Kt().fromArray(i),i=new Pt().setFromEuler(i).invert());const c=new Pt,h=new Kt,u=[];if(!a||!o)return new Ms(e+".quaternion",[0],[0]);for(let d=0;d<a.length;d+=3)h.set(a[d],a[d+1],a[d+2],s),c.setFromEuler(h),n!==void 0&&c.premultiply(n),i!==void 0&&c.multiply(i),d>2&&new Pt().fromArray(u,(d-3)/3*4).dot(c)<0&&c.set(-c.x,-c.y,-c.z,-c.w),c.toArray(u,d/3*4);return new Ms(e+".quaternion",o,u)}generateMorphTrack(e){const t=e.DeformPercent.curves.morph,n=t.values.map(function(s){return s/100}),i=An.getObjectByName(e.modelName).morphTargetDictionary[e.morphName];return new Vr(e.modelName+".morphTargetInfluences["+i+"]",t.times,n)}getTimesForAllAxes(e){let t=[];if(e.x!==void 0&&(t=t.concat(e.x.times)),e.y!==void 0&&(t=t.concat(e.y.times)),e.z!==void 0&&(t=t.concat(e.z.times)),t=t.sort(function(n,i){return n-i}),t.length>1){let n=1,i=t[0];for(let s=1;s<t.length;s++){const o=t[s];o!==i&&(t[n]=o,i=o,n++)}t=t.slice(0,n)}return t}getKeyframeTrackValues(e,t,n){const i=n,s=[];let o=-1,a=-1,l=-1;return e.forEach(function(c){if(t.x&&(o=t.x.times.indexOf(c)),t.y&&(a=t.y.times.indexOf(c)),t.z&&(l=t.z.times.indexOf(c)),o!==-1){const h=t.x.values[o];s.push(h),i[0]=h}else s.push(i[0]);if(a!==-1){const h=t.y.values[a];s.push(h),i[1]=h}else s.push(i[1]);if(l!==-1){const h=t.z.values[l];s.push(h),i[2]=h}else s.push(i[2])}),s}interpolateRotations(e,t,n,i){const s=[],o=[];s.push(e.times[0]),o.push(St.degToRad(e.values[0])),o.push(St.degToRad(t.values[0])),o.push(St.degToRad(n.values[0]));for(let a=1;a<e.values.length;a++){const l=[e.values[a-1],t.values[a-1],n.values[a-1]];if(isNaN(l[0])||isNaN(l[1])||isNaN(l[2]))continue;const c=l.map(St.degToRad),h=[e.values[a],t.values[a],n.values[a]];if(isNaN(h[0])||isNaN(h[1])||isNaN(h[2]))continue;const u=h.map(St.degToRad),d=[h[0]-l[0],h[1]-l[1],h[2]-l[2]],f=[Math.abs(d[0]),Math.abs(d[1]),Math.abs(d[2])];if(f[0]>=180||f[1]>=180||f[2]>=180){const v=Math.max(...f)/180,g=new Kt(...c,i),p=new Kt(...u,i),M=new Pt().setFromEuler(g),x=new Pt().setFromEuler(p);M.dot(x)&&x.set(-x.x,-x.y,-x.z,-x.w);const b=e.times[a-1],D=e.times[a]-b,R=new Pt,P=new Kt;for(let S=0;S<1;S+=1/v)R.copy(M.clone().slerp(x.clone(),S)),s.push(b+S*D),P.setFromQuaternion(R,i),o.push(P.x),o.push(P.y),o.push(P.z)}else s.push(e.times[a]),o.push(St.degToRad(e.values[a])),o.push(St.degToRad(t.values[a])),o.push(St.degToRad(n.values[a]))}return[s,o]}}class Zy{getPrevNode(){return this.nodeStack[this.currentIndent-2]}getCurrentNode(){return this.nodeStack[this.currentIndent-1]}getCurrentProp(){return this.currentProp}pushStack(e){this.nodeStack.push(e),this.currentIndent+=1}popStack(){this.nodeStack.pop(),this.currentIndent-=1}setCurrentProp(e,t){this.currentProp=e,this.currentPropName=t}parse(e){this.currentIndent=0,this.allNodes=new gf,this.nodeStack=[],this.currentProp=[],this.currentPropName="";const t=this,n=e.split(/[\r\n]+/);return n.forEach(function(i,s){const o=i.match(/^[\s\t]*;/),a=i.match(/^[\s\t]*$/);if(o||a)return;const l=i.match("^\\t{"+t.currentIndent+"}(\\w+):(.*){",""),c=i.match("^\\t{"+t.currentIndent+"}(\\w+):[\\s\\t\\r\\n](.*)"),h=i.match("^\\t{"+(t.currentIndent-1)+"}}");l?t.parseNodeBegin(i,l):c?t.parseNodeProperty(i,c,n[++s]):h?t.popStack():i.match(/^[^\s\t}]/)&&t.parseNodePropertyContinued(i)}),this.allNodes}parseNodeBegin(e,t){const n=t[1].trim().replace(/^"/,"").replace(/"$/,""),i=t[2].split(",").map(function(l){return l.trim().replace(/^"/,"").replace(/"$/,"")}),s={name:n},o=this.parseNodeAttr(i),a=this.getCurrentNode();this.currentIndent===0?this.allNodes.add(n,s):n in a?(n==="PoseNode"?a.PoseNode.push(s):a[n].id!==void 0&&(a[n]={},a[n][a[n].id]=a[n]),o.id!==""&&(a[n][o.id]=s)):typeof o.id=="number"?(a[n]={},a[n][o.id]=s):n!=="Properties70"&&(n==="PoseNode"?a[n]=[s]:a[n]=s),typeof o.id=="number"&&(s.id=o.id),o.name!==""&&(s.attrName=o.name),o.type!==""&&(s.attrType=o.type),this.pushStack(s)}parseNodeAttr(e){let t=e[0];e[0]!==""&&(t=parseInt(e[0]),isNaN(t)&&(t=e[0]));let n="",i="";return e.length>1&&(n=e[1].replace(/^(\w+)::/,""),i=e[2]),{id:t,name:n,type:i}}parseNodeProperty(e,t,n){let i=t[1].replace(/^"/,"").replace(/"$/,"").trim(),s=t[2].replace(/^"/,"").replace(/"$/,"").trim();i==="Content"&&s===","&&(s=n.replace(/"/g,"").replace(/,$/,"").trim());const o=this.getCurrentNode();if(o.name==="Properties70"){this.parseNodeSpecialProperty(e,i,s);return}if(i==="C"){const l=s.split(",").slice(1),c=parseInt(l[0]),h=parseInt(l[1]);let u=s.split(",").slice(3);u=u.map(function(d){return d.trim().replace(/^"/,"")}),i="connections",s=[c,h],tb(s,u),o[i]===void 0&&(o[i]=[])}i==="Node"&&(o.id=s),i in o&&Array.isArray(o[i])?o[i].push(s):i!=="a"?o[i]=s:o.a=s,this.setCurrentProp(o,i),i==="a"&&s.slice(-1)!==","&&(o.a=wl(s))}parseNodePropertyContinued(e){const t=this.getCurrentNode();t.a+=e,e.slice(-1)!==","&&(t.a=wl(t.a))}parseNodeSpecialProperty(e,t,n){const i=n.split('",').map(function(h){return h.trim().replace(/^\"/,"").replace(/\s/,"_")}),s=i[0],o=i[1],a=i[2],l=i[3];let c=i[4];switch(o){case"int":case"enum":case"bool":case"ULongLong":case"double":case"Number":case"FieldOfView":c=parseFloat(c);break;case"Color":case"ColorRGB":case"Vector3D":case"Lcl_Translation":case"Lcl_Rotation":case"Lcl_Scaling":c=wl(c);break}this.getPrevNode()[s]={type:o,type2:a,flag:l,value:c},this.setCurrentProp(this.getPrevNode(),s)}}class Ky{parse(e){const t=new Xu(e);t.skip(23);const n=t.getUint32();if(n<6400)throw new Error("THREE.FBXLoader: FBX version not supported, FileVersion: "+n);const i=new gf;for(;!this.endOfContent(t);){const s=this.parseNode(t,n);s!==null&&i.add(s.name,s)}return i}endOfContent(e){return e.size()%16===0?(e.getOffset()+160+16&-16)>=e.size():e.getOffset()+160+16>=e.size()}parseNode(e,t){const n={},i=t>=7500?e.getUint64():e.getUint32(),s=t>=7500?e.getUint64():e.getUint32();t>=7500?e.getUint64():e.getUint32();const o=e.getUint8(),a=e.getString(o);if(i===0)return null;const l=[];for(let d=0;d<s;d++)l.push(this.parseProperty(e));const c=l.length>0?l[0]:"",h=l.length>1?l[1]:"",u=l.length>2?l[2]:"";for(n.singleProperty=s===1&&e.getOffset()===i;i>e.getOffset();){const d=this.parseNode(e,t);d!==null&&this.parseSubNode(a,n,d)}return n.propertyList=l,typeof c=="number"&&(n.id=c),h!==""&&(n.attrName=h),u!==""&&(n.attrType=u),a!==""&&(n.name=a),n}parseSubNode(e,t,n){if(n.singleProperty===!0){const i=n.propertyList[0];Array.isArray(i)?(t[n.name]=n,n.a=i):t[n.name]=i}else if(e==="Connections"&&n.name==="C"){const i=[];n.propertyList.forEach(function(s,o){o!==0&&i.push(s)}),t.connections===void 0&&(t.connections=[]),t.connections.push(i)}else if(n.name==="Properties70")Object.keys(n).forEach(function(s){t[s]=n[s]});else if(e==="Properties70"&&n.name==="P"){let i=n.propertyList[0],s=n.propertyList[1];const o=n.propertyList[2],a=n.propertyList[3];let l;i.indexOf("Lcl ")===0&&(i=i.replace("Lcl ","Lcl_")),s.indexOf("Lcl ")===0&&(s=s.replace("Lcl ","Lcl_")),s==="Color"||s==="ColorRGB"||s==="Vector"||s==="Vector3D"||s.indexOf("Lcl_")===0?l=[n.propertyList[4],n.propertyList[5],n.propertyList[6]]:l=n.propertyList[4],t[i]={type:s,type2:o,flag:a,value:l}}else t[n.name]===void 0?typeof n.id=="number"?(t[n.name]={},t[n.name][n.id]=n):t[n.name]=n:n.name==="PoseNode"?(Array.isArray(t[n.name])||(t[n.name]=[t[n.name]]),t[n.name].push(n)):t[n.name][n.id]===void 0&&(t[n.name][n.id]=n)}parseProperty(e){const t=e.getString(1);let n;switch(t){case"C":return e.getBoolean();case"D":return e.getFloat64();case"F":return e.getFloat32();case"I":return e.getInt32();case"L":return e.getInt64();case"R":return n=e.getUint32(),e.getArrayBuffer(n);case"S":return n=e.getUint32(),e.getString(n);case"Y":return e.getInt16();case"b":case"c":case"d":case"f":case"i":case"l":const i=e.getUint32(),s=e.getUint32(),o=e.getUint32();if(s===0)switch(t){case"b":case"c":return e.getBooleanArray(i);case"d":return e.getFloat64Array(i);case"f":return e.getFloat32Array(i);case"i":return e.getInt32Array(i);case"l":return e.getInt64Array(i)}const a=ky(new Uint8Array(e.getArrayBuffer(o))),l=new Xu(a.buffer);switch(t){case"b":case"c":return l.getBooleanArray(i);case"d":return l.getFloat64Array(i);case"f":return l.getFloat32Array(i);case"i":return l.getInt32Array(i);case"l":return l.getInt64Array(i)}break;default:throw new Error("THREE.FBXLoader: Unknown property type "+t)}}}class Xu{constructor(e,t){this.dv=new DataView(e),this.offset=0,this.littleEndian=t!==void 0?t:!0,this._textDecoder=new TextDecoder}getOffset(){return this.offset}size(){return this.dv.buffer.byteLength}skip(e){this.offset+=e}getBoolean(){return(this.getUint8()&1)===1}getBooleanArray(e){const t=[];for(let n=0;n<e;n++)t.push(this.getBoolean());return t}getUint8(){const e=this.dv.getUint8(this.offset);return this.offset+=1,e}getInt16(){const e=this.dv.getInt16(this.offset,this.littleEndian);return this.offset+=2,e}getInt32(){const e=this.dv.getInt32(this.offset,this.littleEndian);return this.offset+=4,e}getInt32Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getInt32());return t}getUint32(){const e=this.dv.getUint32(this.offset,this.littleEndian);return this.offset+=4,e}getInt64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t&2147483648?(t=~t&4294967295,e=~e&4294967295,e===4294967295&&(t=t+1&4294967295),e=e+1&4294967295,-(t*4294967296+e)):t*4294967296+e}getInt64Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getInt64());return t}getUint64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t*4294967296+e}getFloat32(){const e=this.dv.getFloat32(this.offset,this.littleEndian);return this.offset+=4,e}getFloat32Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getFloat32());return t}getFloat64(){const e=this.dv.getFloat64(this.offset,this.littleEndian);return this.offset+=8,e}getFloat64Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getFloat64());return t}getArrayBuffer(e){const t=this.dv.buffer.slice(this.offset,this.offset+e);return this.offset+=e,t}getString(e){const t=this.offset;let n=new Uint8Array(this.dv.buffer,t,e);this.skip(e);const i=n.indexOf(0);return i>=0&&(n=new Uint8Array(this.dv.buffer,t,i)),this._textDecoder.decode(n)}}class gf{add(e,t){this[e]=t}}function $y(r){const e="Kaydara FBX Binary  \0";return r.byteLength>=e.length&&e===vf(r,0,e.length)}function Jy(r){const e=["K","a","y","d","a","r","a","\\","F","B","X","\\","B","i","n","a","r","y","\\","\\"];let t=0;function n(i){const s=r[i-1];return r=r.slice(t+i),t++,s}for(let i=0;i<e.length;++i)if(n(1)===e[i])return!1;return!0}function ju(r){const e=/FBXVersion: (\d+)/,t=r.match(e);if(t)return parseInt(t[1]);throw new Error("THREE.FBXLoader: Cannot find the version number for the file given.")}function Qy(r){return r/46186158e3}const eb=[];function Go(r,e,t,n){let i;switch(n.mappingType){case"ByPolygonVertex":i=r;break;case"ByPolygon":i=e;break;case"ByVertice":i=t;break;case"AllSame":i=n.indices[0];break;default:console.warn("THREE.FBXLoader: unknown attribute mapping type "+n.mappingType)}n.referenceType==="IndexToDirect"&&(i=n.indices[i]);const s=i*n.dataSize,o=s+n.dataSize;return nb(eb,n.buffer,s,o)}const Sl=new Kt,Xs=new I;function _f(r){const e=new Te,t=new Te,n=new Te,i=new Te,s=new Te,o=new Te,a=new Te,l=new Te,c=new Te,h=new Te,u=new Te,d=new Te,f=r.inheritType?r.inheritType:0;r.translation&&e.setPosition(Xs.fromArray(r.translation));const m=Gr(0);if(r.preRotation){const T=r.preRotation.map(St.degToRad);T.push(m),t.makeRotationFromEuler(Sl.fromArray(T))}if(r.rotation){const T=r.rotation.map(St.degToRad);T.push(r.eulerOrder||m),n.makeRotationFromEuler(Sl.fromArray(T))}if(r.postRotation){const T=r.postRotation.map(St.degToRad);T.push(m),i.makeRotationFromEuler(Sl.fromArray(T)),i.invert()}r.scale&&s.scale(Xs.fromArray(r.scale)),r.scalingOffset&&a.setPosition(Xs.fromArray(r.scalingOffset)),r.scalingPivot&&o.setPosition(Xs.fromArray(r.scalingPivot)),r.rotationOffset&&l.setPosition(Xs.fromArray(r.rotationOffset)),r.rotationPivot&&c.setPosition(Xs.fromArray(r.rotationPivot)),r.parentMatrixWorld&&(u.copy(r.parentMatrix),h.copy(r.parentMatrixWorld));const v=t.clone().multiply(n).multiply(i),g=new Te;g.extractRotation(h);const p=new Te;p.copyPosition(h);const M=p.clone().invert().multiply(h),x=g.clone().invert().multiply(M),b=s,D=new Te;if(f===0)D.copy(g).multiply(v).multiply(x).multiply(b);else if(f===1)D.copy(g).multiply(x).multiply(v).multiply(b);else{const F=new Te().scale(new I().setFromMatrixScale(u)).clone().invert(),k=x.clone().multiply(F);D.copy(g).multiply(v).multiply(k).multiply(b)}const R=c.clone().invert(),P=o.clone().invert();let S=e.clone().multiply(l).multiply(c).multiply(t).multiply(n).multiply(i).multiply(R).multiply(a).multiply(o).multiply(s).multiply(P);const _=new Te().copyPosition(S),y=h.clone().multiply(_);return d.copyPosition(y),S=d.clone().multiply(D),S.premultiply(h.invert()),S}function Gr(r){r=r||0;const e=["ZYX","YZX","XZY","ZXY","YXZ","XYZ"];return r===6?(console.warn("THREE.FBXLoader: unsupported Euler Order: Spherical XYZ. Animations and rotations may be incorrect."),e[0]):e[r]}function wl(r){return r.split(",").map(function(t){return parseFloat(t)})}function vf(r,e,t){return e===void 0&&(e=0),t===void 0&&(t=r.byteLength),new TextDecoder().decode(new Uint8Array(r,e,t))}function tb(r,e){for(let t=0,n=r.length,i=e.length;t<i;t++,n++)r[n]=e[t]}function nb(r,e,t,n){for(let i=t,s=0;i<n;i++,s++)r[s]=e[i];return r}const ib=/^[og]\s*(.+)?/,sb=/^mtllib /,rb=/^usemtl /,ob=/^usemap /,qu=/\s+/,Yu=new I,El=new I,Zu=new I,Ku=new I,Hn=new I,Wo=new Ge;function ab(){const r={objects:[],object:{},vertices:[],normals:[],colors:[],uvs:[],materials:{},materialLibraries:[],startObject:function(e,t){if(this.object&&this.object.fromDeclaration===!1){this.object.name=e,this.object.fromDeclaration=t!==!1;return}const n=this.object&&typeof this.object.currentMaterial=="function"?this.object.currentMaterial():void 0;if(this.object&&typeof this.object._finalize=="function"&&this.object._finalize(!0),this.object={name:e||"",fromDeclaration:t!==!1,geometry:{vertices:[],normals:[],colors:[],uvs:[],hasUVIndices:!1},materials:[],smooth:!0,startMaterial:function(i,s){const o=this._finalize(!1);o&&(o.inherited||o.groupCount<=0)&&this.materials.splice(o.index,1);const a={index:this.materials.length,name:i||"",mtllib:Array.isArray(s)&&s.length>0?s[s.length-1]:"",smooth:o!==void 0?o.smooth:this.smooth,groupStart:o!==void 0?o.groupEnd:0,groupEnd:-1,groupCount:-1,inherited:!1,clone:function(l){const c={index:typeof l=="number"?l:this.index,name:this.name,mtllib:this.mtllib,smooth:this.smooth,groupStart:0,groupEnd:-1,groupCount:-1,inherited:!1};return c.clone=this.clone.bind(c),c}};return this.materials.push(a),a},currentMaterial:function(){if(this.materials.length>0)return this.materials[this.materials.length-1]},_finalize:function(i){const s=this.currentMaterial();if(s&&s.groupEnd===-1&&(s.groupEnd=this.geometry.vertices.length/3,s.groupCount=s.groupEnd-s.groupStart,s.inherited=!1),i&&this.materials.length>1)for(let o=this.materials.length-1;o>=0;o--)this.materials[o].groupCount<=0&&this.materials.splice(o,1);return i&&this.materials.length===0&&this.materials.push({name:"",smooth:this.smooth}),s}},n&&n.name&&typeof n.clone=="function"){const i=n.clone(0);i.inherited=!0,this.object.materials.push(i)}this.objects.push(this.object)},finalize:function(){this.object&&typeof this.object._finalize=="function"&&this.object._finalize(!0)},parseVertexIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseNormalIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseUVIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/2)*2},addVertex:function(e,t,n){const i=this.vertices,s=this.object.geometry.vertices;s.push(i[e+0],i[e+1],i[e+2]),s.push(i[t+0],i[t+1],i[t+2]),s.push(i[n+0],i[n+1],i[n+2])},addVertexPoint:function(e){const t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addVertexLine:function(e){const t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addNormal:function(e,t,n){const i=this.normals,s=this.object.geometry.normals;s.push(i[e+0],i[e+1],i[e+2]),s.push(i[t+0],i[t+1],i[t+2]),s.push(i[n+0],i[n+1],i[n+2])},addFaceNormal:function(e,t,n){const i=this.vertices,s=this.object.geometry.normals;Yu.fromArray(i,e),El.fromArray(i,t),Zu.fromArray(i,n),Hn.subVectors(Zu,El),Ku.subVectors(Yu,El),Hn.cross(Ku),Hn.normalize(),s.push(Hn.x,Hn.y,Hn.z),s.push(Hn.x,Hn.y,Hn.z),s.push(Hn.x,Hn.y,Hn.z)},addColor:function(e,t,n){const i=this.colors,s=this.object.geometry.colors;i[e]!==void 0&&s.push(i[e+0],i[e+1],i[e+2]),i[t]!==void 0&&s.push(i[t+0],i[t+1],i[t+2]),i[n]!==void 0&&s.push(i[n+0],i[n+1],i[n+2])},addUV:function(e,t,n){const i=this.uvs,s=this.object.geometry.uvs;s.push(i[e+0],i[e+1]),s.push(i[t+0],i[t+1]),s.push(i[n+0],i[n+1])},addDefaultUV:function(){const e=this.object.geometry.uvs;e.push(0,0),e.push(0,0),e.push(0,0)},addUVLine:function(e){const t=this.uvs;this.object.geometry.uvs.push(t[e+0],t[e+1])},addFace:function(e,t,n,i,s,o,a,l,c){const h=this.vertices.length;let u=this.parseVertexIndex(e,h),d=this.parseVertexIndex(t,h),f=this.parseVertexIndex(n,h);if(this.addVertex(u,d,f),this.addColor(u,d,f),a!==void 0&&a!==""){const m=this.normals.length;u=this.parseNormalIndex(a,m),d=this.parseNormalIndex(l,m),f=this.parseNormalIndex(c,m),this.addNormal(u,d,f)}else this.addFaceNormal(u,d,f);if(i!==void 0&&i!==""){const m=this.uvs.length;u=this.parseUVIndex(i,m),d=this.parseUVIndex(s,m),f=this.parseUVIndex(o,m),this.addUV(u,d,f),this.object.geometry.hasUVIndices=!0}else this.addDefaultUV()},addPointGeometry:function(e){this.object.geometry.type="Points";const t=this.vertices.length;for(let n=0,i=e.length;n<i;n++){const s=this.parseVertexIndex(e[n],t);this.addVertexPoint(s),this.addColor(s)}},addLineGeometry:function(e,t){this.object.geometry.type="Line";const n=this.vertices.length,i=this.uvs.length;for(let s=0,o=e.length;s<o;s++)this.addVertexLine(this.parseVertexIndex(e[s],n));for(let s=0,o=t.length;s<o;s++)this.addUVLine(this.parseUVIndex(t[s],i))}};return r.startObject("",!1),r}class lb extends Yn{constructor(e){super(e),this.materials=null}load(e,t,n,i){const s=this,o=new qr(this.manager);o.setPath(this.path),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(a){try{t(s.parse(a))}catch(l){i?i(l):console.error(l),s.manager.itemError(e)}},n,i)}setMaterials(e){return this.materials=e,this}parse(e){const t=new ab;e.indexOf(`\r
`)!==-1&&(e=e.replace(/\r\n/g,`
`)),e.indexOf(`\\
`)!==-1&&(e=e.replace(/\\\n/g,""));const n=e.split(`
`);let i=[];for(let a=0,l=n.length;a<l;a++){const c=n[a].trimStart();if(c.length===0)continue;const h=c.charAt(0);if(h!=="#")if(h==="v"){const u=c.split(qu);switch(u[0]){case"v":t.vertices.push(parseFloat(u[1]),parseFloat(u[2]),parseFloat(u[3])),u.length>=7?(Wo.setRGB(parseFloat(u[4]),parseFloat(u[5]),parseFloat(u[6]),xt),t.colors.push(Wo.r,Wo.g,Wo.b)):t.colors.push(void 0,void 0,void 0);break;case"vn":t.normals.push(parseFloat(u[1]),parseFloat(u[2]),parseFloat(u[3]));break;case"vt":t.uvs.push(parseFloat(u[1]),parseFloat(u[2]));break}}else if(h==="f"){const d=c.slice(1).trim().split(qu),f=[];for(let v=0,g=d.length;v<g;v++){const p=d[v];if(p.length>0){const M=p.split("/");f.push(M)}}const m=f[0];for(let v=1,g=f.length-1;v<g;v++){const p=f[v],M=f[v+1];t.addFace(m[0],p[0],M[0],m[1],p[1],M[1],m[2],p[2],M[2])}}else if(h==="l"){const u=c.substring(1).trim().split(" ");let d=[];const f=[];if(c.indexOf("/")===-1)d=u;else for(let m=0,v=u.length;m<v;m++){const g=u[m].split("/");g[0]!==""&&d.push(g[0]),g[1]!==""&&f.push(g[1])}t.addLineGeometry(d,f)}else if(h==="p"){const d=c.slice(1).trim().split(" ");t.addPointGeometry(d)}else if((i=ib.exec(c))!==null){const u=(" "+i[0].slice(1).trim()).slice(1);t.startObject(u)}else if(rb.test(c))t.object.startMaterial(c.substring(7).trim(),t.materialLibraries);else if(sb.test(c))t.materialLibraries.push(c.substring(7).trim());else if(ob.test(c))console.warn('THREE.OBJLoader: Rendering identifier "usemap" not supported. Textures must be defined in MTL files.');else if(h==="s"){if(i=c.split(" "),i.length>1){const d=i[1].trim().toLowerCase();t.object.smooth=d!=="0"&&d!=="off"}else t.object.smooth=!0;const u=t.object.currentMaterial();u&&(u.smooth=t.object.smooth)}else{if(c==="\0")continue;console.warn('THREE.OBJLoader: Unexpected line: "'+c+'"')}}t.finalize();const s=new Mt;if(s.materialLibraries=[].concat(t.materialLibraries),!(t.objects.length===1&&t.objects[0].geometry.vertices.length===0)===!0)for(let a=0,l=t.objects.length;a<l;a++){const c=t.objects[a],h=c.geometry,u=c.materials,d=h.type==="Line",f=h.type==="Points";let m=!1;if(h.vertices.length===0)continue;const v=new yt;v.setAttribute("position",new Le(h.vertices,3)),h.normals.length>0&&v.setAttribute("normal",new Le(h.normals,3)),h.colors.length>0&&(m=!0,v.setAttribute("color",new Le(h.colors,3))),h.hasUVIndices===!0&&v.setAttribute("uv",new Le(h.uvs,2));const g=[];for(let M=0,x=u.length;M<x;M++){const b=u[M],D=b.name+"_"+b.smooth+"_"+m;let R=t.materials[D];if(this.materials!==null){if(R=this.materials.create(b.name),d&&R&&!(R instanceof jn)){const P=new jn;mi.prototype.copy.call(P,R),P.color.copy(R.color),R=P}else if(f&&R&&!(R instanceof Ji)){const P=new Ji({size:10,sizeAttenuation:!1});mi.prototype.copy.call(P,R),P.color.copy(R.color),P.map=R.map,R=P}}R===void 0&&(d?R=new jn:f?R=new Ji({size:1,sizeAttenuation:!1}):R=new kn,R.name=b.name,R.flatShading=!b.smooth,R.vertexColors=m,t.materials[D]=R),g.push(R)}let p;if(g.length>1){for(let M=0,x=u.length;M<x;M++){const b=u[M];v.addGroup(b.groupStart,b.groupCount,M)}d?p=new pr(v,g):f?p=new rr(v,g):p=new ve(v,g)}else d?p=new pr(v,g[0]):f?p=new rr(v,g[0]):p=new ve(v,g[0]);p.name=c.name,s.add(p)}else if(t.vertices.length>0){const a=new Ji({size:1,sizeAttenuation:!1}),l=new yt;l.setAttribute("position",new Le(t.vertices,3)),t.colors.length>0&&t.colors[0]!==void 0&&(l.setAttribute("color",new Le(t.colors,3)),a.vertexColors=!0);const c=new rr(l,a);s.add(c)}return s}}class cb extends Yn{constructor(e){super(e)}load(e,t,n,i){const s=this,o=new qr(this.manager);o.setPath(this.path),o.setResponseType("arraybuffer"),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(a){try{t(s.parse(a))}catch(l){i?i(l):console.error(l),s.manager.itemError(e)}},n,i)}parse(e){function t(c){const h=new DataView(c),u=32/8*3+32/8*3*3+16/8,d=h.getUint32(80,!0);if(80+32/8+d*u===h.byteLength)return!0;const m=[115,111,108,105,100];for(let v=0;v<5;v++)if(n(m,h,v))return!1;return!0}function n(c,h,u){for(let d=0,f=c.length;d<f;d++)if(c[d]!==h.getUint8(u+d))return!1;return!0}function i(c){const h=new DataView(c),u=h.getUint32(80,!0);let d,f,m,v=!1,g,p,M,x,b;for(let T=0;T<70;T++)h.getUint32(T,!1)==1129270351&&h.getUint8(T+4)==82&&h.getUint8(T+5)==61&&(v=!0,g=new Float32Array(u*3*3),p=h.getUint8(T+6)/255,M=h.getUint8(T+7)/255,x=h.getUint8(T+8)/255,b=h.getUint8(T+9)/255);const D=84,R=12*4+2,P=new yt,S=new Float32Array(u*3*3),_=new Float32Array(u*3*3),y=new Ge;for(let T=0;T<u;T++){const F=D+T*R,k=h.getFloat32(F,!0),G=h.getFloat32(F+4,!0),$=h.getFloat32(F+8,!0);if(v){const z=h.getUint16(F+48,!0);(z&32768)===0?(d=(z&31)/31,f=(z>>5&31)/31,m=(z>>10&31)/31):(d=p,f=M,m=x)}for(let z=1;z<=3;z++){const Y=F+z*12,H=T*3*3+(z-1)*3;S[H]=h.getFloat32(Y,!0),S[H+1]=h.getFloat32(Y+4,!0),S[H+2]=h.getFloat32(Y+8,!0),_[H]=k,_[H+1]=G,_[H+2]=$,v&&(y.setRGB(d,f,m,xt),g[H]=y.r,g[H+1]=y.g,g[H+2]=y.b)}}return P.setAttribute("position",new Rn(S,3)),P.setAttribute("normal",new Rn(_,3)),v&&(P.setAttribute("color",new Rn(g,3)),P.hasColors=!0,P.alpha=b),P}function s(c){const h=new yt,u=/solid([\s\S]*?)endsolid/g,d=/facet([\s\S]*?)endfacet/g,f=/solid\s(.+)/;let m=0;const v=/[\s]+([+-]?(?:\d*)(?:\.\d*)?(?:[eE][+-]?\d+)?)/.source,g=new RegExp("vertex"+v+v+v,"g"),p=new RegExp("normal"+v+v+v,"g"),M=[],x=[],b=[],D=new I;let R,P=0,S=0,_=0;for(;(R=u.exec(c))!==null;){S=_;const y=R[0],T=(R=f.exec(y))!==null?R[1]:"";for(b.push(T);(R=d.exec(y))!==null;){let G=0,$=0;const z=R[0];for(;(R=p.exec(z))!==null;)D.x=parseFloat(R[1]),D.y=parseFloat(R[2]),D.z=parseFloat(R[3]),$++;for(;(R=g.exec(z))!==null;)M.push(parseFloat(R[1]),parseFloat(R[2]),parseFloat(R[3])),x.push(D.x,D.y,D.z),G++,_++;$!==1&&console.error("THREE.STLLoader: Something isn't right with the normal of face number "+m),G!==3&&console.error("THREE.STLLoader: Something isn't right with the vertices of face number "+m),m++}const F=S,k=_-S;h.userData.groupNames=b,h.addGroup(F,k,P),P++}return h.setAttribute("position",new Le(M,3)),h.setAttribute("normal",new Le(x,3)),h}function o(c){return typeof c!="string"?new TextDecoder().decode(c):c}function a(c){if(typeof c=="string"){const h=new Uint8Array(c.length);for(let u=0;u<c.length;u++)h[u]=c.charCodeAt(u)&255;return h.buffer||h}else return c}const l=a(e);return t(l)?i(l):s(o(e))}}class wa extends Ct{constructor(e=document.createElement("div")){super(),this.isCSS2DObject=!0,this.element=e,this.element.style.position="absolute",this.element.style.userSelect="none",this.element.setAttribute("draggable",!1),this.center=new ye(.5,.5),this.addEventListener("removed",function(){this.traverse(function(t){t.element instanceof t.element.ownerDocument.defaultView.Element&&t.element.parentNode!==null&&t.element.remove()})})}copy(e,t){return super.copy(e,t),this.element=e.element.cloneNode(!0),this.center=e.center,this}}const js=new I,$u=new Te,Ju=new Te,Qu=new I,ed=new I;class hb{constructor(e={}){const t=this;let n,i,s,o;const a={objects:new WeakMap},l=e.element!==void 0?e.element:document.createElement("div");l.style.overflow="hidden",this.domElement=l,this.getSize=function(){return{width:n,height:i}},this.render=function(m,v){m.matrixWorldAutoUpdate===!0&&m.updateMatrixWorld(),v.parent===null&&v.matrixWorldAutoUpdate===!0&&v.updateMatrixWorld(),$u.copy(v.matrixWorldInverse),Ju.multiplyMatrices(v.projectionMatrix,$u),h(m,m,v),f(m)},this.setSize=function(m,v){n=m,i=v,s=n/2,o=i/2,l.style.width=m+"px",l.style.height=v+"px"};function c(m){m.isCSS2DObject&&(m.element.style.display="none");for(let v=0,g=m.children.length;v<g;v++)c(m.children[v])}function h(m,v,g){if(m.visible===!1){c(m);return}if(m.isCSS2DObject){js.setFromMatrixPosition(m.matrixWorld),js.applyMatrix4(Ju);const p=js.z>=-1&&js.z<=1&&m.layers.test(g.layers)===!0,M=m.element;M.style.display=p===!0?"":"none",p===!0&&(m.onBeforeRender(t,v,g),M.style.transform="translate("+-100*m.center.x+"%,"+-100*m.center.y+"%)translate("+(js.x*s+s)+"px,"+(-js.y*o+o)+"px)",M.parentNode!==l&&l.appendChild(M),m.onAfterRender(t,v,g));const x={distanceToCameraSquared:u(g,m)};a.objects.set(m,x)}for(let p=0,M=m.children.length;p<M;p++)h(m.children[p],v,g)}function u(m,v){return Qu.setFromMatrixPosition(m.matrixWorld),ed.setFromMatrixPosition(v.matrixWorld),Qu.distanceToSquared(ed)}function d(m){const v=[];return m.traverseVisible(function(g){g.isCSS2DObject&&v.push(g)}),v}function f(m){const v=d(m).sort(function(p,M){if(p.renderOrder!==M.renderOrder)return M.renderOrder-p.renderOrder;const x=a.objects.get(p).distanceToCameraSquared,b=a.objects.get(M).distanceToCameraSquared;return x-b}),g=v.length;for(let p=0,M=v.length;p<M;p++)v[p].element.style.zIndex=g-p}}}class ub{editor;enabled;radius;selectedPoints=new Set;deletedPoints=[];constructor(e){this.editor=e}deregisterEventListeners(){const e=this.editor.eventHandler.eventBus;e.off("eraser:toggled",this.handleEraserToggled),e.off("eraser:sizeChanged",this.handleSizeChanged),e.off("eraser:intersectionDetected",this.handleIntersectionDetected),e.off("eraser:intersectionsDetected",this.handleIntersectionDetected),e.off("eraser:unselectPoints",this.handleUnselectPoints),e.off("eraser:deletePoints",this.handleDeletePoints),e.off("eraser:restorePoints",this.handleRestorePoints)}dispose(){this.deregisterEventListeners()}erasePoints(e){const t=e.point,n=this.editor.pointsManager.cloudPoints,i=e.distance,s=this.getScreenDiagonal(13.5),o=this.radius*i/s,a=n.geometry.attributes.position.array,l=a.length/3,c=[];for(let u=0;u<l;u++){const d=a[u*3],f=a[u*3+1],m=a[u*3+2];Math.sqrt((d-t.x)**2+(f-t.y)**2+(m-t.z)**2)>o&&c.push([d.toString(),f.toString(),m.toString(),this.editor.pointsManager.cloudPointsData?this.editor.pointsManager.cloudPointsData[u][3]:"0"])}this.editor.pointsManager.cloudPointsData=c;const h=c.flatMap(u=>u.slice(0,3).map(parseFloat));n.geometry.setAttribute("position",new Le(h,3)),n.geometry.attributes.position.needsUpdate=!0}registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("eraser:toggled",this.handleEraserToggled),e.on("eraser:sizeChanged",this.handleSizeChanged),e.on("eraser:intersectionDetected",this.handleIntersectionDetected),e.on("eraser:intersectionsDetected",this.handleEraserIntersectionsDetected),e.on("eraser:unselectPoints",this.handleUnselectPoints),e.on("eraser:deletePoints",this.handleDeletePoints),e.on("eraser:restorePoints",this.handleRestorePoints)}selectPoints(e,t=16753920){for(const n of e)typeof n.index=="number"&&!this.selectedPoints.has(n.index)&&this.selectedPoints.add(n.index);this.selectedPoints.size&&this.highlightPoints(t)}unselectPoints(e=3800852){this.selectedPoints.size&&(this.highlightPoints(e),this.selectedPoints.clear())}deletePoints(){if(this.selectedPoints.size===0)return;const t=this.editor.pointsManager.cloudPoints.geometry.getAttribute("position"),n=this.editor.pointsManager.cloudPointsData,i=[],s=[];for(let o=0,a=t.count;o<a;o++){const l=[t.getX(o).toString(),t.getY(o).toString(),t.getZ(o).toString(),n[o][3].toString()];this.selectedPoints.has(o)?s.push(l):i.push(l)}this.deletedPoints.push(...s),this.editor.pointsManager.updateCloud(i),this.selectedPoints.clear()}restorePoints(){if(!this.deletedPoints.length)return;const e=this.editor.pointsManager.cloudPointsData,t=this.deletedPoints,n=new Array(e.length+this.deletedPoints.length);for(let i=0;i<e.length;i++)n[i]=e[i];for(let i=0;i<t.length;i++)n[e.length+i]=t[i];this.editor.pointsManager.updateCloud(n)}getScreenDiagonal(e=1){const t=window.innerWidth,n=window.innerHeight;return Math.sqrt(t**2+n**2)/e}handleEraserToggled=e=>{this.enabled=e,e||this.unselectPoints()};handleIntersectionDetected=e=>{this.erasePoints(e)};handleEraserIntersectionsDetected=e=>{this.selectPoints(e)};handleUnselectPoints=()=>{this.unselectPoints()};handleDeletePoints=()=>{this.deletePoints()};handleSizeChanged=e=>{this.radius=e};highlightPoints=e=>{const n=this.editor.pointsManager.cloudPoints.geometry.getAttribute("color"),[i,s,o]=this.toRGBArray(e);for(const a of this.selectedPoints)n.setXYZ(a,i,s,o);n.needsUpdate=!0};toRGBArray(e){const t=new Ge(e);return[t.r,t.g,t.b]}ensureVertexColors(e,t=16777215){const i=e.getAttribute("position").count;let s=e.getAttribute("color");if(!s||s.count!==i){const[o,a,l]=this.toRGBArray(t),c=new Float32Array(i*3);for(let u=0;u<i;u++)c[u*3]=o,c[u*3+1]=a,c[u*3+2]=l;s=new Le(c,3),e.setAttribute("color",s);const h=this.editor.pointsManager.cloudPointsMaterial;h.vertexColors||(h.vertexColors=!0,h.needsUpdate=!0)}}handleRestorePoints=()=>{this.restorePoints()}}function db(r){return{all:r=r||new Map,on:function(e,t){var n=r.get(e);n?n.push(t):r.set(e,[t])},off:function(e,t){var n=r.get(e);n&&(t?n.splice(n.indexOf(t)>>>0,1):r.set(e,[]))},emit:function(e,t){var n=r.get(e);n&&n.slice().map(function(i){i(t)}),(n=r.get("*"))&&n.slice().map(function(i){i(e,t)})}}}class fb{editor;eventBus;constructor(e){this.editor=e,this.eventBus=db()}registerEventListeners(){this.eventBus.on("objectRemoved",this.handleObjectRemoved),this.eventBus.on("topoLoaded",this.handleTopoLoaded),this.eventBus.on("quickAddNode",this.handleQuickAnnotation)}registerCanvasEventListeners(){const e=this.getCanvas();e&&e.addEventListener("mousedown",this.handleCanvasMouseDown)}deregisterEventListeners(){this.eventBus.off("objectRemoved",this.handleObjectRemoved),this.eventBus.off("topoLoaded",this.handleTopoLoaded),this.eventBus.off("quickAddNode",this.handleQuickAnnotation)}deregisterCanvasEventListeners(){const e=this.getCanvas();e&&e.removeEventListener("mousedown",this.handleCanvasMouseDown)}dispose(){this.deregisterEventListeners(),this.deregisterCanvasEventListeners()}handleTopoLoaded=e=>{this.editor.clear({clearCloud:!1,clearTopo:!0}),this.editor.drawTopo(e.topoData)};handleObjectRemoved=e=>{e.object.clear(),this.editor.nodeManager.removeAllLinksRelatedTo(e.object),this.editor.nodeManager.removeAllArrowsRelatedTo(e.object);const t=this.editor.selectableObjects.indexOf(e.object);t>-1&&this.editor.selectableObjects.splice(t,1)};handleQuickAnnotation=()=>{const e=this.editor.robotManager.mainRobot,t={x:e.position.x,y:e.position.y,z:e.position.z,rz:e.rotation.z};this.editor.nodeManager.addNode("GOAL",t)};handleCanvasMouseDown=()=>{const e=this.getCanvas();e&&e.focus()};getCanvas(){return document.querySelector("#three-canvas")}}const gs={GOAL:"GOAL",ROUTE:"ROUTE",INIT:"INIT"};class pb{editor;goalMesh;routeMesh;initMesh;constructor(e){this.editor=e}registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("mappingStarted",this.handleMappingStarted),e.on("mappingStopped",this.handleMappingStopped)}deRegisterEventListeners(){const e=this.editor.eventHandler.eventBus;e.off("mappingStarted",this.handleMappingStarted),e.off("mappingStopped",this.handleMappingStopped)}handleMappingStarted=()=>{this.toggleAllNodes(!1),this.toggleAllArrows(!1)};handleMappingStopped=()=>{this.toggleAllNodes(!0),this.toggleAllArrows(!0)};dispose(){}addLabel(e){const t=window.innerWidth<=768,n=document.createElement("div");n.className="nodeLabel italic text-base p-1 font-semibold rounded-sm",n.textContent=e.name,n.style.cssText=`
      background: #1e2337;
      color: #c0caf5;
      border-left: ${t?4:11}px solid #fa8c16;
    `;const i=new wa(n);i.visible=!0,i.userData.keep=!0,i.userData.labelType="node",i.name="label",i.center.set(0,-.5),e.add(i);const s={obj:i,bucket:null,worldPosition:null};this.editor.eventHandler.eventBus.emit("labelAdded",s)}addNode(e,t,n=null){let i=this.goalMesh;if(!i)return;e===gs.ROUTE?i=this.routeMesh:e===gs.INIT&&(i=this.initMesh);const s=i.clone();s.material=i.material.clone(),s.position.set(t.x,t.y,0),s.rotation.z=t.rz;const o=e===gs.GOAL?"G":e===gs.ROUTE?"R":"I";return s.name=`${o}_${s.id}`,s.userData.id=`N_${s.id}`,s.userData.type=e,s.userData.links=[],s.userData.links_from=[],s.userData.slamLinks=[],s.userData.slamLinks_from=[],s.userData.info="",n&&(s.rotation.z=n.rz*(Math.PI/180),s.name=n.name,s.userData.id=n.id,s.userData.info=n.info),this.addLabel(s),this.editor.zUpGroup.add(s),this.editor.selectableObjects.push(s),this.editor.eventHandler.eventBus.emit("nodeAdded",s),s}alignNodesByAxis(e,t){if(!this.editor.selectedObjects.length)return;const n=t==="min",i=n?Math.min:Math.max,s=n?1/0:-1/0,o=this.editor.selectedObjects.reduce((a,l)=>i(a,l.position[e]),s);for(let a=0,l=this.editor.selectedObjects.length;a<l;a++){const c=this.editor.selectedObjects[a];c.position[e]=o}this.updateLinks(),this.editor.eventHandler.eventBus.emit("objectTransformChanged")}alignNodesWithSpacing(e,t){if(!this.editor.selectedObjects.length)return;const n=this.editor.selectedObjects.map(o=>o.position[e]),i=e==="x"?Math.min(...n):Math.max(...n),s=e==="x"?1:-1;for(let o=0,a=this.editor.selectedObjects.length;o<a;o++){const l=this.editor.selectedObjects[o];l.position[e]=i+s*t*o}this.updateLinks(),this.editor.eventHandler.eventBus.emit("objectTransformChanged")}alignNodesTheta(){if(!this.editor.selectedObjects.length)return;let e=0,t=0;for(let i=0,s=this.editor.selectedObjects.length;i<s;i++){const a=this.editor.selectedObjects[i].rotation.z;e+=Math.sin(a),t+=Math.cos(a)}const n=Math.atan2(e,t);for(let i=0,s=this.editor.selectedObjects.length;i<s;i++){const o=this.editor.selectedObjects[i];o.rotation.z=n}}async cacheMeshes(){this.goalMesh=this.createBoxMesh(.68,.51,.19975,.75,new Ge(16753920),new Ge(4251856),{widthSegments:5}),this.routeMesh=this.createBoxMesh(.33,.33,.19975,.75,new Ge(6591981),new Ge(4251856),{widthSegments:5}),this.initMesh=this.createBoxMesh(.68,.51,.19975,.75,new Ge(6381921),new Ge(16777215),{widthSegments:5})}drawArrow(e,t,n=14540253){const i=e.position,s=t.position,o=new I().subVectors(s,i).normalize(),a=i.distanceTo(s),l=.55,c=new Jd(o,i,a-l,n);c.setLength(a-l,.2,.12),c.name=`${e.id}-${t.id}`,c.userData={from:e.id,to:t.id},this.editor.zUpGroup.add(c)}linkNodes(e,t){if(e.userData.links.includes(t.uuid))return;this.drawArrow(e,t);const n=[...e.userData.links];n.includes(t.uuid)||(n.push(t.uuid),e.userData.links=n);const i=[...t.userData.links_from];i.includes(e.uuid)||(i.push(e.uuid),t.userData.links_from=i);const s=[...e.userData.slamLinks];s.includes(t.userData.id)||(s.push(t.userData.id),e.userData.slamLinks=s);const o=[...t.userData.slamLinks_from];o.includes(e.userData.id)||(o.push(e.userData.id),t.userData.slamLinks_from=o)}toggleAllNodes=e=>{this.editor.selectableObjects.forEach(t=>{t.visible=e})};toggleAllArrows=e=>{this.editor.zUpGroup.traverse(t=>{t.type==="ArrowHelper"&&(t.visible=e)})};unlinkNodes(e,t){const n=this.editor.zUpGroup.getObjectByName(`${e.id}-${t.id}`);n&&(this.editor.zUpGroup.remove(n),this.removeDirectedLinksUserData(e,t));const i=this.editor.zUpGroup.getObjectByName(`${t.id}-${e.id}`);i&&(this.editor.zUpGroup.remove(i),this.removeDirectedLinksUserData(t,e))}updateLinks=()=>{const e=this.editor.selectedObjects;for(let t=0,n=e.length;t<n;t++){const i=e[t];this.removeAllArrowsRelatedTo(i);const s=i.userData.links,o=i.userData.links_from;for(let a=0;a<s.length;a++){const l=this.editor.zUpGroup.getObjectByProperty("uuid",s[a]);l&&this.drawArrow(i,l)}for(let a=0;a<o.length;a++){const l=this.editor.zUpGroup.getObjectByProperty("uuid",o[a]);l&&this.drawArrow(l,i)}}};updateNodeName(e){const t=this.editor.selected;t!==null&&(this.removeLabel(t),t.name=e,this.addLabel(t),this.editor.eventHandler.eventBus.emit("objectNameChanged",t.name))}removeAllArrowsRelatedTo=e=>{const t=[],n=this.editor.zUpGroup.children;for(let i=0,s=n.length;i<s;i++){const o=n[i];if(o.type!=="ArrowHelper")continue;const{from:a,to:l}=o.userData;(a===e.id||l===e.id)&&t.push(o)}for(let i=0;i<t.length;i++)this.editor.zUpGroup.remove(t[i])};removeAllLinksRelatedTo(e){if(!e.userData.links_from)return;e.userData.links_from.map(n=>this.editor.zUpGroup.getObjectByProperty("uuid",n)).filter(n=>n!=null).forEach(n=>{const i=n.userData.links.indexOf(e.uuid);i!==-1&&n.userData.links.splice(i,1);const s=n.userData.links_from.indexOf(e.uuid);s!==-1&&n.userData.links_from.splice(s,1);const o=n.userData.slamLinks.indexOf(e.userData.id);o!==-1&&n.userData.slamLinks.splice(o,1);const a=n.userData.slamLinks_from.indexOf(e.userData.id);a!==-1&&n.userData.slamLinks_from.splice(a,1)}),e.userData.links=[],e.userData.links_from=[],e.userData.slamLinks=[],e.userData.slamLinks_from=[]}removeLabel(e){e.traverse(t=>{t.name==="label"&&e.remove(t)})}transformNodes(e,t){if(!this.editor.selectedObjects.length)return;for(let s=0,o=this.editor.selectedObjects.length;s<o;s++){const a=this.editor.selectedObjects[s];switch(e){case"x":a.position.x+=t;break;case"y":a.position.y+=t;break;case"rz":{const l=t*Math.PI/180;a.rotation.z+=l;break}}}const n=this.editor.selectedObjects[this.editor.selectedObjects.length-1],i=St.radToDeg(n.rotation.z);this.editor.eventHandler.eventBus.emit("objectTransformChanged",{x:n.position.x.toString().slice(0,6),y:n.position.y.toString().slice(0,6),rz:i.toString().slice(0,6)})}transformNodesByInput(e,t){if(this.editor.selectedObjects.length===0)return;const n=Number(t);if(Number.isNaN(n))return;let i=0;e==="rz"&&(i=n*Math.PI/180);for(let a=0,l=this.editor.selectedObjects.length;a<l;a++){const c=this.editor.selectedObjects[a];switch(e){case"x":c.position.x=n;break;case"y":c.position.y=n;break;case"rz":c.rotation.z=i;break}}const s=this.editor.selectedObjects[this.editor.selectedObjects.length-1],o=St.radToDeg(s.rotation.z);this.editor.eventHandler.eventBus.emit("objectTransformChanged",{x:s.position.x.toString().slice(0,6),y:s.position.y.toString().slice(0,6),rz:o.toString().slice(0,6)})}createBoxMesh(e,t,n,i,s,o,a={}){const l=new Yt(e,t,n,a.widthSegments??1,a.heightSegments??1,a.depthSegments??1),c=[],h=-e/2,u=e/2,d=h+(u-h)*i;for(let m=0;m<l.attributes.position.count;m++){const v=new I;v.fromBufferAttribute(l.attributes.position,m);const g=v.x<=d?s:o;c.push(g.r,g.g,g.b)}l.setAttribute("color",new Le(c,3));const f=new qn({vertexColors:!0,transparent:!0});return new ve(l,f)}removeDirectedLinksUserData(e,t){const n=e.userData.links,i=n.indexOf(t.uuid);i!==-1&&n.splice(i,1);const s=t.userData.links_from,o=s.indexOf(e.uuid);o!==-1&&s.splice(o,1);const a=e.userData.slamLinks,l=a.indexOf(t.userData.id);l!==-1&&a.splice(l,1);const c=t.userData.slamLinks_from,h=c.indexOf(e.userData.id);h!==-1&&c.splice(h,1)}}const mb=.07,gb=.2,_b=.3,vb=3;class xb{editor;globalPath;globalPathMap;localPath;constructor(e){this.editor=e,this.globalPathMap=new Map;const t=new Ec,n=new ma({color:16711680,linewidth:mb,vertexColors:!1,worldUnits:!0,dashed:!1});this.globalPath=new Gu(t,n),this.globalPath.visible=!1;const i=new Ec,s=new ma({color:34812,linewidth:gb,vertexColors:!1,worldUnits:!0,dashed:!0,dashSize:_b,dashScale:vb});this.localPath=new Gu(i,s),this.localPath.visible=!1}dispose(){this.editor.eventHandler.eventBus.off("topoCleared",this.handleTopoCleared)}registerEventBusHandler(){this.editor.eventHandler.eventBus.on("topoCleared",this.handleTopoCleared)}updateLocalPath(e){if(e.length){const t=this.convertDataToPositions(e);this.localPath.geometry.setPositions(t),this.localPath.computeLineDistances(),this.localPath.visible=!0}else this.localPath.visible=!1}convertDataToPositions(e){return e.flatMap(t=>t.map(n=>{const i=Number(n);return isNaN(i)&&console.warn(`Invalid number conversion for value: ${n}`),i}))}handleTopoCleared=()=>{this.globalPathMap.clear()}}class $c{boundary;capacity;points;divided;children;constructor(e,t=20){this.boundary=e,this.capacity=t,this.points=[],this.divided=!1,this.children=[]}dispose(){if(this.divided)for(const e of this.children)e.dispose();this.points=[],this.children=[],this.boundary=null,this.divided=!1}insert(e,t){if(!this.boundary.containsPoint(e))return!1;if(this.points.length<this.capacity)return this.points.push({position:e.clone(),index:t}),!0;this.divided||this.subdivide();for(const n of this.children)if(n.insert(e,t))return!0;return!1}subdivide(){const{min:e,max:t}=this.boundary,n=new I().addVectors(e,t).multiplyScalar(.5);for(let i=0;i<2;i++)for(let s=0;s<2;s++)for(let o=0;o<2;o++){const a=new I(i===0?e.x:n.x,s===0?e.y:n.y,o===0?e.z:n.z),l=new I(i===0?n.x:t.x,s===0?n.y:t.y,o===0?n.z:t.z),c=new Cn(a,l);this.children.push(new $c(c,this.capacity))}for(const{position:i,index:s}of this.points)for(const o of this.children)if(o.insert(i,s))break;this.points=[],this.divided=!0}}class Jc{boundary;capacity;points;divided;children;constructor(e,t=8){this.boundary=e.clone(),this.capacity=t,this.points=[],this.divided=!1,this.children=[]}insert(e,t){if(!this.boundary.containsPoint(new ye(e.x,e.y)))return!1;if(!this.divided&&this.points.length<this.capacity)return this.points.push({position:e.clone(),index:t}),!0;this.divided||this.subdivide();for(const n of this.children)if(n.insert(e,t))return!0;return!1}subdivide(){const{min:e,max:t}=this.boundary,n=new ye((e.x+t.x)/2,(e.y+t.y)/2),i=[new Js(new ye(e.x,e.y),new ye(n.x,n.y)),new Js(new ye(n.x,e.y),new ye(t.x,n.y)),new Js(new ye(e.x,n.y),new ye(n.x,t.y)),new Js(new ye(n.x,n.y),new ye(t.x,t.y))];this.children=i.map(s=>new Jc(s,this.capacity));for(const{position:s,index:o}of this.points)for(const a of this.children)if(a.insert(s,o))break;this.points=[],this.divided=!0}queryRange(e,t=[]){if(!this.boundary.intersectsBox(e))return t;if(this.divided)for(const n of this.children)n.queryRange(e,t);else for(const n of this.points)e.containsPoint(new ye(n.position.x,n.position.y))&&t.push(n);return t}clear(){this.points=[];for(const e of this.children)e.clear();this.children=[],this.divided=!1}}const xf=r=>{const{protocol:e,hostname:t}=window.location;return`${e}//${t}:5177${r}`},Ea=r=>xf(`/models${r}`),yb=r=>xf(`/data/joint${r}`);class yf{constructor(e=120){this.cap=e}buf=[];push(e){this.buf.push(e),this.buf.length>this.cap&&this.buf.shift()}bracket(e){let t,n;for(let i=this.buf.length-1;i>=0;--i)if(this.buf[i].t<=e){t=this.buf[i],n=this.buf[i+1];break}return[t,n]}sampleTransform(e){const[t,n]=this.bracket(e),i=t,s=n;if(!i)return null;if(!s)return{...i,t:e};const o=(e-t.t)/(n.t-t.t||1e-6);return{t:e,x:this.lerpNum(i.x,s.x,o),y:this.lerpNum(i.y,s.y,o),rz:this.lerpAngleDeg(i.rz,s.rz,o)}}sampleJoint(e){const[t,n]=this.bracket(e),i=t,s=n;if(!i)return null;if(!s)return{...i,t:e};const o=(e-i.t)/(s.t-i.t||1e-6);return{t:e,map:this.lerpMap(i.map,s.map,o)}}lerpNum(e,t,n){return e+(t-e)*n}lerpAngleDeg(e,t,n){const i=(t-e+540)%360-180;return e+i*n}lerpMap(e,t,n){const i={};for(const s in t){const o=e?e[s]??t[s]:t[s];i[s]=this.lerpNum(o,t[s],n)}return i}}class bf extends Mt{transformBuf=new yf;tmpTransform=new I;clock=new $d;ROT_DAMP_RATE=5;jointBuf;constructor(){super()}pushTransformSnapshot(e){this.transformBuf.push(e)}pushJointsSnapshot(e,t=performance.now()/1e3){this.jointBuf&&this.jointBuf.push({t,map:e})}tick(e){const t=this.transformBuf.sampleTransform(e);if(t){this.tmpTransform.set(t.x,t.y,0),this.position.lerp(this.tmpTransform,.15);const n=this.clock.getDelta(),i=St.degToRad(t.rz),s=St.euclideanModulo(i-this.rotation.z+Math.PI,2*Math.PI)-Math.PI;this.rotation.z+=s*St.damp(0,1,this.ROT_DAMP_RATE,n)}if(this.jointBuf){const n=this.jointBuf.sampleJoint(e);n&&this.applyJointValues?.(n.map)}}}class Ta extends bf{static async create(){const e=new Ta;return await e._initAsync(),e}constructor(){super(),this.name="RB-S100",this.userData.keep=!0}async _initAsync(){const e=new mf,t=Ea("/s100low.fbx");try{const n=await e.loadAsync(t);n.traverse(i=>{if(i.userData.keep=!0,i instanceof ve){const s=i.material;Array.isArray(s)?i.material=s.map(o=>new Hr({color:o.color})):i.material=new Hr({color:s.color})}}),n.scale.setScalar(.1),n.rotation.set(Math.PI/2,0,0),n.updateMatrixWorld(!0),this.add(n)}catch(n){n instanceof Error?console.error("RB-S100 Load Failed:",n.message):console.error("RB-S100 Load Failed:",n)}}update(e){this.position.set(Number(e.x),Number(e.y),0),this.rotation.z=St.degToRad(Number(e.rz))}applyPose(e){const t={t:performance.now()*.001,x:Number(e.x),y:Number(e.y),rz:Number(e.rz)};this.pushTransformSnapshot(t)}}const hi=[{r:44/255,g:123/255,b:182/255},{r:171/255,g:217/255,b:233/255},{r:1,g:1,b:191/255},{r:253/255,g:174/255,b:97/255},{r:215/255,g:25/255,b:28/255}],bb=1024*3;class Mb{editor;pointsOctree=null;pointsQuadTree=null;mappingPoints=null;mappingPointsGeo;mappingPointsMat;cloudPoints;cloudPointsGeometry;cloudPointsMaterial;cloudPointsData;lidarPoints;lidarPointsGeometry;lidarPointsMaterial;lidarFloat32Array=new Float32Array;lidarPositionAttr;lastLidarSphereUpdateTime=0;sphereUpdateInterval=1e4;constructor(e){this.editor=e}registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("lidarUpdated",this.handleLidarUpdated),e.on("cloudLoaded",this.handleCloudLoaded),e.on("mappingStarted",this.handleMappingStarted),e.on("mappingStopped",this.handleMappingStopped),e.on("mappingDataReceived",this.handleMappingDataReceived),e.on("robotmanager:mainrobot:loaded",this.handleMainrobotLoaded),e.on("editor:initialized",this.handleEditorInitialized)}deregisterEventListeners(){const e=this.editor.eventHandler.eventBus;e.off("lidarUpdated",this.handleLidarUpdated),e.off("cloudLoaded",this.handleCloudLoaded),e.off("mappingStarted",this.handleMappingStarted),e.off("mappingStopped",this.handleMappingStopped),e.off("mappingDataReceived",this.handleMappingDataReceived),e.off("robotmanager:mainrobot:loaded",this.handleMainrobotLoaded),e.off("editor:initialized",this.handleEditorInitialized)}changeCloudOpacity(e){this.cloudPointsMaterial.opacity=e*.01}clearCloud(){this.cloudPointsGeometry.deleteAttribute("position"),this.cloudPointsGeometry.setAttribute("position",new Le([],3)),this.cloudPointsGeometry.boundingSphere=null,this.cloudPointsGeometry.attributes.position.needsUpdate=!0,this.cloudPointsData=[],this.editor.eventHandler.eventBus.emit("cloudCleared")}dispose(){this.pointsOctree&&(this.pointsOctree.dispose(),this.pointsOctree=null),this.cloudPointsGeometry.dispose(),this.cloudPointsMaterial.dispose(),this.cloudPointsData=null,this.lidarPointsGeometry.dispose(),this.lidarPointsMaterial.dispose(),this.deregisterEventListeners()}updateCloud(e){if(!this.cloudPointsGeometry)return;const{positions:t,numPoints:n}=this.updatePositions(e,"reset"),{boundaries:i}=this.calculateBoundaries(t,n);this.updateColors(i),this.finalizeUpdate(),this.createCloudQuadTree(),this.cloudPointsData=e}updateMappingPoints(e){!this.mappingPointsGeo||!this.mappingPointsMat||(this.updatePositions(e,"append"),this.mappingPointsGeo.attributes.position.needsUpdate=!0)}flattenCloud(){if(!this.cloudPointsGeometry)return;const e=this.cloudPointsGeometry.getAttribute("position");if(!e||!e.array.length){console.warn("[Flatten Cloud] No position attribute found in geometry.");return}for(let t=0;t<e.count;t++)e.setZ(t,0);this.finalizeUpdate()}restoreCloudDepth(){if(!this.cloudPointsGeometry)return;if(!this.cloudPointsData){console.warn("Original cloud data is missing.");return}const e=this.cloudPointsGeometry.getAttribute("position");if(!e||!e.array.length){console.warn("[Restore Cloud] Position attribute not found in geometry.");return}for(let t=0;t<this.cloudPointsData.length;t++){const n=this.cloudPointsData[t],i=parseFloat(n[2]);e.setZ(t,i)}this.finalizeUpdate()}calculateBoundaries(e,t){let n=1/0,i=-1/0;for(let a=0;a<t;a++){const l=e[a*3+2];l<n&&(n=l),l>i&&(i=l)}if(n===i)return{minZ:n,maxZ:i,boundaries:null};const s=i-n,o=[n,n+s*.2,n+s*.4,n+s*.6,n+s*.8,i];return{minZ:n,maxZ:i,boundaries:o}}createCloudOctree(){const e=this.cloudPointsGeometry.getAttribute("position"),t=new Cn().setFromBufferAttribute(e);t.expandByScalar(1);const n=new $c(t,20);for(let i=0;i<e.count;i++){const s=new I().fromBufferAttribute(e,i);n.insert(s,i)}this.pointsOctree=n}createCloudQuadTree(){const e=this.cloudPointsGeometry.getAttribute("position"),t=new Cn().setFromBufferAttribute(e),n=new Js(new ye(t.min.x,t.min.y),new ye(t.max.x,t.max.y));n.expandByScalar(1);const i=new Jc(n,20);for(let s=0;s<e.count;s++){const o=new I().fromBufferAttribute(e,s);i.insert(o,s)}this.pointsQuadTree=i}ensureCapacity(e){const t=this.lidarPositionAttr.array;if(e>t.length){const n=Math.max(e,t.length*2),i=new Float32Array(n);i.set(t),this.lidarPositionAttr.array=i}}finalizeUpdate(){this.cloudPointsGeometry.attributes.position.needsUpdate=!0,this.cloudPointsGeometry.computeBoundingSphere()}handleLidarUpdated=e=>{const t=this.transformLidarPointsToWorld(e.lidarPoints,e.pose);this.ensureCapacity(t.length),this.lidarPositionAttr.array.set(t),this.lidarPointsGeometry.setAttribute("position",this.lidarPositionAttr);const n=t.length/3;this.lidarPointsGeometry.setDrawRange(0,n),this.lidarPointsGeometry.attributes.position.needsUpdate=!0,this.shouldUpdateSphere()&&this.lidarPointsGeometry.computeBoundingSphere()};shouldUpdateSphere(){const e=performance.now();return e-this.lastLidarSphereUpdateTime>this.sphereUpdateInterval?(this.lastLidarSphereUpdateTime=e,!0):!1}updateColors(e){const t=this.cloudPointsGeometry,n=t.getAttribute("position"),i=n.count,s=n.array;let o=t.getAttribute("color");if((!o||o.count!==i)&&(o=new Le(new Float32Array(i*3),3),t.setAttribute("color",o)),!e){const a=.2235294117647059,l=255/255,c=20/255;for(let h=0;h<i;h++)o.setXYZ(h,a,l,c);o.needsUpdate=!0;return}for(let a=0;a<i;a++){const l=s[a*3+2];let c,h,u,d;l<e[1]?(c=hi[0],h=hi[1],u=e[0],d=e[1]):l<e[2]?(c=hi[1],h=hi[2],u=e[1],d=e[2]):l<e[3]?(c=hi[2],h=hi[3],u=e[2],d=e[3]):l<e[4]?(c=hi[3],h=hi[4],u=e[3],d=e[4]):(c=hi[4],h=hi[4],u=e[4],d=e[5]);const f=d-u||1;let m=(l-u)/f;m=Math.max(0,Math.min(1,m));const v=c.r*(1-m)+h.r*m,g=c.g*(1-m)+h.g*m,p=c.b*(1-m)+h.b*m;o.setXYZ(a,v,g,p)}o.needsUpdate=!0}transformLidarPointToWorld=(e,t)=>{const n=e[0],i=e[1],s=n*Math.cos(t.rz)-i*Math.sin(t.rz),o=n*Math.sin(t.rz)+i*Math.cos(t.rz),a=t.x+s,l=t.y+o;return[a,l,e[2]]};transformLidarPointsToWorld(e,t){return e.map(n=>{const[i,s,o]=n.slice(0,3).map(a=>parseFloat(a));return[i,s,o]}).map(n=>this.transformLidarPointToWorld(n,t)).flat()}updatePositions(e,t="reset"){const n=[];e.forEach(([a,l,c])=>{n.push(+a,+l,+c)});const i=t==="reset"?this.cloudPointsGeometry:this.mappingPointsGeo;let s;if(t==="reset")s=n;else{const a=i.getAttribute("position");s=(a?Array.from(a.array):[]).concat(n)}const o=new Le(s,3);return i.setAttribute("position",o),{positions:s,numPoints:s.length/3}}handleCloudLoaded=e=>{this.editor.clear({clearCloud:!0,clearTopo:!1}),this.updateCloud(e)};handleMappingStarted=()=>{this.handleMappingStopped(),this.cloudPoints.visible=!1,this.mappingPointsGeo=new yt,this.mappingPointsGeo.setAttribute("position",new Le([],3)),this.mappingPointsMat=new Ji({size:.07,color:8245247}),this.mappingPoints=new rr(this.mappingPointsGeo,this.mappingPointsMat),this.mappingPoints.userData.keep=!0,this.editor.zUpGroup.add(this.mappingPoints)};handleMappingStopped=()=>{this.cloudPoints.visible=!0,this.mappingPoints&&this.editor.zUpGroup.remove(this.mappingPoints),this.mappingPointsGeo?.dispose(),this.mappingPointsMat?.dispose(),this.mappingPoints=null};handleMappingDataReceived=e=>{this.updateMappingPoints(e)};handleMainrobotLoaded=()=>{const e=this.editor.robotManager.mainRobot;!e||!(e instanceof Ta)||this.editor.zUpGroup.add(this.lidarPoints)};lidarPointsToFloatArray=e=>{const t=e.length*3;this.lidarFloat32Array.length<t&&(this.lidarFloat32Array=new Float32Array(t*2));for(let n=0,i=0;n<e.length;n++,i+=3){const[s,o,a]=e[n];this.lidarFloat32Array[i]=+s,this.lidarFloat32Array[i+1]=+o,this.lidarFloat32Array[i+2]=+a}return this.lidarFloat32Array.subarray(0,t)};handleEditorInitialized=()=>{this.cloudPointsGeometry=new yt,this.cloudPointsGeometry.setAttribute("position",new Le([],3)),this.cloudPointsMaterial=new Ji({size:.15,vertexColors:!0,transparent:!0,opacity:1}),this.cloudPoints=new rr(this.cloudPointsGeometry,this.cloudPointsMaterial),this.cloudPoints.userData.keep=!0,this.editor.zUpGroup.add(this.cloudPoints),this.cloudPointsData=[],this.lidarPointsGeometry=new yt,this.lidarPointsMaterial=new Ji({size:.2,color:16725342}),this.lidarPoints=new rr(this.lidarPointsGeometry,this.lidarPointsMaterial),this.lidarPoints.userData.keep=!0,this.lidarPositionAttr=new Le(new Float32Array(bb),3)}}const td=new I,Sb=new Kt,Xo=new Te,ji=new Te,jo=new Pt,qo=new I(1,1,1),Yo=new I;class Aa extends Ct{constructor(...e){super(...e),this.urdfNode=null,this.urdfName=""}copy(e,t){return super.copy(e,t),this.urdfNode=e.urdfNode,this.urdfName=e.urdfName,this}}class wb extends Aa{constructor(...e){super(...e),this.isURDFCollider=!0,this.type="URDFCollider"}}class Eb extends Aa{constructor(...e){super(...e),this.isURDFVisual=!0,this.type="URDFVisual"}}class Mf extends Aa{constructor(...e){super(...e),this.isURDFLink=!0,this.type="URDFLink"}}class Sf extends Aa{get jointType(){return this._jointType}set jointType(e){if(this.jointType!==e)switch(this._jointType=e,this.matrixWorldNeedsUpdate=!0,e){case"fixed":this.jointValue=[];break;case"continuous":case"revolute":case"prismatic":this.jointValue=new Array(1).fill(0);break;case"planar":this.jointValue=new Array(3).fill(0),this.axis=new I(0,0,1);break;case"floating":this.jointValue=new Array(6).fill(0);break}}get angle(){return this.jointValue[0]}constructor(...e){super(...e),this.isURDFJoint=!0,this.type="URDFJoint",this.jointValue=null,this.jointType="fixed",this.axis=new I(1,0,0),this.limit={lower:0,upper:0},this.ignoreLimits=!1,this.origPosition=null,this.origQuaternion=null,this.mimicJoints=[]}copy(e,t){return super.copy(e,t),this.jointType=e.jointType,this.axis=e.axis.clone(),this.limit.lower=e.limit.lower,this.limit.upper=e.limit.upper,this.ignoreLimits=!1,this.jointValue=[...e.jointValue],this.origPosition=e.origPosition?e.origPosition.clone():null,this.origQuaternion=e.origQuaternion?e.origQuaternion.clone():null,this.mimicJoints=[...e.mimicJoints],this}setJointValue(...e){e=e.map(n=>n===null?null:parseFloat(n)),(!this.origPosition||!this.origQuaternion)&&(this.origPosition=this.position.clone(),this.origQuaternion=this.quaternion.clone());let t=!1;switch(this.mimicJoints.forEach(n=>{t=n.updateFromMimickedJoint(...e)||t}),this.jointType){case"fixed":return t;case"continuous":case"revolute":{let n=e[0];return n==null||n===this.jointValue[0]?t:(!this.ignoreLimits&&this.jointType==="revolute"&&(n=Math.min(this.limit.upper,n),n=Math.max(this.limit.lower,n)),this.quaternion.setFromAxisAngle(this.axis,n).premultiply(this.origQuaternion),this.jointValue[0]!==n?(this.jointValue[0]=n,this.matrixWorldNeedsUpdate=!0,!0):t)}case"prismatic":{let n=e[0];return n==null||n===this.jointValue[0]?t:(this.ignoreLimits||(n=Math.min(this.limit.upper,n),n=Math.max(this.limit.lower,n)),this.position.copy(this.origPosition),td.copy(this.axis).applyEuler(this.rotation),this.position.addScaledVector(td,n),this.jointValue[0]!==n?(this.jointValue[0]=n,this.matrixWorldNeedsUpdate=!0,!0):t)}case"floating":return this.jointValue.every((n,i)=>e[i]===n||e[i]===null)?t:(this.jointValue[0]=e[0]!==null?e[0]:this.jointValue[0],this.jointValue[1]=e[1]!==null?e[1]:this.jointValue[1],this.jointValue[2]=e[2]!==null?e[2]:this.jointValue[2],this.jointValue[3]=e[3]!==null?e[3]:this.jointValue[3],this.jointValue[4]=e[4]!==null?e[4]:this.jointValue[4],this.jointValue[5]=e[5]!==null?e[5]:this.jointValue[5],ji.compose(this.origPosition,this.origQuaternion,qo),jo.setFromEuler(Sb.set(this.jointValue[3],this.jointValue[4],this.jointValue[5],"XYZ")),Yo.set(this.jointValue[0],this.jointValue[1],this.jointValue[2]),Xo.compose(Yo,jo,qo),ji.premultiply(Xo),this.position.setFromMatrixPosition(ji),this.rotation.setFromRotationMatrix(ji),this.matrixWorldNeedsUpdate=!0,!0);case"planar":return this.jointValue.every((n,i)=>e[i]===n||e[i]===null)?t:(this.jointValue[0]=e[0]!==null?e[0]:this.jointValue[0],this.jointValue[1]=e[1]!==null?e[1]:this.jointValue[1],this.jointValue[2]=e[2]!==null?e[2]:this.jointValue[2],ji.compose(this.origPosition,this.origQuaternion,qo),jo.setFromAxisAngle(this.axis,this.jointValue[2]),Yo.set(this.jointValue[0],this.jointValue[1],0),Xo.compose(Yo,jo,qo),ji.premultiply(Xo),this.position.setFromMatrixPosition(ji),this.rotation.setFromRotationMatrix(ji),this.matrixWorldNeedsUpdate=!0,!0)}return t}}class nd extends Sf{constructor(...e){super(...e),this.type="URDFMimicJoint",this.mimicJoint=null,this.offset=0,this.multiplier=1}updateFromMimickedJoint(...e){const t=e.map(n=>n*this.multiplier+this.offset);return super.setJointValue(...t)}copy(e,t){return super.copy(e,t),this.mimicJoint=e.mimicJoint,this.offset=e.offset,this.multiplier=e.multiplier,this}}class Tb extends Mf{constructor(...e){super(...e),this.isURDFRobot=!0,this.urdfNode=null,this.urdfRobotNode=null,this.robotName=null,this.links=null,this.joints=null,this.colliders=null,this.visual=null,this.frames=null}copy(e,t){super.copy(e,t),this.urdfRobotNode=e.urdfRobotNode,this.robotName=e.robotName,this.links={},this.joints={},this.colliders={},this.visual={},this.traverse(n=>{n.isURDFJoint&&n.urdfName in e.joints&&(this.joints[n.urdfName]=n),n.isURDFLink&&n.urdfName in e.links&&(this.links[n.urdfName]=n),n.isURDFCollider&&n.urdfName in e.colliders&&(this.colliders[n.urdfName]=n),n.isURDFVisual&&n.urdfName in e.visual&&(this.visual[n.urdfName]=n)});for(const n in this.joints)this.joints[n].mimicJoints=this.joints[n].mimicJoints.map(i=>this.joints[i.name]);return this.frames={...this.colliders,...this.visual,...this.links,...this.joints},this}getFrame(e){return this.frames[e]}setJointValue(e,...t){const n=this.joints[e];return n?n.setJointValue(...t):!1}setJointValues(e){let t=!1;for(const n in e){const i=e[n];Array.isArray(i)?t=this.setJointValue(n,...i)||t:t=this.setJointValue(n,i)||t}return t}}const Tl=new Pt,id=new Kt;function qs(r){return r?r.trim().split(/\s+/g).map(e=>parseFloat(e)):[0,0,0]}function sd(r,e,t=!1){t||r.rotation.set(0,0,0),id.set(e[0],e[1],e[2],"ZYX"),Tl.setFromEuler(id),Tl.multiply(r.quaternion),r.quaternion.copy(Tl)}class Ab{constructor(e){this.manager=e||Zd,this.loadMeshCb=this.defaultMeshLoader.bind(this),this.parseVisual=!0,this.parseCollision=!1,this.packages="",this.workingPath="",this.fetchOptions={}}loadAsync(e){return new Promise((t,n)=>{this.load(e,t,null,n)})}load(e,t,n,i){const s=this.manager,o=Wc.extractUrlBase(e),a=this.manager.resolveURL(e);s.itemStart(a),fetch(a,this.fetchOptions).then(l=>{if(l.ok)return n&&n(null),l.text();throw new Error(`URDFLoader: Failed to load url '${a}' with error code ${l.status} : ${l.statusText}.`)}).then(l=>{const c=this.parse(l,this.workingPath||o);t(c),s.itemEnd(a)}).catch(l=>{i?i(l):console.error("URDFLoader: Error loading file.",l),s.itemError(a),s.itemEnd(a)})}parse(e,t=this.workingPath){const n=this.packages,i=this.loadMeshCb,s=this.parseVisual,o=this.parseCollision,a=this.manager,l={},c={},h={};function u(M){if(!/^package:\/\//.test(M))return t?t+M:M;const[x,b]=M.replace(/^package:\/\//,"").split(/\/(.+)/);if(typeof n=="string")return n.endsWith(x)?n+"/"+b:n+"/"+x+"/"+b;if(n instanceof Function)return n(x)+"/"+b;if(typeof n=="object")return x in n?n[x]+"/"+b:(console.error(`URDFLoader : ${x} not found in provided package list.`),null)}function d(M){let x;M instanceof Document?x=[...M.children]:M instanceof Element?x=[M]:x=[...new DOMParser().parseFromString(M,"text/xml").children];const b=x.filter(D=>D.nodeName==="robot").pop();return f(b)}function f(M){const x=[...M.children],b=x.filter(T=>T.nodeName.toLowerCase()==="link"),D=x.filter(T=>T.nodeName.toLowerCase()==="joint"),R=x.filter(T=>T.nodeName.toLowerCase()==="material"),P=new Tb;P.robotName=M.getAttribute("name"),P.urdfRobotNode=M,R.forEach(T=>{const F=T.getAttribute("name");h[F]=g(T)});const S={},_={};b.forEach(T=>{const F=T.getAttribute("name"),k=M.querySelector(`child[link="${F}"]`)===null;l[F]=v(T,S,_,k?P:null)}),D.forEach(T=>{const F=T.getAttribute("name");c[F]=m(T)}),P.joints=c,P.links=l,P.colliders=_,P.visual=S;const y=Object.values(c);return y.forEach(T=>{T instanceof nd&&c[T.mimicJoint].mimicJoints.push(T)}),y.forEach(T=>{const F=new Set,k=G=>{if(F.has(G))throw new Error("URDFLoader: Detected an infinite loop of mimic joints.");F.add(G),G.mimicJoints.forEach($=>{k($)})};k(T)}),P.frames={..._,...S,...l,...c},P}function m(M){const x=[...M.children],b=M.getAttribute("type");let D;const R=x.find(F=>F.nodeName.toLowerCase()==="mimic");R?(D=new nd,D.mimicJoint=R.getAttribute("joint"),D.multiplier=parseFloat(R.getAttribute("multiplier")||1),D.offset=parseFloat(R.getAttribute("offset")||0)):D=new Sf,D.urdfNode=M,D.name=M.getAttribute("name"),D.urdfName=D.name,D.jointType=b;let P=null,S=null,_=[0,0,0],y=[0,0,0];x.forEach(F=>{const k=F.nodeName.toLowerCase();k==="origin"?(_=qs(F.getAttribute("xyz")),y=qs(F.getAttribute("rpy"))):k==="child"?S=l[F.getAttribute("link")]:k==="parent"?P=l[F.getAttribute("link")]:k==="limit"&&(D.limit.lower=parseFloat(F.getAttribute("lower")||D.limit.lower),D.limit.upper=parseFloat(F.getAttribute("upper")||D.limit.upper))}),P.add(D),D.add(S),sd(D,y),D.position.set(_[0],_[1],_[2]);const T=x.filter(F=>F.nodeName.toLowerCase()==="axis")[0];if(T){const F=T.getAttribute("xyz").split(/\s+/g).map(k=>parseFloat(k));D.axis=new I(F[0],F[1],F[2]),D.axis.normalize()}return D}function v(M,x,b,D=null){D===null&&(D=new Mf);const R=[...M.children];return D.name=M.getAttribute("name"),D.urdfName=D.name,D.urdfNode=M,s&&R.filter(S=>S.nodeName.toLowerCase()==="visual").forEach(S=>{const _=p(S,h);if(D.add(_),S.hasAttribute("name")){const y=S.getAttribute("name");_.name=y,_.urdfName=y,x[y]=_}}),o&&R.filter(S=>S.nodeName.toLowerCase()==="collision").forEach(S=>{const _=p(S);if(D.add(_),S.hasAttribute("name")){const y=S.getAttribute("name");_.name=y,_.urdfName=y,b[y]=_}}),D}function g(M){const x=[...M.children],b=new kn;return b.name=M.getAttribute("name")||"",x.forEach(D=>{const R=D.nodeName.toLowerCase();if(R==="color"){const P=D.getAttribute("rgba").split(/\s/g).map(S=>parseFloat(S));b.color.setRGB(P[0],P[1],P[2]),b.opacity=P[3],b.transparent=P[3]<1,b.depthWrite=!b.transparent}else if(R==="texture"){const P=D.getAttribute("filename");if(P){const S=new Ma(a),_=u(P);b.map=S.load(_),b.map.colorSpace=xt}}}),b}function p(M,x={}){const b=M.nodeName.toLowerCase()==="collision",D=[...M.children];let R=null;const P=D.filter(_=>_.nodeName.toLowerCase()==="material")[0];if(P){const _=P.getAttribute("name");_&&_ in x?R=x[_]:R=g(P)}else R=new kn;const S=b?new wb:new Eb;return S.urdfNode=M,D.forEach(_=>{const y=_.nodeName.toLowerCase();if(y==="geometry"){const T=_.children[0].nodeName.toLowerCase();if(T==="mesh"){const F=_.children[0].getAttribute("filename"),k=u(F);if(k!==null){const G=_.children[0].getAttribute("scale");if(G){const $=qs(G);S.scale.set($[0],$[1],$[2])}i(k,a,($,z)=>{z?console.error("URDFLoader: Error loading mesh.",z):$&&($ instanceof ve&&($.material=R),$.position.set(0,0,0),$.quaternion.identity(),S.add($))})}}else if(T==="box"){const F=new ve;F.geometry=new Yt(1,1,1),F.material=R;const k=qs(_.children[0].getAttribute("size"));F.scale.set(k[0],k[1],k[2]),S.add(F)}else if(T==="sphere"){const F=new ve;F.geometry=new jr(1,30,30),F.material=R;const k=parseFloat(_.children[0].getAttribute("radius"))||0;F.scale.set(k,k,k),S.add(F)}else if(T==="cylinder"){const F=new ve;F.geometry=new cn(1,1,1,30),F.material=R;const k=parseFloat(_.children[0].getAttribute("radius"))||0,G=parseFloat(_.children[0].getAttribute("length"))||0;F.scale.set(k,G,k),F.rotation.set(Math.PI/2,0,0),S.add(F)}}else if(y==="origin"){const T=qs(_.getAttribute("xyz")),F=qs(_.getAttribute("rpy"));S.position.set(T[0],T[1],T[2]),S.rotation.set(0,0,0),sd(S,F)}}),S}return d(e)}defaultMeshLoader(e,t,n){/\.stl$/i.test(e)?new cb(t).load(e,s=>{const o=new ve(s,new kn);n(o)}):/\.dae$/i.test(e)?new Xy(t).load(e,s=>n(s.scene)):console.warn(`URDFLoader: Could not load model at ${e}.
No loader available`)}}var sa={exports:{}};/* @license
Papa Parse
v5.5.3
https://github.com/mholt/PapaParse
License: MIT
*/var Rb=sa.exports,rd;function Cb(){return rd||(rd=1,function(r,e){((t,n)=>{r.exports=n()})(Rb,function t(){var n=typeof self<"u"?self:typeof window<"u"?window:n!==void 0?n:{},i,s=!n.document&&!!n.postMessage,o=n.IS_PAPA_WORKER||!1,a={},l=0,c={};function h(S){this._handle=null,this._finished=!1,this._completed=!1,this._halted=!1,this._input=null,this._baseIndex=0,this._partialLine="",this._rowCount=0,this._start=0,this._nextChunk=null,this.isFirstChunk=!0,this._completeResults={data:[],errors:[],meta:{}},function(_){var y=D(_);y.chunkSize=parseInt(y.chunkSize),_.step||_.chunk||(y.chunkSize=null),this._handle=new v(y),(this._handle.streamer=this)._config=y}.call(this,S),this.parseChunk=function(_,y){var T=parseInt(this._config.skipFirstNLines)||0;if(this.isFirstChunk&&0<T){let k=this._config.newline;k||(F=this._config.quoteChar||'"',k=this._handle.guessLineEndings(_,F)),_=[..._.split(k).slice(T)].join(k)}this.isFirstChunk&&P(this._config.beforeFirstChunk)&&(F=this._config.beforeFirstChunk(_))!==void 0&&(_=F),this.isFirstChunk=!1,this._halted=!1;var T=this._partialLine+_,F=(this._partialLine="",this._handle.parse(T,this._baseIndex,!this._finished));if(!this._handle.paused()&&!this._handle.aborted()){if(_=F.meta.cursor,T=(this._finished||(this._partialLine=T.substring(_-this._baseIndex),this._baseIndex=_),F&&F.data&&(this._rowCount+=F.data.length),this._finished||this._config.preview&&this._rowCount>=this._config.preview),o)n.postMessage({results:F,workerId:c.WORKER_ID,finished:T});else if(P(this._config.chunk)&&!y){if(this._config.chunk(F,this._handle),this._handle.paused()||this._handle.aborted())return void(this._halted=!0);this._completeResults=F=void 0}return this._config.step||this._config.chunk||(this._completeResults.data=this._completeResults.data.concat(F.data),this._completeResults.errors=this._completeResults.errors.concat(F.errors),this._completeResults.meta=F.meta),this._completed||!T||!P(this._config.complete)||F&&F.meta.aborted||(this._config.complete(this._completeResults,this._input),this._completed=!0),T||F&&F.meta.paused||this._nextChunk(),F}this._halted=!0},this._sendError=function(_){P(this._config.error)?this._config.error(_):o&&this._config.error&&n.postMessage({workerId:c.WORKER_ID,error:_,finished:!1})}}function u(S){var _;(S=S||{}).chunkSize||(S.chunkSize=c.RemoteChunkSize),h.call(this,S),this._nextChunk=s?function(){this._readChunk(),this._chunkLoaded()}:function(){this._readChunk()},this.stream=function(y){this._input=y,this._nextChunk()},this._readChunk=function(){if(this._finished)this._chunkLoaded();else{if(_=new XMLHttpRequest,this._config.withCredentials&&(_.withCredentials=this._config.withCredentials),s||(_.onload=R(this._chunkLoaded,this),_.onerror=R(this._chunkError,this)),_.open(this._config.downloadRequestBody?"POST":"GET",this._input,!s),this._config.downloadRequestHeaders){var y,T=this._config.downloadRequestHeaders;for(y in T)_.setRequestHeader(y,T[y])}var F;this._config.chunkSize&&(F=this._start+this._config.chunkSize-1,_.setRequestHeader("Range","bytes="+this._start+"-"+F));try{_.send(this._config.downloadRequestBody)}catch(k){this._chunkError(k.message)}s&&_.status===0&&this._chunkError()}},this._chunkLoaded=function(){_.readyState===4&&(_.status<200||400<=_.status?this._chunkError():(this._start+=this._config.chunkSize||_.responseText.length,this._finished=!this._config.chunkSize||this._start>=(y=>(y=y.getResponseHeader("Content-Range"))!==null?parseInt(y.substring(y.lastIndexOf("/")+1)):-1)(_),this.parseChunk(_.responseText)))},this._chunkError=function(y){y=_.statusText||y,this._sendError(new Error(y))}}function d(S){(S=S||{}).chunkSize||(S.chunkSize=c.LocalChunkSize),h.call(this,S);var _,y,T=typeof FileReader<"u";this.stream=function(F){this._input=F,y=F.slice||F.webkitSlice||F.mozSlice,T?((_=new FileReader).onload=R(this._chunkLoaded,this),_.onerror=R(this._chunkError,this)):_=new FileReaderSync,this._nextChunk()},this._nextChunk=function(){this._finished||this._config.preview&&!(this._rowCount<this._config.preview)||this._readChunk()},this._readChunk=function(){var F=this._input,k=(this._config.chunkSize&&(k=Math.min(this._start+this._config.chunkSize,this._input.size),F=y.call(F,this._start,k)),_.readAsText(F,this._config.encoding));T||this._chunkLoaded({target:{result:k}})},this._chunkLoaded=function(F){this._start+=this._config.chunkSize,this._finished=!this._config.chunkSize||this._start>=this._input.size,this.parseChunk(F.target.result)},this._chunkError=function(){this._sendError(_.error)}}function f(S){var _;h.call(this,S=S||{}),this.stream=function(y){return _=y,this._nextChunk()},this._nextChunk=function(){var y,T;if(!this._finished)return y=this._config.chunkSize,_=y?(T=_.substring(0,y),_.substring(y)):(T=_,""),this._finished=!_,this.parseChunk(T)}}function m(S){h.call(this,S=S||{});var _=[],y=!0,T=!1;this.pause=function(){h.prototype.pause.apply(this,arguments),this._input.pause()},this.resume=function(){h.prototype.resume.apply(this,arguments),this._input.resume()},this.stream=function(F){this._input=F,this._input.on("data",this._streamData),this._input.on("end",this._streamEnd),this._input.on("error",this._streamError)},this._checkIsFinished=function(){T&&_.length===1&&(this._finished=!0)},this._nextChunk=function(){this._checkIsFinished(),_.length?this.parseChunk(_.shift()):y=!0},this._streamData=R(function(F){try{_.push(typeof F=="string"?F:F.toString(this._config.encoding)),y&&(y=!1,this._checkIsFinished(),this.parseChunk(_.shift()))}catch(k){this._streamError(k)}},this),this._streamError=R(function(F){this._streamCleanUp(),this._sendError(F)},this),this._streamEnd=R(function(){this._streamCleanUp(),T=!0,this._streamData("")},this),this._streamCleanUp=R(function(){this._input.removeListener("data",this._streamData),this._input.removeListener("end",this._streamEnd),this._input.removeListener("error",this._streamError)},this)}function v(S){var _,y,T,F,k=Math.pow(2,53),G=-k,$=/^\s*-?(\d+\.?|\.\d+|\d+\.\d+)([eE][-+]?\d+)?\s*$/,z=/^((\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z)))$/,Y=this,H=0,q=0,ue=!1,re=!1,de=[],ie={data:[],errors:[],meta:{}};function W(ce){return S.skipEmptyLines==="greedy"?ce.join("").trim()==="":ce.length===1&&ce[0].length===0}function Z(){if(ie&&T&&(ne("Delimiter","UndetectableDelimiter","Unable to auto-detect delimiting character; defaulted to '"+c.DefaultDelimiter+"'"),T=!1),S.skipEmptyLines&&(ie.data=ie.data.filter(function(Ne){return!W(Ne)})),Q()){let Ne=function(Je,We){P(S.transformHeader)&&(Je=S.transformHeader(Je,We)),de.push(Je)};if(ie)if(Array.isArray(ie.data[0])){for(var ce=0;Q()&&ce<ie.data.length;ce++)ie.data[ce].forEach(Ne);ie.data.splice(0,1)}else ie.data.forEach(Ne)}function Me(Ne,Je){for(var We=S.header?{}:[],B=0;B<Ne.length;B++){var ht=B,Pe=Ne[B],Pe=((tt,me)=>(Qe=>(S.dynamicTypingFunction&&S.dynamicTyping[Qe]===void 0&&(S.dynamicTyping[Qe]=S.dynamicTypingFunction(Qe)),(S.dynamicTyping[Qe]||S.dynamicTyping)===!0))(tt)?me==="true"||me==="TRUE"||me!=="false"&&me!=="FALSE"&&((Qe=>{if($.test(Qe)&&(Qe=parseFloat(Qe),G<Qe&&Qe<k))return 1})(me)?parseFloat(me):z.test(me)?new Date(me):me===""?null:me):me)(ht=S.header?B>=de.length?"__parsed_extra":de[B]:ht,Pe=S.transform?S.transform(Pe,ht):Pe);ht==="__parsed_extra"?(We[ht]=We[ht]||[],We[ht].push(Pe)):We[ht]=Pe}return S.header&&(B>de.length?ne("FieldMismatch","TooManyFields","Too many fields: expected "+de.length+" fields but parsed "+B,q+Je):B<de.length&&ne("FieldMismatch","TooFewFields","Too few fields: expected "+de.length+" fields but parsed "+B,q+Je)),We}var we;ie&&(S.header||S.dynamicTyping||S.transform)&&(we=1,!ie.data.length||Array.isArray(ie.data[0])?(ie.data=ie.data.map(Me),we=ie.data.length):ie.data=Me(ie.data,0),S.header&&ie.meta&&(ie.meta.fields=de),q+=we)}function Q(){return S.header&&de.length===0}function ne(ce,Me,we,Ne){ce={type:ce,code:Me,message:we},Ne!==void 0&&(ce.row=Ne),ie.errors.push(ce)}P(S.step)&&(F=S.step,S.step=function(ce){ie=ce,Q()?Z():(Z(),ie.data.length!==0&&(H+=ce.data.length,S.preview&&H>S.preview?y.abort():(ie.data=ie.data[0],F(ie,Y))))}),this.parse=function(ce,Me,we){var Ne=S.quoteChar||'"',Ne=(S.newline||(S.newline=this.guessLineEndings(ce,Ne)),T=!1,S.delimiter?P(S.delimiter)&&(S.delimiter=S.delimiter(ce),ie.meta.delimiter=S.delimiter):((Ne=((Je,We,B,ht,Pe)=>{var tt,me,Qe,ke;Pe=Pe||[",","	","|",";",c.RECORD_SEP,c.UNIT_SEP];for(var O=0;O<Pe.length;O++){for(var A,K=Pe[O],ae=0,he=0,se=0,Re=(Qe=void 0,new p({comments:ht,delimiter:K,newline:We,preview:10}).parse(Je)),xe=0;xe<Re.data.length;xe++)B&&W(Re.data[xe])?se++:(A=Re.data[xe].length,he+=A,Qe===void 0?Qe=A:0<A&&(ae+=Math.abs(A-Qe),Qe=A));0<Re.data.length&&(he/=Re.data.length-se),(me===void 0||ae<=me)&&(ke===void 0||ke<he)&&1.99<he&&(me=ae,tt=K,ke=he)}return{successful:!!(S.delimiter=tt),bestDelimiter:tt}})(ce,S.newline,S.skipEmptyLines,S.comments,S.delimitersToGuess)).successful?S.delimiter=Ne.bestDelimiter:(T=!0,S.delimiter=c.DefaultDelimiter),ie.meta.delimiter=S.delimiter),D(S));return S.preview&&S.header&&Ne.preview++,_=ce,y=new p(Ne),ie=y.parse(_,Me,we),Z(),ue?{meta:{paused:!0}}:ie||{meta:{paused:!1}}},this.paused=function(){return ue},this.pause=function(){ue=!0,y.abort(),_=P(S.chunk)?"":_.substring(y.getCharIndex())},this.resume=function(){Y.streamer._halted?(ue=!1,Y.streamer.parseChunk(_,!0)):setTimeout(Y.resume,3)},this.aborted=function(){return re},this.abort=function(){re=!0,y.abort(),ie.meta.aborted=!0,P(S.complete)&&S.complete(ie),_=""},this.guessLineEndings=function(Je,Ne){Je=Je.substring(0,1048576);var Ne=new RegExp(g(Ne)+"([^]*?)"+g(Ne),"gm"),we=(Je=Je.replace(Ne,"")).split("\r"),Ne=Je.split(`
`),Je=1<Ne.length&&Ne[0].length<we[0].length;if(we.length===1||Je)return`
`;for(var We=0,B=0;B<we.length;B++)we[B][0]===`
`&&We++;return We>=we.length/2?`\r
`:"\r"}}function g(S){return S.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function p(S){var _=(S=S||{}).delimiter,y=S.newline,T=S.comments,F=S.step,k=S.preview,G=S.fastMode,$=null,z=!1,Y=S.quoteChar==null?'"':S.quoteChar,H=Y;if(S.escapeChar!==void 0&&(H=S.escapeChar),(typeof _!="string"||-1<c.BAD_DELIMITERS.indexOf(_))&&(_=","),T===_)throw new Error("Comment character same as delimiter");T===!0?T="#":(typeof T!="string"||-1<c.BAD_DELIMITERS.indexOf(T))&&(T=!1),y!==`
`&&y!=="\r"&&y!==`\r
`&&(y=`
`);var q=0,ue=!1;this.parse=function(re,de,ie){if(typeof re!="string")throw new Error("Input must be a string");var W=re.length,Z=_.length,Q=y.length,ne=T.length,ce=P(F),Me=[],we=[],Ne=[],Je=q=0;if(!re)return ae();if(G||G!==!1&&re.indexOf(Y)===-1){for(var We=re.split(y),B=0;B<We.length;B++){if(Ne=We[B],q+=Ne.length,B!==We.length-1)q+=y.length;else if(ie)return ae();if(!T||Ne.substring(0,ne)!==T){if(ce){if(Me=[],ke(Ne.split(_)),he(),ue)return ae()}else ke(Ne.split(_));if(k&&k<=B)return Me=Me.slice(0,k),ae(!0)}}return ae()}for(var ht=re.indexOf(_,q),Pe=re.indexOf(y,q),tt=new RegExp(g(H)+g(Y),"g"),me=re.indexOf(Y,q);;)if(re[q]===Y)for(me=q,q++;;){if((me=re.indexOf(Y,me+1))===-1)return ie||we.push({type:"Quotes",code:"MissingQuotes",message:"Quoted field unterminated",row:Me.length,index:q}),A();if(me===W-1)return A(re.substring(q,me).replace(tt,Y));if(Y===H&&re[me+1]===H)me++;else if(Y===H||me===0||re[me-1]!==H){ht!==-1&&ht<me+1&&(ht=re.indexOf(_,me+1));var Qe=O((Pe=Pe!==-1&&Pe<me+1?re.indexOf(y,me+1):Pe)===-1?ht:Math.min(ht,Pe));if(re.substr(me+1+Qe,Z)===_){Ne.push(re.substring(q,me).replace(tt,Y)),re[q=me+1+Qe+Z]!==Y&&(me=re.indexOf(Y,q)),ht=re.indexOf(_,q),Pe=re.indexOf(y,q);break}if(Qe=O(Pe),re.substring(me+1+Qe,me+1+Qe+Q)===y){if(Ne.push(re.substring(q,me).replace(tt,Y)),K(me+1+Qe+Q),ht=re.indexOf(_,q),me=re.indexOf(Y,q),ce&&(he(),ue))return ae();if(k&&Me.length>=k)return ae(!0);break}we.push({type:"Quotes",code:"InvalidQuotes",message:"Trailing quote on quoted field is malformed",row:Me.length,index:q}),me++}}else if(T&&Ne.length===0&&re.substring(q,q+ne)===T){if(Pe===-1)return ae();q=Pe+Q,Pe=re.indexOf(y,q),ht=re.indexOf(_,q)}else if(ht!==-1&&(ht<Pe||Pe===-1))Ne.push(re.substring(q,ht)),q=ht+Z,ht=re.indexOf(_,q);else{if(Pe===-1)break;if(Ne.push(re.substring(q,Pe)),K(Pe+Q),ce&&(he(),ue))return ae();if(k&&Me.length>=k)return ae(!0)}return A();function ke(se){Me.push(se),Je=q}function O(se){var Re=0;return Re=se!==-1&&(se=re.substring(me+1,se))&&se.trim()===""?se.length:Re}function A(se){return ie||(se===void 0&&(se=re.substring(q)),Ne.push(se),q=W,ke(Ne),ce&&he()),ae()}function K(se){q=se,ke(Ne),Ne=[],Pe=re.indexOf(y,q)}function ae(se){if(S.header&&!de&&Me.length&&!z){var Re=Me[0],xe=Object.create(null),Fe=new Set(Re);let gt=!1;for(let ge=0;ge<Re.length;ge++){let Ee=Re[ge];if(xe[Ee=P(S.transformHeader)?S.transformHeader(Ee,ge):Ee]){let qe,et=xe[Ee];for(;qe=Ee+"_"+et,et++,Fe.has(qe););Fe.add(qe),Re[ge]=qe,xe[Ee]++,gt=!0,($=$===null?{}:$)[qe]=Ee}else xe[Ee]=1,Re[ge]=Ee;Fe.add(Ee)}gt&&console.warn("Duplicate headers found and renamed."),z=!0}return{data:Me,errors:we,meta:{delimiter:_,linebreak:y,aborted:ue,truncated:!!se,cursor:Je+(de||0),renamedHeaders:$}}}function he(){F(ae()),Me=[],we=[]}},this.abort=function(){ue=!0},this.getCharIndex=function(){return q}}function M(S){var _=S.data,y=a[_.workerId],T=!1;if(_.error)y.userError(_.error,_.file);else if(_.results&&_.results.data){var F={abort:function(){T=!0,x(_.workerId,{data:[],errors:[],meta:{aborted:!0}})},pause:b,resume:b};if(P(y.userStep)){for(var k=0;k<_.results.data.length&&(y.userStep({data:_.results.data[k],errors:_.results.errors,meta:_.results.meta},F),!T);k++);delete _.results}else P(y.userChunk)&&(y.userChunk(_.results,F,_.file),delete _.results)}_.finished&&!T&&x(_.workerId,_.results)}function x(S,_){var y=a[S];P(y.userComplete)&&y.userComplete(_),y.terminate(),delete a[S]}function b(){throw new Error("Not implemented.")}function D(S){if(typeof S!="object"||S===null)return S;var _,y=Array.isArray(S)?[]:{};for(_ in S)y[_]=D(S[_]);return y}function R(S,_){return function(){S.apply(_,arguments)}}function P(S){return typeof S=="function"}return c.parse=function(S,_){var y=(_=_||{}).dynamicTyping||!1;if(P(y)&&(_.dynamicTypingFunction=y,y={}),_.dynamicTyping=y,_.transform=!!P(_.transform)&&_.transform,!_.worker||!c.WORKERS_SUPPORTED)return y=null,c.NODE_STREAM_INPUT,typeof S=="string"?(S=(T=>T.charCodeAt(0)!==65279?T:T.slice(1))(S),y=new(_.download?u:f)(_)):S.readable===!0&&P(S.read)&&P(S.on)?y=new m(_):(n.File&&S instanceof File||S instanceof Object)&&(y=new d(_)),y.stream(S);(y=(()=>{var T;return!!c.WORKERS_SUPPORTED&&(T=(()=>{var F=n.URL||n.webkitURL||null,k=t.toString();return c.BLOB_URL||(c.BLOB_URL=F.createObjectURL(new Blob(["var global = (function() { if (typeof self !== 'undefined') { return self; } if (typeof window !== 'undefined') { return window; } if (typeof global !== 'undefined') { return global; } return {}; })(); global.IS_PAPA_WORKER=true; ","(",k,")();"],{type:"text/javascript"})))})(),(T=new n.Worker(T)).onmessage=M,T.id=l++,a[T.id]=T)})()).userStep=_.step,y.userChunk=_.chunk,y.userComplete=_.complete,y.userError=_.error,_.step=P(_.step),_.chunk=P(_.chunk),_.complete=P(_.complete),_.error=P(_.error),delete _.worker,y.postMessage({input:S,config:_,workerId:y.id})},c.unparse=function(S,_){var y=!1,T=!0,F=",",k=`\r
`,G='"',$=G+G,z=!1,Y=null,H=!1,q=((()=>{if(typeof _=="object"){if(typeof _.delimiter!="string"||c.BAD_DELIMITERS.filter(function(de){return _.delimiter.indexOf(de)!==-1}).length||(F=_.delimiter),typeof _.quotes!="boolean"&&typeof _.quotes!="function"&&!Array.isArray(_.quotes)||(y=_.quotes),typeof _.skipEmptyLines!="boolean"&&typeof _.skipEmptyLines!="string"||(z=_.skipEmptyLines),typeof _.newline=="string"&&(k=_.newline),typeof _.quoteChar=="string"&&(G=_.quoteChar),typeof _.header=="boolean"&&(T=_.header),Array.isArray(_.columns)){if(_.columns.length===0)throw new Error("Option columns is empty");Y=_.columns}_.escapeChar!==void 0&&($=_.escapeChar+G),_.escapeFormulae instanceof RegExp?H=_.escapeFormulae:typeof _.escapeFormulae=="boolean"&&_.escapeFormulae&&(H=/^[=+\-@\t\r].*$/)}})(),new RegExp(g(G),"g"));if(typeof S=="string"&&(S=JSON.parse(S)),Array.isArray(S)){if(!S.length||Array.isArray(S[0]))return ue(null,S,z);if(typeof S[0]=="object")return ue(Y||Object.keys(S[0]),S,z)}else if(typeof S=="object")return typeof S.data=="string"&&(S.data=JSON.parse(S.data)),Array.isArray(S.data)&&(S.fields||(S.fields=S.meta&&S.meta.fields||Y),S.fields||(S.fields=Array.isArray(S.data[0])?S.fields:typeof S.data[0]=="object"?Object.keys(S.data[0]):[]),Array.isArray(S.data[0])||typeof S.data[0]=="object"||(S.data=[S.data])),ue(S.fields||[],S.data||[],z);throw new Error("Unable to serialize unrecognized input");function ue(de,ie,W){var Z="",Q=(typeof de=="string"&&(de=JSON.parse(de)),typeof ie=="string"&&(ie=JSON.parse(ie)),Array.isArray(de)&&0<de.length),ne=!Array.isArray(ie[0]);if(Q&&T){for(var ce=0;ce<de.length;ce++)0<ce&&(Z+=F),Z+=re(de[ce],ce);0<ie.length&&(Z+=k)}for(var Me=0;Me<ie.length;Me++){var we=(Q?de:ie[Me]).length,Ne=!1,Je=Q?Object.keys(ie[Me]).length===0:ie[Me].length===0;if(W&&!Q&&(Ne=W==="greedy"?ie[Me].join("").trim()==="":ie[Me].length===1&&ie[Me][0].length===0),W==="greedy"&&Q){for(var We=[],B=0;B<we;B++){var ht=ne?de[B]:B;We.push(ie[Me][ht])}Ne=We.join("").trim()===""}if(!Ne){for(var Pe=0;Pe<we;Pe++){0<Pe&&!Je&&(Z+=F);var tt=Q&&ne?de[Pe]:Pe;Z+=re(ie[Me][tt],Pe)}Me<ie.length-1&&(!W||0<we&&!Je)&&(Z+=k)}}return Z}function re(de,ie){var W,Z;return de==null?"":de.constructor===Date?JSON.stringify(de).slice(1,25):(Z=!1,H&&typeof de=="string"&&H.test(de)&&(de="'"+de,Z=!0),W=de.toString().replace(q,$),(Z=Z||y===!0||typeof y=="function"&&y(de,ie)||Array.isArray(y)&&y[ie]||((Q,ne)=>{for(var ce=0;ce<ne.length;ce++)if(-1<Q.indexOf(ne[ce]))return!0;return!1})(W,c.BAD_DELIMITERS)||-1<W.indexOf(F)||W.charAt(0)===" "||W.charAt(W.length-1)===" ")?G+W+G:W)}},c.RECORD_SEP="",c.UNIT_SEP="",c.BYTE_ORDER_MARK="\uFEFF",c.BAD_DELIMITERS=["\r",`
`,'"',c.BYTE_ORDER_MARK],c.WORKERS_SUPPORTED=!s&&!!n.Worker,c.NODE_STREAM_INPUT=1,c.LocalChunkSize=10485760,c.RemoteChunkSize=5242880,c.DefaultDelimiter=",",c.Parser=p,c.ParserHandle=v,c.NetworkStreamer=u,c.FileStreamer=d,c.StringStreamer=f,c.ReadableStreamStreamer=m,n.jQuery&&((i=n.jQuery).fn.parse=function(S){var _=S.config||{},y=[];return this.each(function(k){if(!(i(this).prop("tagName").toUpperCase()==="INPUT"&&i(this).attr("type").toLowerCase()==="file"&&n.FileReader)||!this.files||this.files.length===0)return!0;for(var G=0;G<this.files.length;G++)y.push({file:this.files[G],inputElem:this,instanceConfig:i.extend({},_)})}),T(),this;function T(){if(y.length===0)P(S.complete)&&S.complete();else{var k,G,$,z,Y=y[0];if(P(S.before)){var H=S.before(Y.file,Y.inputElem);if(typeof H=="object"){if(H.action==="abort")return k="AbortError",G=Y.file,$=Y.inputElem,z=H.reason,void(P(S.error)&&S.error({name:k},G,$,z));if(H.action==="skip")return void F();typeof H.config=="object"&&(Y.instanceConfig=i.extend(Y.instanceConfig,H.config))}else if(H==="skip")return void F()}var q=Y.instanceConfig.complete;Y.instanceConfig.complete=function(ue){P(q)&&q(ue,Y.file,Y.inputElem),F()},c.parse(Y.file,Y.instanceConfig)}}function F(){y.splice(0,1),T()}}),o&&(n.onmessage=function(S){S=S.data,c.WORKER_ID===void 0&&S&&(c.WORKER_ID=S.workerId),typeof S.input=="string"?n.postMessage({workerId:c.WORKER_ID,results:c.parse(S.input,S.config),finished:!0}):(n.File&&S.input instanceof File||S.input instanceof Object)&&(S=c.parse(S.input,S.config))&&n.postMessage({workerId:c.WORKER_ID,results:S,finished:!0})}),(u.prototype=Object.create(h.prototype)).constructor=u,(d.prototype=Object.create(h.prototype)).constructor=d,(f.prototype=Object.create(f.prototype)).constructor=f,(m.prototype=Object.create(h.prototype)).constructor=m,c})}(sa)),sa.exports}var Pb=Cb();const Lb=Rf(Pb);class Qc extends bf{robot;static async create(){const e=new Qc;return await e._initAsync(),e}constructor(){super(),this.jointBuf=new yf,this.name="RBQ",this.userData.keep=!0}async _initAsync(){const e=new Yd,t=new Ab(e),n=Ea("/rbq/rbq10.urdf");try{const i=await t.loadAsync(n);this.robot=i,this.add(i)}catch(i){console.error(i)}}update(e){this.position.set(+e.x,+e.y,0),this.rotation.z=St.degToRad(+e.rz)}applyPose(e){this.pushTransformSnapshot({t:performance.now()*.001,x:+e.x,y:+e.y,rz:+e.rz})}async loadJointData(e,t=!0,n=1){const i=yb(e),s=await fetch(i).then(c=>c.text()),{data:o}=Lb.parse(s,{header:!0,dynamicTyping:!0,skipEmptyLines:!0}),a=o.sort((c,h)=>c.time-h.time),l=performance.now()/1e3;for(const c of a){const{time:h,...u}=c,d=u,f=l+h/n;t?setTimeout(()=>this.pushJointsSnapshot(d,f),h/n*1e3):this.pushJointsSnapshot(d,f)}}applyJointValues(e){this.robot?.setJointValues(e)}}const od=["#0087fc","#f77468","#f37a32","#dc8932","#ca9232","#bb9832","#ae9d31","#9fa131","#8ea631","#77ab31","#50b131","#32b25c","#33b07a","#34af8c","#35ae99","#36ada4","#36acae","#37aab9","#38a9c5","#39a7d5","#3ba3ec","#6e9bf4","#9591f4","#b287f4","#cc7af4","#e866f4","#f560e4","#f565cc","#f66ab7","#f66da2"];class Db{editor;mainRobot;rbq;s100;robotMap;previousUpdateTime;availableColors;constructor(e){this.editor=e,this.s100=null,this.rbq=null,this.robotMap=new Map,this.previousUpdateTime=Date.now(),this.availableColors=[...od]}addLabel(e){const t=document.createElement("div");t.className="nodeLabel",t.textContent=e.name,t.style.color="white",t.style.backgroundColor="transparent",t.style.position="absolute",t.style.fontSize="6.5px",t.style.zIndex="-999";const n=new wa(t);n.userData.keep=!0,n.userData.labelType="robot",n.name="label",n.center.set(0,-.5),e.add(n)}count(){return this.robotMap.size}dispose(){this.rbq=null,this.s100=null,this.mainRobot=null}async loadMainRobot(e){if(!this.mainRobot){switch(e){case"S100":this.mainRobot=await Ta.create(),this.s100=this.mainRobot;break;case"RBQ":this.mainRobot=await Qc.create(),this.rbq=this.mainRobot;break}this.editor.zUpGroup.add(this.mainRobot),this.robotMap.set("mainRobot",this.mainRobot),this.editor.eventHandler.eventBus.emit("robotmanager:mainrobot:loaded")}}update=(e,t)=>{e.visible?(e.position.set(t.x,t.y,e.position.z),e.rotation.z=t.rz*Math.PI/180):(e.position.set(t.x,t.y,0),e.rotation.z=t.rz,e.visible=!0)};updateAll(e){this.mainRobot?.tick(e)}addAxesHelper(e){const t=new Yc(1e3);t.userData.keep=!0,e.add(t)}cloneEdgeLine(e,t){const n=e.getObjectByName("edgeLine"),i=t.getObjectByName("edgeLine");n&&i&&(i.material=n.material.clone())}cloneRobot(e){const t=e.clone();t.name="robot";const n=e.material.clone();return n.color=new Ge(this.getUniqueColor()),t.material=n,t}getUniqueColor(){return this.availableColors.length===0&&(this.availableColors=[...od]),this.availableColors.splice(0,1)[0]}}const ui=new ye,Al=new Js,ti=new qc;ti.params.Points.threshold=.5;class Ib{editor;mode;_invMat=new Te;constructor(e){this.editor=e,this.mode="single"}dispose(){this.deregisterEvents()}deregisterEvents(){const e=this.editor.eventHandler.eventBus;e.off("intersectionsDetected",this.handleIntersectionsDetected),e.off("changeSelectMode",this.handleChangeSelectMode),e.off("boxIntersectionsDetected",this.handleBoxIntersectionsDetected),e.off("nodesCopied",this.handleNodesCopied),e.off("objectRemoved",this.handleObjectRemoved),e.off("resetSelection",this.handleResetSelection)}getSelectionBoxIntersects(e,t,n){Al.min=new ye(Math.min(t.x,n.x),Math.min(t.y,n.y)),Al.max=new ye(Math.max(t.x,n.x),Math.max(t.y,n.y));const i=[],s=this.editor.selectableObjects,o=s.length;for(let l=0;l<o;l++){const c=s[l],h=this.toScreenPosition(e,c),u=new ye(h.x,h.y);Al.containsPoint(u)&&i.push(c)}return this.getSortedIntersects(i)}getPointerPlaneIntersection(e,t){return ui.set(e.x*2-1,-(e.y*2)+1),ti.setFromCamera(ui,t),this.computeGlobalPlaneIntersection(ti)}getPointerObjectIntersections(e,t){return ui.set(e.x*2-1,-(e.y*2)+1),ti.setFromCamera(ui,t),this.computeObjectIntersects(ti)}getPointerOctreeIntersections(e,t){return ui.set(e.x*2-1,-(e.y*2)+1),ti.setFromCamera(ui,t),this.computeOctreePointIntersections(ti,t)}getPointerQuadTreeIntersections(e,t){return ui.set(e.x*2-1,-(e.y*2)+1),ti.setFromCamera(ui,t),this.computeQuadtreePointIntersections(ti,t)}getPointerNearestPointIntersection(e,t){return ui.set(e.x*2-1,-(e.y*2)+1),ti.setFromCamera(ui,t),this.computeNearestPointIntersect(ti,t)}registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("intersectionsDetected",this.handleIntersectionsDetected),e.on("changeSelectMode",this.handleChangeSelectMode),e.on("boxIntersectionsDetected",this.handleBoxIntersectionsDetected),e.on("nodesCopied",this.handleNodesCopied),e.on("objectRemoved",this.handleObjectRemoved),e.on("resetSelection",this.handleResetSelection)}accumulateOctreeIntersections(e,t,n,i,s){if(e.intersectsBox(t.boundary))if(t.divided)for(const o of t.children)this.accumulateOctreeIntersections(e,o,n,i,s);else for(const{position:o,index:a}of t.points){const l=e.distanceToPoint(o);if(l<=n){const c=i.position.distanceTo(o);s.push({point:o.clone(),index:a,distance:l,cameraDist:c})}}}computeGlobalPlaneIntersection(e){return e.intersectObject(this.editor.globalPlane)}computeNearestPointIntersect(e,t){const n=e.ray,i=this.editor.pointsManager.pointsOctree;return this.findNearestOctreeIntersection(n,i,e.params.Points.threshold,t)}computeObjectIntersects(e){return e.intersectObjects(this.editor.selectableObjects,!1)}computeOctreePointIntersections(e,t){const n=e.ray,i=[],s=this.editor.pointsManager.pointsOctree;return this.accumulateOctreeIntersections(n,s,e.params.Points.threshold,t,i),i}findNearestOctreeIntersection(e,t,n,i){if(!e.intersectsBox(t.boundary))return null;let s=null;if(t.divided)for(const o of t.children){const a=this.findNearestOctreeIntersection(e,o,n,i);a!==null&&(s===null||a.cameraDist<s.cameraDist)&&(s=a)}else for(const{position:o,index:a}of t.points){const l=e.distanceToPoint(o);if(l<=n){const c=i.position.distanceTo(o);(s===null||c<s.cameraDist)&&(s={point:o.clone(),index:a,distance:l,cameraDist:c})}}return s}getSortedIntersects(e){return e.sort((t,n)=>{const i=t.position.x-n.position.x;return i!==0?i:n.position.y-t.position.y}),e}handleBoxIntersectionsDetected=e=>{this.select(null),this.multiSelect(e)};handleChangeSelectMode=e=>{this.mode=e,this.select(null)};handleIntersectionsDetected=e=>{if(e.length>0){const t=e[0].object;this.select(t)}else this.select(null)};handleNodesCopied=e=>{this.select(null),this.multiSelect(e)};handleObjectRemoved=()=>{this.select(null)};multiSelect=e=>{this.editor.selected=e[e.length-1],this.editor.selectedObjects=e,this.editor.eventHandler.eventBus.emit("objectsSelected",{selectedObjects:e})};select=e=>{this.editor.selected!==e&&(this.editor.selected=e,e?this.editor.selectedObjects.includes(e)||this.editor.selectedObjects.push(e):this.editor.selectedObjects=[],this.editor.eventHandler.eventBus.emit("objectSelected",{object:e,selectedObjects:this.editor.selectedObjects}))};toScreenPosition(e,t){const n=e.getBoundingClientRect(),i=new I;return t.updateMatrixWorld(),i.setFromMatrixPosition(t.matrixWorld),i.project(this.editor.camera),{x:(i.x+1)/2*n.width+n.left,y:(-i.y+1)/2*n.height+n.top}}computeQuadtreePointIntersections(e,t){const n=[],i=this.editor.pointsManager.pointsQuadTree;if(!i)return n;const s=this.worldRayToLocal(e.ray,this.editor.zUpGroup),o=e.params.Points.threshold??1;return this.accumulateQuadtreeIntersections(s,i,o,t,n),n}worldRayToLocal(e,t){this._invMat.copy(t.matrixWorld).invert();const n=e.origin.clone().applyMatrix4(this._invMat),i=e.direction.clone().transformDirection(this._invMat).normalize();return new Ts(n,i)}_visualizeRay(e,t,n,i=30,s=65535){const o=new Jd(t,e,i,s,.3,.3);n.add(o)}accumulateQuadtreeIntersections(e,t,n,i,s){const o=t.boundary.clone().expandByScalar(n),a=new Cn(new I(o.min.x,o.min.y,-n),new I(o.max.x,o.max.y,n));if(e.intersectsBox(a))if(t.divided)for(const l of t.children)this.accumulateQuadtreeIntersections(e,l,n,i,s);else for(const{position:l,index:c}of t.points){const h=e.distanceToPoint(l);if(h<=n){const u=i.position.distanceTo(l);s.push({point:l.clone(),index:c,distance:h,cameraDist:u})}}}handleResetSelection=()=>{this.select(null)}}/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */function sn(r,e,t,n){function i(s){return s instanceof t?s:new t(function(o){o(s)})}return new(t||(t=Promise))(function(s,o){function a(h){try{c(n.next(h))}catch(u){o(u)}}function l(h){try{c(n.throw(h))}catch(u){o(u)}}function c(h){h.done?s(h.value):i(h.value).then(a,l)}c((n=n.apply(r,[])).next())})}class Kr{constructor(){this.name="",this.minZoom=0,this.maxZoom=20,this.bounds=[],this.center=[]}fetchTile(e,t,n){return null}getMetaData(){return sn(this,void 0,void 0,function*(){})}}class Nb extends Kr{constructor(e="https://a.tile.openstreetmap.org/"){super(),this.address=e,this.format="png",this.maxZoom=19}fetchTile(e,t,n){return new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",o.src=this.address+e+"/"+t+"/"+n+"."+this.format})}}class eh{static createOffscreenCanvas(e,t){if(typeof OffscreenCanvas<"u")return new OffscreenCanvas(e,t);{let n=document.createElement("canvas");return n.width=e,n.height=t,n}}}class wf{static createFillTexture(e="#000000",t=1,n=1){const i=eh.createOffscreenCanvas(t,n),s=i.getContext("2d");s.fillStyle=e,s.fillRect(0,0,t,n);const o=new qt(i);return o.format=Sn,o.magFilter=mn,o.minFilter=mn,o.generateMipmaps=!1,o.needsUpdate=!0,o}}class jt{}jt.root=-1;jt.topLeft=0;jt.topRight=1;jt.bottomLeft=2;jt.bottomRight=3;class Mn extends ve{constructor(e=null,t=null,n=jt.root,i=0,s=0,o=0,a=null,l=null){super(a,l),this.mapView=null,this.parentNode=null,this.subdivided=!1,this.disposed=!1,this.nodesLoaded=0,this.childrenCache=null,this.isMesh=!0,this.mapView=t,this.parentNode=e,this.disposed=!1,this.location=n,this.level=i,this.x=s,this.y=o,this.initialize()}initialize(){return sn(this,void 0,void 0,function*(){})}createChildNodes(){}subdivide(){const e=this.mapView.maxZoom();this.children.length>0||this.level+1>e||this.parentNode!==null&&this.parentNode.nodesLoaded<Mn.childrens||(this.mapView.cacheTiles&&this.childrenCache!==null?(this.isMesh=!1,this.children=this.childrenCache,this.nodesLoaded=this.childrenCache.length):this.createChildNodes(),this.subdivided=!0)}simplify(){const e=this.mapView.minZoom();if(!(this.level-1<e)){if(this.mapView.cacheTiles)this.childrenCache=this.children;else for(let t=0;t<this.children.length;t++)this.children[t].dispose();this.subdivided=!1,this.isMesh=!0,this.children=[],this.nodesLoaded=0}}loadData(){return sn(this,void 0,void 0,function*(){if(this.level<this.mapView.provider.minZoom||this.level>this.mapView.provider.maxZoom){console.warn("Geo-Three: Loading tile outside of provider range.",this),this.material.map=Mn.defaultTexture,this.material.needsUpdate=!0;return}try{const e=yield this.mapView.provider.fetchTile(this.level,this.x,this.y);yield this.applyTexture(e)}catch{if(this.disposed)return;console.warn("Geo-Three: Failed to load node tile data.",this),this.material.map=Mn.defaultTexture}this.material.needsUpdate=!0})}applyTexture(e){return sn(this,void 0,void 0,function*(){if(this.disposed)return;const t=new qt(e);parseInt(_s)>=152&&(t.colorSpace="srgb"),t.generateMipmaps=!1,t.format=Sn,t.magFilter=mn,t.minFilter=mn,t.needsUpdate=!0,this.material.map=t})}nodeReady(){if(this.disposed){console.warn("Geo-Three: nodeReady() called for disposed node.",this),this.dispose();return}if(this.parentNode!==null){if(this.parentNode.nodesLoaded++,this.parentNode.nodesLoaded===Mn.childrens){this.parentNode.subdivided===!0&&(this.parentNode.isMesh=!1);for(let e=0;e<this.parentNode.children.length;e++)this.parentNode.children[e].visible=!0}this.parentNode.nodesLoaded>Mn.childrens&&console.error("Geo-Three: Loaded more children objects than expected.",this.parentNode.nodesLoaded,this)}else this.visible=!0}dispose(){this.disposed=!0;const e=this;try{const t=e.material;t.dispose(),t.map&&t.map!==Mn.defaultTexture&&t.map.dispose()}catch{}try{e.geometry.dispose()}catch{}}}Mn.defaultTexture=wf.createFillTexture();Mn.baseGeometry=null;Mn.baseScale=null;Mn.childrens=4;class Oi extends yt{constructor(e=1,t=1,n=1,i=1,s=!1,o=10){super();const a=[],l=[],c=[],h=[];Oi.buildPlane(e,t,n,i,a,l,c,h),s&&Oi.buildSkirt(e,t,n,i,o,a,l,c,h),this.setIndex(a),this.setAttribute("position",new Le(l,3)),this.setAttribute("normal",new Le(c,3)),this.setAttribute("uv",new Le(h,2))}static buildPlane(e=1,t=1,n=1,i=1,s,o,a,l){const c=e/2,h=t/2,u=n+1,d=i+1,f=e/n,m=t/i;for(let v=0;v<d;v++){const g=v*m-h;for(let p=0;p<u;p++){const M=p*f-c;o.push(M,0,g),a.push(0,1,0),l.push(p/n,1-v/i)}}for(let v=0;v<i;v++)for(let g=0;g<n;g++){const p=g+u*v,M=g+u*(v+1),x=g+1+u*(v+1),b=g+1+u*v;s.push(p,M,b,M,x,b)}}static buildSkirt(e=1,t=1,n=1,i=1,s,o,a,l,c){const h=e/2,u=t/2,d=n+1,f=i+1,m=e/n,v=t/i;let g=a.length/3;for(let M=0;M<d;M++){const x=M*m-h,b=-u;a.push(x,-s,b),l.push(0,1,0),c.push(M/n,1)}for(let M=0;M<n;M++){const x=M,b=M+1,D=M+g,R=M+g+1;o.push(b,D,x,b,R,D)}g=a.length/3;for(let M=0;M<d;M++){const x=M*m-h,b=i*v-u;a.push(x,-s,b),l.push(0,1,0),c.push(M/n,0)}let p=d*f-n-1;for(let M=0;M<n;M++){const x=p+M,b=p+M+1,D=M+g,R=M+g+1;o.push(x,D,b,D,R,b)}g=a.length/3;for(let M=0;M<f;M++){const x=M*v-u,b=-h;a.push(b,-s,x),l.push(0,1,0),c.push(0,1-M/i)}for(let M=0;M<i;M++){const x=M*f,b=(M+1)*f,D=M+g,R=M+g+1;o.push(x,D,b,D,R,b)}g=a.length/3;for(let M=0;M<f;M++){const x=M*v-u,b=n*m-h;a.push(b,-s,x),l.push(0,1,0),c.push(1,1-M/i)}for(let M=0;M<i;M++){const x=M*f+i,b=(M+1)*f+i,D=M+g,R=M+g+1;o.push(b,D,x,b,R,D)}}}class Rl{constructor(e,t){this.latitude=e,this.longitude=t}}class _t{static datumsToSpherical(e,t){const n=t*_t.EARTH_ORIGIN/180;let i=Math.log(Math.tan((90+e)*Math.PI/360))/(Math.PI/180);return i=i*_t.EARTH_ORIGIN/180,new ye(n,i)}static sphericalToDatums(e,t){const n=e/_t.EARTH_ORIGIN*180;let i=t/_t.EARTH_ORIGIN*180;return i=180/Math.PI*(2*Math.atan(Math.exp(i*Math.PI/180))-Math.PI/2),new Rl(i,n)}static quadtreeToDatums(e,t,n){const i=Math.pow(2,e),s=t/i*360-180,a=180*(Math.atan(Math.sinh(Math.PI*(1-2*n/i)))/Math.PI);return new Rl(a,s)}static vectorToDatums(e){const t=180/Math.PI,n=Math.atan2(e.y,Math.sqrt(Math.pow(e.x,2)+Math.pow(-e.z,2)))*t,i=Math.atan2(-e.z,e.x)*t;return new Rl(n,i)}static datumsToVector(e,t){const n=Math.PI/180,i=t*n,s=e*n;var o=Math.cos(s);return new I(-Math.cos(i+Math.PI)*o,Math.sin(s),Math.sin(i+Math.PI)*o)}static mapboxAltitude(e){return(e.r*255*65536+e.g*255*256+e.b*255)*.1-1e4}static getTileSize(e){const t=_t.WEB_MERCATOR_MAX_EXTENT,n=Math.pow(2,e);return 2*t/n}static tileBounds(e,t,n){const i=_t.getTileSize(e),s=-_t.WEB_MERCATOR_MAX_EXTENT+t*i,o=_t.WEB_MERCATOR_MAX_EXTENT-(n+1)*i;return[s,i,o,i]}static webMercatorToLatitude(e,t){const n=_t.WEB_MERCATOR_MAX_EXTENT-t*_t.getTileSize(e);return Math.atan(Math.sinh(n/_t.EARTH_RADIUS))}static webMercatorToLongitude(e,t){return(-_t.WEB_MERCATOR_MAX_EXTENT+t*_t.getTileSize(e))/_t.EARTH_RADIUS}}_t.EARTH_RADIUS=6371008;_t.EARTH_RADIUS_A=6378137;_t.EARTH_RADIUS_B=6356752314245e-6;_t.EARTH_PERIMETER=2*Math.PI*_t.EARTH_RADIUS;_t.EARTH_ORIGIN=_t.EARTH_PERIMETER/2;_t.WEB_MERCATOR_MAX_EXTENT=2003750834e-2;class Zn extends Mn{constructor(e=null,t=null,n=jt.root,i=0,s=0,o=0){super(e,t,n,i,s,o,Zn.geometry,new qn({wireframe:!1})),this.matrixAutoUpdate=!1,this.isMesh=!0,this.visible=!1}initialize(){const e=Object.create(null,{initialize:{get:()=>super.initialize}});return sn(this,void 0,void 0,function*(){e.initialize.call(this),yield this.loadData(),this.nodeReady()})}createChildNodes(){const e=this.level+1,t=this.x*2,n=this.y*2,i=Object.getPrototypeOf(this).constructor;let s=new i(this,this.mapView,jt.topLeft,e,t,n);s.scale.set(.5,1,.5),s.position.set(-.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new i(this,this.mapView,jt.topRight,e,t+1,n),s.scale.set(.5,1,.5),s.position.set(.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new i(this,this.mapView,jt.bottomLeft,e,t,n+1),s.scale.set(.5,1,.5),s.position.set(-.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new i(this,this.mapView,jt.bottomRight,e,t+1,n+1),s.scale.set(.5,1,.5),s.position.set(.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0)}raycast(e,t){this.isMesh===!0&&super.raycast(e,t)}}Zn.geometry=new Oi(1,1,1,1,!1);Zn.baseGeometry=Zn.geometry;Zn.baseScale=new I(_t.EARTH_PERIMETER,1,_t.EARTH_PERIMETER);class Ub extends yt{constructor(e=1,t=1,n=1,i=1,s=!1,o=10,a=null,l=!0){super();const c=[],h=[],u=[],d=[];Oi.buildPlane(e,t,n,i,c,h,u,d);const f=a.data;for(let m=0,v=0;m<f.length&&v<h.length;m+=4,v+=3){const g=f[m],p=f[m+1],M=f[m+2],x=(g*65536+p*256+M)*.1-1e4;h[v+1]=x}s&&Oi.buildSkirt(e,t,n,i,o,c,h,u,d),this.setIndex(c),this.setAttribute("position",new Le(h,3)),this.setAttribute("normal",new Le(u,3)),this.setAttribute("uv",new Le(d,2)),l&&this.computeNormals(n,i)}computeNormals(e,t){const n=this.getAttribute("position");if(n!==void 0){let i=this.getAttribute("normal");const s=t*e;for(let v=0;v<s;v++)i.setXYZ(v,0,0,0);const o=new I,a=new I,l=new I,c=new I,h=new I,u=new I,d=new I,f=new I,m=t*e*6;for(let v=0;v<m;v+=3){const g=this.index.getX(v+0),p=this.index.getX(v+1),M=this.index.getX(v+2);o.fromBufferAttribute(n,g),a.fromBufferAttribute(n,p),l.fromBufferAttribute(n,M),d.subVectors(l,a),f.subVectors(o,a),d.cross(f),c.fromBufferAttribute(i,g),h.fromBufferAttribute(i,p),u.fromBufferAttribute(i,M),c.add(d),h.add(d),u.add(d),i.setXYZ(g,c.x,c.y,c.z),i.setXYZ(p,h.x,h.y,h.z),i.setXYZ(M,u.x,u.y,u.z)}this.normalizeNormals(),i.needsUpdate=!0}}}class oi extends Mn{constructor(e=null,t=null,n=jt.root,i=0,s=0,o=0,a=oi.geometry,l=new kn({wireframe:!1,color:16777215})){super(e,t,n,i,s,o,a,l),this.heightLoaded=!1,this.textureLoaded=!1,this.geometrySize=16,this.geometryNormals=!1,this.isMesh=!0,this.visible=!1,this.matrixAutoUpdate=!1}initialize(){const e=Object.create(null,{initialize:{get:()=>super.initialize}});return sn(this,void 0,void 0,function*(){e.initialize.call(this),yield this.loadData(),yield this.loadHeightGeometry(),this.nodeReady()})}loadData(){const e=Object.create(null,{loadData:{get:()=>super.loadData}});return sn(this,void 0,void 0,function*(){yield e.loadData.call(this),this.textureLoaded=!0})}loadHeightGeometry(){return sn(this,void 0,void 0,function*(){if(this.mapView.heightProvider===null)throw new Error("GeoThree: MapView.heightProvider provider is null.");if(this.level<this.mapView.heightProvider.minZoom||this.level>this.mapView.heightProvider.maxZoom){console.warn("Geo-Three: Loading tile outside of provider range.",this),this.geometry=Zn.baseGeometry;return}try{const e=yield this.mapView.heightProvider.fetchTile(this.level,this.x,this.y);if(this.disposed)return;const t=eh.createOffscreenCanvas(this.geometrySize+1,this.geometrySize+1),n=t.getContext("2d");n.imageSmoothingEnabled=!1,n.drawImage(e,0,0,oi.tileSize,oi.tileSize,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height);this.geometry=new Ub(1,1,this.geometrySize,this.geometrySize,!0,10,i,!0)}catch{if(this.disposed)return;this.geometry=Zn.baseGeometry}this.heightLoaded=!0})}createChildNodes(){const e=this.level+1,t=Object.getPrototypeOf(this).constructor,n=this.x*2,i=this.y*2;let s=new t(this,this.mapView,jt.topLeft,e,n,i);s.scale.set(.5,1,.5),s.position.set(-.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new t(this,this.mapView,jt.topRight,e,n+1,i),s.scale.set(.5,1,.5),s.position.set(.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new t(this,this.mapView,jt.bottomLeft,e,n,i+1),s.scale.set(.5,1,.5),s.position.set(-.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new t(this,this.mapView,jt.bottomRight,e,n+1,i+1),s.scale.set(.5,1,.5),s.position.set(.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0)}raycast(e,t){this.isMesh===!0&&super.raycast(e,t)}}oi.tileSize=256;oi.geometry=new Oi(1,1,1,1);oi.baseGeometry=Zn.geometry;oi.baseScale=new I(_t.EARTH_PERIMETER,1,_t.EARTH_PERIMETER);class Ef extends yt{constructor(e,t,n,i,s,o,a){super();const l=o+a;let c=0;const h=[],u=new I,d=new I,f=[],m=[],v=[],g=[];for(let p=0;p<=n;p++){const M=[],x=p/n;for(let b=0;b<=t;b++){const D=b/t;u.x=-e*Math.cos(i+D*s)*Math.sin(o+x*a),u.y=e*Math.cos(o+x*a),u.z=e*Math.sin(i+D*s)*Math.sin(o+x*a),m.push(u.x,u.y,u.z),d.set(u.x,u.y,u.z).normalize(),v.push(d.x,d.y,d.z),g.push(D,1-x),M.push(c++)}h.push(M)}for(let p=0;p<n;p++)for(let M=0;M<t;M++){const x=h[p][M+1],b=h[p][M],D=h[p+1][M],R=h[p+1][M+1];(p!==0||o>0)&&f.push(x,b,R),(p!==n-1||l<Math.PI)&&f.push(b,D,R)}this.setIndex(f),this.setAttribute("position",new Le(m,3)),this.setAttribute("normal",new Le(v,3)),this.setAttribute("uv",new Le(g,2))}}class ws extends Mn{constructor(e=null,t=null,n=jt.root,i=0,s=0,o=0){let a=_t.tileBounds(i,s,o);const l=`
		varying vec3 vPosition;

		void main() {
			vPosition = position;
			gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
		}
		`,c=`
		#define PI 3.1415926538
		varying vec3 vPosition;
		uniform sampler2D uTexture;
		uniform vec4 webMercatorBounds;

		void main() {
			// this could also be a constant, but for some reason using a constant causes more visible tile gaps at high zoom
			float radius = length(vPosition);

			float latitude = asin(vPosition.y / radius);
			float longitude = atan(-vPosition.z, vPosition.x);

			float web_mercator_x = radius * longitude;
			float web_mercator_y = radius * log(tan(PI / 4.0 + latitude / 2.0));
			float y = (web_mercator_y - webMercatorBounds.z) / webMercatorBounds.w;
			float x = (web_mercator_x - webMercatorBounds.x) / webMercatorBounds.y;

			vec4 color = texture2D(uTexture, vec2(x, y));
			gl_FragColor = color;
			${parseInt(_s)<152?"":`
				#include <tonemapping_fragment>
				#include ${parseInt(_s)>=154?"<colorspace_fragment>":"<encodings_fragment>"}
				`}
		}
		`;let h=new ct(...a);const u=new gi({uniforms:{uTexture:{value:new qt},webMercatorBounds:{value:h}},vertexShader:l,fragmentShader:c});super(e,t,n,i,s,o,ws.createGeometry(i,s,o),u),this.applyScaleNode(),this.matrixAutoUpdate=!1,this.isMesh=!0,this.visible=!1}initialize(){const e=Object.create(null,{initialize:{get:()=>super.initialize}});return sn(this,void 0,void 0,function*(){e.initialize.call(this),yield this.loadData(),this.nodeReady()})}static createGeometry(e,t,n){const i=Math.pow(2,e),s=40,o=Math.floor(ws.segments*(s/(e+1))/s),a=t>0?_t.webMercatorToLongitude(e,t)+Math.PI:0,l=t<i-1?_t.webMercatorToLongitude(e,t+1)+Math.PI:2*Math.PI,c=a,h=l-a,u=n>0?_t.webMercatorToLatitude(e,n):Math.PI/2,d=n<i-1?_t.webMercatorToLatitude(e,n+1):-Math.PI/2,f=u-d,m=Math.PI-(u+Math.PI/2);return new Ef(1,o,o,c,h,m,f)}applyTexture(e){return sn(this,void 0,void 0,function*(){const n=new Ma().load(e.src,function(){parseInt(_s)>=152&&(n.colorSpace="srgb")});this.material.uniforms.uTexture.value=n,this.material.uniforms.uTexture.needsUpdate=!0})}applyScaleNode(){this.geometry.computeBoundingBox();const t=this.geometry.boundingBox.clone().getCenter(new I),n=new Te;n.compose(new I(-t.x,-t.y,-t.z),new Pt,new I(_t.EARTH_RADIUS,_t.EARTH_RADIUS,_t.EARTH_RADIUS)),this.geometry.applyMatrix4(n),this.position.copy(t),this.updateMatrix(),this.updateMatrixWorld()}updateMatrix(){this.matrix.setPosition(this.position),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e=!1){(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorld.copy(this.matrix),this.matrixWorldNeedsUpdate=!1)}createChildNodes(){const e=this.level+1,t=this.x*2,n=this.y*2,i=Object.getPrototypeOf(this).constructor;let s=new i(this,this.mapView,jt.topLeft,e,t,n);this.add(s),s=new i(this,this.mapView,jt.topRight,e,t+1,n),this.add(s),s=new i(this,this.mapView,jt.bottomLeft,e,t,n+1),this.add(s),s=new i(this,this.mapView,jt.bottomRight,e,t+1,n+1),this.add(s)}raycast(e,t){this.isMesh===!0&&super.raycast(e,t)}}ws.baseGeometry=new Ef(_t.EARTH_RADIUS,64,64,0,2*Math.PI,0,Math.PI);ws.baseScale=new I(1,1,1);ws.segments=80;class bn extends oi{constructor(e=null,t=null,n=jt.root,i=0,s=0,o=0){const a=bn.prepareMaterial(new kn({map:Mn.defaultTexture,color:16777215}));super(e,t,n,i,s,o,bn.geometry,a),this.frustumCulled=!1}static prepareMaterial(e){return e.userData={heightMap:{value:bn.defaultHeightTexture}},e.onBeforeCompile=t=>{for(const n in e.userData)t.uniforms[n]=e.userData[n];t.vertexShader=`
			uniform sampler2D heightMap;
			`+t.vertexShader,t.vertexShader=t.vertexShader.replace("#include <fog_vertex>",`
			#include <fog_vertex>
	
			// Calculate height of the title
			vec4 _theight = texture2D(heightMap, vUv);
			float _height = ((_theight.r * 255.0 * 65536.0 + _theight.g * 255.0 * 256.0 + _theight.b * 255.0) * 0.1) - 10000.0;
			vec3 _transformed = position + _height * normal;
	
			// Vertex position based on height
			gl_Position = projectionMatrix * modelViewMatrix * vec4(_transformed, 1.0);
			`)},e}loadData(){const e=Object.create(null,{loadData:{get:()=>super.loadData}});return sn(this,void 0,void 0,function*(){yield e.loadData.call(this),this.textureLoaded=!0})}loadHeightGeometry(){return sn(this,void 0,void 0,function*(){if(this.mapView.heightProvider===null)throw new Error("GeoThree: MapView.heightProvider provider is null.");if(this.level<this.mapView.heightProvider.minZoom||this.level>this.mapView.heightProvider.maxZoom){console.warn("Geo-Three: Loading tile outside of provider range.",this),this.material.map=bn.defaultTexture,this.material.needsUpdate=!0;return}try{const e=yield this.mapView.heightProvider.fetchTile(this.level,this.x,this.y);if(this.disposed)return;const t=new qt(e);t.generateMipmaps=!1,t.format=Sn,t.magFilter=gn,t.minFilter=gn,t.needsUpdate=!0,this.material.userData.heightMap.value=t}catch{if(this.disposed)return;console.error("Geo-Three: Failed to load node tile height data.",this),this.material.userData.heightMap.value=bn.defaultHeightTexture}this.material.needsUpdate=!0,this.heightLoaded=!0})}raycast(e,t){this.isMesh===!0&&(this.geometry=Zn.geometry,super.raycast(e,t),this.geometry=bn.geometry)}dispose(){super.dispose(),this.material.userData.heightMap.value&&this.material.userData.heightMap.value!==bn.defaultHeightTexture&&this.material.userData.heightMap.value.dispose()}}bn.defaultHeightTexture=wf.createFillTexture("#0186C0");bn.geometrySize=256;bn.geometry=new Oi(1,1,bn.geometrySize,bn.geometrySize,!0);bn.baseGeometry=Zn.geometry;bn.baseScale=new I(_t.EARTH_PERIMETER,1,_t.EARTH_PERIMETER);class Fb{constructor(){this.subdivisionRays=1,this.thresholdUp=.6,this.thresholdDown=.15,this.raycaster=new qc,this.mouse=new ye,this.powerDistance=!1,this.scaleDistance=!0}updateLOD(e,t,n,i){const s=[];for(let o=0;o<this.subdivisionRays;o++){this.mouse.set(Math.random()*2-1,Math.random()*2-1),this.raycaster.setFromCamera(this.mouse,t);let a=[];this.raycaster.intersectObjects(e.children,!0,a),a.length>0&&s.push(a[0])}for(let o=0;o<s.length;o++){const a=s[o].object;let l=s[o].distance;if(this.powerDistance&&(l=Math.pow(l*2,a.level)),this.scaleDistance){const c=a.matrixWorld.elements;l=new I(c[0],c[1],c[2]).length()/l}l>this.thresholdUp?a.subdivide():l<this.thresholdDown&&a.parentNode&&a.parentNode.simplify()}}}class Ob{constructor(e=257){this.gridSize=e;const t=e-1;if(t&t-1)throw new Error(`Expected grid size to be 2^n+1, got ${e}.`);this.numTriangles=t*t*2-2,this.numParentTriangles=this.numTriangles-t*t,this.indices=new Uint32Array(this.gridSize*this.gridSize),this.coords=new Uint16Array(this.numTriangles*4);for(let n=0;n<this.numTriangles;n++){let i=n+2,s=0,o=0,a=0,l=0,c=0,h=0;for(i&1?a=l=c=t:s=o=h=t;(i>>=1)>1;){const d=s+a>>1,f=o+l>>1;i&1?(a=s,l=o,s=c,o=h):(s=a,o=l,a=c,l=h),c=d,h=f}const u=n*4;this.coords[u+0]=s,this.coords[u+1]=o,this.coords[u+2]=a,this.coords[u+3]=l}}createTile(e){return new Bb(e,this)}}class Bb{constructor(e,t){const n=t.gridSize;if(e.length!==n*n)throw new Error(`Expected terrain data of length ${n*n} (${n} x ${n}), got ${e.length}.`);this.terrain=e,this.martini=t,this.errors=new Float32Array(e.length),this.update()}update(){const{numTriangles:e,numParentTriangles:t,coords:n,gridSize:i}=this.martini,{terrain:s,errors:o}=this;for(let a=e-1;a>=0;a--){const l=a*4,c=n[l+0],h=n[l+1],u=n[l+2],d=n[l+3],f=c+u>>1,m=h+d>>1,v=f+m-h,g=m+c-f,p=(s[h*i+c]+s[d*i+u])/2,M=m*i+f,x=Math.abs(p-s[M]);if(o[M]=Math.max(o[M],x),a<t){const b=(h+g>>1)*i+(c+v>>1),D=(d+g>>1)*i+(u+v>>1);o[M]=Math.max(o[M],o[b],o[D])}}}getMesh(e=0,t=!1){const{gridSize:n,indices:i}=this.martini,{errors:s}=this;let o=0,a=0;const l=n-1;let c,h,u=0;const d=[],f=[],m=[],v=[];i.fill(0);function g(P,S,_,y,T,F){const k=P+_>>1,G=S+y>>1;Math.abs(P-T)+Math.abs(S-F)>1&&s[G*n+k]>e?(g(T,F,P,S,k,G),g(_,y,T,F,k,G)):(c=S*n+P,h=y*n+_,u=F*n+T,i[c]===0&&(t&&(P===0?d.push(o):P===l&&f.push(o),S===0?m.push(o):S===l&&v.push(o)),i[c]=++o),i[h]===0&&(t&&(_===0?d.push(o):_===l&&f.push(o),y===0?m.push(o):y===l&&v.push(o)),i[h]=++o),i[u]===0&&(t&&(T===0?d.push(o):T===l&&f.push(o),F===0?m.push(o):F===l&&v.push(o)),i[u]=++o),a++)}g(0,0,l,l,l,0),g(l,l,0,0,0,l);let p=o*2,M=a*3;t&&(p+=(d.length+f.length+m.length+v.length)*2,M+=((d.length-1)*2+(f.length-1)*2+(m.length-1)*2+(v.length-1)*2)*3);const x=new Uint16Array(p),b=new Uint32Array(M);let D=0;function R(P,S,_,y,T,F){const k=P+_>>1,G=S+y>>1;if(Math.abs(P-T)+Math.abs(S-F)>1&&s[G*n+k]>e)R(T,F,P,S,k,G),R(_,y,T,F,k,G);else{const $=i[S*n+P]-1,z=i[y*n+_]-1,Y=i[F*n+T]-1;x[2*$]=P,x[2*$+1]=S,x[2*z]=_,x[2*z+1]=y,x[2*Y]=T,x[2*Y+1]=F,b[D++]=$,b[D++]=z,b[D++]=Y}}if(R(0,0,l,l,l,0),R(l,l,0,0,0,l),t){let S=function(_){const y=_.length;for(let T=0;T<y-1;T++){const F=_[T],k=_[T+1],G=P/2,$=(P+2)/2;x[P++]=x[2*F],x[P++]=x[2*F+1],b[D++]=F,b[D++]=G,b[D++]=k,b[D++]=G,b[D++]=$,b[D++]=k}x[P++]=x[2*_[y-1]],x[P++]=x[2*_[y-1]+1]};d.sort((_,y)=>x[2*_+1]-x[2*y+1]),f.sort((_,y)=>x[2*y+1]-x[2*_+1]),m.sort((_,y)=>x[2*y]-x[2*_]),v.sort((_,y)=>x[2*_]-x[2*y]);let P=o*2;S(d),S(f),S(m),S(v)}return{vertices:x,triangles:b,numVerticesWithoutSkirts:o}}}class Gn extends oi{constructor(e=null,t=null,n=jt.root,i=0,s=0,o=0,{elevationDecoder:a=null,meshMaxError:l=10,exageration:c=1}={}){super(e,t,n,i,s,o,Gn.geometry,Gn.prepareMaterial(new kn({map:Gn.emptyTexture,color:16777215,side:Wn}),i,c)),this.elevationDecoder={rScaler:256,gScaler:1,bScaler:1/256,offset:-32768},this.exageration=1,this.meshMaxError=10,a&&(this.elevationDecoder=a),this.meshMaxError=l,this.exageration=c,this.frustumCulled=!1}static prepareMaterial(e,t,n=1){return e.userData={heightMap:{value:Gn.emptyTexture},drawNormals:{value:0},drawBlack:{value:0},zoomlevel:{value:t},computeNormals:{value:1},drawTexture:{value:1}},e.onBeforeCompile=i=>{for(let s in e.userData)i.uniforms[s]=e.userData[s];i.vertexShader=`
				uniform bool computeNormals;
				uniform float zoomlevel;
				uniform sampler2D heightMap;
				`+i.vertexShader,i.fragmentShader=`
				uniform bool drawNormals;
				uniform bool drawTexture;
				uniform bool drawBlack;
				`+i.fragmentShader,i.fragmentShader=i.fragmentShader.replace("#include <dithering_fragment>",`
				if(drawBlack) {
					gl_FragColor = vec4( 0.0,0.0,0.0, 1.0 );
				} else if(drawNormals) {
					gl_FragColor = vec4( ( 0.5 * vNormal + 0.5 ), 1.0 );
				} else if (!drawTexture) {
					gl_FragColor = vec4( 0.0,0.0,0.0, 0.0 );
				}`),i.vertexShader=i.vertexShader.replace("#include <fog_vertex>",`
				#include <fog_vertex>

				// queried pixels:
				// +-----------+
				// |   |   |   |
				// | a | b | c |
				// |   |   |   |
				// +-----------+
				// |   |   |   |
				// | d | e | f |
				// |   |   |   |
				// +-----------+
				// |   |   |   |
				// | g | h | i |
				// |   |   |   |
				// +-----------+

				if (computeNormals) {
					float e = getElevation(vUv, 0.0);
					ivec2 size = textureSize(heightMap, 0);
					float offset = 1.0 / float(size.x);
					float a = getElevation(vUv + vec2(-offset, -offset), 0.0);
					float b = getElevation(vUv + vec2(0, -offset), 0.0);
					float c = getElevation(vUv + vec2(offset, -offset), 0.0);
					float d = getElevation(vUv + vec2(-offset, 0), 0.0);
					float f = getElevation(vUv + vec2(offset, 0), 0.0);
					float g = getElevation(vUv + vec2(-offset, offset), 0.0);
					float h = getElevation(vUv + vec2(0, offset), 0.0);
					float i = getElevation(vUv + vec2(offset,offset), 0.0);


					float normalLength = 500.0 / zoomlevel;

					vec3 v0 = vec3(0.0, 0.0, 0.0);
					vec3 v1 = vec3(0.0, normalLength, 0.0);
					vec3 v2 = vec3(normalLength, 0.0, 0.0);
					v0.z = (e + d + g + h) / 4.0;
					v1.z = (e+ b + a + d) / 4.0;
					v2.z = (e+ h + i + f) / 4.0;
					vNormal = (normalize(cross(v2 - v0, v1 - v0))).rbg;
				}
				`)},e}static getTerrain(e,t,n){const{rScaler:i,bScaler:s,gScaler:o,offset:a}=n,l=t+1,c=new Float32Array(l*l);for(let h=0,u=0;u<t;u++)for(let d=0;d<t;d++,h++){const f=h*4,m=e[f+0],v=e[f+1],g=e[f+2];c[h+u]=m*i+v*o+g*s+a}for(let h=l*(l-1),u=0;u<l-1;u++,h++)c[h]=c[h-l];for(let h=l-1,u=0;u<l;u++,h+=l)c[h]=c[h-1];return c}static getMeshAttributes(e,t,n,i,s){const o=n+1,a=e.length/2,l=new Float32Array(a*3),c=new Float32Array(a*2),[h,u,d,f]=i||[0,0,n,n],m=(d-h)/n,v=(f-u)/n;for(let g=0;g<a;g++){const p=e[g*2],M=e[g*2+1],x=M*o+p;l[3*g+0]=p*m+h,l[3*g+1]=-t[x]*s,l[3*g+2]=-M*v+f,c[2*g+0]=p/n,c[2*g+1]=M/n}return{position:{value:l,size:3},uv:{value:c,size:2}}}processHeight(e){return sn(this,void 0,void 0,function*(){const t=e.width,n=t+1;var i=eh.createOffscreenCanvas(t,t),s=i.getContext("2d");s.imageSmoothingEnabled=!1,s.drawImage(e,0,0,t,t,0,0,i.width,i.height);var o=s.getImageData(0,0,i.width,i.height),a=o.data;const l=Gn.getTerrain(a,t,this.elevationDecoder),h=new Ob(n).createTile(l),{vertices:u,triangles:d}=h.getMesh(typeof this.meshMaxError=="function"?this.meshMaxError(this.level):this.meshMaxError),f=Gn.getMeshAttributes(u,l,t,[-.5,-.5,.5,.5],this.exageration);this.geometry=new yt,this.geometry.setIndex(new Oc(d,1)),this.geometry.setAttribute("position",new Le(f.position.value,f.position.size)),this.geometry.setAttribute("uv",new Le(f.uv.value,f.uv.size)),this.geometry.rotateX(Math.PI);var m=new qt(e);m.generateMipmaps=!1,m.format=Sn,m.magFilter=gn,m.minFilter=gn,m.needsUpdate=!0,this.material.userData.heightMap.value=m,this.material.map=m,this.material.needsUpdate=!0})}loadHeightGeometry(){return sn(this,void 0,void 0,function*(){if(this.mapView.heightProvider===null)throw new Error("GeoThree: MapView.heightProvider provider is null.");const e=yield this.mapView.heightProvider.fetchTile(this.level,this.x,this.y);this.disposed||(this.processHeight(e),this.heightLoaded=!0,this.nodeReady())})}}Gn.geometrySize=16;Gn.emptyTexture=new qt;Gn.geometry=new Oi(1,1,1,1);Gn.tileSize=256;class pn extends ve{constructor(e=pn.PLANAR,t=new Nb,n=null){super(void 0,new qn({transparent:!0,opacity:0,depthWrite:!1,colorWrite:!1})),this.lod=null,this.provider=null,this.heightProvider=null,this.root=null,this.cacheTiles=!1,this.onBeforeRender=(i,s,o,a,l,c)=>{this.lod.updateLOD(this,o,i,s)},this.lod=new Fb,this.provider=t,this.heightProvider=n,this.setRoot(e),this.preSubdivide()}setRoot(e){if(typeof e=="number"){if(!pn.mapModes.has(e))throw new Error("Map mode "+e+" does is not registered.");const t=pn.mapModes.get(e);e=new t(null,this)}this.root!==null&&(this.remove(this.root),this.root=null),this.root=e,this.root!==null&&(this.geometry=this.root.constructor.baseGeometry,this.scale.copy(this.root.constructor.baseScale),this.root.mapView=this,this.add(this.root),this.root.initialize())}preSubdivide(){var e,t;function n(s,o){if(!(o<=0)){s.subdivide();for(let a=0;a<s.children.length;a++)if(s.children[a]instanceof Mn){const l=s.children[a];n(l,o-1)}}}const i=Math.max(this.provider.minZoom,(t=(e=this.heightProvider)===null||e===void 0?void 0:e.minZoom)!==null&&t!==void 0?t:-1/0);i>0&&n(this.root,i)}setProvider(e){e!==this.provider&&(this.provider=e,this.clear())}setHeightProvider(e){e!==this.heightProvider&&(this.heightProvider=e,this.clear())}clear(){return this.traverse(function(e){e.childrenCache&&(e.childrenCache=null),e.initialize&&e.initialize()}),this}minZoom(){var e,t;return Math.max(this.provider.minZoom,(t=(e=this.heightProvider)===null||e===void 0?void 0:e.minZoom)!==null&&t!==void 0?t:-1/0)}maxZoom(){var e,t;return Math.min(this.provider.maxZoom,(t=(e=this.heightProvider)===null||e===void 0?void 0:e.maxZoom)!==null&&t!==void 0?t:1/0)}getMetaData(){this.provider.getMetaData()}raycast(e,t){return!1}}pn.PLANAR=200;pn.SPHERICAL=201;pn.HEIGHT=202;pn.HEIGHT_SHADER=203;pn.MARTINI=204;pn.mapModes=new Map([[pn.PLANAR,Zn],[pn.SPHERICAL,ws],[pn.HEIGHT,oi],[pn.HEIGHT_SHADER,bn],[pn.MARTINI,Gn]]);new I;new I;new Te;new I;new xa;new I;class Tf{static get(e){return sn(this,void 0,void 0,function*(){return new Promise(function(t,n){const i=new XMLHttpRequest;i.overrideMimeType("text/plain"),i.open("GET",e,!0),i.onload=function(){t(i.response)},i.onerror=n,i.send(null)})})}static getRaw(e){return sn(this,void 0,void 0,function*(){return new Promise(function(t,n){var i=new XMLHttpRequest;i.responseType="arraybuffer",i.open("GET",e,!0),i.onload=function(){t(i.response)},i.onerror=n,i.send(null)})})}static request(e,t,n,i,s,o,a){function l(h){try{return JSON.parse(h)}catch{return h}}const c=new XMLHttpRequest;if(c.overrideMimeType("text/plain"),c.open(t,e,!0),n!=null)for(const h in n)c.setRequestHeader(h,n[h]);return s!==void 0&&(c.onload=function(h){s(l(c.response),c)}),o!==void 0&&(c.onerror=o),a!==void 0&&(c.onprogress=a),c.send(i!==void 0?i:null),c}}class pi extends Kr{constructor(e="",t=pi.AERIAL){super(),this.maxZoom=19,this.minZoom=1,this.format="jpeg",this.mapSize=512,this.subdomain="t1",this.meta=null,this.apiKey=e,this.type=t}getMetaData(){return sn(this,void 0,void 0,function*(){const e=pi.ADDRESS+"/REST/V1/Imagery/Metadata/RoadOnDemand?output=json&include=ImageryProviders&key="+this.apiKey,t=yield Tf.get(e);this.meta=JSON.parse(t)})}static quadKey(e,t,n){let i="";for(let s=e;s>0;s--){const o=1<<s-1;let a=0;(t&o)!==0&&a++,(n&o)!==0&&(a+=2),i+=a}return i}fetchTile(e,t,n){return new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",o.src="http://ecn."+this.subdomain+".tiles.virtualearth.net/tiles/"+this.type+pi.quadKey(e,t,n)+".jpeg?g=1173"})}}pi.ADDRESS="https://dev.virtualearth.net";pi.AERIAL="a";pi.ROAD="r";pi.AERIAL_LABELS="h";pi.OBLIQUE="o";pi.OBLIQUE_LABELS="b";class kb extends Kr{constructor(e="",t="",n="base",i="normal.day",s="png",o=512){super(),this.appId=e,this.appCode=t,this.style=n,this.scheme=i,this.format=s,this.size=o,this.version="newest",this.server=1}nextServer(){this.server=this.server%4===0?1:this.server+1}getMetaData(){return sn(this,void 0,void 0,function*(){})}fetchTile(e,t,n){return this.nextServer(),new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",o.src="https://"+this.server+"."+this.style+".maps.api.here.com/maptile/2.1/maptile/"+this.version+"/"+this.scheme+"/"+e+"/"+t+"/"+n+"/"+this.size+"/"+this.format+"?app_id="+this.appId+"&app_code="+this.appCode})}}kb.PATH="/maptile/2.1/";class Ci extends Kr{constructor(e="",t="",n=Ci.STYLE,i="png",s=!1,o="v4"){super(),this.apiToken=e,this.format=i,this.useHDPI=s,this.mode=n,this.mapId=t,this.style=t,this.version=o}getMetaData(){return sn(this,void 0,void 0,function*(){const e=Ci.ADDRESS+this.version+"/"+this.mapId+".json?access_token="+this.apiToken,t=yield Tf.get(e),n=JSON.parse(t);this.name=n.name,this.minZoom=n.minZoom,this.maxZoom=n.maxZoom,this.bounds=n.bounds,this.center=n.center})}fetchTile(e,t,n){return new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",this.mode===Ci.STYLE?o.src=Ci.ADDRESS+"styles/v1/"+this.style+"/tiles/"+e+"/"+t+"/"+n+(this.useHDPI?"@2x?access_token=":"?access_token=")+this.apiToken:o.src=Ci.ADDRESS+"v4/"+this.mapId+"/"+e+"/"+t+"/"+n+(this.useHDPI?"@2x.":".")+this.format+"?access_token="+this.apiToken})}}Ci.ADDRESS="https://api.mapbox.com/";Ci.STYLE=100;Ci.MAP_ID=101;class zb extends Kr{mapName;constructor(){super()}fetchTile(e,t,n){if(this.mapName)return new Promise((i,s)=>{const o=document.createElement("img");o.onload=()=>i(o),o.onerror=()=>s(),o.crossOrigin="anonymous",o.src=`${Pf}/api/map/tiles/${this.mapName}/${e}/${t}/${n}`})}setMapName(e){this.mapName=e}}class Hb{tileProvider;mapView;editor;constructor(e){const t=new zb;t.minZoom=0,t.maxZoom=25;const n=new pn(pn.PLANAR,t);n.position.set(0,-.2,-0),this.editor=e,this.mapView=n,this.tileProvider=t}dispose=()=>{this.deregisterEventListeners()};handleMapName=e=>{this.tileProvider.setMapName(e)};registerEventListeners=()=>{const e=this.editor.eventHandler.eventBus;e.on("setTileVisibility",this.handleToggleTile),e.on("updatemapNameData",this.handleMapName)};deregisterEventListeners=()=>{const e=this.editor.eventHandler.eventBus;e.off("setTileVisibility",this.handleToggleTile),e.off("updatemapNameData",this.handleMapName)};handleToggleTile=e=>{e?this.addToScene():this.removeToScene()};addToScene=()=>{this.editor.scene.add(this.mapView)};removeToScene=()=>{this.editor.scene.remove(this.mapView)}}class Vb extends Mt{constructor(){super(),this.name="S100Helper",this.userData.keep=!0,this.visible=!1,this._init()}updatePosition(e){const t=this.parent.worldToLocal(e.clone());this.position.copy(t)}updateRotation(e){const t=this.parent.worldToLocal(e.clone()),n=t.x-this.position.x,i=t.y-this.position.y;this.rotation.z=Math.atan2(i,n)}_init(){const e=new mf,t=Ea("/s100low.fbx");new Promise((n,i)=>{e.load(t,s=>{s.traverse(a=>{if(a.userData.keep=!0,a instanceof ve){const l=a.material;Array.isArray(l)&&(a.material=l.map(()=>new Hr({color:new Ge(12436423),transparent:!0,opacity:.3})))}}),s.scale.setScalar(.1),s.rotation.set(Math.PI/2,0,0),s.updateMatrixWorld(!0),s.userData.keep=!0;const o=new Yc(10);o.userData.keep=!0,o.rotation.x=-Math.PI/2,s.add(o),n(s)},void 0,s=>{console.error(s),i(s)})}).then(n=>{this.add(n)}).catch(n=>{console.error("Failed to load s100 model:",n)})}}const Wr=new Qt(50,1,.01,1e3);Wr.name="Camera";Wr.position.set(0,20,0);Wr.lookAt(new I);class tr{static instance;env="prod";nodeManager;eventHandler;robotManager;selector;eraser;pathDrawer;pointsManager;scene;sceneHelpers;zUpGroup;camera;viewportCamera;_selected;selectableObjects;selectedObjects;previewHelper;globalPlane;tileMap;constructor(){this._selected=null,this.nodeManager=new pb(this),this.eventHandler=new fb(this),this.robotManager=new Db(this),this.selector=new Ib(this),this.eraser=new ub(this),this.pathDrawer=new xb(this),this.pointsManager=new Mb(this),this.tileMap=new Hb(this)}static getInstance(){return tr.instance||(tr.instance=new tr),tr.instance}get selected(){return this._selected}set selected(e){this._selected=e}async initialize(){this.scene=new mc,this.sceneHelpers=new mc,this.zUpGroup=new Mt,this.zUpGroup.rotation.x=-Math.PI/2,this.zUpGroup.name="zUpGroup",this.zUpGroup.userData.keep=!0,this.scene.add(this.zUpGroup),this.camera=Wr.clone(),this.viewportCamera=this.camera;const e=new mr(1e4,1e4),t=new qn({visible:!1}),n=new ve(e,t);n.name="globalPlane",n.userData.keep=!0,this.globalPlane=n,this.zUpGroup.add(this.globalPlane);const i=new Gc(16777215);i.userData.keep=!0,this.scene.add(i);const s=new pa(16777215);s.userData.keep=!0,s.position.set(0,1e4,0),this.scene.add(s);const o=new pa(16777215);o.userData.keep=!0,o.position.set(0,-1e4,0),this.scene.add(o),this.sceneHelpers.add(new Zm(16777215,8947848,2)),this.selectableObjects=[],this.selectedObjects=[],this.eventHandler.registerEventListeners(),this.eventHandler.registerCanvasEventListeners(),this.selector.registerEventListeners(),this.pointsManager.registerEventListeners(),this.tileMap.registerEventListeners(),this.eraser.registerEventListeners(),this.nodeManager.registerEventListeners(),this.nodeManager.cacheMeshes(),this.setupPreviewHelper(),this.eventHandler.eventBus.emit("editor:initialized")}addOrigin(e){const t=new jr(.1),n=new qn({color:16711680}),i=new ve(t,n);i.name="origin";const s=new Yc(e);i.add(s),this.zUpGroup.add(i)}clear(e={clearCloud:!0,clearTopo:!0}){e.clearCloud&&this.pointsManager.clearCloud(),e.clearTopo&&this.clearTopo()}resetCamera(){this.camera.copy(Wr),this.eventHandler.eventBus.emit("cameraReset")}clearTopo(){const e=[];this.zUpGroup.traverse(t=>{t instanceof wa&&t.userData.labelType==="node"?(t.element&&t.element.parentNode&&t.element.parentNode.removeChild(t.element),e.push(t)):t.userData.keep||e.push(t)});for(let t=0,n=e.length;t<n;t++){const i=e[t];this.removeObject(i)}this.resetSelections(),this.eventHandler.eventBus.emit("topoCleared")}resetSelections(){this.selected=null,this.selectableObjects=[],this.selectedObjects=[]}dispose(){for(this.eventHandler.dispose(),this.eraser.dispose(),this.pathDrawer.dispose(),this.robotManager.dispose(),this.selector.dispose(),this.pointsManager.dispose(),this.nodeManager.dispose(),this.tileMap.dispose(),this.scene.traverse(e=>{e instanceof ve&&(e.geometry&&e.geometry.dispose(),e.material&&Array.isArray(e.material)&&e.material.forEach(t=>{t.dispose()}))});this.scene.children.length>0;)this.scene.remove(this.scene.children[0])}async drawTopo(e){if(!e||!e.length)return;const t=e.map((n,i)=>{const s=n.pose.split(",").map(Number),o={x:s[0],y:s[1],z:s[2],rz:s[5],idx:i},a={name:n.name,id:n.id,info:n.info,rz:o.rz};if(n.type===gs.GOAL)return this.nodeManager.addNode("GOAL",o,a);if(n.type===gs.ROUTE)return this.nodeManager.addNode("ROUTE",o,a);if(n.type===gs.INIT)return this.nodeManager.addNode("INIT",o,a)});await Promise.all(t);for(let n=0,i=e.length;n<i;n++){const s=e[n],o=this.zUpGroup.getObjectByName(s.name);for(let a=0;a<s.links.length;a++){const l=s.links[a],c=this.getObjectBySlamId(l);o&&c&&this.nodeManager.linkNodes(o,c)}}}getObjectBySlamId(e){let t=null;return this.zUpGroup.traverse(n=>{n.userData.id===e&&(t=n)}),t}removeObject(e){e.parent!==null&&(e.parent.remove(e),this.eventHandler.eventBus.emit("objectRemoved",{object:e,label:e.children[0]}))}setupPreviewHelper(){const e=new Vb;this.previewHelper=e,this.zUpGroup.add(this.previewHelper)}}const ad=new ye,ld=new ye,Cl=new ye;let Ys=null,cd=0;const Gb=200,Wb=3,hd=new ye,ud=new ye,Zo=new Cn,qi=new ye,Zs=new ye,Xb=.15,dd=[1,3,6,12,20,40],Ko=["text-7xl","text-5xl","text-4xl","text-base","text-sm","text-xs","hidden"];class jb{editor;_renderCSS2D;container;scene;sceneHelpers;camera;renderer;css2DRenderer;robotPos=new I;robotQuat=new Pt;lookOffset=new I;robotForward=new I;PRIMARY_MOUSE_BUTTON=0;tmpView=new I;control;arcball;orbit;transformControls;selectionBox;boxSelectHelper;labels;clock;grid;stats;interactionTimer;pointerAction="none";constructor(e,t){this.editor=e,this._renderCSS2D=!1,this.scene=e.scene,this.sceneHelpers=e.sceneHelpers,this.camera=e.camera,this.labels=[],this.clock=new $d;const n=document.querySelector("#three-canvas");this.renderer=new Yx({canvas:n,antialias:!0});const i=document.querySelector(`#${t}-canvas__wrapper`);this.container=i,this.stats=[],this.renderer.domElement.addEventListener("pointerdown",this.onPointerDown),this.renderer.setClearColor(3355443),this.renderer.setPixelRatio(window.devicePixelRatio),this.renderer.setSize(i.clientWidth,i.clientHeight),this.renderer.setAnimationLoop(this.animate),n.tabIndex=0,n.style.outline="none",this.camera instanceof Qt&&(this.camera.aspect=n.clientWidth/n.clientHeight,this.camera.updateProjectionMatrix()),this.css2DRenderer=new hb,this.css2DRenderer.setSize(n.clientWidth,n.clientHeight),this.css2DRenderer.domElement.style.position="absolute",this.css2DRenderer.domElement.style.top=`${n.parentElement?.offsetTop}px`,this.css2DRenderer.domElement.style.pointerEvents="none",n.parentElement?.appendChild(this.css2DRenderer.domElement),this.control="orbit",this.orbit=new Kx(this.editor.camera,this.renderer.domElement),this.orbit.mouseButtons={LEFT:Ii.PAN,MIDDLE:Ii.DOLLY,RIGHT:Ii.ROTATE},this.orbit.touches={ONE:Ki.PAN,TWO:Ki.DOLLY_ROTATE},this.orbit.panSpeed=.75,this.orbit.rotateSpeed=.75,this.orbit.zoomSpeed=.5,this.orbit.enableRotate=!0,this.orbit.maxPolarAngle=Math.PI/2,this.orbit.zoomToCursor=!0,this.orbit.addEventListener("change",this.handleOrbitChange),this.transformControls=new cy(this.camera,this.renderer.domElement),this.transformControls.addEventListener("dragging-changed",h=>{this.orbit.enabled=!h.value}),this.transformControls.addEventListener("objectChange",this.handleTransformChange),this.transformControls.addEventListener("object-changed",this.handleTransformChange);const s=this.transformControls.getHelper();this.sceneHelpers.add(s),this.selectionBox=new ug(Zo),this.selectionBox.material.depthTest=!1,this.selectionBox.material.transparent=!0,this.selectionBox.visible=!1,this.sceneHelpers.add(this.selectionBox),this.boxSelectHelper=document.createElement("div"),this.boxSelectHelper.style.position="absolute",this.boxSelectHelper.style.border="1px dashed #ffffff",this.boxSelectHelper.style.background="rgba(255, 255, 255, 0.1)",this.boxSelectHelper.style.pointerEvents="none",document.body.appendChild(this.boxSelectHelper);const o=[5592405,8947848],a=new Mt;a.rotation.x=-Math.PI/2;const l=new nu(50,50);l.material.color.setHex(o[0]),l.material.vertexColors=!1,l.rotateX(Math.PI/2),a.add(l);const c=new nu(50,10);c.material.color.setHex(o[1]),c.material.vertexColors=!1,c.rotateX(Math.PI/2),a.add(c),this.grid=a,this.grid.visible=!1,this.render(),this.registerEventListeners()}get renderCSS2D(){return this._renderCSS2D}set renderCSS2D(e){this._renderCSS2D=e}animate=e=>{const t=e*.001-Xb;this.editor.robotManager.updateAll(t),this.control==="follow"&&this.alignCameraToRobotView(),this.render(),this.editor.env==="dev"&&this.stats.forEach(n=>n.update())};registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("cameraReset",this.handleCameraReset),e.on("objectSelected",this.handleObjectSelected),e.on("objectsSelected",this.handleObjectsSelected),e.on("objectTransformChanged",this.handleObjectTransformChanged),e.on("changeSelectMode",this.handleChangeSelectMode),e.on("cloudCleared",this.handleCloudCleared),e.on("objectRemoved",this.handleObjectRemoved),e.on("setGridVisibility",this.handleSetGridVisibility),e.on("controlChanged",this.handleControlChanged),e.on("toggleTransformAxisY",this.handleToggleTransformAxisY),e.on("toggleLocalizationMode",this.handleToggleLocalizationMode),e.on("setLabelVisibility",this.handleSetLabelVisibility),e.on("labelAdded",this.handleLabelAdded),e.on("setPointerAction",this.handleSetPointerAction),window.addEventListener("resize",this.resizeWindow)}deregisterEventListeners(){const e=this.editor.eventHandler.eventBus;e.off("cameraReset",this.handleCameraReset),e.off("objectSelected",this.handleObjectSelected),e.off("objectsSelected",this.handleObjectsSelected),e.off("objectTransformChanged",this.handleObjectTransformChanged),e.off("changeSelectMode",this.handleChangeSelectMode),e.off("cloudCleared",this.handleCloudCleared),e.off("objectRemoved",this.handleObjectRemoved),e.off("setGridVisibility",this.handleSetGridVisibility),e.off("controlChanged",this.handleControlChanged),e.off("toggleTransformAxisY",this.handleToggleTransformAxisY),e.off("toggleLocalizationMode",this.handleToggleLocalizationMode),e.off("setLabelVisibility",this.handleSetLabelVisibility),e.off("labelAdded",this.handleLabelAdded),e.off("setPointerAction",this.handleSetPointerAction),window.removeEventListener("resize",this.resizeWindow)}dispose(){this.editor.env==="dev"&&this.stats.forEach(e=>e.dom.remove()),this.renderer.setAnimationLoop(null),this.renderer.dispose(),this.css2DRenderer.domElement.remove(),this.renderer.domElement.removeEventListener("pointerdown",this.onPointerDown),this.orbit.dispose(),this.deregisterEventListeners()}handleLabelAdded=e=>{this.labels.push(e)};handleSetLabelVisibility=e=>{this.renderCSS2D=e,this.resizeLabels(),this.css2DRenderer.domElement.style.display=this.renderCSS2D?"":"none";const t=this.editor.selectableObjects;for(let n=0;n<t.length;n++)t[n].traverse(s=>{s instanceof wa&&(s.visible=e)})};handleToggleLocalizationMode=e=>{e?(this.editor.previewHelper.visible=!0,this.transformControls.setMode("rotate"),this.transformControls.showX=!1,this.transformControls.showY=!0,this.transformControls.showZ=!1,this.transformControls.attach(this.editor.previewHelper)):(this.editor.previewHelper.visible=!1,this.transformControls.setMode("translate"),this.transformControls.showX=!0,this.transformControls.showY=!1,this.transformControls.showZ=!0,this.transformControls.detach()),this.orbit.update()};render=()=>{this.renderer.render(this.editor.scene,this.editor.viewportCamera),this.renderCSS2D&&this.css2DRenderer.render(this.editor.scene,this.editor.viewportCamera),this.renderer.autoClear=!1,this.renderer.render(this.grid,this.editor.viewportCamera),this.sceneHelpers.visible&&this.renderer.render(this.sceneHelpers,this.editor.viewportCamera),this.renderer.autoClear=!0};resizeWindow=()=>{const e=this.editor.camera,n=this.renderer.domElement.parentNode;e instanceof Qt&&(e.aspect=n.clientWidth/n.clientHeight,e.updateProjectionMatrix(),this.renderer.setSize(n.clientWidth,n.clientHeight),this.css2DRenderer.setSize(n.clientWidth,n.clientHeight))};depthToBucket(e){for(let t=0;t<dd.length;t++)if(e<dd[t])return t;return Ko.length-1}resizeLabels=()=>{const{camera:e,labels:t,tmpView:n}=this;e.updateMatrixWorld();const i=e.matrixWorldInverse;for(const s of t){s.worldPosition||(s.worldPosition=new I,s.obj.getWorldPosition(s.worldPosition)),n.copy(s.worldPosition).applyMatrix4(i);const o=Math.abs(n.z),a=this.depthToBucket(o);if(a!==s.bucket){const l=s.obj.element;s.bucket!==null?l.classList.replace(Ko[s.bucket],Ko[a]):l.classList.add(Ko[a]),s.bucket=a}}};alignCameraToRobotView(){this.editor.robotManager.mainRobot&&(this.setCameraPosition(),this.setCameraOrientation())}getRobotWorldPose(){const e=this.editor.robotManager.mainRobot;return e.getWorldPosition(this.robotPos),e.getWorldQuaternion(this.robotQuat),{pos:this.robotPos,quat:this.robotQuat}}computeShoulderOffset(e){return this.lookOffset.set(-4,0,2).applyQuaternion(e)}setCameraPosition(){const{pos:e,quat:t}=this.getRobotWorldPose(),n=this.computeShoulderOffset(t);this.camera.position.copy(e).add(n)}setCameraOrientation(){const{pos:e,quat:t}=this.getRobotWorldPose(),n=this.robotForward.set(1,0,0).applyQuaternion(t);this.camera.lookAt(e.clone().add(n.multiplyScalar(10)))}getNormalizedPos(e,t){const n=this.renderer.domElement.getBoundingClientRect();return[(e-n.left)/n.width,(t-n.top)/n.height]}onPointerDown=e=>{cd=performance.now(),e.preventDefault(),e.target===this.renderer.domElement&&(this.renderer.domElement.setPointerCapture(e.pointerId),Ys=e.pointerId,ad.fromArray(this.getNormalizedPos(e.clientX,e.clientY)),hd.set(e.clientX,e.clientY),e.pointerType==="mouse"&&this.editor.selector.mode==="box"&&e.button===0&&(qi.set(e.clientX,e.clientY),Object.assign(this.boxSelectHelper.style,{left:`${qi.x}px`,top:`${qi.y}px`,width:"0px",height:"0px",display:"block"})),this.renderer.domElement.addEventListener("pointermove",this.onPointerMove,{passive:!1}),this.renderer.domElement.addEventListener("pointerup",this.onPointerUp),this.renderer.domElement.addEventListener("pointercancel",this.onPointerUp))};onPointerMove=e=>{if(!(e.pointerId!==Ys||(e.preventDefault(),ld.fromArray(this.getNormalizedPos(e.clientX,e.clientY)),!this.editor.selector.getPointerPlaneIntersection(ld,this.editor.camera).length))&&e.pointerType==="mouse"&&e.buttons===1&&this.editor.selector.mode==="box"){Zs.set(e.clientX,e.clientY);const n=Math.min(qi.x,Zs.x),i=Math.min(qi.y,Zs.y),s=Math.abs(Zs.x-qi.x),o=Math.abs(Zs.y-qi.y);Object.assign(this.boxSelectHelper.style,{left:`${n}px`,top:`${i}px`,width:`${s}px`,height:`${o}px`})}};finishPointer=()=>{this.renderer.domElement.removeEventListener("pointermove",this.onPointerMove),this.renderer.domElement.removeEventListener("pointerup",this.onPointerUp),this.renderer.domElement.removeEventListener("pointercancel",this.onPointerUp),Ys!==null&&(this.renderer.domElement.releasePointerCapture(Ys),Ys=null),this.boxSelectHelper.style.display="none"};onPointerUp=e=>{if(e.pointerId!==Ys)return;Cl.fromArray(this.getNormalizedPos(e.clientX,e.clientY)),ud.set(e.clientX,e.clientY);const t=e.pointerType==="mouse"&&e.button===this.PRIMARY_MOUSE_BUTTON,n=e.pointerType==="touch";(t||n)&&this.handlePrimaryPointerAction(),this.finishPointer()};handlePrimaryPointerAction=()=>{const e=performance.now()-cd,t=hd.distanceToSquared(ud),n=Math.pow(Wb*devicePixelRatio,2);if(e<Gb&&t<=n)switch(this.pointerAction){case"none":break;case"select":this.handleSelect();break;case"locatePreview":this.updatePreviewOnPointer();break;case"erase":this.handleErase();break;default:this.pointerAction}else this.editor.selector.mode==="box"&&this.handleBoxSelect();this.render()};handleErase=()=>{const e=this.editor.selector.getPointerQuadTreeIntersections(Cl,this.editor.camera);this.editor.eventHandler.eventBus.emit("eraser:intersectionsDetected",e)};updatePreviewOnPointer=()=>{const e=this.editor.selector.getPointerPlaneIntersection(ad,this.editor.camera);e.length&&(this.editor.previewHelper.updatePosition(e[0].point),this.transformControls.attach(this.editor.previewHelper))};handleSelect=()=>{const e=this.editor.selector.getPointerObjectIntersections(Cl,this.editor.camera);this.editor.eventHandler.eventBus.emit("intersectionsDetected",e)};handleCameraReset=()=>{const e=this.renderer.domElement;this.camera instanceof Qt&&(this.camera.aspect=e.clientWidth/e.clientHeight,this.camera.updateProjectionMatrix(),this.orbit.target.set(0,0,0))};handleBoxSelect=()=>{this.boxSelectHelper.style.display="none";const e=this.editor.selector.getSelectionBoxIntersects(this.renderer.domElement,qi,Zs);e.length&&this.editor.eventHandler.eventBus.emit("boxIntersectionsDetected",e)};handleTransformChange=()=>{if(this.transformControls.object){const e=St.radToDeg(this.transformControls.object.rotation.z);this.editor.eventHandler.eventBus.emit("objectTransformChanged",{x:this.transformControls.object.position.x.toString().slice(0,6),y:this.transformControls.object.position.y.toString().slice(0,6),rz:e.toString().slice(0,6)})}else this.editor.eventHandler.eventBus.emit("objectTransformChanged",null)};handleObjectSelected=e=>{this.selectionBox.visible=!1,this.transformControls.detach();const t=e.object;if(t!==null){Zo.setFromObject(t,!0),Zo.isEmpty()||(this.selectionBox.visible=!0);const n=t.material;n.opacity=.4,this.transformControls.attach(t)}else{const n=this.editor.selectableObjects;for(let i=0;i<n.length;i++){const s=n[i];s.material.opacity=1}}};handleObjectsSelected=e=>{const t=e.selectedObjects;for(let n=0;n<t.length;n++){const s=t[n].material;s.opacity=.4}};handleObjectTransformChanged=()=>{if(this.editor.nodeManager.updateLinks(),this.editor.selected){Zo.setFromObject(this.editor.selected,!0);const e=this.editor.selected.children[0];if(e){if(!this.renderCSS2D)return;clearTimeout(this.interactionTimer),this.interactionTimer=setTimeout(()=>{const t=this.labels.find(n=>n.obj===e);t.worldPosition=new I,t.obj.getWorldPosition(t.worldPosition),this.resizeLabels()},200)}}};handleChangeSelectMode=e=>{e==="box"?this.orbit.enablePan=!1:(this.orbit.enablePan=!0,this.boxSelectHelper.style.display="none")};handleCloudCleared=()=>{this.selectionBox.visible=!1,this.transformControls.detach()};handleObjectRemoved=e=>{if(!e.label)return;const t=e.label,n=this.labels.findIndex(i=>i.obj===t);n>-1&&this.labels.splice(n,1),this.selectionBox.visible=!1,this.transformControls.detach()};handleSetGridVisibility=e=>{this.grid.visible=e};handleControlChanged=e=>{e==="orbit"?this.activateOrbitMode():e==="follow"&&this.activateFollowMode()};activateOrbitMode(){this.orbit.enabled=!0;const{pos:e}=this.getRobotWorldPose();this.orbit.target.copy(e);const t=this.editor.robotManager.mainRobot,n=new _i;new Cn().setFromObject(t).getBoundingSphere(n);const i=n.radius||1,s=this.camera.position.clone().sub(this.orbit.target).normalize(),o=St.clamp(i*15,this.orbit.minDistance+.1,this.orbit.maxDistance-.1);this.camera.position.copy(this.orbit.target).addScaledVector(s,o),this.orbit.update(),this.control="orbit"}activateFollowMode(){this.orbit.enabled=!1,this.control="follow"}handleToggleTransformAxisY=e=>{this.transformControls.showY=e};handleOrbitChange=()=>{this.renderCSS2D&&(clearTimeout(this.interactionTimer),this.interactionTimer=setTimeout(()=>{this.resizeLabels()},200))};handleSetPointerAction=e=>{this.pointerAction=e}}const qb=({className:r})=>ra("div",{className:xd("absolute z-50 flex justify-center items-center w-full h-full text-5xl text-white bg-[#333]",r),children:ra(Lf,{size:"3rem"})}),fd=r=>{let e;const t=new Set,n=(c,h)=>{const u=typeof c=="function"?c(e):c;if(!Object.is(u,e)){const d=e;e=h??(typeof u!="object"||u===null)?u:Object.assign({},e,u),t.forEach(f=>f(e,d))}},i=()=>e,a={setState:n,getState:i,getInitialState:()=>l,subscribe:c=>(t.add(c),()=>t.delete(c))},l=e=r(n,i,a);return a},Yb=r=>r?fd(r):fd,pd=await yd("react"),Zb=r=>r;function Kb(r,e=Zb){const t=pd.useSyncExternalStore(r.subscribe,()=>e(r.getState()),()=>e(r.getInitialState()));return pd.useDebugValue(t),t}const md=r=>{const e=Yb(r),t=n=>Kb(e,n);return Object.assign(t,e),t},$b=r=>r?md(r):md,Jb=$b(r=>({handle:null,setHandle:e=>r({handle:e}),clearHandle:()=>r({handle:null})})),{forwardRef:Qb,useEffect:cs,useImperativeHandle:eM,useMemo:tM,useRef:gd,useState:_d,useCallback:vd}=await yd("react"),nM=Qb(({className:r,parameters:e,onSelectChange:t,onLoadingChange:n,onSelectedObjectTransformChange:i},s)=>{const[o,a]=_d(!1),[l,c]=_d(!1),h=gd(tr.getInstance()).current,u=If(),d=gd(h.eventHandler.eventBus).current,f=!o||!l,m=tM(()=>({addNodeByPreview(){if(!h?.previewHelper.visible)return;const x=h.previewHelper.position,b={x:x.x,y:x.y,z:x.z,rz:h.previewHelper.rotation.z};h.nodeManager.addNode("GOAL",b)},clear(){h.clear({clearCloud:!0,clearTopo:!0})},deleteNodes(){const x=h.selectedObjects;x.length?x.forEach(b=>{h.removeObject(b)}):io.openToast({type:"fail",title:"노드 삭제",content:"선택된 노드가 없습니다",position:"top-right",duration:5e3})},deletePoints(){d.emit("eraser:deletePoints")},getAnnotationData(){return h.selectableObjects.map(x=>{const D=x.position.toArray().map(y=>y.toString().slice(0,6)).toString(),P=x.rotation.toArray().slice(0,3).map(y=>(y*(180/Math.PI)).toString().slice(0,6)).toString(),S=`${D},${P}`,_=x.userData.slamLinks;return{id:x.userData.id,name:x.name,pose:S,info:x.userData.info,links:_,type:x.userData.type}})},getCloudPointsData(){return h.pointsManager.cloudPointsData},getPreviewHelperTransformData(){const x=h.previewHelper;return{x:x.position.x.toString(),y:x.position.y.toString(),z:x.position.z.toString(),rz:(x.rotation.z*(180/Math.PI)).toString()}},linkSelectedNodesBidirectionally(){const x=h.selectedObjects;if(x.length>1)for(let b=0;b<x.length-1;b++){const D=x[b],R=x[b+1];h.nodeManager.linkNodes(D,R),h.nodeManager.linkNodes(R,D)}else io.openToast({type:"fail",title:"링크 연결",content:"2개 이상의 노드를 선택해 주세요.",position:"top-right",duration:5e3})},linkSelectedNodesMonodirectionally(){const x=h.selectedObjects;if(x.length>1)for(let b=0;b<x.length-1;b++){const D=x[b],R=x[b+1];h.nodeManager.linkNodes(D,R)}else io.openToast({type:"fail",title:"링크 연결",content:"2개 이상의 노드를 선택해 주세요.",position:"top-right",duration:5e3})},quickAddNode(){h.eventHandler.eventBus.emit("quickAddNode")},resetSelection(){d.emit("resetSelection")},setControlMode(x){h.eventHandler.eventBus.emit("controlChanged",x)},setLabelVisibility(x){d.emit("setLabelVisibility",x)},toggleLocalizationMode(x){d.emit("toggleLocalizationMode",x)},setGridVisibility(x){h.eventHandler.eventBus.emit("setGridVisibility",x)},setPointerAction(x){d.emit("setPointerAction",x)},startMapping(){d.emit("mappingStarted")},stopMapping(){d.emit("mappingStopped")},setTileVisibility(x){h.eventHandler.eventBus.emit("setTileVisibility",x)},restorePoints(){d.emit("eraser:restorePoints")},toggleEraser(x){d.emit("eraser:toggled",x)},toggleLidarVisibility(){h.pointsManager.lidarPoints.visible=!h.pointsManager.lidarPoints.visible},unselectPoints(){d.emit("eraser:unselectPoints")},unlinkSelectedNodes(){const x=h.selectedObjects;if(x.length>1)for(let b=0;b<x.length-1;b++){const D=x[b],R=x[b+1];h.nodeManager.unlinkNodes(D,R)}else io.openToast({type:"fail",title:"링크 삭제",content:"2개 이상의 노드를 선택해 주세요.",position:"top-right",duration:5e3})},updateCloudData(x){x===void 0?h.clear({clearCloud:!0,clearTopo:!1}):h.eventHandler.eventBus.emit("cloudLoaded",x)},updateMappingCloudData(x){x&&d.emit("mappingDataReceived",x)},updateTopoData(x){x===void 0?h.clear({clearCloud:!1,clearTopo:!0}):h.eventHandler.eventBus.emit("topoLoaded",{reset:!1,topoData:x})},updateMapNameData(x){x&&h.eventHandler.eventBus.emit("updatemapNameData",x)}}),[h,d]),{setHandle:v,clearHandle:g}=Jb();eM(s,()=>m,[m]);const p=vd(async()=>{a(!0)},[]),M=vd(async()=>{setTimeout(()=>{c(!0)},300)},[]);return cs(()=>(v(m),()=>{g()}),[m,v,g]),cs(()=>{console.log("====== EDITOR INIT ======"),d.on("editor:initialized",p),d.on("robotmanager:mainrobot:loaded",M),h.initialize();const x=new jb(h,"editor");return()=>{h.dispose(),x.dispose(),d.off("editor:initialized",p),d.off("robotmanager:mainrobot:loaded",M),console.log("====== EDITOR DISPOSED ======")}},[h,d,p,M]),cs(()=>{o&&(h.robotManager.loadMainRobot(e.robot),d.emit("setGridVisibility",e.isGridVisible),d.emit("toggleTransformAxisY",e.useAxisY))},[o]),cs(()=>{if(t)return h.eventHandler.eventBus.on("objectSelected",t),()=>{h.eventHandler.eventBus.off("objectSelected",t)}},[h,t]),cs(()=>{if(i)return h.eventHandler.eventBus.on("objectTransformChanged",i),()=>{h.eventHandler.eventBus.off("objectTransformChanged",i)}}),cs(()=>{const x=h.robotManager.mainRobot;if(u?.data){const b={x:parseFloat(u.pose.x),y:parseFloat(u.pose.y),rz:parseFloat(u.pose.rz)*Math.PI/180};h.eventHandler.eventBus.emit("lidarUpdated",{lidarPoints:u.data,pose:b}),x&&u.pose&&x.applyPose(u.pose)}},[h,u]),cs(()=>{n&&n(f)},[f,n]),Df("div",{id:"editor-canvas__wrapper",className:xd("h-full w-full",r),children:[(!o||!l)&&ra(qb,{}),ra("canvas",{id:"three-canvas"})]})});nM.displayName="EditorComponent";class oM extends Mt{centerToLegX=.19725;centerToLegY=.09;centerToHipX=.11493;hipToThigh=.10285;thighToKnee=.3;kneeToFoot=.294;rearRightLeg;rearLeftLeg;frontRightLeg;frontLeftLeg;constructor(){super(),this.name="RBQ10_Robot",this.userData.keep=!0,this.init()}loadObj(e){return new Promise((t,n)=>{new lb().load(e,s=>t(s),void 0,s=>n(s))})}init(){const t=["fuselage","leg3","hip1","hip3","thigh_right","thigh_left","calf","foot"].map(n=>{const i=Ea(`/rbq10/${n}.obj`);return this.loadObj(i).then(s=>({name:n,obj:s}))});Promise.all(t).then(n=>{const i={};n.forEach(o=>{i[o.name]=o.obj}),this.name="rbq10";const s=i.fuselage.clone();s.name="fuselage",this.add(s),this.rotateX(St.degToRad(90)),this.rearRightLeg=this.createRearRightLeg(i),this.rearRightLeg.position.set(-this.centerToLegX,0,this.centerToLegY),this.add(this.rearRightLeg),this.rearLeftLeg=this.createRearLeftLeg(i),this.rearLeftLeg.position.set(-this.centerToLegX,0,-this.centerToLegY),this.add(this.rearLeftLeg),this.frontRightLeg=this.createFrontRightLeg(i),this.frontRightLeg.position.set(this.centerToLegX,0,this.centerToLegY),this.add(this.frontRightLeg),this.frontLeftLeg=this.createFrontLeftLeg(i),this.frontLeftLeg.position.set(this.centerToLegX,0,-this.centerToLegY),this.add(this.frontLeftLeg)}).catch(n=>{console.error("Error loading robot parts:",n)})}createRearRightLeg(e){const t=new Mt;t.name="rearRightLegGroup";const n=e.leg3.clone();n.name="rearRightLegReducer",t.add(n);const i=new Mt;i.name="rearRightHipGroup",i.position.set(-this.centerToHipX,0,0);const s=e.hip3.clone();s.name="rearRightHipMesh",s.rotateY(St.degToRad(180)),i.add(s),t.add(i);const o=new Mt;o.name="rearRightThighGroup",o.position.set(0,0,this.hipToThigh);const a=e.thigh_right.clone();a.name="rearRightThighMesh",o.add(a),i.add(o);const l=new Mt;l.name="rearRightCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="rearRightCalfMesh",l.add(c),o.add(l);const h=new Mt;h.name="rearRightFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="rearRightFootMesh",h.add(u),l.add(h),t}createRearLeftLeg(e){const t=new Mt;t.name="rearLeftLegGroup";const n=e.leg3.clone();n.name="rearLeftLegReducer",t.add(n);const i=new Mt;i.name="rearLeftHipGroup",i.position.set(-this.centerToHipX,0,0);const s=e.hip1.clone();s.name="rearLeftHipMesh",i.add(s),t.add(i);const o=new Mt;o.name="rearLeftThighGroup",o.position.set(0,0,-this.hipToThigh);const a=e.thigh_left.clone();a.name="rearLeftThighMesh",o.add(a),i.add(o);const l=new Mt;l.name="rearLeftCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="rearLeftCalfMesh",l.add(c),o.add(l);const h=new Mt;h.name="rearLeftFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="rearLeftFootMesh",h.add(u),l.add(h),t}createFrontRightLeg(e){const t=new Mt;t.name="frontRightLegGroup";const n=e.leg3.clone();n.name="frontRightLegReducer",t.add(n);const i=new Mt;i.name="frontRightHipGroup",i.position.set(this.centerToHipX,0,0);const s=e.hip1.clone();s.name="frontRightHipMesh",s.rotateY(St.degToRad(180)),i.add(s),t.add(i);const o=new Mt;o.name="frontRightThighGroup",o.position.set(0,0,this.hipToThigh);const a=e.thigh_right.clone();a.name="frontRightThighMesh",o.add(a),i.add(o);const l=new Mt;l.name="frontRightCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="frontRightCalfMesh",l.add(c),o.add(l);const h=new Mt;h.name="frontRightFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="frontRightFootMesh",h.add(u),l.add(h),t}createFrontLeftLeg(e){const t=new Mt;t.name="frontLeftLegGroup";const n=e.leg3.clone();n.name="frontLeftLegReducer",t.add(n);const i=new Mt;i.name="frontLeftHipGroup",i.position.set(this.centerToHipX,0,0);const s=e.hip3.clone();s.name="frontLeftHipMesh",i.add(s),t.add(i);const o=new Mt;o.name="frontLeftThighGroup",o.position.set(0,0,-this.hipToThigh);const a=e.thigh_left.clone();a.name="frontLeftThighMesh",o.add(a),i.add(o);const l=new Mt;l.name="frontLeftCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="frontLeftCalfMesh",l.add(c),o.add(l);const h=new Mt;h.name="frontLeftFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="frontLeftFootMesh",h.add(u),l.add(h),t}update(){}}export{tr as Editor,nM as EditorComponent,ub as Eraser,fb as EventHandler,pb as NodeManager,xb as PathDrawer,oM as RBQ10,Db as RobotManager,Ib as Selector,jb as Viewport};
