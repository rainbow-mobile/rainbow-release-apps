import{g as zf}from"./_commonjsHelpers-Cpj98o6Y.js";import{u as Hf,z as Vf,j as ga,b as Pd,A as Gf,e as Wf,d as Xf}from"./__federation_expose_App-Can7JG4Y.js";import{importShared as jf}from"./__federation_fn_import-eXNVcZim.js";const qf=()=>{const{data:r,loading:e}=Hf("lidarCloud",{defaultValue:{data:[],pose:{x:"0",y:"0",rz:"0"}}});return{...r,loading:e}};/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */const gs="174",Ni={ROTATE:0,DOLLY:1,PAN:2},$i={ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},Yf=0,ph=1,Zf=2,Ld=1,Kf=2,Ci=3,Fi=0,Un=1,Xn=2,Ji=0,ar=1,mh=2,gh=3,_h=4,$f=5,us=100,Jf=101,Qf=102,ep=103,tp=104,np=200,ip=201,sp=202,rp=203,Gl=204,Wl=205,op=206,ap=207,lp=208,cp=209,hp=210,up=211,dp=212,fp=213,pp=214,Xl=0,jl=1,ql=2,hr=3,Yl=4,Zl=5,Kl=6,$l=7,Aa=0,mp=1,gp=2,Qi=0,_p=1,vp=2,xp=3,yp=4,bp=5,Mp=6,wp=7,vh="attached",Sp="detached",Dd=300,ur=301,dr=302,_a=303,Jl=304,Ra=306,Li=1e3,Bn=1001,Ql=1002,gn=1003,Ep=1004,fo=1005,mn=1006,ja=1007,Di=1008,Oi=1009,Id=1010,Nd=1011,Xr=1012,kc=1013,vs=1014,pi=1015,eo=1016,zc=1017,Hc=1018,fr=1020,Ud=35902,Fd=1021,Od=1022,wn=1023,Bd=1024,kd=1025,lr=1026,pr=1027,zd=1028,Vc=1029,Hd=1030,Gc=1031,Wc=1033,la=33776,ca=33777,ha=33778,ua=33779,ec=35840,tc=35841,nc=35842,ic=35843,sc=36196,rc=37492,oc=37496,ac=37808,lc=37809,cc=37810,hc=37811,uc=37812,dc=37813,fc=37814,pc=37815,mc=37816,gc=37817,_c=37818,vc=37819,xc=37820,yc=37821,da=36492,bc=36494,Mc=36495,Vd=36283,wc=36284,Sc=36285,Ec=36286,va=2300,Tc=2301,qa=2302,xh=2400,yh=2401,bh=2402,Tp=2500,Ap=3200,Rp=3201,Xc=0,Cp=1,Ki="",vt="srgb",mr="srgb-linear",xa="linear",Nt="srgb",Ps=7680,Mh=519,Pp=512,Lp=513,Dp=514,Gd=515,Ip=516,Np=517,Up=518,Fp=519,Ac=35044,wh="300 es",Ii=2e3,ya=2001;class Ss{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});const n=this._listeners;n[e]===void 0&&(n[e]=[]),n[e].indexOf(t)===-1&&n[e].push(t)}hasEventListener(e,t){const n=this._listeners;return n===void 0?!1:n[e]!==void 0&&n[e].indexOf(t)!==-1}removeEventListener(e,t){const n=this._listeners;if(n===void 0)return;const i=n[e];if(i!==void 0){const s=i.indexOf(t);s!==-1&&i.splice(s,1)}}dispatchEvent(e){const t=this._listeners;if(t===void 0)return;const n=t[e.type];if(n!==void 0){e.target=this;const i=n.slice(0);for(let s=0,o=i.length;s<o;s++)i[s].call(this,e);e.target=null}}}const vn=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"];let Sh=1234567;const zr=Math.PI/180,gr=180/Math.PI;function ri(){const r=Math.random()*4294967295|0,e=Math.random()*4294967295|0,t=Math.random()*4294967295|0,n=Math.random()*4294967295|0;return(vn[r&255]+vn[r>>8&255]+vn[r>>16&255]+vn[r>>24&255]+"-"+vn[e&255]+vn[e>>8&255]+"-"+vn[e>>16&15|64]+vn[e>>24&255]+"-"+vn[t&63|128]+vn[t>>8&255]+"-"+vn[t>>16&255]+vn[t>>24&255]+vn[n&255]+vn[n>>8&255]+vn[n>>16&255]+vn[n>>24&255]).toLowerCase()}function dt(r,e,t){return Math.max(e,Math.min(t,r))}function jc(r,e){return(r%e+e)%e}function Op(r,e,t,n,i){return n+(r-e)*(i-n)/(t-e)}function Bp(r,e,t){return r!==e?(t-r)/(e-r):0}function Hr(r,e,t){return(1-t)*r+t*e}function kp(r,e,t,n){return Hr(r,e,1-Math.exp(-t*n))}function zp(r,e=1){return e-Math.abs(jc(r,e*2)-e)}function Hp(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e),r*r*(3-2*r))}function Vp(r,e,t){return r<=e?0:r>=t?1:(r=(r-e)/(t-e),r*r*r*(r*(r*6-15)+10))}function Gp(r,e){return r+Math.floor(Math.random()*(e-r+1))}function Wp(r,e){return r+Math.random()*(e-r)}function Xp(r){return r*(.5-Math.random())}function jp(r){r!==void 0&&(Sh=r);let e=Sh+=1831565813;return e=Math.imul(e^e>>>15,e|1),e^=e+Math.imul(e^e>>>7,e|61),((e^e>>>14)>>>0)/4294967296}function qp(r){return r*zr}function Yp(r){return r*gr}function Zp(r){return(r&r-1)===0&&r!==0}function Kp(r){return Math.pow(2,Math.ceil(Math.log(r)/Math.LN2))}function $p(r){return Math.pow(2,Math.floor(Math.log(r)/Math.LN2))}function Jp(r,e,t,n,i){const s=Math.cos,o=Math.sin,a=s(t/2),l=o(t/2),c=s((e+n)/2),h=o((e+n)/2),u=s((e-n)/2),d=o((e-n)/2),f=s((n-e)/2),g=o((n-e)/2);switch(i){case"XYX":r.set(a*h,l*u,l*d,a*c);break;case"YZY":r.set(l*d,a*h,l*u,a*c);break;case"ZXZ":r.set(l*u,l*d,a*h,a*c);break;case"XZX":r.set(a*h,l*g,l*f,a*c);break;case"YXY":r.set(l*f,a*h,l*g,a*c);break;case"ZYZ":r.set(l*g,l*f,a*h,a*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+i)}}function si(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return r/4294967295;case Uint16Array:return r/65535;case Uint8Array:return r/255;case Int32Array:return Math.max(r/2147483647,-1);case Int16Array:return Math.max(r/32767,-1);case Int8Array:return Math.max(r/127,-1);default:throw new Error("Invalid component type.")}}function It(r,e){switch(e.constructor){case Float32Array:return r;case Uint32Array:return Math.round(r*4294967295);case Uint16Array:return Math.round(r*65535);case Uint8Array:return Math.round(r*255);case Int32Array:return Math.round(r*2147483647);case Int16Array:return Math.round(r*32767);case Int8Array:return Math.round(r*127);default:throw new Error("Invalid component type.")}}const Pt={DEG2RAD:zr,RAD2DEG:gr,generateUUID:ri,clamp:dt,euclideanModulo:jc,mapLinear:Op,inverseLerp:Bp,lerp:Hr,damp:kp,pingpong:zp,smoothstep:Hp,smootherstep:Vp,randInt:Gp,randFloat:Wp,randFloatSpread:Xp,seededRandom:jp,degToRad:qp,radToDeg:Yp,isPowerOfTwo:Zp,ceilPowerOfTwo:Kp,floorPowerOfTwo:$p,setQuaternionFromProperEuler:Jp,normalize:It,denormalize:si};class ye{constructor(e=0,t=0){ye.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){const t=this.x,n=this.y,i=e.elements;return this.x=i[0]*t+i[3]*n+i[6],this.y=i[1]*t+i[4]*n+i[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=dt(this.x,e.x,t.x),this.y=dt(this.y,e.y,t.y),this}clampScalar(e,t){return this.x=dt(this.x,e,t),this.y=dt(this.y,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(dt(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(dt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y;return t*t+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){const n=Math.cos(t),i=Math.sin(t),s=this.x-e.x,o=this.y-e.y;return this.x=s*n-o*i+e.x,this.y=s*i+o*n+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}}class ct{constructor(e,t,n,i,s,o,a,l,c){ct.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,n,i,s,o,a,l,c)}set(e,t,n,i,s,o,a,l,c){const h=this.elements;return h[0]=e,h[1]=i,h[2]=a,h[3]=t,h[4]=s,h[5]=l,h[6]=n,h[7]=o,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],this}extractBasis(e,t,n){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),n.setFromMatrix3Column(this,2),this}setFromMatrix4(e){const t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,i=t.elements,s=this.elements,o=n[0],a=n[3],l=n[6],c=n[1],h=n[4],u=n[7],d=n[2],f=n[5],g=n[8],v=i[0],m=i[3],p=i[6],w=i[1],y=i[4],b=i[7],D=i[2],R=i[5],P=i[8];return s[0]=o*v+a*w+l*D,s[3]=o*m+a*y+l*R,s[6]=o*p+a*b+l*P,s[1]=c*v+h*w+u*D,s[4]=c*m+h*y+u*R,s[7]=c*p+h*b+u*P,s[2]=d*v+f*w+g*D,s[5]=d*m+f*y+g*R,s[8]=d*p+f*b+g*P,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8];return t*o*h-t*a*c-n*s*h+n*a*l+i*s*c-i*o*l}invert(){const e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=h*o-a*c,d=a*l-h*s,f=c*s-o*l,g=t*u+n*d+i*f;if(g===0)return this.set(0,0,0,0,0,0,0,0,0);const v=1/g;return e[0]=u*v,e[1]=(i*c-h*n)*v,e[2]=(a*n-i*o)*v,e[3]=d*v,e[4]=(h*t-i*l)*v,e[5]=(i*s-a*t)*v,e[6]=f*v,e[7]=(n*l-c*t)*v,e[8]=(o*t-n*s)*v,this}transpose(){let e;const t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){const t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,n,i,s,o,a){const l=Math.cos(s),c=Math.sin(s);return this.set(n*l,n*c,-n*(l*o+c*a)+o+e,-i*c,i*l,-i*(-c*o+l*a)+a+t,0,0,1),this}scale(e,t){return this.premultiply(Ya.makeScale(e,t)),this}rotate(e){return this.premultiply(Ya.makeRotation(-e)),this}translate(e,t){return this.premultiply(Ya.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,n,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){const t=this.elements,n=e.elements;for(let i=0;i<9;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<9;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e}clone(){return new this.constructor().fromArray(this.elements)}}const Ya=new ct;function Wd(r){for(let e=r.length-1;e>=0;--e)if(r[e]>=65535)return!0;return!1}function jr(r){return document.createElementNS("http://www.w3.org/1999/xhtml",r)}function Qp(){const r=jr("canvas");return r.style.display="block",r}const Eh={};function ls(r){r in Eh||(Eh[r]=!0,console.warn(r))}function em(r,e,t){return new Promise(function(n,i){function s(){switch(r.clientWaitSync(e,r.SYNC_FLUSH_COMMANDS_BIT,0)){case r.WAIT_FAILED:i();break;case r.TIMEOUT_EXPIRED:setTimeout(s,t);break;default:n()}}setTimeout(s,t)})}function tm(r){const e=r.elements;e[2]=.5*e[2]+.5*e[3],e[6]=.5*e[6]+.5*e[7],e[10]=.5*e[10]+.5*e[11],e[14]=.5*e[14]+.5*e[15]}function nm(r){const e=r.elements;e[11]===-1?(e[10]=-e[10]-1,e[14]=-e[14]):(e[10]=-e[10],e[14]=-e[14]+1)}const Th=new ct().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Ah=new ct().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715);function im(){const r={enabled:!0,workingColorSpace:mr,spaces:{},convert:function(i,s,o){return this.enabled===!1||s===o||!s||!o||(this.spaces[s].transfer===Nt&&(i.r=Ui(i.r),i.g=Ui(i.g),i.b=Ui(i.b)),this.spaces[s].primaries!==this.spaces[o].primaries&&(i.applyMatrix3(this.spaces[s].toXYZ),i.applyMatrix3(this.spaces[o].fromXYZ)),this.spaces[o].transfer===Nt&&(i.r=cr(i.r),i.g=cr(i.g),i.b=cr(i.b))),i},fromWorkingColorSpace:function(i,s){return this.convert(i,this.workingColorSpace,s)},toWorkingColorSpace:function(i,s){return this.convert(i,s,this.workingColorSpace)},getPrimaries:function(i){return this.spaces[i].primaries},getTransfer:function(i){return i===Ki?xa:this.spaces[i].transfer},getLuminanceCoefficients:function(i,s=this.workingColorSpace){return i.fromArray(this.spaces[s].luminanceCoefficients)},define:function(i){Object.assign(this.spaces,i)},_getMatrix:function(i,s,o){return i.copy(this.spaces[s].toXYZ).multiply(this.spaces[o].fromXYZ)},_getDrawingBufferColorSpace:function(i){return this.spaces[i].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(i=this.workingColorSpace){return this.spaces[i].workingColorSpaceConfig.unpackColorSpace}},e=[.64,.33,.3,.6,.15,.06],t=[.2126,.7152,.0722],n=[.3127,.329];return r.define({[mr]:{primaries:e,whitePoint:n,transfer:xa,toXYZ:Th,fromXYZ:Ah,luminanceCoefficients:t,workingColorSpaceConfig:{unpackColorSpace:vt},outputColorSpaceConfig:{drawingBufferColorSpace:vt}},[vt]:{primaries:e,whitePoint:n,transfer:Nt,toXYZ:Th,fromXYZ:Ah,luminanceCoefficients:t,outputColorSpaceConfig:{drawingBufferColorSpace:vt}}}),r}const rt=im();function Ui(r){return r<.04045?r*.0773993808:Math.pow(r*.9478672986+.0521327014,2.4)}function cr(r){return r<.0031308?r*12.92:1.055*Math.pow(r,.41666)-.055}let Ls;class sm{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Ls===void 0&&(Ls=jr("canvas")),Ls.width=e.width,Ls.height=e.height;const n=Ls.getContext("2d");e instanceof ImageData?n.putImageData(e,0,0):n.drawImage(e,0,0,e.width,e.height),t=Ls}return t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){const t=jr("canvas");t.width=e.width,t.height=e.height;const n=t.getContext("2d");n.drawImage(e,0,0,e.width,e.height);const i=n.getImageData(0,0,e.width,e.height),s=i.data;for(let o=0;o<s.length;o++)s[o]=Ui(s[o]/255)*255;return n.putImageData(i,0,0),t}else if(e.data){const t=e.data.slice(0);for(let n=0;n<t.length;n++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[n]=Math.floor(Ui(t[n]/255)*255):t[n]=Ui(t[n]);return{data:t,width:e.width,height:e.height}}else return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}}let rm=0;class qc{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:rm++}),this.uuid=ri(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];const n={uuid:this.uuid,url:""},i=this.data;if(i!==null){let s;if(Array.isArray(i)){s=[];for(let o=0,a=i.length;o<a;o++)i[o].isDataTexture?s.push(Za(i[o].image)):s.push(Za(i[o]))}else s=Za(i);n.url=s}return t||(e.images[this.uuid]=n),n}}function Za(r){return typeof HTMLImageElement<"u"&&r instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&r instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&r instanceof ImageBitmap?sm.getDataURL(r):r.data?{data:Array.from(r.data),width:r.width,height:r.height,type:r.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}let om=0;class Wt extends Ss{constructor(e=Wt.DEFAULT_IMAGE,t=Wt.DEFAULT_MAPPING,n=Bn,i=Bn,s=mn,o=Di,a=wn,l=Oi,c=Wt.DEFAULT_ANISOTROPY,h=Ki){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:om++}),this.uuid=ri(),this.name="",this.source=new qc(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=n,this.wrapT=i,this.magFilter=s,this.minFilter=o,this.anisotropy=c,this.format=a,this.internalFormat=null,this.type=l,this.offset=new ye(0,0),this.repeat=new ye(1,1),this.center=new ye(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new ct,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.renderTarget=e.renderTarget,this.isRenderTargetTexture=e.isRenderTargetTexture,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){const t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];const n={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(n.userData=this.userData),t||(e.textures[this.uuid]=n),n}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==Dd)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Li:e.x=e.x-Math.floor(e.x);break;case Bn:e.x=e.x<0?0:1;break;case Ql:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x);break}if(e.y<0||e.y>1)switch(this.wrapT){case Li:e.y=e.y-Math.floor(e.y);break;case Bn:e.y=e.y<0?0:1;break;case Ql:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y);break}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}}Wt.DEFAULT_IMAGE=null;Wt.DEFAULT_MAPPING=Dd;Wt.DEFAULT_ANISOTROPY=1;class at{constructor(e=0,t=0,n=0,i=1){at.prototype.isVector4=!0,this.x=e,this.y=t,this.z=n,this.w=i}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,n,i){return this.x=e,this.y=t,this.z=n,this.w=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){const t=this.x,n=this.y,i=this.z,s=this.w,o=e.elements;return this.x=o[0]*t+o[4]*n+o[8]*i+o[12]*s,this.y=o[1]*t+o[5]*n+o[9]*i+o[13]*s,this.z=o[2]*t+o[6]*n+o[10]*i+o[14]*s,this.w=o[3]*t+o[7]*n+o[11]*i+o[15]*s,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);const t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,n,i,s;const l=e.elements,c=l[0],h=l[4],u=l[8],d=l[1],f=l[5],g=l[9],v=l[2],m=l[6],p=l[10];if(Math.abs(h-d)<.01&&Math.abs(u-v)<.01&&Math.abs(g-m)<.01){if(Math.abs(h+d)<.1&&Math.abs(u+v)<.1&&Math.abs(g+m)<.1&&Math.abs(c+f+p-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;const y=(c+1)/2,b=(f+1)/2,D=(p+1)/2,R=(h+d)/4,P=(u+v)/4,M=(g+m)/4;return y>b&&y>D?y<.01?(n=0,i=.707106781,s=.707106781):(n=Math.sqrt(y),i=R/n,s=P/n):b>D?b<.01?(n=.707106781,i=0,s=.707106781):(i=Math.sqrt(b),n=R/i,s=M/i):D<.01?(n=.707106781,i=.707106781,s=0):(s=Math.sqrt(D),n=P/s,i=M/s),this.set(n,i,s,t),this}let w=Math.sqrt((m-g)*(m-g)+(u-v)*(u-v)+(d-h)*(d-h));return Math.abs(w)<.001&&(w=1),this.x=(m-g)/w,this.y=(u-v)/w,this.z=(d-h)/w,this.w=Math.acos((c+f+p-1)/2),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=dt(this.x,e.x,t.x),this.y=dt(this.y,e.y,t.y),this.z=dt(this.z,e.z,t.z),this.w=dt(this.w,e.w,t.w),this}clampScalar(e,t){return this.x=dt(this.x,e,t),this.y=dt(this.y,e,t),this.z=dt(this.z,e,t),this.w=dt(this.w,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(dt(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this.w=e.w+(t.w-e.w)*n,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}}class am extends Ss{constructor(e=1,t=1,n={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new at(0,0,e,t),this.scissorTest=!1,this.viewport=new at(0,0,e,t);const i={width:e,height:t,depth:1};n=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:mn,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},n);const s=new Wt(i,n.mapping,n.wrapS,n.wrapT,n.magFilter,n.minFilter,n.format,n.type,n.anisotropy,n.colorSpace);s.flipY=!1,s.generateMipmaps=n.generateMipmaps,s.internalFormat=n.internalFormat,this.textures=[];const o=n.count;for(let a=0;a<o;a++)this.textures[a]=s.clone(),this.textures[a].isRenderTargetTexture=!0,this.textures[a].renderTarget=this;this.depthBuffer=n.depthBuffer,this.stencilBuffer=n.stencilBuffer,this.resolveDepthBuffer=n.resolveDepthBuffer,this.resolveStencilBuffer=n.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=n.depthTexture,this.samples=n.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}set depthTexture(e){this._depthTexture!==null&&(this._depthTexture.renderTarget=null),e!==null&&(e.renderTarget=this),this._depthTexture=e}get depthTexture(){return this._depthTexture}setSize(e,t,n=1){if(this.width!==e||this.height!==t||this.depth!==n){this.width=e,this.height=t,this.depth=n;for(let i=0,s=this.textures.length;i<s;i++)this.textures[i].image.width=e,this.textures[i].image.height=t,this.textures[i].image.depth=n;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let t=0,n=e.textures.length;t<n;t++){this.textures[t]=e.textures[t].clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;const i=Object.assign({},e.textures[t].image);this.textures[t].source=new qc(i)}return this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}}class xs extends am{constructor(e=1,t=1,n={}){super(e,t,n),this.isWebGLRenderTarget=!0}}class Xd extends Wt{constructor(e=null,t=1,n=1,i=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=gn,this.minFilter=gn,this.wrapR=Bn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}}class lm extends Wt{constructor(e=null,t=1,n=1,i=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:n,depth:i},this.magFilter=gn,this.minFilter=gn,this.wrapR=Bn,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}class St{constructor(e=0,t=0,n=0,i=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=n,this._w=i}static slerpFlat(e,t,n,i,s,o,a){let l=n[i+0],c=n[i+1],h=n[i+2],u=n[i+3];const d=s[o+0],f=s[o+1],g=s[o+2],v=s[o+3];if(a===0){e[t+0]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u;return}if(a===1){e[t+0]=d,e[t+1]=f,e[t+2]=g,e[t+3]=v;return}if(u!==v||l!==d||c!==f||h!==g){let m=1-a;const p=l*d+c*f+h*g+u*v,w=p>=0?1:-1,y=1-p*p;if(y>Number.EPSILON){const D=Math.sqrt(y),R=Math.atan2(D,p*w);m=Math.sin(m*R)/D,a=Math.sin(a*R)/D}const b=a*w;if(l=l*m+d*b,c=c*m+f*b,h=h*m+g*b,u=u*m+v*b,m===1-a){const D=1/Math.sqrt(l*l+c*c+h*h+u*u);l*=D,c*=D,h*=D,u*=D}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=u}static multiplyQuaternionsFlat(e,t,n,i,s,o){const a=n[i],l=n[i+1],c=n[i+2],h=n[i+3],u=s[o],d=s[o+1],f=s[o+2],g=s[o+3];return e[t]=a*g+h*u+l*f-c*d,e[t+1]=l*g+h*d+c*u-a*f,e[t+2]=c*g+h*f+a*d-l*u,e[t+3]=h*g-a*u-l*d-c*f,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,n,i){return this._x=e,this._y=t,this._z=n,this._w=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){const n=e._x,i=e._y,s=e._z,o=e._order,a=Math.cos,l=Math.sin,c=a(n/2),h=a(i/2),u=a(s/2),d=l(n/2),f=l(i/2),g=l(s/2);switch(o){case"XYZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"YXZ":this._x=d*h*u+c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"ZXY":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u-d*f*g;break;case"ZYX":this._x=d*h*u-c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u+d*f*g;break;case"YZX":this._x=d*h*u+c*f*g,this._y=c*f*u+d*h*g,this._z=c*h*g-d*f*u,this._w=c*h*u-d*f*g;break;case"XZY":this._x=d*h*u-c*f*g,this._y=c*f*u-d*h*g,this._z=c*h*g+d*f*u,this._w=c*h*u+d*f*g;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+o)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){const n=t/2,i=Math.sin(n);return this._x=e.x*i,this._y=e.y*i,this._z=e.z*i,this._w=Math.cos(n),this._onChangeCallback(),this}setFromRotationMatrix(e){const t=e.elements,n=t[0],i=t[4],s=t[8],o=t[1],a=t[5],l=t[9],c=t[2],h=t[6],u=t[10],d=n+a+u;if(d>0){const f=.5/Math.sqrt(d+1);this._w=.25/f,this._x=(h-l)*f,this._y=(s-c)*f,this._z=(o-i)*f}else if(n>a&&n>u){const f=2*Math.sqrt(1+n-a-u);this._w=(h-l)/f,this._x=.25*f,this._y=(i+o)/f,this._z=(s+c)/f}else if(a>u){const f=2*Math.sqrt(1+a-n-u);this._w=(s-c)/f,this._x=(i+o)/f,this._y=.25*f,this._z=(l+h)/f}else{const f=2*Math.sqrt(1+u-n-a);this._w=(o-i)/f,this._x=(s+c)/f,this._y=(l+h)/f,this._z=.25*f}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let n=e.dot(t)+1;return n<Number.EPSILON?(n=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=n):(this._x=0,this._y=-e.z,this._z=e.y,this._w=n)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=n),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(dt(this.dot(e),-1,1)))}rotateTowards(e,t){const n=this.angleTo(e);if(n===0)return this;const i=Math.min(1,t/n);return this.slerp(e,i),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){const n=e._x,i=e._y,s=e._z,o=e._w,a=t._x,l=t._y,c=t._z,h=t._w;return this._x=n*h+o*a+i*c-s*l,this._y=i*h+o*l+s*a-n*c,this._z=s*h+o*c+n*l-i*a,this._w=o*h-n*a-i*l-s*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);const n=this._x,i=this._y,s=this._z,o=this._w;let a=o*e._w+n*e._x+i*e._y+s*e._z;if(a<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,a=-a):this.copy(e),a>=1)return this._w=o,this._x=n,this._y=i,this._z=s,this;const l=1-a*a;if(l<=Number.EPSILON){const f=1-t;return this._w=f*o+t*this._w,this._x=f*n+t*this._x,this._y=f*i+t*this._y,this._z=f*s+t*this._z,this.normalize(),this}const c=Math.sqrt(l),h=Math.atan2(c,a),u=Math.sin((1-t)*h)/c,d=Math.sin(t*h)/c;return this._w=o*u+this._w*d,this._x=n*u+this._x*d,this._y=i*u+this._y*d,this._z=s*u+this._z*d,this._onChangeCallback(),this}slerpQuaternions(e,t,n){return this.copy(e).slerp(t,n)}random(){const e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),n=Math.random(),i=Math.sqrt(1-n),s=Math.sqrt(n);return this.set(i*Math.sin(e),i*Math.cos(e),s*Math.sin(t),s*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}}class L{constructor(e=0,t=0,n=0){L.prototype.isVector3=!0,this.x=e,this.y=t,this.z=n}set(e,t,n){return n===void 0&&(n=this.z),this.x=e,this.y=t,this.z=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Rh.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Rh.setFromAxisAngle(e,t))}applyMatrix3(e){const t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[3]*n+s[6]*i,this.y=s[1]*t+s[4]*n+s[7]*i,this.z=s[2]*t+s[5]*n+s[8]*i,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){const t=this.x,n=this.y,i=this.z,s=e.elements,o=1/(s[3]*t+s[7]*n+s[11]*i+s[15]);return this.x=(s[0]*t+s[4]*n+s[8]*i+s[12])*o,this.y=(s[1]*t+s[5]*n+s[9]*i+s[13])*o,this.z=(s[2]*t+s[6]*n+s[10]*i+s[14])*o,this}applyQuaternion(e){const t=this.x,n=this.y,i=this.z,s=e.x,o=e.y,a=e.z,l=e.w,c=2*(o*i-a*n),h=2*(a*t-s*i),u=2*(s*n-o*t);return this.x=t+l*c+o*u-a*h,this.y=n+l*h+a*c-s*u,this.z=i+l*u+s*h-o*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){const t=this.x,n=this.y,i=this.z,s=e.elements;return this.x=s[0]*t+s[4]*n+s[8]*i,this.y=s[1]*t+s[5]*n+s[9]*i,this.z=s[2]*t+s[6]*n+s[10]*i,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=dt(this.x,e.x,t.x),this.y=dt(this.y,e.y,t.y),this.z=dt(this.z,e.z,t.z),this}clampScalar(e,t){return this.x=dt(this.x,e,t),this.y=dt(this.y,e,t),this.z=dt(this.z,e,t),this}clampLength(e,t){const n=this.length();return this.divideScalar(n||1).multiplyScalar(dt(n,e,t))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,n){return this.x=e.x+(t.x-e.x)*n,this.y=e.y+(t.y-e.y)*n,this.z=e.z+(t.z-e.z)*n,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){const n=e.x,i=e.y,s=e.z,o=t.x,a=t.y,l=t.z;return this.x=i*l-s*a,this.y=s*o-n*l,this.z=n*a-i*o,this}projectOnVector(e){const t=e.lengthSq();if(t===0)return this.set(0,0,0);const n=e.dot(this)/t;return this.copy(e).multiplyScalar(n)}projectOnPlane(e){return Ka.copy(this).projectOnVector(e),this.sub(Ka)}reflect(e){return this.sub(Ka.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){const t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;const n=this.dot(e)/t;return Math.acos(dt(n,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){const t=this.x-e.x,n=this.y-e.y,i=this.z-e.z;return t*t+n*n+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,n){const i=Math.sin(t)*e;return this.x=i*Math.sin(n),this.y=Math.cos(t)*e,this.z=i*Math.cos(n),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,n){return this.x=e*Math.sin(t),this.y=n,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){const t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){const t=this.setFromMatrixColumn(e,0).length(),n=this.setFromMatrixColumn(e,1).length(),i=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=n,this.z=i,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,t*4)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,t*3)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){const e=Math.random()*Math.PI*2,t=Math.random()*2-1,n=Math.sqrt(1-t*t);return this.x=n*Math.cos(e),this.y=t,this.z=n*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}}const Ka=new L,Rh=new St;class Cn{constructor(e=new L(1/0,1/0,1/0),t=new L(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t+=3)this.expandByPoint(Jn.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,n=e.count;t<n;t++)this.expandByPoint(Jn.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=Jn.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);const n=e.geometry;if(n!==void 0){const s=n.getAttribute("position");if(t===!0&&s!==void 0&&e.isInstancedMesh!==!0)for(let o=0,a=s.count;o<a;o++)e.isMesh===!0?e.getVertexPosition(o,Jn):Jn.fromBufferAttribute(s,o),Jn.applyMatrix4(e.matrixWorld),this.expandByPoint(Jn);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),po.copy(e.boundingBox)):(n.boundingBox===null&&n.computeBoundingBox(),po.copy(n.boundingBox)),po.applyMatrix4(e.matrixWorld),this.union(po)}const i=e.children;for(let s=0,o=i.length;s<o;s++)this.expandByObject(i[s],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Jn),Jn.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,n;return e.normal.x>0?(t=e.normal.x*this.min.x,n=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,n=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,n+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,n+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,n+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,n+=e.normal.z*this.min.z),t<=-e.constant&&n>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(Tr),mo.subVectors(this.max,Tr),Ds.subVectors(e.a,Tr),Is.subVectors(e.b,Tr),Ns.subVectors(e.c,Tr),ki.subVectors(Is,Ds),zi.subVectors(Ns,Is),ts.subVectors(Ds,Ns);let t=[0,-ki.z,ki.y,0,-zi.z,zi.y,0,-ts.z,ts.y,ki.z,0,-ki.x,zi.z,0,-zi.x,ts.z,0,-ts.x,-ki.y,ki.x,0,-zi.y,zi.x,0,-ts.y,ts.x,0];return!$a(t,Ds,Is,Ns,mo)||(t=[1,0,0,0,1,0,0,0,1],!$a(t,Ds,Is,Ns,mo))?!1:(go.crossVectors(ki,zi),t=[go.x,go.y,go.z],$a(t,Ds,Is,Ns,mo))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Jn).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=this.getSize(Jn).length()*.5),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()?this:(wi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),wi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),wi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),wi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),wi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),wi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),wi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),wi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(wi),this)}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const wi=[new L,new L,new L,new L,new L,new L,new L,new L],Jn=new L,po=new Cn,Ds=new L,Is=new L,Ns=new L,ki=new L,zi=new L,ts=new L,Tr=new L,mo=new L,go=new L,ns=new L;function $a(r,e,t,n,i){for(let s=0,o=r.length-3;s<=o;s+=3){ns.fromArray(r,s);const a=i.x*Math.abs(ns.x)+i.y*Math.abs(ns.y)+i.z*Math.abs(ns.z),l=e.dot(ns),c=t.dot(ns),h=n.dot(ns);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>a)return!1}return!0}const cm=new Cn,Ar=new L,Ja=new L;class vi{constructor(e=new L,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){const n=this.center;t!==void 0?n.copy(t):cm.setFromPoints(e).getCenter(n);let i=0;for(let s=0,o=e.length;s<o;s++)i=Math.max(i,n.distanceToSquared(e[s]));return this.radius=Math.sqrt(i),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){const t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){const n=this.center.distanceToSquared(e);return t.copy(e),n>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ar.subVectors(e,this.center);const t=Ar.lengthSq();if(t>this.radius*this.radius){const n=Math.sqrt(t),i=(n-this.radius)*.5;this.center.addScaledVector(Ar,i/n),this.radius+=i}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Ja.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ar.copy(e.center).add(Ja)),this.expandByPoint(Ar.copy(e.center).sub(Ja))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}}const Si=new L,Qa=new L,_o=new L,Hi=new L,el=new L,vo=new L,tl=new L;class Es{constructor(e=new L,t=new L(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,Si)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);const n=t.dot(this.direction);return n<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,n)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){const t=Si.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(Si.copy(this.origin).addScaledVector(this.direction,t),Si.distanceToSquared(e))}distanceSqToSegment(e,t,n,i){Qa.copy(e).add(t).multiplyScalar(.5),_o.copy(t).sub(e).normalize(),Hi.copy(this.origin).sub(Qa);const s=e.distanceTo(t)*.5,o=-this.direction.dot(_o),a=Hi.dot(this.direction),l=-Hi.dot(_o),c=Hi.lengthSq(),h=Math.abs(1-o*o);let u,d,f,g;if(h>0)if(u=o*l-a,d=o*a-l,g=s*h,u>=0)if(d>=-g)if(d<=g){const v=1/h;u*=v,d*=v,f=u*(u+o*d+2*a)+d*(o*u+d+2*l)+c}else d=s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d=-s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;else d<=-g?(u=Math.max(0,-(-o*s+a)),d=u>0?-s:Math.min(Math.max(-s,-l),s),f=-u*u+d*(d+2*l)+c):d<=g?(u=0,d=Math.min(Math.max(-s,-l),s),f=d*(d+2*l)+c):(u=Math.max(0,-(o*s+a)),d=u>0?s:Math.min(Math.max(-s,-l),s),f=-u*u+d*(d+2*l)+c);else d=o>0?-s:s,u=Math.max(0,-(o*d+a)),f=-u*u+d*(d+2*l)+c;return n&&n.copy(this.origin).addScaledVector(this.direction,u),i&&i.copy(Qa).addScaledVector(_o,d),f}intersectSphere(e,t){Si.subVectors(e.center,this.origin);const n=Si.dot(this.direction),i=Si.dot(Si)-n*n,s=e.radius*e.radius;if(i>s)return null;const o=Math.sqrt(s-i),a=n-o,l=n+o;return l<0?null:a<0?this.at(l,t):this.at(a,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){const t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;const n=-(this.origin.dot(e.normal)+e.constant)/t;return n>=0?n:null}intersectPlane(e,t){const n=this.distanceToPlane(e);return n===null?null:this.at(n,t)}intersectsPlane(e){const t=e.distanceToPoint(this.origin);return t===0||e.normal.dot(this.direction)*t<0}intersectBox(e,t){let n,i,s,o,a,l;const c=1/this.direction.x,h=1/this.direction.y,u=1/this.direction.z,d=this.origin;return c>=0?(n=(e.min.x-d.x)*c,i=(e.max.x-d.x)*c):(n=(e.max.x-d.x)*c,i=(e.min.x-d.x)*c),h>=0?(s=(e.min.y-d.y)*h,o=(e.max.y-d.y)*h):(s=(e.max.y-d.y)*h,o=(e.min.y-d.y)*h),n>o||s>i||((s>n||isNaN(n))&&(n=s),(o<i||isNaN(i))&&(i=o),u>=0?(a=(e.min.z-d.z)*u,l=(e.max.z-d.z)*u):(a=(e.max.z-d.z)*u,l=(e.min.z-d.z)*u),n>l||a>i)||((a>n||n!==n)&&(n=a),(l<i||i!==i)&&(i=l),i<0)?null:this.at(n>=0?n:i,t)}intersectsBox(e){return this.intersectBox(e,Si)!==null}intersectTriangle(e,t,n,i,s){el.subVectors(t,e),vo.subVectors(n,e),tl.crossVectors(el,vo);let o=this.direction.dot(tl),a;if(o>0){if(i)return null;a=1}else if(o<0)a=-1,o=-o;else return null;Hi.subVectors(this.origin,e);const l=a*this.direction.dot(vo.crossVectors(Hi,vo));if(l<0)return null;const c=a*this.direction.dot(el.cross(Hi));if(c<0||l+c>o)return null;const h=-a*Hi.dot(tl);return h<0?null:this.at(h/o,s)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}}class Ee{constructor(e,t,n,i,s,o,a,l,c,h,u,d,f,g,v,m){Ee.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,n,i,s,o,a,l,c,h,u,d,f,g,v,m)}set(e,t,n,i,s,o,a,l,c,h,u,d,f,g,v,m){const p=this.elements;return p[0]=e,p[4]=t,p[8]=n,p[12]=i,p[1]=s,p[5]=o,p[9]=a,p[13]=l,p[2]=c,p[6]=h,p[10]=u,p[14]=d,p[3]=f,p[7]=g,p[11]=v,p[15]=m,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new Ee().fromArray(this.elements)}copy(e){const t=this.elements,n=e.elements;return t[0]=n[0],t[1]=n[1],t[2]=n[2],t[3]=n[3],t[4]=n[4],t[5]=n[5],t[6]=n[6],t[7]=n[7],t[8]=n[8],t[9]=n[9],t[10]=n[10],t[11]=n[11],t[12]=n[12],t[13]=n[13],t[14]=n[14],t[15]=n[15],this}copyPosition(e){const t=this.elements,n=e.elements;return t[12]=n[12],t[13]=n[13],t[14]=n[14],this}setFromMatrix3(e){const t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,n){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),n.setFromMatrixColumn(this,2),this}makeBasis(e,t,n){return this.set(e.x,t.x,n.x,0,e.y,t.y,n.y,0,e.z,t.z,n.z,0,0,0,0,1),this}extractRotation(e){const t=this.elements,n=e.elements,i=1/Us.setFromMatrixColumn(e,0).length(),s=1/Us.setFromMatrixColumn(e,1).length(),o=1/Us.setFromMatrixColumn(e,2).length();return t[0]=n[0]*i,t[1]=n[1]*i,t[2]=n[2]*i,t[3]=0,t[4]=n[4]*s,t[5]=n[5]*s,t[6]=n[6]*s,t[7]=0,t[8]=n[8]*o,t[9]=n[9]*o,t[10]=n[10]*o,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){const t=this.elements,n=e.x,i=e.y,s=e.z,o=Math.cos(n),a=Math.sin(n),l=Math.cos(i),c=Math.sin(i),h=Math.cos(s),u=Math.sin(s);if(e.order==="XYZ"){const d=o*h,f=o*u,g=a*h,v=a*u;t[0]=l*h,t[4]=-l*u,t[8]=c,t[1]=f+g*c,t[5]=d-v*c,t[9]=-a*l,t[2]=v-d*c,t[6]=g+f*c,t[10]=o*l}else if(e.order==="YXZ"){const d=l*h,f=l*u,g=c*h,v=c*u;t[0]=d+v*a,t[4]=g*a-f,t[8]=o*c,t[1]=o*u,t[5]=o*h,t[9]=-a,t[2]=f*a-g,t[6]=v+d*a,t[10]=o*l}else if(e.order==="ZXY"){const d=l*h,f=l*u,g=c*h,v=c*u;t[0]=d-v*a,t[4]=-o*u,t[8]=g+f*a,t[1]=f+g*a,t[5]=o*h,t[9]=v-d*a,t[2]=-o*c,t[6]=a,t[10]=o*l}else if(e.order==="ZYX"){const d=o*h,f=o*u,g=a*h,v=a*u;t[0]=l*h,t[4]=g*c-f,t[8]=d*c+v,t[1]=l*u,t[5]=v*c+d,t[9]=f*c-g,t[2]=-c,t[6]=a*l,t[10]=o*l}else if(e.order==="YZX"){const d=o*l,f=o*c,g=a*l,v=a*c;t[0]=l*h,t[4]=v-d*u,t[8]=g*u+f,t[1]=u,t[5]=o*h,t[9]=-a*h,t[2]=-c*h,t[6]=f*u+g,t[10]=d-v*u}else if(e.order==="XZY"){const d=o*l,f=o*c,g=a*l,v=a*c;t[0]=l*h,t[4]=-u,t[8]=c*h,t[1]=d*u+v,t[5]=o*h,t[9]=f*u-g,t[2]=g*u-f,t[6]=a*h,t[10]=v*u+d}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(hm,e,um)}lookAt(e,t,n){const i=this.elements;return Fn.subVectors(e,t),Fn.lengthSq()===0&&(Fn.z=1),Fn.normalize(),Vi.crossVectors(n,Fn),Vi.lengthSq()===0&&(Math.abs(n.z)===1?Fn.x+=1e-4:Fn.z+=1e-4,Fn.normalize(),Vi.crossVectors(n,Fn)),Vi.normalize(),xo.crossVectors(Fn,Vi),i[0]=Vi.x,i[4]=xo.x,i[8]=Fn.x,i[1]=Vi.y,i[5]=xo.y,i[9]=Fn.y,i[2]=Vi.z,i[6]=xo.z,i[10]=Fn.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){const n=e.elements,i=t.elements,s=this.elements,o=n[0],a=n[4],l=n[8],c=n[12],h=n[1],u=n[5],d=n[9],f=n[13],g=n[2],v=n[6],m=n[10],p=n[14],w=n[3],y=n[7],b=n[11],D=n[15],R=i[0],P=i[4],M=i[8],_=i[12],x=i[1],T=i[5],F=i[9],k=i[13],G=i[2],K=i[6],z=i[10],Z=i[14],V=i[3],Y=i[7],ue=i[11],ie=i[15];return s[0]=o*R+a*x+l*G+c*V,s[4]=o*P+a*T+l*K+c*Y,s[8]=o*M+a*F+l*z+c*ue,s[12]=o*_+a*k+l*Z+c*ie,s[1]=h*R+u*x+d*G+f*V,s[5]=h*P+u*T+d*K+f*Y,s[9]=h*M+u*F+d*z+f*ue,s[13]=h*_+u*k+d*Z+f*ie,s[2]=g*R+v*x+m*G+p*V,s[6]=g*P+v*T+m*K+p*Y,s[10]=g*M+v*F+m*z+p*ue,s[14]=g*_+v*k+m*Z+p*ie,s[3]=w*R+y*x+b*G+D*V,s[7]=w*P+y*T+b*K+D*Y,s[11]=w*M+y*F+b*z+D*ue,s[15]=w*_+y*k+b*Z+D*ie,this}multiplyScalar(e){const t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){const e=this.elements,t=e[0],n=e[4],i=e[8],s=e[12],o=e[1],a=e[5],l=e[9],c=e[13],h=e[2],u=e[6],d=e[10],f=e[14],g=e[3],v=e[7],m=e[11],p=e[15];return g*(+s*l*u-i*c*u-s*a*d+n*c*d+i*a*f-n*l*f)+v*(+t*l*f-t*c*d+s*o*d-i*o*f+i*c*h-s*l*h)+m*(+t*c*u-t*a*f-s*o*u+n*o*f+s*a*h-n*c*h)+p*(-i*a*h-t*l*u+t*a*d+i*o*u-n*o*d+n*l*h)}transpose(){const e=this.elements;let t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,n){const i=this.elements;return e.isVector3?(i[12]=e.x,i[13]=e.y,i[14]=e.z):(i[12]=e,i[13]=t,i[14]=n),this}invert(){const e=this.elements,t=e[0],n=e[1],i=e[2],s=e[3],o=e[4],a=e[5],l=e[6],c=e[7],h=e[8],u=e[9],d=e[10],f=e[11],g=e[12],v=e[13],m=e[14],p=e[15],w=u*m*c-v*d*c+v*l*f-a*m*f-u*l*p+a*d*p,y=g*d*c-h*m*c-g*l*f+o*m*f+h*l*p-o*d*p,b=h*v*c-g*u*c+g*a*f-o*v*f-h*a*p+o*u*p,D=g*u*l-h*v*l-g*a*d+o*v*d+h*a*m-o*u*m,R=t*w+n*y+i*b+s*D;if(R===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);const P=1/R;return e[0]=w*P,e[1]=(v*d*s-u*m*s-v*i*f+n*m*f+u*i*p-n*d*p)*P,e[2]=(a*m*s-v*l*s+v*i*c-n*m*c-a*i*p+n*l*p)*P,e[3]=(u*l*s-a*d*s-u*i*c+n*d*c+a*i*f-n*l*f)*P,e[4]=y*P,e[5]=(h*m*s-g*d*s+g*i*f-t*m*f-h*i*p+t*d*p)*P,e[6]=(g*l*s-o*m*s-g*i*c+t*m*c+o*i*p-t*l*p)*P,e[7]=(o*d*s-h*l*s+h*i*c-t*d*c-o*i*f+t*l*f)*P,e[8]=b*P,e[9]=(g*u*s-h*v*s-g*n*f+t*v*f+h*n*p-t*u*p)*P,e[10]=(o*v*s-g*a*s+g*n*c-t*v*c-o*n*p+t*a*p)*P,e[11]=(h*a*s-o*u*s-h*n*c+t*u*c+o*n*f-t*a*f)*P,e[12]=D*P,e[13]=(h*v*i-g*u*i+g*n*d-t*v*d-h*n*m+t*u*m)*P,e[14]=(g*a*i-o*v*i-g*n*l+t*v*l+o*n*m-t*a*m)*P,e[15]=(o*u*i-h*a*i+h*n*l-t*u*l-o*n*d+t*a*d)*P,this}scale(e){const t=this.elements,n=e.x,i=e.y,s=e.z;return t[0]*=n,t[4]*=i,t[8]*=s,t[1]*=n,t[5]*=i,t[9]*=s,t[2]*=n,t[6]*=i,t[10]*=s,t[3]*=n,t[7]*=i,t[11]*=s,this}getMaxScaleOnAxis(){const e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],n=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],i=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,n,i))}makeTranslation(e,t,n){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,n,0,0,0,1),this}makeRotationX(e){const t=Math.cos(e),n=Math.sin(e);return this.set(1,0,0,0,0,t,-n,0,0,n,t,0,0,0,0,1),this}makeRotationY(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,0,n,0,0,1,0,0,-n,0,t,0,0,0,0,1),this}makeRotationZ(e){const t=Math.cos(e),n=Math.sin(e);return this.set(t,-n,0,0,n,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){const n=Math.cos(t),i=Math.sin(t),s=1-n,o=e.x,a=e.y,l=e.z,c=s*o,h=s*a;return this.set(c*o+n,c*a-i*l,c*l+i*a,0,c*a+i*l,h*a+n,h*l-i*o,0,c*l-i*a,h*l+i*o,s*l*l+n,0,0,0,0,1),this}makeScale(e,t,n){return this.set(e,0,0,0,0,t,0,0,0,0,n,0,0,0,0,1),this}makeShear(e,t,n,i,s,o){return this.set(1,n,s,0,e,1,o,0,t,i,1,0,0,0,0,1),this}compose(e,t,n){const i=this.elements,s=t._x,o=t._y,a=t._z,l=t._w,c=s+s,h=o+o,u=a+a,d=s*c,f=s*h,g=s*u,v=o*h,m=o*u,p=a*u,w=l*c,y=l*h,b=l*u,D=n.x,R=n.y,P=n.z;return i[0]=(1-(v+p))*D,i[1]=(f+b)*D,i[2]=(g-y)*D,i[3]=0,i[4]=(f-b)*R,i[5]=(1-(d+p))*R,i[6]=(m+w)*R,i[7]=0,i[8]=(g+y)*P,i[9]=(m-w)*P,i[10]=(1-(d+v))*P,i[11]=0,i[12]=e.x,i[13]=e.y,i[14]=e.z,i[15]=1,this}decompose(e,t,n){const i=this.elements;let s=Us.set(i[0],i[1],i[2]).length();const o=Us.set(i[4],i[5],i[6]).length(),a=Us.set(i[8],i[9],i[10]).length();this.determinant()<0&&(s=-s),e.x=i[12],e.y=i[13],e.z=i[14],Qn.copy(this);const c=1/s,h=1/o,u=1/a;return Qn.elements[0]*=c,Qn.elements[1]*=c,Qn.elements[2]*=c,Qn.elements[4]*=h,Qn.elements[5]*=h,Qn.elements[6]*=h,Qn.elements[8]*=u,Qn.elements[9]*=u,Qn.elements[10]*=u,t.setFromRotationMatrix(Qn),n.x=s,n.y=o,n.z=a,this}makePerspective(e,t,n,i,s,o,a=Ii){const l=this.elements,c=2*s/(t-e),h=2*s/(n-i),u=(t+e)/(t-e),d=(n+i)/(n-i);let f,g;if(a===Ii)f=-(o+s)/(o-s),g=-2*o*s/(o-s);else if(a===ya)f=-o/(o-s),g=-o*s/(o-s);else throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);return l[0]=c,l[4]=0,l[8]=u,l[12]=0,l[1]=0,l[5]=h,l[9]=d,l[13]=0,l[2]=0,l[6]=0,l[10]=f,l[14]=g,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,n,i,s,o,a=Ii){const l=this.elements,c=1/(t-e),h=1/(n-i),u=1/(o-s),d=(t+e)*c,f=(n+i)*h;let g,v;if(a===Ii)g=(o+s)*u,v=-2*u;else if(a===ya)g=s*u,v=-1*u;else throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-d,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-f,l[2]=0,l[6]=0,l[10]=v,l[14]=-g,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){const t=this.elements,n=e.elements;for(let i=0;i<16;i++)if(t[i]!==n[i])return!1;return!0}fromArray(e,t=0){for(let n=0;n<16;n++)this.elements[n]=e[n+t];return this}toArray(e=[],t=0){const n=this.elements;return e[t]=n[0],e[t+1]=n[1],e[t+2]=n[2],e[t+3]=n[3],e[t+4]=n[4],e[t+5]=n[5],e[t+6]=n[6],e[t+7]=n[7],e[t+8]=n[8],e[t+9]=n[9],e[t+10]=n[10],e[t+11]=n[11],e[t+12]=n[12],e[t+13]=n[13],e[t+14]=n[14],e[t+15]=n[15],e}}const Us=new L,Qn=new Ee,hm=new L(0,0,0),um=new L(1,1,1),Vi=new L,xo=new L,Fn=new L,Ch=new Ee,Ph=new St;class Bt{constructor(e=0,t=0,n=0,i=Bt.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=n,this._order=i}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,n,i=this._order){return this._x=e,this._y=t,this._z=n,this._order=i,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,n=!0){const i=e.elements,s=i[0],o=i[4],a=i[8],l=i[1],c=i[5],h=i[9],u=i[2],d=i[6],f=i[10];switch(t){case"XYZ":this._y=Math.asin(dt(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(-h,f),this._z=Math.atan2(-o,s)):(this._x=Math.atan2(d,c),this._z=0);break;case"YXZ":this._x=Math.asin(-dt(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(a,f),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-u,s),this._z=0);break;case"ZXY":this._x=Math.asin(dt(d,-1,1)),Math.abs(d)<.9999999?(this._y=Math.atan2(-u,f),this._z=Math.atan2(-o,c)):(this._y=0,this._z=Math.atan2(l,s));break;case"ZYX":this._y=Math.asin(-dt(u,-1,1)),Math.abs(u)<.9999999?(this._x=Math.atan2(d,f),this._z=Math.atan2(l,s)):(this._x=0,this._z=Math.atan2(-o,c));break;case"YZX":this._z=Math.asin(dt(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-u,s)):(this._x=0,this._y=Math.atan2(a,f));break;case"XZY":this._z=Math.asin(-dt(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(d,c),this._y=Math.atan2(a,s)):(this._x=Math.atan2(-h,f),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,n===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,n){return Ch.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Ch,t,n)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Ph.setFromEuler(this),this.setFromQuaternion(Ph,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}}Bt.DEFAULT_ORDER="XYZ";class Yc{constructor(){this.mask=1}set(e){this.mask=(1<<e|0)>>>0}enable(e){this.mask|=1<<e|0}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e|0}disable(e){this.mask&=~(1<<e|0)}disableAll(){this.mask=0}test(e){return(this.mask&e.mask)!==0}isEnabled(e){return(this.mask&(1<<e|0))!==0}}let dm=0;const Lh=new L,Fs=new St,Ei=new Ee,yo=new L,Rr=new L,fm=new L,pm=new St,Dh=new L(1,0,0),Ih=new L(0,1,0),Nh=new L(0,0,1),Uh={type:"added"},mm={type:"removed"},Os={type:"childadded",child:null},nl={type:"childremoved",child:null};class Mt extends Ss{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:dm++}),this.uuid=ri(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=Mt.DEFAULT_UP.clone();const e=new L,t=new Bt,n=new St,i=new L(1,1,1);function s(){n.setFromEuler(t,!1)}function o(){t.setFromQuaternion(n,void 0,!1)}t._onChange(s),n._onChange(o),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:n},scale:{configurable:!0,enumerable:!0,value:i},modelViewMatrix:{value:new Ee},normalMatrix:{value:new ct}}),this.matrix=new Ee,this.matrixWorld=new Ee,this.matrixAutoUpdate=Mt.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=Mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new Yc,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Fs.setFromAxisAngle(e,t),this.quaternion.multiply(Fs),this}rotateOnWorldAxis(e,t){return Fs.setFromAxisAngle(e,t),this.quaternion.premultiply(Fs),this}rotateX(e){return this.rotateOnAxis(Dh,e)}rotateY(e){return this.rotateOnAxis(Ih,e)}rotateZ(e){return this.rotateOnAxis(Nh,e)}translateOnAxis(e,t){return Lh.copy(e).applyQuaternion(this.quaternion),this.position.add(Lh.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(Dh,e)}translateY(e){return this.translateOnAxis(Ih,e)}translateZ(e){return this.translateOnAxis(Nh,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Ei.copy(this.matrixWorld).invert())}lookAt(e,t,n){e.isVector3?yo.copy(e):yo.set(e,t,n);const i=this.parent;this.updateWorldMatrix(!0,!1),Rr.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Ei.lookAt(Rr,yo,this.up):Ei.lookAt(yo,Rr,this.up),this.quaternion.setFromRotationMatrix(Ei),i&&(Ei.extractRotation(i.matrixWorld),Fs.setFromRotationMatrix(Ei),this.quaternion.premultiply(Fs.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Uh),Os.child=e,this.dispatchEvent(Os),Os.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let n=0;n<arguments.length;n++)this.remove(arguments[n]);return this}const t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(mm),nl.child=e,this.dispatchEvent(nl),nl.child=null),this}removeFromParent(){const e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Ei.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Ei.multiply(e.parent.matrixWorld)),e.applyMatrix4(Ei),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Uh),Os.child=e,this.dispatchEvent(Os),Os.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let n=0,i=this.children.length;n<i;n++){const o=this.children[n].getObjectByProperty(e,t);if(o!==void 0)return o}}getObjectsByProperty(e,t,n=[]){this[e]===t&&n.push(this);const i=this.children;for(let s=0,o=i.length;s<o;s++)i[s].getObjectsByProperty(e,t,n);return n}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Rr,e,fm),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(Rr,pm,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);const t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);const t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);const t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].traverseVisible(e)}traverseAncestors(e){const t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);const t=this.children;for(let n=0,i=t.length;n<i;n++)t[n].updateMatrixWorld(e)}updateWorldMatrix(e,t){const n=this.parent;if(e===!0&&n!==null&&n.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){const i=this.children;for(let s=0,o=i.length;s<o;s++)i[s].updateWorldMatrix(!1,!0)}}toJSON(e){const t=e===void 0||typeof e=="string",n={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},n.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});const i={};i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.castShadow===!0&&(i.castShadow=!0),this.receiveShadow===!0&&(i.receiveShadow=!0),this.visible===!1&&(i.visible=!1),this.frustumCulled===!1&&(i.frustumCulled=!1),this.renderOrder!==0&&(i.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(i.userData=this.userData),i.layers=this.layers.mask,i.matrix=this.matrix.toArray(),i.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(i.matrixAutoUpdate=!1),this.isInstancedMesh&&(i.type="InstancedMesh",i.count=this.count,i.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(i.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(i.type="BatchedMesh",i.perObjectFrustumCulled=this.perObjectFrustumCulled,i.sortObjects=this.sortObjects,i.drawRanges=this._drawRanges,i.reservedRanges=this._reservedRanges,i.visibility=this._visibility,i.active=this._active,i.bounds=this._bounds.map(a=>({boxInitialized:a.boxInitialized,boxMin:a.box.min.toArray(),boxMax:a.box.max.toArray(),sphereInitialized:a.sphereInitialized,sphereRadius:a.sphere.radius,sphereCenter:a.sphere.center.toArray()})),i.maxInstanceCount=this._maxInstanceCount,i.maxVertexCount=this._maxVertexCount,i.maxIndexCount=this._maxIndexCount,i.geometryInitialized=this._geometryInitialized,i.geometryCount=this._geometryCount,i.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(i.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(i.boundingSphere={center:i.boundingSphere.center.toArray(),radius:i.boundingSphere.radius}),this.boundingBox!==null&&(i.boundingBox={min:i.boundingBox.min.toArray(),max:i.boundingBox.max.toArray()}));function s(a,l){return a[l.uuid]===void 0&&(a[l.uuid]=l.toJSON(e)),l.uuid}if(this.isScene)this.background&&(this.background.isColor?i.background=this.background.toJSON():this.background.isTexture&&(i.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(i.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){i.geometry=s(e.geometries,this.geometry);const a=this.geometry.parameters;if(a!==void 0&&a.shapes!==void 0){const l=a.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){const u=l[c];s(e.shapes,u)}else s(e.shapes,l)}}if(this.isSkinnedMesh&&(i.bindMode=this.bindMode,i.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(s(e.skeletons,this.skeleton),i.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){const a=[];for(let l=0,c=this.material.length;l<c;l++)a.push(s(e.materials,this.material[l]));i.material=a}else i.material=s(e.materials,this.material);if(this.children.length>0){i.children=[];for(let a=0;a<this.children.length;a++)i.children.push(this.children[a].toJSON(e).object)}if(this.animations.length>0){i.animations=[];for(let a=0;a<this.animations.length;a++){const l=this.animations[a];i.animations.push(s(e.animations,l))}}if(t){const a=o(e.geometries),l=o(e.materials),c=o(e.textures),h=o(e.images),u=o(e.shapes),d=o(e.skeletons),f=o(e.animations),g=o(e.nodes);a.length>0&&(n.geometries=a),l.length>0&&(n.materials=l),c.length>0&&(n.textures=c),h.length>0&&(n.images=h),u.length>0&&(n.shapes=u),d.length>0&&(n.skeletons=d),f.length>0&&(n.animations=f),g.length>0&&(n.nodes=g)}return n.object=i,n;function o(a){const l=[];for(const c in a){const h=a[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let n=0;n<e.children.length;n++){const i=e.children[n];this.add(i.clone())}return this}}Mt.DEFAULT_UP=new L(0,1,0);Mt.DEFAULT_MATRIX_AUTO_UPDATE=!0;Mt.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;const ei=new L,Ti=new L,il=new L,Ai=new L,Bs=new L,ks=new L,Fh=new L,sl=new L,rl=new L,ol=new L,al=new at,ll=new at,cl=new at;class jn{constructor(e=new L,t=new L,n=new L){this.a=e,this.b=t,this.c=n}static getNormal(e,t,n,i){i.subVectors(n,t),ei.subVectors(e,t),i.cross(ei);const s=i.lengthSq();return s>0?i.multiplyScalar(1/Math.sqrt(s)):i.set(0,0,0)}static getBarycoord(e,t,n,i,s){ei.subVectors(i,t),Ti.subVectors(n,t),il.subVectors(e,t);const o=ei.dot(ei),a=ei.dot(Ti),l=ei.dot(il),c=Ti.dot(Ti),h=Ti.dot(il),u=o*c-a*a;if(u===0)return s.set(0,0,0),null;const d=1/u,f=(c*l-a*h)*d,g=(o*h-a*l)*d;return s.set(1-f-g,g,f)}static containsPoint(e,t,n,i){return this.getBarycoord(e,t,n,i,Ai)===null?!1:Ai.x>=0&&Ai.y>=0&&Ai.x+Ai.y<=1}static getInterpolation(e,t,n,i,s,o,a,l){return this.getBarycoord(e,t,n,i,Ai)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(s,Ai.x),l.addScaledVector(o,Ai.y),l.addScaledVector(a,Ai.z),l)}static getInterpolatedAttribute(e,t,n,i,s,o){return al.setScalar(0),ll.setScalar(0),cl.setScalar(0),al.fromBufferAttribute(e,t),ll.fromBufferAttribute(e,n),cl.fromBufferAttribute(e,i),o.setScalar(0),o.addScaledVector(al,s.x),o.addScaledVector(ll,s.y),o.addScaledVector(cl,s.z),o}static isFrontFacing(e,t,n,i){return ei.subVectors(n,t),Ti.subVectors(e,t),ei.cross(Ti).dot(i)<0}set(e,t,n){return this.a.copy(e),this.b.copy(t),this.c.copy(n),this}setFromPointsAndIndices(e,t,n,i){return this.a.copy(e[t]),this.b.copy(e[n]),this.c.copy(e[i]),this}setFromAttributeAndIndices(e,t,n,i){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,n),this.c.fromBufferAttribute(e,i),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return ei.subVectors(this.c,this.b),Ti.subVectors(this.a,this.b),ei.cross(Ti).length()*.5}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return jn.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return jn.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,n,i,s){return jn.getInterpolation(e,this.a,this.b,this.c,t,n,i,s)}containsPoint(e){return jn.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return jn.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){const n=this.a,i=this.b,s=this.c;let o,a;Bs.subVectors(i,n),ks.subVectors(s,n),sl.subVectors(e,n);const l=Bs.dot(sl),c=ks.dot(sl);if(l<=0&&c<=0)return t.copy(n);rl.subVectors(e,i);const h=Bs.dot(rl),u=ks.dot(rl);if(h>=0&&u<=h)return t.copy(i);const d=l*u-h*c;if(d<=0&&l>=0&&h<=0)return o=l/(l-h),t.copy(n).addScaledVector(Bs,o);ol.subVectors(e,s);const f=Bs.dot(ol),g=ks.dot(ol);if(g>=0&&f<=g)return t.copy(s);const v=f*c-l*g;if(v<=0&&c>=0&&g<=0)return a=c/(c-g),t.copy(n).addScaledVector(ks,a);const m=h*g-f*u;if(m<=0&&u-h>=0&&f-g>=0)return Fh.subVectors(s,i),a=(u-h)/(u-h+(f-g)),t.copy(i).addScaledVector(Fh,a);const p=1/(m+v+d);return o=v*p,a=d*p,t.copy(n).addScaledVector(Bs,o).addScaledVector(ks,a)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}}const jd={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},Gi={h:0,s:0,l:0},bo={h:0,s:0,l:0};function hl(r,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?r+(e-r)*6*t:t<1/2?e:t<2/3?r+(e-r)*6*(2/3-t):r}class ke{constructor(e,t,n){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,n)}set(e,t,n){if(t===void 0&&n===void 0){const i=e;i&&i.isColor?this.copy(i):typeof i=="number"?this.setHex(i):typeof i=="string"&&this.setStyle(i)}else this.setRGB(e,t,n);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=vt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(e&255)/255,rt.toWorkingColorSpace(this,t),this}setRGB(e,t,n,i=rt.workingColorSpace){return this.r=e,this.g=t,this.b=n,rt.toWorkingColorSpace(this,i),this}setHSL(e,t,n,i=rt.workingColorSpace){if(e=jc(e,1),t=dt(t,0,1),n=dt(n,0,1),t===0)this.r=this.g=this.b=n;else{const s=n<=.5?n*(1+t):n+t-n*t,o=2*n-s;this.r=hl(o,s,e+1/3),this.g=hl(o,s,e),this.b=hl(o,s,e-1/3)}return rt.toWorkingColorSpace(this,i),this}setStyle(e,t=vt){function n(s){s!==void 0&&parseFloat(s)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let i;if(i=/^(\w+)\(([^\)]*)\)/.exec(e)){let s;const o=i[1],a=i[2];switch(o){case"rgb":case"rgba":if(s=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setRGB(Math.min(255,parseInt(s[1],10))/255,Math.min(255,parseInt(s[2],10))/255,Math.min(255,parseInt(s[3],10))/255,t);if(s=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setRGB(Math.min(100,parseInt(s[1],10))/100,Math.min(100,parseInt(s[2],10))/100,Math.min(100,parseInt(s[3],10))/100,t);break;case"hsl":case"hsla":if(s=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))return n(s[4]),this.setHSL(parseFloat(s[1])/360,parseFloat(s[2])/100,parseFloat(s[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(i=/^\#([A-Fa-f\d]+)$/.exec(e)){const s=i[1],o=s.length;if(o===3)return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,t);if(o===6)return this.setHex(parseInt(s,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=vt){const n=jd[e.toLowerCase()];return n!==void 0?this.setHex(n,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ui(e.r),this.g=Ui(e.g),this.b=Ui(e.b),this}copyLinearToSRGB(e){return this.r=cr(e.r),this.g=cr(e.g),this.b=cr(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=vt){return rt.fromWorkingColorSpace(xn.copy(this),e),Math.round(dt(xn.r*255,0,255))*65536+Math.round(dt(xn.g*255,0,255))*256+Math.round(dt(xn.b*255,0,255))}getHexString(e=vt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=rt.workingColorSpace){rt.fromWorkingColorSpace(xn.copy(this),t);const n=xn.r,i=xn.g,s=xn.b,o=Math.max(n,i,s),a=Math.min(n,i,s);let l,c;const h=(a+o)/2;if(a===o)l=0,c=0;else{const u=o-a;switch(c=h<=.5?u/(o+a):u/(2-o-a),o){case n:l=(i-s)/u+(i<s?6:0);break;case i:l=(s-n)/u+2;break;case s:l=(n-i)/u+4;break}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=rt.workingColorSpace){return rt.fromWorkingColorSpace(xn.copy(this),t),e.r=xn.r,e.g=xn.g,e.b=xn.b,e}getStyle(e=vt){rt.fromWorkingColorSpace(xn.copy(this),e);const t=xn.r,n=xn.g,i=xn.b;return e!==vt?`color(${e} ${t.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})`:`rgb(${Math.round(t*255)},${Math.round(n*255)},${Math.round(i*255)})`}offsetHSL(e,t,n){return this.getHSL(Gi),this.setHSL(Gi.h+e,Gi.s+t,Gi.l+n)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,n){return this.r=e.r+(t.r-e.r)*n,this.g=e.g+(t.g-e.g)*n,this.b=e.b+(t.b-e.b)*n,this}lerpHSL(e,t){this.getHSL(Gi),e.getHSL(bo);const n=Hr(Gi.h,bo.h,t),i=Hr(Gi.s,bo.s,t),s=Hr(Gi.l,bo.l,t);return this.setHSL(n,i,s),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){const t=this.r,n=this.g,i=this.b,s=e.elements;return this.r=s[0]*t+s[3]*n+s[6]*i,this.g=s[1]*t+s[4]*n+s[7]*i,this.b=s[2]*t+s[5]*n+s[8]*i,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}}const xn=new ke;ke.NAMES=jd;let gm=0;class ai extends Ss{constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:gm++}),this.uuid=ri(),this.name="",this.type="Material",this.blending=ar,this.side=Fi,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=Gl,this.blendDst=Wl,this.blendEquation=us,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ke(0,0,0),this.blendAlpha=0,this.depthFunc=hr,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=Mh,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=Ps,this.stencilZFail=Ps,this.stencilZPass=Ps,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(const t in e){const n=e[t];if(n===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}const i=this[t];if(i===void 0){console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`);continue}i&&i.isColor?i.set(n):i&&i.isVector3&&n&&n.isVector3?i.copy(n):this[t]=n}}toJSON(e){const t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});const n={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.color&&this.color.isColor&&(n.color=this.color.getHex()),this.roughness!==void 0&&(n.roughness=this.roughness),this.metalness!==void 0&&(n.metalness=this.metalness),this.sheen!==void 0&&(n.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(n.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(n.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(n.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(n.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(n.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(n.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(n.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(n.shininess=this.shininess),this.clearcoat!==void 0&&(n.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(n.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(n.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(n.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(n.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,n.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(n.dispersion=this.dispersion),this.iridescence!==void 0&&(n.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(n.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(n.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(n.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(n.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(n.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(n.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(n.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(n.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(n.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(n.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(n.lightMap=this.lightMap.toJSON(e).uuid,n.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(n.aoMap=this.aoMap.toJSON(e).uuid,n.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(n.bumpMap=this.bumpMap.toJSON(e).uuid,n.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(n.normalMap=this.normalMap.toJSON(e).uuid,n.normalMapType=this.normalMapType,n.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(n.displacementMap=this.displacementMap.toJSON(e).uuid,n.displacementScale=this.displacementScale,n.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(n.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(n.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(n.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(n.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(n.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(n.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(n.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(n.combine=this.combine)),this.envMapRotation!==void 0&&(n.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(n.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(n.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(n.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(n.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(n.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(n.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(n.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(n.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(n.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(n.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(n.size=this.size),this.shadowSide!==null&&(n.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(n.sizeAttenuation=this.sizeAttenuation),this.blending!==ar&&(n.blending=this.blending),this.side!==Fi&&(n.side=this.side),this.vertexColors===!0&&(n.vertexColors=!0),this.opacity<1&&(n.opacity=this.opacity),this.transparent===!0&&(n.transparent=!0),this.blendSrc!==Gl&&(n.blendSrc=this.blendSrc),this.blendDst!==Wl&&(n.blendDst=this.blendDst),this.blendEquation!==us&&(n.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(n.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(n.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(n.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(n.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(n.blendAlpha=this.blendAlpha),this.depthFunc!==hr&&(n.depthFunc=this.depthFunc),this.depthTest===!1&&(n.depthTest=this.depthTest),this.depthWrite===!1&&(n.depthWrite=this.depthWrite),this.colorWrite===!1&&(n.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(n.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==Mh&&(n.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(n.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(n.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==Ps&&(n.stencilFail=this.stencilFail),this.stencilZFail!==Ps&&(n.stencilZFail=this.stencilZFail),this.stencilZPass!==Ps&&(n.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(n.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(n.rotation=this.rotation),this.polygonOffset===!0&&(n.polygonOffset=!0),this.polygonOffsetFactor!==0&&(n.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(n.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(n.linewidth=this.linewidth),this.dashSize!==void 0&&(n.dashSize=this.dashSize),this.gapSize!==void 0&&(n.gapSize=this.gapSize),this.scale!==void 0&&(n.scale=this.scale),this.dithering===!0&&(n.dithering=!0),this.alphaTest>0&&(n.alphaTest=this.alphaTest),this.alphaHash===!0&&(n.alphaHash=!0),this.alphaToCoverage===!0&&(n.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(n.premultipliedAlpha=!0),this.forceSinglePass===!0&&(n.forceSinglePass=!0),this.wireframe===!0&&(n.wireframe=!0),this.wireframeLinewidth>1&&(n.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(n.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(n.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(n.flatShading=!0),this.visible===!1&&(n.visible=!1),this.toneMapped===!1&&(n.toneMapped=!1),this.fog===!1&&(n.fog=!1),Object.keys(this.userData).length>0&&(n.userData=this.userData);function i(s){const o=[];for(const a in s){const l=s[a];delete l.metadata,o.push(l)}return o}if(t){const s=i(e.textures),o=i(e.images);s.length>0&&(n.textures=s),o.length>0&&(n.images=o)}return n}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;const t=e.clippingPlanes;let n=null;if(t!==null){const i=t.length;n=new Array(i);for(let s=0;s!==i;++s)n[s]=t[s].clone()}return this.clippingPlanes=n,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}}class zn extends ai{constructor(e){super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new ke(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Bt,this.combine=Aa,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}}const Jt=new L,Mo=new ye;let _m=0;class Rn{constructor(e,t,n=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:_m++}),this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=n,this.usage=Ac,this.updateRanges=[],this.gpuType=pi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,n){e*=this.itemSize,n*=t.itemSize;for(let i=0,s=this.itemSize;i<s;i++)this.array[e+i]=t.array[n+i];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,n=this.count;t<n;t++)Mo.fromBufferAttribute(this,t),Mo.applyMatrix3(e),this.setXY(t,Mo.x,Mo.y);else if(this.itemSize===3)for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.applyMatrix3(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}applyMatrix4(e){for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.applyMatrix4(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.applyNormalMatrix(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)Jt.fromBufferAttribute(this,t),Jt.transformDirection(e),this.setXYZ(t,Jt.x,Jt.y,Jt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let n=this.array[e*this.itemSize+t];return this.normalized&&(n=si(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=It(n,this.array)),this.array[e*this.itemSize+t]=n,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=si(t,this.array)),t}setX(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=si(t,this.array)),t}setY(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=si(t,this.array)),t}setZ(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=si(t,this.array)),t}setW(e,t){return this.normalized&&(t=It(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,n){return e*=this.itemSize,this.normalized&&(t=It(t,this.array),n=It(n,this.array)),this.array[e+0]=t,this.array[e+1]=n,this}setXYZ(e,t,n,i){return e*=this.itemSize,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e*=this.itemSize,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array),s=It(s,this.array)),this.array[e+0]=t,this.array[e+1]=n,this.array[e+2]=i,this.array[e+3]=s,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){const e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Ac&&(e.usage=this.usage),e}}class Zc extends Rn{constructor(e,t,n){super(new Uint16Array(e),t,n)}}class Kc extends Rn{constructor(e,t,n){super(new Uint32Array(e),t,n)}}class Ne extends Rn{constructor(e,t,n){super(new Float32Array(e),t,n)}}let vm=0;const Hn=new Ee,ul=new Mt,zs=new L,On=new Cn,Cr=new Cn,cn=new L;class yt extends Ss{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:vm++}),this.uuid=ri(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Wd(e)?Kc:Zc)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,n=0){this.groups.push({start:e,count:t,materialIndex:n})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){const t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);const n=this.attributes.normal;if(n!==void 0){const s=new ct().getNormalMatrix(e);n.applyNormalMatrix(s),n.needsUpdate=!0}const i=this.attributes.tangent;return i!==void 0&&(i.transformDirection(e),i.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Hn.makeRotationFromQuaternion(e),this.applyMatrix4(Hn),this}rotateX(e){return Hn.makeRotationX(e),this.applyMatrix4(Hn),this}rotateY(e){return Hn.makeRotationY(e),this.applyMatrix4(Hn),this}rotateZ(e){return Hn.makeRotationZ(e),this.applyMatrix4(Hn),this}translate(e,t,n){return Hn.makeTranslation(e,t,n),this.applyMatrix4(Hn),this}scale(e,t,n){return Hn.makeScale(e,t,n),this.applyMatrix4(Hn),this}lookAt(e){return ul.lookAt(e),ul.updateMatrix(),this.applyMatrix4(ul.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(zs).negate(),this.translate(zs.x,zs.y,zs.z),this}setFromPoints(e){const t=this.getAttribute("position");if(t===void 0){const n=[];for(let i=0,s=e.length;i<s;i++){const o=e[i];n.push(o.x,o.y,o.z||0)}this.setAttribute("position",new Ne(n,3))}else{const n=Math.min(e.length,t.count);for(let i=0;i<n;i++){const s=e[i];t.setXYZ(i,s.x,s.y,s.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Cn);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new L(-1/0,-1/0,-1/0),new L(1/0,1/0,1/0));return}if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let n=0,i=t.length;n<i;n++){const s=t[n];On.setFromBufferAttribute(s),this.morphTargetsRelative?(cn.addVectors(this.boundingBox.min,On.min),this.boundingBox.expandByPoint(cn),cn.addVectors(this.boundingBox.max,On.max),this.boundingBox.expandByPoint(cn)):(this.boundingBox.expandByPoint(On.min),this.boundingBox.expandByPoint(On.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new vi);const e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute){console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new L,1/0);return}if(e){const n=this.boundingSphere.center;if(On.setFromBufferAttribute(e),t)for(let s=0,o=t.length;s<o;s++){const a=t[s];Cr.setFromBufferAttribute(a),this.morphTargetsRelative?(cn.addVectors(On.min,Cr.min),On.expandByPoint(cn),cn.addVectors(On.max,Cr.max),On.expandByPoint(cn)):(On.expandByPoint(Cr.min),On.expandByPoint(Cr.max))}On.getCenter(n);let i=0;for(let s=0,o=e.count;s<o;s++)cn.fromBufferAttribute(e,s),i=Math.max(i,n.distanceToSquared(cn));if(t)for(let s=0,o=t.length;s<o;s++){const a=t[s],l=this.morphTargetsRelative;for(let c=0,h=a.count;c<h;c++)cn.fromBufferAttribute(a,c),l&&(zs.fromBufferAttribute(e,c),cn.add(zs)),i=Math.max(i,n.distanceToSquared(cn))}this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){const e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0){console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");return}const n=t.position,i=t.normal,s=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new Rn(new Float32Array(4*n.count),4));const o=this.getAttribute("tangent"),a=[],l=[];for(let M=0;M<n.count;M++)a[M]=new L,l[M]=new L;const c=new L,h=new L,u=new L,d=new ye,f=new ye,g=new ye,v=new L,m=new L;function p(M,_,x){c.fromBufferAttribute(n,M),h.fromBufferAttribute(n,_),u.fromBufferAttribute(n,x),d.fromBufferAttribute(s,M),f.fromBufferAttribute(s,_),g.fromBufferAttribute(s,x),h.sub(c),u.sub(c),f.sub(d),g.sub(d);const T=1/(f.x*g.y-g.x*f.y);isFinite(T)&&(v.copy(h).multiplyScalar(g.y).addScaledVector(u,-f.y).multiplyScalar(T),m.copy(u).multiplyScalar(f.x).addScaledVector(h,-g.x).multiplyScalar(T),a[M].add(v),a[_].add(v),a[x].add(v),l[M].add(m),l[_].add(m),l[x].add(m))}let w=this.groups;w.length===0&&(w=[{start:0,count:e.count}]);for(let M=0,_=w.length;M<_;++M){const x=w[M],T=x.start,F=x.count;for(let k=T,G=T+F;k<G;k+=3)p(e.getX(k+0),e.getX(k+1),e.getX(k+2))}const y=new L,b=new L,D=new L,R=new L;function P(M){D.fromBufferAttribute(i,M),R.copy(D);const _=a[M];y.copy(_),y.sub(D.multiplyScalar(D.dot(_))).normalize(),b.crossVectors(R,_);const T=b.dot(l[M])<0?-1:1;o.setXYZW(M,y.x,y.y,y.z,T)}for(let M=0,_=w.length;M<_;++M){const x=w[M],T=x.start,F=x.count;for(let k=T,G=T+F;k<G;k+=3)P(e.getX(k+0)),P(e.getX(k+1)),P(e.getX(k+2))}}computeVertexNormals(){const e=this.index,t=this.getAttribute("position");if(t!==void 0){let n=this.getAttribute("normal");if(n===void 0)n=new Rn(new Float32Array(t.count*3),3),this.setAttribute("normal",n);else for(let d=0,f=n.count;d<f;d++)n.setXYZ(d,0,0,0);const i=new L,s=new L,o=new L,a=new L,l=new L,c=new L,h=new L,u=new L;if(e)for(let d=0,f=e.count;d<f;d+=3){const g=e.getX(d+0),v=e.getX(d+1),m=e.getX(d+2);i.fromBufferAttribute(t,g),s.fromBufferAttribute(t,v),o.fromBufferAttribute(t,m),h.subVectors(o,s),u.subVectors(i,s),h.cross(u),a.fromBufferAttribute(n,g),l.fromBufferAttribute(n,v),c.fromBufferAttribute(n,m),a.add(h),l.add(h),c.add(h),n.setXYZ(g,a.x,a.y,a.z),n.setXYZ(v,l.x,l.y,l.z),n.setXYZ(m,c.x,c.y,c.z)}else for(let d=0,f=t.count;d<f;d+=3)i.fromBufferAttribute(t,d+0),s.fromBufferAttribute(t,d+1),o.fromBufferAttribute(t,d+2),h.subVectors(o,s),u.subVectors(i,s),h.cross(u),n.setXYZ(d+0,h.x,h.y,h.z),n.setXYZ(d+1,h.x,h.y,h.z),n.setXYZ(d+2,h.x,h.y,h.z);this.normalizeNormals(),n.needsUpdate=!0}}normalizeNormals(){const e=this.attributes.normal;for(let t=0,n=e.count;t<n;t++)cn.fromBufferAttribute(e,t),cn.normalize(),e.setXYZ(t,cn.x,cn.y,cn.z)}toNonIndexed(){function e(a,l){const c=a.array,h=a.itemSize,u=a.normalized,d=new c.constructor(l.length*h);let f=0,g=0;for(let v=0,m=l.length;v<m;v++){a.isInterleavedBufferAttribute?f=l[v]*a.data.stride+a.offset:f=l[v]*h;for(let p=0;p<h;p++)d[g++]=c[f++]}return new Rn(d,h,u)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;const t=new yt,n=this.index.array,i=this.attributes;for(const a in i){const l=i[a],c=e(l,n);t.setAttribute(a,c)}const s=this.morphAttributes;for(const a in s){const l=[],c=s[a];for(let h=0,u=c.length;h<u;h++){const d=c[h],f=e(d,n);l.push(f)}t.morphAttributes[a]=l}t.morphTargetsRelative=this.morphTargetsRelative;const o=this.groups;for(let a=0,l=o.length;a<l;a++){const c=o[a];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){const e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){const l=this.parameters;for(const c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};const t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});const n=this.attributes;for(const l in n){const c=n[l];e.data.attributes[l]=c.toJSON(e.data)}const i={};let s=!1;for(const l in this.morphAttributes){const c=this.morphAttributes[l],h=[];for(let u=0,d=c.length;u<d;u++){const f=c[u];h.push(f.toJSON(e.data))}h.length>0&&(i[l]=h,s=!0)}s&&(e.data.morphAttributes=i,e.data.morphTargetsRelative=this.morphTargetsRelative);const o=this.groups;o.length>0&&(e.data.groups=JSON.parse(JSON.stringify(o)));const a=this.boundingSphere;return a!==null&&(e.data.boundingSphere={center:a.center.toArray(),radius:a.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;const t={};this.name=e.name;const n=e.index;n!==null&&this.setIndex(n.clone(t));const i=e.attributes;for(const c in i){const h=i[c];this.setAttribute(c,h.clone(t))}const s=e.morphAttributes;for(const c in s){const h=[],u=s[c];for(let d=0,f=u.length;d<f;d++)h.push(u[d].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;const o=e.groups;for(let c=0,h=o.length;c<h;c++){const u=o[c];this.addGroup(u.start,u.count,u.materialIndex)}const a=e.boundingBox;a!==null&&(this.boundingBox=a.clone());const l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}}const Oh=new Ee,is=new Es,wo=new vi,Bh=new L,So=new L,Eo=new L,To=new L,dl=new L,Ao=new L,kh=new L,Ro=new L;class ve extends Mt{constructor(e=new yt,t=new zn){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=i.length;s<o;s++){const a=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}getVertexPosition(e,t){const n=this.geometry,i=n.attributes.position,s=n.morphAttributes.position,o=n.morphTargetsRelative;t.fromBufferAttribute(i,e);const a=this.morphTargetInfluences;if(s&&a){Ao.set(0,0,0);for(let l=0,c=s.length;l<c;l++){const h=a[l],u=s[l];h!==0&&(dl.fromBufferAttribute(u,e),o?Ao.addScaledVector(dl,h):Ao.addScaledVector(dl.sub(t),h))}t.add(Ao)}return t}raycast(e,t){const n=this.geometry,i=this.material,s=this.matrixWorld;i!==void 0&&(n.boundingSphere===null&&n.computeBoundingSphere(),wo.copy(n.boundingSphere),wo.applyMatrix4(s),is.copy(e.ray).recast(e.near),!(wo.containsPoint(is.origin)===!1&&(is.intersectSphere(wo,Bh)===null||is.origin.distanceToSquared(Bh)>(e.far-e.near)**2))&&(Oh.copy(s).invert(),is.copy(e.ray).applyMatrix4(Oh),!(n.boundingBox!==null&&is.intersectsBox(n.boundingBox)===!1)&&this._computeIntersections(e,t,is)))}_computeIntersections(e,t,n){let i;const s=this.geometry,o=this.material,a=s.index,l=s.attributes.position,c=s.attributes.uv,h=s.attributes.uv1,u=s.attributes.normal,d=s.groups,f=s.drawRange;if(a!==null)if(Array.isArray(o))for(let g=0,v=d.length;g<v;g++){const m=d[g],p=o[m.materialIndex],w=Math.max(m.start,f.start),y=Math.min(a.count,Math.min(m.start+m.count,f.start+f.count));for(let b=w,D=y;b<D;b+=3){const R=a.getX(b),P=a.getX(b+1),M=a.getX(b+2);i=Co(this,p,e,n,c,h,u,R,P,M),i&&(i.faceIndex=Math.floor(b/3),i.face.materialIndex=m.materialIndex,t.push(i))}}else{const g=Math.max(0,f.start),v=Math.min(a.count,f.start+f.count);for(let m=g,p=v;m<p;m+=3){const w=a.getX(m),y=a.getX(m+1),b=a.getX(m+2);i=Co(this,o,e,n,c,h,u,w,y,b),i&&(i.faceIndex=Math.floor(m/3),t.push(i))}}else if(l!==void 0)if(Array.isArray(o))for(let g=0,v=d.length;g<v;g++){const m=d[g],p=o[m.materialIndex],w=Math.max(m.start,f.start),y=Math.min(l.count,Math.min(m.start+m.count,f.start+f.count));for(let b=w,D=y;b<D;b+=3){const R=b,P=b+1,M=b+2;i=Co(this,p,e,n,c,h,u,R,P,M),i&&(i.faceIndex=Math.floor(b/3),i.face.materialIndex=m.materialIndex,t.push(i))}}else{const g=Math.max(0,f.start),v=Math.min(l.count,f.start+f.count);for(let m=g,p=v;m<p;m+=3){const w=m,y=m+1,b=m+2;i=Co(this,o,e,n,c,h,u,w,y,b),i&&(i.faceIndex=Math.floor(m/3),t.push(i))}}}}function xm(r,e,t,n,i,s,o,a){let l;if(e.side===Un?l=n.intersectTriangle(o,s,i,!0,a):l=n.intersectTriangle(i,s,o,e.side===Fi,a),l===null)return null;Ro.copy(a),Ro.applyMatrix4(r.matrixWorld);const c=t.ray.origin.distanceTo(Ro);return c<t.near||c>t.far?null:{distance:c,point:Ro.clone(),object:r}}function Co(r,e,t,n,i,s,o,a,l,c){r.getVertexPosition(a,So),r.getVertexPosition(l,Eo),r.getVertexPosition(c,To);const h=xm(r,e,t,n,So,Eo,To,kh);if(h){const u=new L;jn.getBarycoord(kh,So,Eo,To,u),i&&(h.uv=jn.getInterpolatedAttribute(i,a,l,c,u,new ye)),s&&(h.uv1=jn.getInterpolatedAttribute(s,a,l,c,u,new ye)),o&&(h.normal=jn.getInterpolatedAttribute(o,a,l,c,u,new L),h.normal.dot(n.direction)>0&&h.normal.multiplyScalar(-1));const d={a,b:l,c,normal:new L,materialIndex:0};jn.getNormal(So,Eo,To,d.normal),h.face=d,h.barycoord=u}return h}class Zt extends yt{constructor(e=1,t=1,n=1,i=1,s=1,o=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:n,widthSegments:i,heightSegments:s,depthSegments:o};const a=this;i=Math.floor(i),s=Math.floor(s),o=Math.floor(o);const l=[],c=[],h=[],u=[];let d=0,f=0;g("z","y","x",-1,-1,n,t,e,o,s,0),g("z","y","x",1,-1,n,t,-e,o,s,1),g("x","z","y",1,1,e,n,t,i,o,2),g("x","z","y",1,-1,e,n,-t,i,o,3),g("x","y","z",1,-1,e,t,n,i,s,4),g("x","y","z",-1,-1,e,t,-n,i,s,5),this.setIndex(l),this.setAttribute("position",new Ne(c,3)),this.setAttribute("normal",new Ne(h,3)),this.setAttribute("uv",new Ne(u,2));function g(v,m,p,w,y,b,D,R,P,M,_){const x=b/P,T=D/M,F=b/2,k=D/2,G=R/2,K=P+1,z=M+1;let Z=0,V=0;const Y=new L;for(let ue=0;ue<z;ue++){const ie=ue*T-k;for(let he=0;he<K;he++){const se=he*x-F;Y[v]=se*w,Y[m]=ie*y,Y[p]=G,c.push(Y.x,Y.y,Y.z),Y[v]=0,Y[m]=0,Y[p]=R>0?1:-1,h.push(Y.x,Y.y,Y.z),u.push(he/P),u.push(1-ue/M),Z+=1}}for(let ue=0;ue<M;ue++)for(let ie=0;ie<P;ie++){const he=d+ie+K*ue,se=d+ie+K*(ue+1),H=d+(ie+1)+K*(ue+1),j=d+(ie+1)+K*ue;l.push(he,se,j),l.push(se,H,j),V+=6}a.addGroup(f,V,_),f+=V,d+=Z}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Zt(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}}function _r(r){const e={};for(const t in r){e[t]={};for(const n in r[t]){const i=r[t][n];i&&(i.isColor||i.isMatrix3||i.isMatrix4||i.isVector2||i.isVector3||i.isVector4||i.isTexture||i.isQuaternion)?i.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][n]=null):e[t][n]=i.clone():Array.isArray(i)?e[t][n]=i.slice():e[t][n]=i}}return e}function Tn(r){const e={};for(let t=0;t<r.length;t++){const n=_r(r[t]);for(const i in n)e[i]=n[i]}return e}function ym(r){const e=[];for(let t=0;t<r.length;t++)e.push(r[t].clone());return e}function qd(r){const e=r.getRenderTarget();return e===null?r.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:rt.workingColorSpace}const $c={clone:_r,merge:Tn};var bm=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,Mm=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`;class _i extends ai{constructor(e){super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=bm,this.fragmentShader=Mm,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=_r(e.uniforms),this.uniformsGroups=ym(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){const t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(const i in this.uniforms){const o=this.uniforms[i].value;o&&o.isTexture?t.uniforms[i]={type:"t",value:o.toJSON(e).uuid}:o&&o.isColor?t.uniforms[i]={type:"c",value:o.getHex()}:o&&o.isVector2?t.uniforms[i]={type:"v2",value:o.toArray()}:o&&o.isVector3?t.uniforms[i]={type:"v3",value:o.toArray()}:o&&o.isVector4?t.uniforms[i]={type:"v4",value:o.toArray()}:o&&o.isMatrix3?t.uniforms[i]={type:"m3",value:o.toArray()}:o&&o.isMatrix4?t.uniforms[i]={type:"m4",value:o.toArray()}:t.uniforms[i]={value:o}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;const n={};for(const i in this.extensions)this.extensions[i]===!0&&(n[i]=!0);return Object.keys(n).length>0&&(t.extensions=n),t}}class Yd extends Mt{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ee,this.projectionMatrix=new Ee,this.projectionMatrixInverse=new Ee,this.coordinateSystem=Ii}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}}const Wi=new L,zh=new ye,Hh=new ye;class Qt extends Yd{constructor(e=50,t=1,n=.1,i=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=n,this.far=i,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){const t=.5*this.getFilmHeight()/e;this.fov=gr*2*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){const e=Math.tan(zr*.5*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return gr*2*Math.atan(Math.tan(zr*.5*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,n){Wi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Wi.x,Wi.y).multiplyScalar(-e/Wi.z),Wi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),n.set(Wi.x,Wi.y).multiplyScalar(-e/Wi.z)}getViewSize(e,t){return this.getViewBounds(e,zh,Hh),t.subVectors(Hh,zh)}setViewOffset(e,t,n,i,s,o){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=this.near;let t=e*Math.tan(zr*.5*this.fov)/this.zoom,n=2*t,i=this.aspect*n,s=-.5*i;const o=this.view;if(this.view!==null&&this.view.enabled){const l=o.fullWidth,c=o.fullHeight;s+=o.offsetX*i/l,t-=o.offsetY*n/c,i*=o.width/l,n*=o.height/c}const a=this.filmOffset;a!==0&&(s+=e*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(s,s+i,t,t-n,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}}const Hs=-90,Vs=1;class wm extends Mt{constructor(e,t,n){super(),this.type="CubeCamera",this.renderTarget=n,this.coordinateSystem=null,this.activeMipmapLevel=0;const i=new Qt(Hs,Vs,e,t);i.layers=this.layers,this.add(i);const s=new Qt(Hs,Vs,e,t);s.layers=this.layers,this.add(s);const o=new Qt(Hs,Vs,e,t);o.layers=this.layers,this.add(o);const a=new Qt(Hs,Vs,e,t);a.layers=this.layers,this.add(a);const l=new Qt(Hs,Vs,e,t);l.layers=this.layers,this.add(l);const c=new Qt(Hs,Vs,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){const e=this.coordinateSystem,t=this.children.concat(),[n,i,s,o,a,l]=t;for(const c of t)this.remove(c);if(e===Ii)n.up.set(0,1,0),n.lookAt(1,0,0),i.up.set(0,1,0),i.lookAt(-1,0,0),s.up.set(0,0,-1),s.lookAt(0,1,0),o.up.set(0,0,1),o.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else if(e===ya)n.up.set(0,-1,0),n.lookAt(-1,0,0),i.up.set(0,-1,0),i.lookAt(1,0,0),s.up.set(0,0,1),s.lookAt(0,1,0),o.up.set(0,0,-1),o.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1);else throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);for(const c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();const{renderTarget:n,activeMipmapLevel:i}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());const[s,o,a,l,c,h]=this.children,u=e.getRenderTarget(),d=e.getActiveCubeFace(),f=e.getActiveMipmapLevel(),g=e.xr.enabled;e.xr.enabled=!1;const v=n.texture.generateMipmaps;n.texture.generateMipmaps=!1,e.setRenderTarget(n,0,i),e.render(t,s),e.setRenderTarget(n,1,i),e.render(t,o),e.setRenderTarget(n,2,i),e.render(t,a),e.setRenderTarget(n,3,i),e.render(t,l),e.setRenderTarget(n,4,i),e.render(t,c),n.texture.generateMipmaps=v,e.setRenderTarget(n,5,i),e.render(t,h),e.setRenderTarget(u,d,f),e.xr.enabled=g,n.texture.needsPMREMUpdate=!0}}class Zd extends Wt{constructor(e,t,n,i,s,o,a,l,c,h){e=e!==void 0?e:[],t=t!==void 0?t:ur,super(e,t,n,i,s,o,a,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}}class Sm extends xs{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;const n={width:e,height:e,depth:1},i=[n,n,n,n,n,n];this.texture=new Zd(i,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0?t.generateMipmaps:!1,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:mn}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;const n={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new Zt(5,5,5),s=new _i({name:"CubemapFromEquirect",uniforms:_r(n.uniforms),vertexShader:n.vertexShader,fragmentShader:n.fragmentShader,side:Un,blending:Ji});s.uniforms.tEquirect.value=t;const o=new ve(i,s),a=t.minFilter;return t.minFilter===Di&&(t.minFilter=mn),new wm(1,10,this).update(e,o),t.minFilter=a,o.geometry.dispose(),o.material.dispose(),this}clear(e,t,n,i){const s=e.getRenderTarget();for(let o=0;o<6;o++)e.setRenderTarget(this,o),e.clear(t,n,i);e.setRenderTarget(s)}}class wt extends Mt{constructor(){super(),this.isGroup=!0,this.type="Group"}}const Em={type:"move"};class fl{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new wt,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new wt,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new L,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new L),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new wt,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new L,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new L),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){const t=this._hand;if(t)for(const n of e.hand.values())this._getHandJoint(t,n)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,n){let i=null,s=null,o=null;const a=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){o=!0;for(const v of e.hand.values()){const m=t.getJointPose(v,n),p=this._getHandJoint(c,v);m!==null&&(p.matrix.fromArray(m.transform.matrix),p.matrix.decompose(p.position,p.rotation,p.scale),p.matrixWorldNeedsUpdate=!0,p.jointRadius=m.radius),p.visible=m!==null}const h=c.joints["index-finger-tip"],u=c.joints["thumb-tip"],d=h.position.distanceTo(u.position),f=.02,g=.005;c.inputState.pinching&&d>f+g?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&d<=f-g&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(s=t.getPose(e.gripSpace,n),s!==null&&(l.matrix.fromArray(s.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,s.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(s.linearVelocity)):l.hasLinearVelocity=!1,s.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(s.angularVelocity)):l.hasAngularVelocity=!1));a!==null&&(i=t.getPose(e.targetRaySpace,n),i===null&&s!==null&&(i=s),i!==null&&(a.matrix.fromArray(i.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,i.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(i.linearVelocity)):a.hasLinearVelocity=!1,i.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(i.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(Em)))}return a!==null&&(a.visible=i!==null),l!==null&&(l.visible=s!==null),c!==null&&(c.visible=o!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){const n=new wt;n.matrixAutoUpdate=!1,n.visible=!1,e.joints[t.jointName]=n,e.add(n)}return e.joints[t.jointName]}}class Rc extends Mt{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Bt,this.environmentIntensity=1,this.environmentRotation=new Bt,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){const t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}}class Kd{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Ac,this.updateRanges=[],this.version=0,this.uuid=ri()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,n){e*=this.stride,n*=t.stride;for(let i=0,s=this.stride;i<s;i++)this.array[e+i]=t.array[n+i];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ri()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);const t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),n=new this.constructor(t,this.stride);return n.setUsage(this.usage),n}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=ri()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}}const En=new L;class mi{constructor(e,t,n,i=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=n,this.normalized=i}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,n=this.data.count;t<n;t++)En.fromBufferAttribute(this,t),En.applyMatrix4(e),this.setXYZ(t,En.x,En.y,En.z);return this}applyNormalMatrix(e){for(let t=0,n=this.count;t<n;t++)En.fromBufferAttribute(this,t),En.applyNormalMatrix(e),this.setXYZ(t,En.x,En.y,En.z);return this}transformDirection(e){for(let t=0,n=this.count;t<n;t++)En.fromBufferAttribute(this,t),En.transformDirection(e),this.setXYZ(t,En.x,En.y,En.z);return this}getComponent(e,t){let n=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(n=si(n,this.array)),n}setComponent(e,t,n){return this.normalized&&(n=It(n,this.array)),this.data.array[e*this.data.stride+this.offset+t]=n,this}setX(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=It(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=si(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=si(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=si(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=si(t,this.array)),t}setXY(e,t,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=It(t,this.array),n=It(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this}setXYZ(e,t,n,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this}setXYZW(e,t,n,i,s){return e=e*this.data.stride+this.offset,this.normalized&&(t=It(t,this.array),n=It(n,this.array),i=It(i,this.array),s=It(s,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=n,this.data.array[e+2]=i,this.data.array[e+3]=s,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return new Rn(new this.array.constructor(t),this.itemSize,this.normalized)}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new mi(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");const t=[];for(let n=0;n<this.count;n++){const i=n*this.data.stride+this.offset;for(let s=0;s<this.itemSize;s++)t.push(this.data.array[i+s])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}else return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}}class $d extends ai{constructor(e){super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new ke(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}let Gs;const Pr=new L,Ws=new L,Xs=new L,js=new ye,Lr=new ye,Jd=new Ee,Po=new L,Dr=new L,Lo=new L,Vh=new ye,pl=new ye,Gh=new ye;class qs extends Mt{constructor(e=new $d){if(super(),this.isSprite=!0,this.type="Sprite",Gs===void 0){Gs=new yt;const t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),n=new Kd(t,5);Gs.setIndex([0,1,2,0,2,3]),Gs.setAttribute("position",new mi(n,3,0,!1)),Gs.setAttribute("uv",new mi(n,2,3,!1))}this.geometry=Gs,this.material=e,this.center=new ye(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),Ws.setFromMatrixScale(this.matrixWorld),Jd.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),Xs.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&Ws.multiplyScalar(-Xs.z);const n=this.material.rotation;let i,s;n!==0&&(s=Math.cos(n),i=Math.sin(n));const o=this.center;Do(Po.set(-.5,-.5,0),Xs,o,Ws,i,s),Do(Dr.set(.5,-.5,0),Xs,o,Ws,i,s),Do(Lo.set(.5,.5,0),Xs,o,Ws,i,s),Vh.set(0,0),pl.set(1,0),Gh.set(1,1);let a=e.ray.intersectTriangle(Po,Dr,Lo,!1,Pr);if(a===null&&(Do(Dr.set(-.5,.5,0),Xs,o,Ws,i,s),pl.set(0,1),a=e.ray.intersectTriangle(Po,Lo,Dr,!1,Pr),a===null))return;const l=e.ray.origin.distanceTo(Pr);l<e.near||l>e.far||t.push({distance:l,point:Pr.clone(),uv:jn.getInterpolation(Pr,Po,Dr,Lo,Vh,pl,Gh,new ye),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}}function Do(r,e,t,n,i,s){js.subVectors(r,t).addScalar(.5).multiply(n),i!==void 0?(Lr.x=s*js.x-i*js.y,Lr.y=i*js.x+s*js.y):Lr.copy(js),r.copy(e),r.x+=Lr.x,r.y+=Lr.y,r.applyMatrix4(Jd)}const Wh=new L,Xh=new at,jh=new at,Tm=new L,qh=new Ee,Io=new L,ml=new vi,Yh=new Ee,gl=new Es;class Qd extends ve{constructor(e,t){super(e,t),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=vh,this.bindMatrix=new Ee,this.bindMatrixInverse=new Ee,this.boundingBox=null,this.boundingSphere=null}computeBoundingBox(){const e=this.geometry;this.boundingBox===null&&(this.boundingBox=new Cn),this.boundingBox.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Io),this.boundingBox.expandByPoint(Io)}computeBoundingSphere(){const e=this.geometry;this.boundingSphere===null&&(this.boundingSphere=new vi),this.boundingSphere.makeEmpty();const t=e.getAttribute("position");for(let n=0;n<t.count;n++)this.getVertexPosition(n,Io),this.boundingSphere.expandByPoint(Io)}copy(e,t){return super.copy(e,t),this.bindMode=e.bindMode,this.bindMatrix.copy(e.bindMatrix),this.bindMatrixInverse.copy(e.bindMatrixInverse),this.skeleton=e.skeleton,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}raycast(e,t){const n=this.material,i=this.matrixWorld;n!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),ml.copy(this.boundingSphere),ml.applyMatrix4(i),e.ray.intersectsSphere(ml)!==!1&&(Yh.copy(i).invert(),gl.copy(e.ray).applyMatrix4(Yh),!(this.boundingBox!==null&&gl.intersectsBox(this.boundingBox)===!1)&&this._computeIntersections(e,t,gl)))}getVertexPosition(e,t){return super.getVertexPosition(e,t),this.applyBoneTransform(e,t),t}bind(e,t){this.skeleton=e,t===void 0&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),t=this.matrixWorld),this.bindMatrix.copy(t),this.bindMatrixInverse.copy(t).invert()}pose(){this.skeleton.pose()}normalizeSkinWeights(){const e=new at,t=this.geometry.attributes.skinWeight;for(let n=0,i=t.count;n<i;n++){e.fromBufferAttribute(t,n);const s=1/e.manhattanLength();s!==1/0?e.multiplyScalar(s):e.set(1,0,0,0),t.setXYZW(n,e.x,e.y,e.z,e.w)}}updateMatrixWorld(e){super.updateMatrixWorld(e),this.bindMode===vh?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===Sp?this.bindMatrixInverse.copy(this.bindMatrix).invert():console.warn("THREE.SkinnedMesh: Unrecognized bindMode: "+this.bindMode)}applyBoneTransform(e,t){const n=this.skeleton,i=this.geometry;Xh.fromBufferAttribute(i.attributes.skinIndex,e),jh.fromBufferAttribute(i.attributes.skinWeight,e),Wh.copy(t).applyMatrix4(this.bindMatrix),t.set(0,0,0);for(let s=0;s<4;s++){const o=jh.getComponent(s);if(o!==0){const a=Xh.getComponent(s);qh.multiplyMatrices(n.bones[a].matrixWorld,n.boneInverses[a]),t.addScaledVector(Tm.copy(Wh).applyMatrix4(qh),o)}}return t.applyMatrix4(this.bindMatrixInverse)}}class ba extends Mt{constructor(){super(),this.isBone=!0,this.type="Bone"}}class ef extends Wt{constructor(e=null,t=1,n=1,i,s,o,a,l,c=gn,h=gn,u,d){super(null,o,a,l,c,h,i,s,u,d),this.isDataTexture=!0,this.image={data:e,width:t,height:n},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}}const Zh=new Ee,Am=new Ee;class Ca{constructor(e=[],t=[]){this.uuid=ri(),this.bones=e.slice(0),this.boneInverses=t,this.boneMatrices=null,this.boneTexture=null,this.init()}init(){const e=this.bones,t=this.boneInverses;if(this.boneMatrices=new Float32Array(e.length*16),t.length===0)this.calculateInverses();else if(e.length!==t.length){console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];for(let n=0,i=this.bones.length;n<i;n++)this.boneInverses.push(new Ee)}}calculateInverses(){this.boneInverses.length=0;for(let e=0,t=this.bones.length;e<t;e++){const n=new Ee;this.bones[e]&&n.copy(this.bones[e].matrixWorld).invert(),this.boneInverses.push(n)}}pose(){for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&n.matrixWorld.copy(this.boneInverses[e]).invert()}for(let e=0,t=this.bones.length;e<t;e++){const n=this.bones[e];n&&(n.parent&&n.parent.isBone?(n.matrix.copy(n.parent.matrixWorld).invert(),n.matrix.multiply(n.matrixWorld)):n.matrix.copy(n.matrixWorld),n.matrix.decompose(n.position,n.quaternion,n.scale))}}update(){const e=this.bones,t=this.boneInverses,n=this.boneMatrices,i=this.boneTexture;for(let s=0,o=e.length;s<o;s++){const a=e[s]?e[s].matrixWorld:Am;Zh.multiplyMatrices(a,t[s]),Zh.toArray(n,s*16)}i!==null&&(i.needsUpdate=!0)}clone(){return new Ca(this.bones,this.boneInverses)}computeBoneTexture(){let e=Math.sqrt(this.bones.length*4);e=Math.ceil(e/4)*4,e=Math.max(e,4);const t=new Float32Array(e*e*4);t.set(this.boneMatrices);const n=new ef(t,e,e,wn,pi);return n.needsUpdate=!0,this.boneMatrices=t,this.boneTexture=n,this}getBoneByName(e){for(let t=0,n=this.bones.length;t<n;t++){const i=this.bones[t];if(i.name===e)return i}}dispose(){this.boneTexture!==null&&(this.boneTexture.dispose(),this.boneTexture=null)}fromJSON(e,t){this.uuid=e.uuid;for(let n=0,i=e.bones.length;n<i;n++){const s=e.bones[n];let o=t[s];o===void 0&&(console.warn("THREE.Skeleton: No bone found with UUID:",s),o=new ba),this.bones.push(o),this.boneInverses.push(new Ee().fromArray(e.boneInverses[n]))}return this.init(),this}toJSON(){const e={metadata:{version:4.6,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};e.uuid=this.uuid;const t=this.bones,n=this.boneInverses;for(let i=0,s=t.length;i<s;i++){const o=t[i];e.bones.push(o.uuid);const a=n[i];e.boneInverses.push(a.toArray())}return e}}const _l=new L,Rm=new L,Cm=new ct;class Zi{constructor(e=new L(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,n,i){return this.normal.set(e,t,n),this.constant=i,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,n){const i=_l.subVectors(n,t).cross(Rm.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(i,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){const e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){const n=e.delta(_l),i=this.normal.dot(n);if(i===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;const s=-(e.start.dot(this.normal)+this.constant)/i;return s<0||s>1?null:t.copy(e.start).addScaledVector(n,s)}intersectsLine(e){const t=this.distanceToPoint(e.start),n=this.distanceToPoint(e.end);return t<0&&n>0||n<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){const n=t||Cm.getNormalMatrix(e),i=this.coplanarPoint(_l).applyMatrix4(e),s=this.normal.applyMatrix3(n).normalize();return this.constant=-i.dot(s),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}}const ss=new vi,No=new L;class Pa{constructor(e=new Zi,t=new Zi,n=new Zi,i=new Zi,s=new Zi,o=new Zi){this.planes=[e,t,n,i,s,o]}set(e,t,n,i,s,o){const a=this.planes;return a[0].copy(e),a[1].copy(t),a[2].copy(n),a[3].copy(i),a[4].copy(s),a[5].copy(o),this}copy(e){const t=this.planes;for(let n=0;n<6;n++)t[n].copy(e.planes[n]);return this}setFromProjectionMatrix(e,t=Ii){const n=this.planes,i=e.elements,s=i[0],o=i[1],a=i[2],l=i[3],c=i[4],h=i[5],u=i[6],d=i[7],f=i[8],g=i[9],v=i[10],m=i[11],p=i[12],w=i[13],y=i[14],b=i[15];if(n[0].setComponents(l-s,d-c,m-f,b-p).normalize(),n[1].setComponents(l+s,d+c,m+f,b+p).normalize(),n[2].setComponents(l+o,d+h,m+g,b+w).normalize(),n[3].setComponents(l-o,d-h,m-g,b-w).normalize(),n[4].setComponents(l-a,d-u,m-v,b-y).normalize(),t===Ii)n[5].setComponents(l+a,d+u,m+v,b+y).normalize();else if(t===ya)n[5].setComponents(a,u,v,y).normalize();else throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),ss.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{const t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),ss.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(ss)}intersectsSprite(e){return ss.center.set(0,0,0),ss.radius=.7071067811865476,ss.applyMatrix4(e.matrixWorld),this.intersectsSphere(ss)}intersectsSphere(e){const t=this.planes,n=e.center,i=-e.radius;for(let s=0;s<6;s++)if(t[s].distanceToPoint(n)<i)return!1;return!0}intersectsBox(e){const t=this.planes;for(let n=0;n<6;n++){const i=t[n];if(No.x=i.normal.x>0?e.max.x:e.min.x,No.y=i.normal.y>0?e.max.y:e.min.y,No.z=i.normal.z>0?e.max.z:e.min.z,i.distanceToPoint(No)<0)return!1}return!0}containsPoint(e){const t=this.planes;for(let n=0;n<6;n++)if(t[n].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}}class Yn extends ai{constructor(e){super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new ke(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}}const Ma=new L,wa=new L,Kh=new Ee,Ir=new Es,Uo=new vi,vl=new L,$h=new L;class Gn extends Mt{constructor(e=new yt,t=new Yn){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[0];for(let i=1,s=t.count;i<s;i++)Ma.fromBufferAttribute(t,i-1),wa.fromBufferAttribute(t,i),n[i]=n[i-1],n[i]+=Ma.distanceTo(wa);e.setAttribute("lineDistance",new Ne(n,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){const n=this.geometry,i=this.matrixWorld,s=e.params.Line.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Uo.copy(n.boundingSphere),Uo.applyMatrix4(i),Uo.radius+=s,e.ray.intersectsSphere(Uo)===!1)return;Kh.copy(i).invert(),Ir.copy(e.ray).applyMatrix4(Kh);const a=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=this.isLineSegments?2:1,h=n.index,d=n.attributes.position;if(h!==null){const f=Math.max(0,o.start),g=Math.min(h.count,o.start+o.count);for(let v=f,m=g-1;v<m;v+=c){const p=h.getX(v),w=h.getX(v+1),y=Fo(this,e,Ir,l,p,w,v);y&&t.push(y)}if(this.isLineLoop){const v=h.getX(g-1),m=h.getX(f),p=Fo(this,e,Ir,l,v,m,g-1);p&&t.push(p)}}else{const f=Math.max(0,o.start),g=Math.min(d.count,o.start+o.count);for(let v=f,m=g-1;v<m;v+=c){const p=Fo(this,e,Ir,l,v,v+1,v);p&&t.push(p)}if(this.isLineLoop){const v=Fo(this,e,Ir,l,g-1,f,g-1);v&&t.push(v)}}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=i.length;s<o;s++){const a=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}}function Fo(r,e,t,n,i,s,o){const a=r.geometry.attributes.position;if(Ma.fromBufferAttribute(a,i),wa.fromBufferAttribute(a,s),t.distanceSqToSegment(Ma,wa,vl,$h)>n)return;vl.applyMatrix4(r.matrixWorld);const c=e.ray.origin.distanceTo(vl);if(!(c<e.near||c>e.far))return{distance:c,point:$h.clone().applyMatrix4(r.matrixWorld),index:o,face:null,faceIndex:null,barycoord:null,object:r}}const Jh=new L,Qh=new L;class vr extends Gn{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){const e=this.geometry;if(e.index===null){const t=e.attributes.position,n=[];for(let i=0,s=t.count;i<s;i+=2)Jh.fromBufferAttribute(t,i),Qh.fromBufferAttribute(t,i+1),n[i]=i===0?0:n[i-1],n[i+1]=n[i]+Jh.distanceTo(Qh);e.setAttribute("lineDistance",new Ne(n,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}}class ps extends ai{constructor(e){super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new ke(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}}const eu=new Ee,Cc=new Es,Oo=new vi,Bo=new L;class Vr extends Mt{constructor(e=new yt,t=new ps){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){const n=this.geometry,i=this.matrixWorld,s=e.params.Points.threshold,o=n.drawRange;if(n.boundingSphere===null&&n.computeBoundingSphere(),Oo.copy(n.boundingSphere),Oo.applyMatrix4(i),Oo.radius+=s,e.ray.intersectsSphere(Oo)===!1)return;eu.copy(i).invert(),Cc.copy(e.ray).applyMatrix4(eu);const a=s/((this.scale.x+this.scale.y+this.scale.z)/3),l=a*a,c=n.index,u=n.attributes.position;if(c!==null){const d=Math.max(0,o.start),f=Math.min(c.count,o.start+o.count);for(let g=d,v=f;g<v;g++){const m=c.getX(g);Bo.fromBufferAttribute(u,m),tu(Bo,m,l,i,e,t,this)}}else{const d=Math.max(0,o.start),f=Math.min(u.count,o.start+o.count);for(let g=d,v=f;g<v;g++)Bo.fromBufferAttribute(u,g),tu(Bo,g,l,i,e,t,this)}}updateMorphTargets(){const t=this.geometry.morphAttributes,n=Object.keys(t);if(n.length>0){const i=t[n[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let s=0,o=i.length;s<o;s++){const a=i[s].name||String(s);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=s}}}}}function tu(r,e,t,n,i,s,o){const a=Cc.distanceSqToPoint(r);if(a<t){const l=new L;Cc.closestPointToPoint(r,l),l.applyMatrix4(n);const c=i.ray.origin.distanceTo(l);if(c<i.near||c>i.far)return;s.push({distance:c,distanceToRay:Math.sqrt(a),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:o})}}class Pm extends Wt{constructor(e,t,n,i,s,o,a,l,c){super(e,t,n,i,s,o,a,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}}class tf extends Wt{constructor(e,t,n,i,s,o,a,l,c,h=lr){if(h!==lr&&h!==pr)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");n===void 0&&h===lr&&(n=vs),n===void 0&&h===pr&&(n=fr),super(null,i,s,o,a,l,h,n,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=a!==void 0?a:gn,this.minFilter=l!==void 0?l:gn,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.source=new qc(Object.assign({},e.image)),this.compareFunction=e.compareFunction,this}toJSON(e){const t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}}class Lm{constructor(){this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null}getPoint(){console.warn("THREE.Curve: .getPoint() not implemented.")}getPointAt(e,t){const n=this.getUtoTmapping(e);return this.getPoint(n,t)}getPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPoint(n/e));return t}getSpacedPoints(e=5){const t=[];for(let n=0;n<=e;n++)t.push(this.getPointAt(n/e));return t}getLength(){const e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;const t=[];let n,i=this.getPoint(0),s=0;t.push(0);for(let o=1;o<=e;o++)n=this.getPoint(o/e),s+=n.distanceTo(i),t.push(s),i=n;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t=null){const n=this.getLengths();let i=0;const s=n.length;let o;t?o=t:o=e*n[s-1];let a=0,l=s-1,c;for(;a<=l;)if(i=Math.floor(a+(l-a)/2),c=n[i]-o,c<0)a=i+1;else if(c>0)l=i-1;else{l=i;break}if(i=l,n[i]===o)return i/(s-1);const h=n[i],d=n[i+1]-h,f=(o-h)/d;return(i+f)/(s-1)}getTangent(e,t){let i=e-1e-4,s=e+1e-4;i<0&&(i=0),s>1&&(s=1);const o=this.getPoint(i),a=this.getPoint(s),l=t||(o.isVector2?new ye:new L);return l.copy(a).sub(o).normalize(),l}getTangentAt(e,t){const n=this.getUtoTmapping(e);return this.getTangent(n,t)}computeFrenetFrames(e,t=!1){const n=new L,i=[],s=[],o=[],a=new L,l=new Ee;for(let f=0;f<=e;f++){const g=f/e;i[f]=this.getTangentAt(g,new L)}s[0]=new L,o[0]=new L;let c=Number.MAX_VALUE;const h=Math.abs(i[0].x),u=Math.abs(i[0].y),d=Math.abs(i[0].z);h<=c&&(c=h,n.set(1,0,0)),u<=c&&(c=u,n.set(0,1,0)),d<=c&&n.set(0,0,1),a.crossVectors(i[0],n).normalize(),s[0].crossVectors(i[0],a),o[0].crossVectors(i[0],s[0]);for(let f=1;f<=e;f++){if(s[f]=s[f-1].clone(),o[f]=o[f-1].clone(),a.crossVectors(i[f-1],i[f]),a.length()>Number.EPSILON){a.normalize();const g=Math.acos(dt(i[f-1].dot(i[f]),-1,1));s[f].applyMatrix4(l.makeRotationAxis(a,g))}o[f].crossVectors(i[f],s[f])}if(t===!0){let f=Math.acos(dt(s[0].dot(s[e]),-1,1));f/=e,i[0].dot(a.crossVectors(s[0],s[e]))>0&&(f=-f);for(let g=1;g<=e;g++)s[g].applyMatrix4(l.makeRotationAxis(i[g],f*g)),o[g].crossVectors(i[g],s[g])}return{tangents:i,normals:s,binormals:o}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){const e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}}class sn extends yt{constructor(e=1,t=1,n=1,i=32,s=1,o=!1,a=0,l=Math.PI*2){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:n,radialSegments:i,heightSegments:s,openEnded:o,thetaStart:a,thetaLength:l};const c=this;i=Math.floor(i),s=Math.floor(s);const h=[],u=[],d=[],f=[];let g=0;const v=[],m=n/2;let p=0;w(),o===!1&&(e>0&&y(!0),t>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new Ne(u,3)),this.setAttribute("normal",new Ne(d,3)),this.setAttribute("uv",new Ne(f,2));function w(){const b=new L,D=new L;let R=0;const P=(t-e)/n;for(let M=0;M<=s;M++){const _=[],x=M/s,T=x*(t-e)+e;for(let F=0;F<=i;F++){const k=F/i,G=k*l+a,K=Math.sin(G),z=Math.cos(G);D.x=T*K,D.y=-x*n+m,D.z=T*z,u.push(D.x,D.y,D.z),b.set(K,P,z).normalize(),d.push(b.x,b.y,b.z),f.push(k,1-x),_.push(g++)}v.push(_)}for(let M=0;M<i;M++)for(let _=0;_<s;_++){const x=v[_][M],T=v[_+1][M],F=v[_+1][M+1],k=v[_][M+1];(e>0||_!==0)&&(h.push(x,T,k),R+=3),(t>0||_!==s-1)&&(h.push(T,F,k),R+=3)}c.addGroup(p,R,0),p+=R}function y(b){const D=g,R=new ye,P=new L;let M=0;const _=b===!0?e:t,x=b===!0?1:-1;for(let F=1;F<=i;F++)u.push(0,m*x,0),d.push(0,x,0),f.push(.5,.5),g++;const T=g;for(let F=0;F<=i;F++){const G=F/i*l+a,K=Math.cos(G),z=Math.sin(G);P.x=_*z,P.y=m*x,P.z=_*K,u.push(P.x,P.y,P.z),d.push(0,x,0),R.x=K*.5+.5,R.y=z*.5*x+.5,f.push(R.x,R.y),g++}for(let F=0;F<i;F++){const k=D+F,G=T+F;b===!0?h.push(G,G+1,k):h.push(G+1,G,k),M+=3}c.addGroup(p,M,b===!0?1:2),p+=M}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new sn(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}}class Jc extends yt{constructor(e=[],t=[],n=1,i=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:n,detail:i};const s=[],o=[];a(i),c(n),h(),this.setAttribute("position",new Ne(s,3)),this.setAttribute("normal",new Ne(s.slice(),3)),this.setAttribute("uv",new Ne(o,2)),i===0?this.computeVertexNormals():this.normalizeNormals();function a(w){const y=new L,b=new L,D=new L;for(let R=0;R<t.length;R+=3)f(t[R+0],y),f(t[R+1],b),f(t[R+2],D),l(y,b,D,w)}function l(w,y,b,D){const R=D+1,P=[];for(let M=0;M<=R;M++){P[M]=[];const _=w.clone().lerp(b,M/R),x=y.clone().lerp(b,M/R),T=R-M;for(let F=0;F<=T;F++)F===0&&M===R?P[M][F]=_:P[M][F]=_.clone().lerp(x,F/T)}for(let M=0;M<R;M++)for(let _=0;_<2*(R-M)-1;_++){const x=Math.floor(_/2);_%2===0?(d(P[M][x+1]),d(P[M+1][x]),d(P[M][x])):(d(P[M][x+1]),d(P[M+1][x+1]),d(P[M+1][x]))}}function c(w){const y=new L;for(let b=0;b<s.length;b+=3)y.x=s[b+0],y.y=s[b+1],y.z=s[b+2],y.normalize().multiplyScalar(w),s[b+0]=y.x,s[b+1]=y.y,s[b+2]=y.z}function h(){const w=new L;for(let y=0;y<s.length;y+=3){w.x=s[y+0],w.y=s[y+1],w.z=s[y+2];const b=m(w)/2/Math.PI+.5,D=p(w)/Math.PI+.5;o.push(b,1-D)}g(),u()}function u(){for(let w=0;w<o.length;w+=6){const y=o[w+0],b=o[w+2],D=o[w+4],R=Math.max(y,b,D),P=Math.min(y,b,D);R>.9&&P<.1&&(y<.2&&(o[w+0]+=1),b<.2&&(o[w+2]+=1),D<.2&&(o[w+4]+=1))}}function d(w){s.push(w.x,w.y,w.z)}function f(w,y){const b=w*3;y.x=e[b+0],y.y=e[b+1],y.z=e[b+2]}function g(){const w=new L,y=new L,b=new L,D=new L,R=new ye,P=new ye,M=new ye;for(let _=0,x=0;_<s.length;_+=9,x+=6){w.set(s[_+0],s[_+1],s[_+2]),y.set(s[_+3],s[_+4],s[_+5]),b.set(s[_+6],s[_+7],s[_+8]),R.set(o[x+0],o[x+1]),P.set(o[x+2],o[x+3]),M.set(o[x+4],o[x+5]),D.copy(w).add(y).add(b).divideScalar(3);const T=m(D);v(R,x+0,w,T),v(P,x+2,y,T),v(M,x+4,b,T)}}function v(w,y,b,D){D<0&&w.x===1&&(o[y]=w.x-1),b.x===0&&b.z===0&&(o[y]=D/2/Math.PI+.5)}function m(w){return Math.atan2(w.z,-w.x)}function p(w){return Math.atan2(-w.y,Math.sqrt(w.x*w.x+w.z*w.z))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new Jc(e.vertices,e.indices,e.radius,e.details)}}class Dm{static triangulate(e,t,n=2){const i=t&&t.length,s=i?t[0]*n:e.length;let o=nf(e,0,s,n,!0);const a=[];if(!o||o.next===o.prev)return a;let l,c,h,u,d,f,g;if(i&&(o=Om(e,t,o,n)),e.length>80*n){l=h=e[0],c=u=e[1];for(let v=n;v<s;v+=n)d=e[v],f=e[v+1],d<l&&(l=d),f<c&&(c=f),d>h&&(h=d),f>u&&(u=f);g=Math.max(h-l,u-c),g=g!==0?32767/g:0}return qr(o,a,n,l,c,g,0),a}}function nf(r,e,t,n,i){let s,o;if(i===Ym(r,e,t,n)>0)for(s=e;s<t;s+=n)o=nu(s,r[s],r[s+1],o);else for(s=t-n;s>=e;s-=n)o=nu(s,r[s],r[s+1],o);return o&&La(o,o.next)&&(Zr(o),o=o.next),o}function ys(r,e){if(!r)return r;e||(e=r);let t=r,n;do if(n=!1,!t.steiner&&(La(t,t.next)||qt(t.prev,t,t.next)===0)){if(Zr(t),t=e=t.prev,t===t.next)break;n=!0}else t=t.next;while(n||t!==e);return e}function qr(r,e,t,n,i,s,o){if(!r)return;!o&&s&&Vm(r,n,i,s);let a=r,l,c;for(;r.prev!==r.next;){if(l=r.prev,c=r.next,s?Nm(r,n,i,s):Im(r)){e.push(l.i/t|0),e.push(r.i/t|0),e.push(c.i/t|0),Zr(r),r=c.next,a=c.next;continue}if(r=c,r===a){o?o===1?(r=Um(ys(r),e,t),qr(r,e,t,n,i,s,2)):o===2&&Fm(r,e,t,n,i,s):qr(ys(r),e,t,n,i,s,1);break}}}function Im(r){const e=r.prev,t=r,n=r.next;if(qt(e,t,n)>=0)return!1;const i=e.x,s=t.x,o=n.x,a=e.y,l=t.y,c=n.y,h=i<s?i<o?i:o:s<o?s:o,u=a<l?a<c?a:c:l<c?l:c,d=i>s?i>o?i:o:s>o?s:o,f=a>l?a>c?a:c:l>c?l:c;let g=n.next;for(;g!==e;){if(g.x>=h&&g.x<=d&&g.y>=u&&g.y<=f&&tr(i,a,s,l,o,c,g.x,g.y)&&qt(g.prev,g,g.next)>=0)return!1;g=g.next}return!0}function Nm(r,e,t,n){const i=r.prev,s=r,o=r.next;if(qt(i,s,o)>=0)return!1;const a=i.x,l=s.x,c=o.x,h=i.y,u=s.y,d=o.y,f=a<l?a<c?a:c:l<c?l:c,g=h<u?h<d?h:d:u<d?u:d,v=a>l?a>c?a:c:l>c?l:c,m=h>u?h>d?h:d:u>d?u:d,p=Pc(f,g,e,t,n),w=Pc(v,m,e,t,n);let y=r.prevZ,b=r.nextZ;for(;y&&y.z>=p&&b&&b.z<=w;){if(y.x>=f&&y.x<=v&&y.y>=g&&y.y<=m&&y!==i&&y!==o&&tr(a,h,l,u,c,d,y.x,y.y)&&qt(y.prev,y,y.next)>=0||(y=y.prevZ,b.x>=f&&b.x<=v&&b.y>=g&&b.y<=m&&b!==i&&b!==o&&tr(a,h,l,u,c,d,b.x,b.y)&&qt(b.prev,b,b.next)>=0))return!1;b=b.nextZ}for(;y&&y.z>=p;){if(y.x>=f&&y.x<=v&&y.y>=g&&y.y<=m&&y!==i&&y!==o&&tr(a,h,l,u,c,d,y.x,y.y)&&qt(y.prev,y,y.next)>=0)return!1;y=y.prevZ}for(;b&&b.z<=w;){if(b.x>=f&&b.x<=v&&b.y>=g&&b.y<=m&&b!==i&&b!==o&&tr(a,h,l,u,c,d,b.x,b.y)&&qt(b.prev,b,b.next)>=0)return!1;b=b.nextZ}return!0}function Um(r,e,t){let n=r;do{const i=n.prev,s=n.next.next;!La(i,s)&&sf(i,n,n.next,s)&&Yr(i,s)&&Yr(s,i)&&(e.push(i.i/t|0),e.push(n.i/t|0),e.push(s.i/t|0),Zr(n),Zr(n.next),n=r=s),n=n.next}while(n!==r);return ys(n)}function Fm(r,e,t,n,i,s){let o=r;do{let a=o.next.next;for(;a!==o.prev;){if(o.i!==a.i&&Xm(o,a)){let l=rf(o,a);o=ys(o,o.next),l=ys(l,l.next),qr(o,e,t,n,i,s,0),qr(l,e,t,n,i,s,0);return}a=a.next}o=o.next}while(o!==r)}function Om(r,e,t,n){const i=[];let s,o,a,l,c;for(s=0,o=e.length;s<o;s++)a=e[s]*n,l=s<o-1?e[s+1]*n:r.length,c=nf(r,a,l,n,!1),c===c.next&&(c.steiner=!0),i.push(Wm(c));for(i.sort(Bm),s=0;s<i.length;s++)t=km(i[s],t);return t}function Bm(r,e){return r.x-e.x}function km(r,e){const t=zm(r,e);if(!t)return e;const n=rf(t,r);return ys(n,n.next),ys(t,t.next)}function zm(r,e){let t=e,n=-1/0,i;const s=r.x,o=r.y;do{if(o<=t.y&&o>=t.next.y&&t.next.y!==t.y){const d=t.x+(o-t.y)*(t.next.x-t.x)/(t.next.y-t.y);if(d<=s&&d>n&&(n=d,i=t.x<t.next.x?t:t.next,d===s))return i}t=t.next}while(t!==e);if(!i)return null;const a=i,l=i.x,c=i.y;let h=1/0,u;t=i;do s>=t.x&&t.x>=l&&s!==t.x&&tr(o<c?s:n,o,l,c,o<c?n:s,o,t.x,t.y)&&(u=Math.abs(o-t.y)/(s-t.x),Yr(t,r)&&(u<h||u===h&&(t.x>i.x||t.x===i.x&&Hm(i,t)))&&(i=t,h=u)),t=t.next;while(t!==a);return i}function Hm(r,e){return qt(r.prev,r,e.prev)<0&&qt(e.next,r,r.next)<0}function Vm(r,e,t,n){let i=r;do i.z===0&&(i.z=Pc(i.x,i.y,e,t,n)),i.prevZ=i.prev,i.nextZ=i.next,i=i.next;while(i!==r);i.prevZ.nextZ=null,i.prevZ=null,Gm(i)}function Gm(r){let e,t,n,i,s,o,a,l,c=1;do{for(t=r,r=null,s=null,o=0;t;){for(o++,n=t,a=0,e=0;e<c&&(a++,n=n.nextZ,!!n);e++);for(l=c;a>0||l>0&&n;)a!==0&&(l===0||!n||t.z<=n.z)?(i=t,t=t.nextZ,a--):(i=n,n=n.nextZ,l--),s?s.nextZ=i:r=i,i.prevZ=s,s=i;t=n}s.nextZ=null,c*=2}while(o>1);return r}function Pc(r,e,t,n,i){return r=(r-t)*i|0,e=(e-n)*i|0,r=(r|r<<8)&16711935,r=(r|r<<4)&252645135,r=(r|r<<2)&858993459,r=(r|r<<1)&1431655765,e=(e|e<<8)&16711935,e=(e|e<<4)&252645135,e=(e|e<<2)&858993459,e=(e|e<<1)&1431655765,r|e<<1}function Wm(r){let e=r,t=r;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==r);return t}function tr(r,e,t,n,i,s,o,a){return(i-o)*(e-a)>=(r-o)*(s-a)&&(r-o)*(n-a)>=(t-o)*(e-a)&&(t-o)*(s-a)>=(i-o)*(n-a)}function Xm(r,e){return r.next.i!==e.i&&r.prev.i!==e.i&&!jm(r,e)&&(Yr(r,e)&&Yr(e,r)&&qm(r,e)&&(qt(r.prev,r,e.prev)||qt(r,e.prev,e))||La(r,e)&&qt(r.prev,r,r.next)>0&&qt(e.prev,e,e.next)>0)}function qt(r,e,t){return(e.y-r.y)*(t.x-e.x)-(e.x-r.x)*(t.y-e.y)}function La(r,e){return r.x===e.x&&r.y===e.y}function sf(r,e,t,n){const i=zo(qt(r,e,t)),s=zo(qt(r,e,n)),o=zo(qt(t,n,r)),a=zo(qt(t,n,e));return!!(i!==s&&o!==a||i===0&&ko(r,t,e)||s===0&&ko(r,n,e)||o===0&&ko(t,r,n)||a===0&&ko(t,e,n))}function ko(r,e,t){return e.x<=Math.max(r.x,t.x)&&e.x>=Math.min(r.x,t.x)&&e.y<=Math.max(r.y,t.y)&&e.y>=Math.min(r.y,t.y)}function zo(r){return r>0?1:r<0?-1:0}function jm(r,e){let t=r;do{if(t.i!==r.i&&t.next.i!==r.i&&t.i!==e.i&&t.next.i!==e.i&&sf(t,t.next,r,e))return!0;t=t.next}while(t!==r);return!1}function Yr(r,e){return qt(r.prev,r,r.next)<0?qt(r,e,r.next)>=0&&qt(r,r.prev,e)>=0:qt(r,e,r.prev)<0||qt(r,r.next,e)<0}function qm(r,e){let t=r,n=!1;const i=(r.x+e.x)/2,s=(r.y+e.y)/2;do t.y>s!=t.next.y>s&&t.next.y!==t.y&&i<(t.next.x-t.x)*(s-t.y)/(t.next.y-t.y)+t.x&&(n=!n),t=t.next;while(t!==r);return n}function rf(r,e){const t=new Lc(r.i,r.x,r.y),n=new Lc(e.i,e.x,e.y),i=r.next,s=e.prev;return r.next=e,e.prev=r,t.next=i,i.prev=t,n.next=t,t.prev=n,s.next=n,n.prev=s,n}function nu(r,e,t,n){const i=new Lc(r,e,t);return n?(i.next=n.next,i.prev=n,n.next.prev=i,n.next=i):(i.prev=i,i.next=i),i}function Zr(r){r.next.prev=r.prev,r.prev.next=r.next,r.prevZ&&(r.prevZ.nextZ=r.nextZ),r.nextZ&&(r.nextZ.prevZ=r.prevZ)}function Lc(r,e,t){this.i=r,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}function Ym(r,e,t,n){let i=0;for(let s=e,o=t-n;s<t;s+=n)i+=(r[o]-r[s])*(r[s+1]+r[o+1]),o=s;return i}class Qc{static area(e){const t=e.length;let n=0;for(let i=t-1,s=0;s<t;i=s++)n+=e[i].x*e[s].y-e[s].x*e[i].y;return n*.5}static isClockWise(e){return Qc.area(e)<0}static triangulateShape(e,t){const n=[],i=[],s=[];iu(e),su(n,e);let o=e.length;t.forEach(iu);for(let l=0;l<t.length;l++)i.push(o),o+=t[l].length,su(n,t[l]);const a=Dm.triangulate(n,i);for(let l=0;l<a.length;l+=3)s.push(a.slice(l,l+3));return s}}function iu(r){const e=r.length;e>2&&r[e-1].equals(r[0])&&r.pop()}function su(r,e){for(let t=0;t<e.length;t++)r.push(e[t].x),r.push(e[t].y)}class nr extends Jc{constructor(e=1,t=0){const n=[1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],i=[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2];super(n,i,e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new nr(e.radius,e.detail)}}class xr extends yt{constructor(e=1,t=1,n=1,i=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:n,heightSegments:i};const s=e/2,o=t/2,a=Math.floor(n),l=Math.floor(i),c=a+1,h=l+1,u=e/a,d=t/l,f=[],g=[],v=[],m=[];for(let p=0;p<h;p++){const w=p*d-o;for(let y=0;y<c;y++){const b=y*u-s;g.push(b,-w,0),v.push(0,0,1),m.push(y/a),m.push(1-p/l)}}for(let p=0;p<l;p++)for(let w=0;w<a;w++){const y=w+c*p,b=w+c*(p+1),D=w+1+c*(p+1),R=w+1+c*p;f.push(y,b,R),f.push(b,D,R)}this.setIndex(f),this.setAttribute("position",new Ne(g,3)),this.setAttribute("normal",new Ne(v,3)),this.setAttribute("uv",new Ne(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new xr(e.width,e.height,e.widthSegments,e.heightSegments)}}class to extends yt{constructor(e=1,t=32,n=16,i=0,s=Math.PI*2,o=0,a=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:n,phiStart:i,phiLength:s,thetaStart:o,thetaLength:a},t=Math.max(3,Math.floor(t)),n=Math.max(2,Math.floor(n));const l=Math.min(o+a,Math.PI);let c=0;const h=[],u=new L,d=new L,f=[],g=[],v=[],m=[];for(let p=0;p<=n;p++){const w=[],y=p/n;let b=0;p===0&&o===0?b=.5/t:p===n&&l===Math.PI&&(b=-.5/t);for(let D=0;D<=t;D++){const R=D/t;u.x=-e*Math.cos(i+R*s)*Math.sin(o+y*a),u.y=e*Math.cos(o+y*a),u.z=e*Math.sin(i+R*s)*Math.sin(o+y*a),g.push(u.x,u.y,u.z),d.copy(u).normalize(),v.push(d.x,d.y,d.z),m.push(R+b,1-y),w.push(c++)}h.push(w)}for(let p=0;p<n;p++)for(let w=0;w<t;w++){const y=h[p][w+1],b=h[p][w],D=h[p+1][w],R=h[p+1][w+1];(p!==0||o>0)&&f.push(y,b,R),(p!==n-1||l<Math.PI)&&f.push(b,D,R)}this.setIndex(f),this.setAttribute("position",new Ne(g,3)),this.setAttribute("normal",new Ne(v,3)),this.setAttribute("uv",new Ne(m,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new to(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}}class ds extends yt{constructor(e=1,t=.4,n=12,i=48,s=Math.PI*2){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:n,tubularSegments:i,arc:s},n=Math.floor(n),i=Math.floor(i);const o=[],a=[],l=[],c=[],h=new L,u=new L,d=new L;for(let f=0;f<=n;f++)for(let g=0;g<=i;g++){const v=g/i*s,m=f/n*Math.PI*2;u.x=(e+t*Math.cos(m))*Math.cos(v),u.y=(e+t*Math.cos(m))*Math.sin(v),u.z=t*Math.sin(m),a.push(u.x,u.y,u.z),h.x=e*Math.cos(v),h.y=e*Math.sin(v),d.subVectors(u,h).normalize(),l.push(d.x,d.y,d.z),c.push(g/i),c.push(f/n)}for(let f=1;f<=n;f++)for(let g=1;g<=i;g++){const v=(i+1)*f+g-1,m=(i+1)*(f-1)+g-1,p=(i+1)*(f-1)+g,w=(i+1)*f+g;o.push(v,m,w),o.push(m,p,w)}this.setIndex(o),this.setAttribute("position",new Ne(a,3)),this.setAttribute("normal",new Ne(l,3)),this.setAttribute("uv",new Ne(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new ds(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}}class Zm extends yt{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){const t=[],n=new Set,i=new L,s=new L;if(e.index!==null){const o=e.attributes.position,a=e.index;let l=e.groups;l.length===0&&(l=[{start:0,count:a.count,materialIndex:0}]);for(let c=0,h=l.length;c<h;++c){const u=l[c],d=u.start,f=u.count;for(let g=d,v=d+f;g<v;g+=3)for(let m=0;m<3;m++){const p=a.getX(g+m),w=a.getX(g+(m+1)%3);i.fromBufferAttribute(o,p),s.fromBufferAttribute(o,w),ru(i,s,n)===!0&&(t.push(i.x,i.y,i.z),t.push(s.x,s.y,s.z))}}}else{const o=e.attributes.position;for(let a=0,l=o.count/3;a<l;a++)for(let c=0;c<3;c++){const h=3*a+c,u=3*a+(c+1)%3;i.fromBufferAttribute(o,h),s.fromBufferAttribute(o,u),ru(i,s,n)===!0&&(t.push(i.x,i.y,i.z),t.push(s.x,s.y,s.z))}}this.setAttribute("position",new Ne(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}}function ru(r,e,t){const n=`${r.x},${r.y},${r.z}-${e.x},${e.y},${e.z}`,i=`${e.x},${e.y},${e.z}-${r.x},${r.y},${r.z}`;return t.has(n)===!0||t.has(i)===!0?!1:(t.add(n),t.add(i),!0)}class kn extends ai{constructor(e){super(),this.isMeshPhongMaterial=!0,this.type="MeshPhongMaterial",this.color=new ke(16777215),this.specular=new ke(1118481),this.shininess=30,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ke(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Xc,this.normalScale=new ye(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Bt,this.combine=Aa,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.specular.copy(e.specular),this.shininess=e.shininess,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Kr extends ai{constructor(e){super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new ke(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ke(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=Xc,this.normalScale=new ye(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Bt,this.combine=Aa,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}}class Km extends ai{constructor(e){super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=Ap,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}}class $m extends ai{constructor(e){super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}}function Ho(r,e,t){return!r||!t&&r.constructor===e?r:typeof e.BYTES_PER_ELEMENT=="number"?new e(r):Array.prototype.slice.call(r)}function Jm(r){return ArrayBuffer.isView(r)&&!(r instanceof DataView)}function Qm(r){function e(i,s){return r[i]-r[s]}const t=r.length,n=new Array(t);for(let i=0;i!==t;++i)n[i]=i;return n.sort(e),n}function ou(r,e,t){const n=r.length,i=new r.constructor(n);for(let s=0,o=0;o!==n;++s){const a=t[s]*e;for(let l=0;l!==e;++l)i[o++]=r[a+l]}return i}function of(r,e,t,n){let i=1,s=r[0];for(;s!==void 0&&s[n]===void 0;)s=r[i++];if(s===void 0)return;let o=s[n];if(o!==void 0)if(Array.isArray(o))do o=s[n],o!==void 0&&(e.push(s.time),t.push(...o)),s=r[i++];while(s!==void 0);else if(o.toArray!==void 0)do o=s[n],o!==void 0&&(e.push(s.time),o.toArray(t,t.length)),s=r[i++];while(s!==void 0);else do o=s[n],o!==void 0&&(e.push(s.time),t.push(o)),s=r[i++];while(s!==void 0)}class Da{constructor(e,t,n,i){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=i!==void 0?i:new t.constructor(n),this.sampleValues=t,this.valueSize=n,this.settings=null,this.DefaultSettings_={}}evaluate(e){const t=this.parameterPositions;let n=this._cachedIndex,i=t[n],s=t[n-1];n:{e:{let o;t:{i:if(!(e<i)){for(let a=n+2;;){if(i===void 0){if(e<s)break i;return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}if(n===a)break;if(s=i,i=t[++n],e<i)break e}o=t.length;break t}if(!(e>=s)){const a=t[1];e<a&&(n=2,s=a);for(let l=n-2;;){if(s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===l)break;if(i=s,s=t[--n-1],e>=s)break e}o=n,n=0;break t}break n}for(;n<o;){const a=n+o>>>1;e<t[a]?o=a:n=a+1}if(i=t[n],s=t[n-1],s===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===void 0)return n=t.length,this._cachedIndex=n,this.copySampleValue_(n-1)}this._cachedIndex=n,this.intervalChanged_(n,s,i)}return this.interpolate_(n,s,e,i)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){const t=this.resultBuffer,n=this.sampleValues,i=this.valueSize,s=e*i;for(let o=0;o!==i;++o)t[o]=n[s+o];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}}class eg extends Da{constructor(e,t,n,i){super(e,t,n,i),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:xh,endingEnd:xh}}intervalChanged_(e,t,n){const i=this.parameterPositions;let s=e-2,o=e+1,a=i[s],l=i[o];if(a===void 0)switch(this.getSettings_().endingStart){case yh:s=e,a=2*t-n;break;case bh:s=i.length-2,a=t+i[s]-i[s+1];break;default:s=e,a=n}if(l===void 0)switch(this.getSettings_().endingEnd){case yh:o=e,l=2*n-t;break;case bh:o=1,l=n+i[1]-i[0];break;default:o=e-1,l=t}const c=(n-t)*.5,h=this.valueSize;this._weightPrev=c/(t-a),this._weightNext=c/(l-n),this._offsetPrev=s*h,this._offsetNext=o*h}interpolate_(e,t,n,i){const s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=this._offsetPrev,u=this._offsetNext,d=this._weightPrev,f=this._weightNext,g=(n-t)/(i-t),v=g*g,m=v*g,p=-d*m+2*d*v-d*g,w=(1+d)*m+(-1.5-2*d)*v+(-.5+d)*g+1,y=(-1-f)*m+(1.5+f)*v+.5*g,b=f*m-f*v;for(let D=0;D!==a;++D)s[D]=p*o[h+D]+w*o[c+D]+y*o[l+D]+b*o[u+D];return s}}class tg extends Da{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){const s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=e*a,c=l-a,h=(n-t)/(i-t),u=1-h;for(let d=0;d!==a;++d)s[d]=o[c+d]*u+o[l+d]*h;return s}}class ng extends Da{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e){return this.copySampleValue_(e-1)}}class xi{constructor(e,t,n,i){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=Ho(t,this.TimeBufferType),this.values=Ho(n,this.ValueBufferType),this.setInterpolation(i||this.DefaultInterpolation)}static toJSON(e){const t=e.constructor;let n;if(t.toJSON!==this.toJSON)n=t.toJSON(e);else{n={name:e.name,times:Ho(e.times,Array),values:Ho(e.values,Array)};const i=e.getInterpolation();i!==e.DefaultInterpolation&&(n.interpolation=i)}return n.type=e.ValueTypeName,n}InterpolantFactoryMethodDiscrete(e){return new ng(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new tg(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new eg(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case va:t=this.InterpolantFactoryMethodDiscrete;break;case Tc:t=this.InterpolantFactoryMethodLinear;break;case qa:t=this.InterpolantFactoryMethodSmooth;break}if(t===void 0){const n="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0)if(e!==this.DefaultInterpolation)this.setInterpolation(this.DefaultInterpolation);else throw new Error(n);return console.warn("THREE.KeyframeTrack:",n),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return va;case this.InterpolantFactoryMethodLinear:return Tc;case this.InterpolantFactoryMethodSmooth:return qa}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){const t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]+=e}return this}scale(e){if(e!==1){const t=this.times;for(let n=0,i=t.length;n!==i;++n)t[n]*=e}return this}trim(e,t){const n=this.times,i=n.length;let s=0,o=i-1;for(;s!==i&&n[s]<e;)++s;for(;o!==-1&&n[o]>t;)--o;if(++o,s!==0||o!==i){s>=o&&(o=Math.max(o,1),s=o-1);const a=this.getValueSize();this.times=n.slice(s,o),this.values=this.values.slice(s*a,o*a)}return this}validate(){let e=!0;const t=this.getValueSize();t-Math.floor(t)!==0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);const n=this.times,i=this.values,s=n.length;s===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let o=null;for(let a=0;a!==s;a++){const l=n[a];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,a,l),e=!1;break}if(o!==null&&o>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,a,l,o),e=!1;break}o=l}if(i!==void 0&&Jm(i))for(let a=0,l=i.length;a!==l;++a){const c=i[a];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,a,c),e=!1;break}}return e}optimize(){const e=this.times.slice(),t=this.values.slice(),n=this.getValueSize(),i=this.getInterpolation()===qa,s=e.length-1;let o=1;for(let a=1;a<s;++a){let l=!1;const c=e[a],h=e[a+1];if(c!==h&&(a!==1||c!==e[0]))if(i)l=!0;else{const u=a*n,d=u-n,f=u+n;for(let g=0;g!==n;++g){const v=t[u+g];if(v!==t[d+g]||v!==t[f+g]){l=!0;break}}}if(l){if(a!==o){e[o]=e[a];const u=a*n,d=o*n;for(let f=0;f!==n;++f)t[d+f]=t[u+f]}++o}}if(s>0){e[o]=e[s];for(let a=s*n,l=o*n,c=0;c!==n;++c)t[l+c]=t[a+c];++o}return o!==e.length?(this.times=e.slice(0,o),this.values=t.slice(0,o*n)):(this.times=e,this.values=t),this}clone(){const e=this.times.slice(),t=this.values.slice(),n=this.constructor,i=new n(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}}xi.prototype.TimeBufferType=Float32Array;xi.prototype.ValueBufferType=Float32Array;xi.prototype.DefaultInterpolation=Tc;class yr extends xi{constructor(e,t,n){super(e,t,n)}}yr.prototype.ValueTypeName="bool";yr.prototype.ValueBufferType=Array;yr.prototype.DefaultInterpolation=va;yr.prototype.InterpolantFactoryMethodLinear=void 0;yr.prototype.InterpolantFactoryMethodSmooth=void 0;class af extends xi{}af.prototype.ValueTypeName="color";class $r extends xi{}$r.prototype.ValueTypeName="number";class ig extends Da{constructor(e,t,n,i){super(e,t,n,i)}interpolate_(e,t,n,i){const s=this.resultBuffer,o=this.sampleValues,a=this.valueSize,l=(n-t)/(i-t);let c=e*a;for(let h=c+a;c!==h;c+=4)St.slerpFlat(s,0,o,c-a,o,c,l);return s}}class bs extends xi{InterpolantFactoryMethodLinear(e){return new ig(this.times,this.values,this.getValueSize(),e)}}bs.prototype.ValueTypeName="quaternion";bs.prototype.InterpolantFactoryMethodSmooth=void 0;class br extends xi{constructor(e,t,n){super(e,t,n)}}br.prototype.ValueTypeName="string";br.prototype.ValueBufferType=Array;br.prototype.DefaultInterpolation=va;br.prototype.InterpolantFactoryMethodLinear=void 0;br.prototype.InterpolantFactoryMethodSmooth=void 0;class Ms extends xi{}Ms.prototype.ValueTypeName="vector";class Dc{constructor(e="",t=-1,n=[],i=Tp){this.name=e,this.tracks=n,this.duration=t,this.blendMode=i,this.uuid=ri(),this.duration<0&&this.resetDuration()}static parse(e){const t=[],n=e.tracks,i=1/(e.fps||1);for(let o=0,a=n.length;o!==a;++o)t.push(rg(n[o]).scale(i));const s=new this(e.name,e.duration,t,e.blendMode);return s.uuid=e.uuid,s}static toJSON(e){const t=[],n=e.tracks,i={name:e.name,duration:e.duration,tracks:t,uuid:e.uuid,blendMode:e.blendMode};for(let s=0,o=n.length;s!==o;++s)t.push(xi.toJSON(n[s]));return i}static CreateFromMorphTargetSequence(e,t,n,i){const s=t.length,o=[];for(let a=0;a<s;a++){let l=[],c=[];l.push((a+s-1)%s,a,(a+1)%s),c.push(0,1,0);const h=Qm(l);l=ou(l,1,h),c=ou(c,1,h),!i&&l[0]===0&&(l.push(s),c.push(c[0])),o.push(new $r(".morphTargetInfluences["+t[a].name+"]",l,c).scale(1/n))}return new this(e,-1,o)}static findByName(e,t){let n=e;if(!Array.isArray(e)){const i=e;n=i.geometry&&i.geometry.animations||i.animations}for(let i=0;i<n.length;i++)if(n[i].name===t)return n[i];return null}static CreateClipsFromMorphTargetSequences(e,t,n){const i={},s=/^([\w-]*?)([\d]+)$/;for(let a=0,l=e.length;a<l;a++){const c=e[a],h=c.name.match(s);if(h&&h.length>1){const u=h[1];let d=i[u];d||(i[u]=d=[]),d.push(c)}}const o=[];for(const a in i)o.push(this.CreateFromMorphTargetSequence(a,i[a],t,n));return o}static parseAnimation(e,t){if(!e)return console.error("THREE.AnimationClip: No animation in JSONLoader data."),null;const n=function(u,d,f,g,v){if(f.length!==0){const m=[],p=[];of(f,m,p,g),m.length!==0&&v.push(new u(d,m,p))}},i=[],s=e.name||"default",o=e.fps||30,a=e.blendMode;let l=e.length||-1;const c=e.hierarchy||[];for(let u=0;u<c.length;u++){const d=c[u].keys;if(!(!d||d.length===0))if(d[0].morphTargets){const f={};let g;for(g=0;g<d.length;g++)if(d[g].morphTargets)for(let v=0;v<d[g].morphTargets.length;v++)f[d[g].morphTargets[v]]=-1;for(const v in f){const m=[],p=[];for(let w=0;w!==d[g].morphTargets.length;++w){const y=d[g];m.push(y.time),p.push(y.morphTarget===v?1:0)}i.push(new $r(".morphTargetInfluence["+v+"]",m,p))}l=f.length*o}else{const f=".bones["+t[u].name+"]";n(Ms,f+".position",d,"pos",i),n(bs,f+".quaternion",d,"rot",i),n(Ms,f+".scale",d,"scl",i)}}return i.length===0?null:new this(s,l,i,a)}resetDuration(){const e=this.tracks;let t=0;for(let n=0,i=e.length;n!==i;++n){const s=this.tracks[n];t=Math.max(t,s.times[s.times.length-1])}return this.duration=t,this}trim(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].trim(0,this.duration);return this}validate(){let e=!0;for(let t=0;t<this.tracks.length;t++)e=e&&this.tracks[t].validate();return e}optimize(){for(let e=0;e<this.tracks.length;e++)this.tracks[e].optimize();return this}clone(){const e=[];for(let t=0;t<this.tracks.length;t++)e.push(this.tracks[t].clone());return new this.constructor(this.name,this.duration,e,this.blendMode)}toJSON(){return this.constructor.toJSON(this)}}function sg(r){switch(r.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":return $r;case"vector":case"vector2":case"vector3":case"vector4":return Ms;case"color":return af;case"quaternion":return bs;case"bool":case"boolean":return yr;case"string":return br}throw new Error("THREE.KeyframeTrack: Unsupported typeName: "+r)}function rg(r){if(r.type===void 0)throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");const e=sg(r.type);if(r.times===void 0){const t=[],n=[];of(r.keys,t,n,"value"),r.times=t,r.values=n}return e.parse!==void 0?e.parse(r):new e(r.name,r.times,r.values,r.interpolation)}const Sa={enabled:!1,files:{},add:function(r,e){this.enabled!==!1&&(this.files[r]=e)},get:function(r){if(this.enabled!==!1)return this.files[r]},remove:function(r){delete this.files[r]},clear:function(){this.files={}}};class lf{constructor(e,t,n){const i=this;let s=!1,o=0,a=0,l;const c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=n,this.itemStart=function(h){a++,s===!1&&i.onStart!==void 0&&i.onStart(h,o,a),s=!0},this.itemEnd=function(h){o++,i.onProgress!==void 0&&i.onProgress(h,o,a),o===a&&(s=!1,i.onLoad!==void 0&&i.onLoad())},this.itemError=function(h){i.onError!==void 0&&i.onError(h)},this.resolveURL=function(h){return l?l(h):h},this.setURLModifier=function(h){return l=h,this},this.addHandler=function(h,u){return c.push(h,u),this},this.removeHandler=function(h){const u=c.indexOf(h);return u!==-1&&c.splice(u,2),this},this.getHandler=function(h){for(let u=0,d=c.length;u<d;u+=2){const f=c[u],g=c[u+1];if(f.global&&(f.lastIndex=0),f.test(h))return g}return null}}}const cf=new lf;class Zn{constructor(e){this.manager=e!==void 0?e:cf,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){const n=this;return new Promise(function(i,s){n.load(e,i,t,s)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}}Zn.DEFAULT_MATERIAL_NAME="__DEFAULT";const Ri={};class og extends Error{constructor(e,t){super(e),this.response=t}}class no extends Zn{constructor(e){super(e)}load(e,t,n,i){e===void 0&&(e=""),this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=Sa.get(e);if(s!==void 0)return this.manager.itemStart(e),setTimeout(()=>{t&&t(s),this.manager.itemEnd(e)},0),s;if(Ri[e]!==void 0){Ri[e].push({onLoad:t,onProgress:n,onError:i});return}Ri[e]=[],Ri[e].push({onLoad:t,onProgress:n,onError:i});const o=new Request(e,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin"}),a=this.mimeType,l=this.responseType;fetch(o).then(c=>{if(c.status===200||c.status===0){if(c.status===0&&console.warn("THREE.FileLoader: HTTP Status 0 received."),typeof ReadableStream>"u"||c.body===void 0||c.body.getReader===void 0)return c;const h=Ri[e],u=c.body.getReader(),d=c.headers.get("X-File-Size")||c.headers.get("Content-Length"),f=d?parseInt(d):0,g=f!==0;let v=0;const m=new ReadableStream({start(p){w();function w(){u.read().then(({done:y,value:b})=>{if(y)p.close();else{v+=b.byteLength;const D=new ProgressEvent("progress",{lengthComputable:g,loaded:v,total:f});for(let R=0,P=h.length;R<P;R++){const M=h[R];M.onProgress&&M.onProgress(D)}p.enqueue(b),w()}},y=>{p.error(y)})}}});return new Response(m)}else throw new og(`fetch for "${c.url}" responded with ${c.status}: ${c.statusText}`,c)}).then(c=>{switch(l){case"arraybuffer":return c.arrayBuffer();case"blob":return c.blob();case"document":return c.text().then(h=>new DOMParser().parseFromString(h,a));case"json":return c.json();default:if(a===void 0)return c.text();{const u=/charset="?([^;"\s]*)"?/i.exec(a),d=u&&u[1]?u[1].toLowerCase():void 0,f=new TextDecoder(d);return c.arrayBuffer().then(g=>f.decode(g))}}}).then(c=>{Sa.add(e,c);const h=Ri[e];delete Ri[e];for(let u=0,d=h.length;u<d;u++){const f=h[u];f.onLoad&&f.onLoad(c)}}).catch(c=>{const h=Ri[e];if(h===void 0)throw this.manager.itemError(e),c;delete Ri[e];for(let u=0,d=h.length;u<d;u++){const f=h[u];f.onError&&f.onError(c)}this.manager.itemError(e)}).finally(()=>{this.manager.itemEnd(e)}),this.manager.itemStart(e)}setResponseType(e){return this.responseType=e,this}setMimeType(e){return this.mimeType=e,this}}class ag extends Zn{constructor(e){super(e)}load(e,t,n,i){this.path!==void 0&&(e=this.path+e),e=this.manager.resolveURL(e);const s=this,o=Sa.get(e);if(o!==void 0)return s.manager.itemStart(e),setTimeout(function(){t&&t(o),s.manager.itemEnd(e)},0),o;const a=jr("img");function l(){h(),Sa.add(e,this),t&&t(this),s.manager.itemEnd(e)}function c(u){h(),i&&i(u),s.manager.itemError(e),s.manager.itemEnd(e)}function h(){a.removeEventListener("load",l,!1),a.removeEventListener("error",c,!1)}return a.addEventListener("load",l,!1),a.addEventListener("error",c,!1),e.slice(0,5)!=="data:"&&this.crossOrigin!==void 0&&(a.crossOrigin=this.crossOrigin),s.manager.itemStart(e),a.src=e,a}}class lg extends Zn{constructor(e){super(e)}load(e,t,n,i){const s=this,o=new ef,a=new no(this.manager);return a.setResponseType("arraybuffer"),a.setRequestHeader(this.requestHeader),a.setPath(this.path),a.setWithCredentials(s.withCredentials),a.load(e,function(l){let c;try{c=s.parse(l)}catch(h){if(i!==void 0)i(h);else{console.error(h);return}}c.image!==void 0?o.image=c.image:c.data!==void 0&&(o.image.width=c.width,o.image.height=c.height,o.image.data=c.data),o.wrapS=c.wrapS!==void 0?c.wrapS:Bn,o.wrapT=c.wrapT!==void 0?c.wrapT:Bn,o.magFilter=c.magFilter!==void 0?c.magFilter:mn,o.minFilter=c.minFilter!==void 0?c.minFilter:mn,o.anisotropy=c.anisotropy!==void 0?c.anisotropy:1,c.colorSpace!==void 0&&(o.colorSpace=c.colorSpace),c.flipY!==void 0&&(o.flipY=c.flipY),c.format!==void 0&&(o.format=c.format),c.type!==void 0&&(o.type=c.type),c.mipmaps!==void 0&&(o.mipmaps=c.mipmaps,o.minFilter=Di),c.mipmapCount===1&&(o.minFilter=mn),c.generateMipmaps!==void 0&&(o.generateMipmaps=c.generateMipmaps),o.needsUpdate=!0,t&&t(o,c)},n,i),o}}class Ia extends Zn{constructor(e){super(e)}load(e,t,n,i){const s=new Wt,o=new ag(this.manager);return o.setCrossOrigin(this.crossOrigin),o.setPath(this.path),o.load(e,function(a){s.image=a,s.needsUpdate=!0,t!==void 0&&t(s)},n,i),s}}class io extends Mt{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new ke(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){const t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}}class cg extends io{constructor(e,t,n){super(e,n),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.groundColor=new ke(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}}const xl=new Ee,au=new L,lu=new L;class eh{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new ye(512,512),this.map=null,this.mapPass=null,this.matrix=new Ee,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Pa,this._frameExtents=new ye(1,1),this._viewportCount=1,this._viewports=[new at(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){const t=this.camera,n=this.matrix;au.setFromMatrixPosition(e.matrixWorld),t.position.copy(au),lu.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(lu),t.updateMatrixWorld(),xl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(xl),n.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),n.multiply(xl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){const e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),(this.mapSize.x!==512||this.mapSize.y!==512)&&(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}}class hg extends eh{constructor(){super(new Qt(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1}updateMatrices(e){const t=this.camera,n=gr*2*e.angle*this.focus,i=this.mapSize.width/this.mapSize.height,s=e.distance||t.far;(n!==t.fov||i!==t.aspect||s!==t.far)&&(t.fov=n,t.aspect=i,t.far=s,t.updateProjectionMatrix()),super.updateMatrices(e)}copy(e){return super.copy(e),this.focus=e.focus,this}}class hf extends io{constructor(e,t,n=0,i=Math.PI/3,s=0,o=2){super(e,t),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.distance=n,this.angle=i,this.penumbra=s,this.decay=o,this.map=null,this.shadow=new hg}get power(){return this.intensity*Math.PI}set power(e){this.intensity=e/Math.PI}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.angle=e.angle,this.penumbra=e.penumbra,this.decay=e.decay,this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}const cu=new Ee,Nr=new L,yl=new L;class ug extends eh{constructor(){super(new Qt(90,1,.5,500)),this.isPointLightShadow=!0,this._frameExtents=new ye(4,2),this._viewportCount=6,this._viewports=[new at(2,1,1,1),new at(0,1,1,1),new at(3,1,1,1),new at(1,1,1,1),new at(3,0,1,1),new at(1,0,1,1)],this._cubeDirections=[new L(1,0,0),new L(-1,0,0),new L(0,0,1),new L(0,0,-1),new L(0,1,0),new L(0,-1,0)],this._cubeUps=[new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,1,0),new L(0,0,1),new L(0,0,-1)]}updateMatrices(e,t=0){const n=this.camera,i=this.matrix,s=e.distance||n.far;s!==n.far&&(n.far=s,n.updateProjectionMatrix()),Nr.setFromMatrixPosition(e.matrixWorld),n.position.copy(Nr),yl.copy(n.position),yl.add(this._cubeDirections[t]),n.up.copy(this._cubeUps[t]),n.lookAt(yl),n.updateMatrixWorld(),i.makeTranslation(-Nr.x,-Nr.y,-Nr.z),cu.multiplyMatrices(n.projectionMatrix,n.matrixWorldInverse),this._frustum.setFromProjectionMatrix(cu)}}class Ic extends io{constructor(e,t,n=0,i=2){super(e,t),this.isPointLight=!0,this.type="PointLight",this.distance=n,this.decay=i,this.shadow=new ug}get power(){return this.intensity*4*Math.PI}set power(e){this.intensity=e/(4*Math.PI)}dispose(){this.shadow.dispose()}copy(e,t){return super.copy(e,t),this.distance=e.distance,this.decay=e.decay,this.shadow=e.shadow.clone(),this}}class Na extends Yd{constructor(e=-1,t=1,n=1,i=-1,s=.1,o=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=n,this.bottom=i,this.near=s,this.far=o,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,n,i,s,o){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=n,this.view.offsetY=i,this.view.width=s,this.view.height=o,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){const e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),n=(this.right+this.left)/2,i=(this.top+this.bottom)/2;let s=n-e,o=n+e,a=i+t,l=i-t;if(this.view!==null&&this.view.enabled){const c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;s+=c*this.view.offsetX,o=s+c*this.view.width,a-=h*this.view.offsetY,l=a-h*this.view.height}this.projectionMatrix.makeOrthographic(s,o,a,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){const t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}}class dg extends eh{constructor(){super(new Na(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}}class Ea extends io{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(Mt.DEFAULT_UP),this.updateMatrix(),this.target=new Mt,this.shadow=new dg}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}}class th extends io{constructor(e,t){super(e,t),this.isAmbientLight=!0,this.type="AmbientLight"}}class nh{static decodeText(e){if(console.warn("THREE.LoaderUtils: decodeText() has been deprecated with r165 and will be removed with r175. Use TextDecoder instead."),typeof TextDecoder<"u")return new TextDecoder().decode(e);let t="";for(let n=0,i=e.length;n<i;n++)t+=String.fromCharCode(e[n]);try{return decodeURIComponent(escape(t))}catch{return t}}static extractUrlBase(e){const t=e.lastIndexOf("/");return t===-1?"./":e.slice(0,t+1)}static resolveURL(e,t){return typeof e!="string"||e===""?"":(/^https?:\/\//i.test(t)&&/^\//.test(e)&&(t=t.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(e)||/^data:.*,.*$/i.test(e)||/^blob:.*$/i.test(e)?e:t+e)}}class fg extends yt{constructor(){super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0}copy(e){return super.copy(e),this.instanceCount=e.instanceCount,this}toJSON(){const e=super.toJSON();return e.instanceCount=this.instanceCount,e.isInstancedBufferGeometry=!0,e}}class pg extends Qt{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e,this.index=0}}class mg{constructor(e=!0){this.autoStart=e,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1}start(){this.startTime=hu(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0}stop(){this.getElapsedTime(),this.running=!1,this.autoStart=!1}getElapsedTime(){return this.getDelta(),this.elapsedTime}getDelta(){let e=0;if(this.autoStart&&!this.running)return this.start(),0;if(this.running){const t=hu();e=(t-this.oldTime)/1e3,this.oldTime=t,this.elapsedTime+=e}return e}}function hu(){return performance.now()}const ih="\\[\\]\\.:\\/",gg=new RegExp("["+ih+"]","g"),sh="[^"+ih+"]",_g="[^"+ih.replace("\\.","")+"]",vg=/((?:WC+[\/:])*)/.source.replace("WC",sh),xg=/(WCOD+)?/.source.replace("WCOD",_g),yg=/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",sh),bg=/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",sh),Mg=new RegExp("^"+vg+xg+yg+bg+"$"),wg=["material","materials","bones","map"];class Sg{constructor(e,t,n){const i=n||Ct.parseTrackName(t);this._targetGroup=e,this._bindings=e.subscribe_(t,i)}getValue(e,t){this.bind();const n=this._targetGroup.nCachedObjects_,i=this._bindings[n];i!==void 0&&i.getValue(e,t)}setValue(e,t){const n=this._bindings;for(let i=this._targetGroup.nCachedObjects_,s=n.length;i!==s;++i)n[i].setValue(e,t)}bind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].bind()}unbind(){const e=this._bindings;for(let t=this._targetGroup.nCachedObjects_,n=e.length;t!==n;++t)e[t].unbind()}}class Ct{constructor(e,t,n){this.path=t,this.parsedPath=n||Ct.parseTrackName(t),this.node=Ct.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,n){return e&&e.isAnimationObjectGroup?new Ct.Composite(e,t,n):new Ct(e,t,n)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(gg,"")}static parseTrackName(e){const t=Mg.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);const n={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},i=n.nodeName&&n.nodeName.lastIndexOf(".");if(i!==void 0&&i!==-1){const s=n.nodeName.substring(i+1);wg.indexOf(s)!==-1&&(n.nodeName=n.nodeName.substring(0,i),n.objectName=s)}if(n.propertyName===null||n.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return n}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){const n=e.skeleton.getBoneByName(t);if(n!==void 0)return n}if(e.children){const n=function(s){for(let o=0;o<s.length;o++){const a=s[o];if(a.name===t||a.uuid===t)return a;const l=n(a.children);if(l)return l}return null},i=n(e.children);if(i)return i}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)e[t++]=n[i]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++]}_setValue_array_setNeedsUpdate(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){const n=this.resolvedProperty;for(let i=0,s=n.length;i!==s;++i)n[i]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node;const t=this.parsedPath,n=t.objectName,i=t.propertyName;let s=t.propertyIndex;if(e||(e=Ct.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e){console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");return}if(n){let c=t.objectIndex;switch(n){case"materials":if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.materials){console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);return}e=e.material.materials;break;case"bones":if(!e.skeleton){console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);return}e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material){console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);return}if(!e.material.map){console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);return}e=e.material.map;break;default:if(e[n]===void 0){console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);return}e=e[n]}if(c!==void 0){if(e[c]===void 0){console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);return}e=e[c]}}const o=e[i];if(o===void 0){const c=t.nodeName;console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+i+" but it wasn't found.",e);return}let a=this.Versioning.None;this.targetObject=e,e.isMaterial===!0?a=this.Versioning.NeedsUpdate:e.isObject3D===!0&&(a=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(s!==void 0){if(i==="morphTargetInfluences"){if(!e.geometry){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);return}if(!e.geometry.morphAttributes){console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);return}e.morphTargetDictionary[s]!==void 0&&(s=e.morphTargetDictionary[s])}l=this.BindingType.ArrayElement,this.resolvedProperty=o,this.propertyIndex=s}else o.fromArray!==void 0&&o.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=o):Array.isArray(o)?(l=this.BindingType.EntireArray,this.resolvedProperty=o):this.propertyName=i;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][a]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}}Ct.Composite=Sg;Ct.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3};Ct.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2};Ct.prototype.GetterByBindingType=[Ct.prototype._getValue_direct,Ct.prototype._getValue_array,Ct.prototype._getValue_arrayElement,Ct.prototype._getValue_toArray];Ct.prototype.SetterByBindingTypeAndVersioning=[[Ct.prototype._setValue_direct,Ct.prototype._setValue_direct_setNeedsUpdate,Ct.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[Ct.prototype._setValue_array,Ct.prototype._setValue_array_setNeedsUpdate,Ct.prototype._setValue_array_setMatrixWorldNeedsUpdate],[Ct.prototype._setValue_arrayElement,Ct.prototype._setValue_arrayElement_setNeedsUpdate,Ct.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[Ct.prototype._setValue_fromArray,Ct.prototype._setValue_fromArray_setNeedsUpdate,Ct.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];class Nc extends Kd{constructor(e,t,n=1){super(e,t),this.isInstancedInterleavedBuffer=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}clone(e){const t=super.clone(e);return t.meshPerAttribute=this.meshPerAttribute,t}toJSON(e){const t=super.toJSON(e);return t.isInstancedInterleavedBuffer=!0,t.meshPerAttribute=this.meshPerAttribute,t}}const uu=new Ee;class Ua{constructor(e,t,n=0,i=1/0){this.ray=new Es(e,t),this.near=n,this.far=i,this.camera=null,this.layers=new Yc,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}}set(e,t){this.ray.set(e,t)}setFromCamera(e,t){t.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(e.x,e.y,.5).unproject(t).sub(this.ray.origin).normalize(),this.camera=t):t.isOrthographicCamera?(this.ray.origin.set(e.x,e.y,(t.near+t.far)/(t.near-t.far)).unproject(t),this.ray.direction.set(0,0,-1).transformDirection(t.matrixWorld),this.camera=t):console.error("THREE.Raycaster: Unsupported camera type: "+t.type)}setFromXRController(e){return uu.identity().extractRotation(e.matrixWorld),this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(uu),this}intersectObject(e,t=!0,n=[]){return Uc(e,this,n,t),n.sort(du),n}intersectObjects(e,t=!0,n=[]){for(let i=0,s=e.length;i<s;i++)Uc(e[i],this,n,t);return n.sort(du),n}}function du(r,e){return r.distance-e.distance}function Uc(r,e,t,n){let i=!0;if(r.layers.test(e.layers)&&r.raycast(e,t)===!1&&(i=!1),i===!0&&n===!0){const s=r.children;for(let o=0,a=s.length;o<a;o++)Uc(s[o],e,t,!0)}}class fu{constructor(e=1,t=0,n=0){this.radius=e,this.phi=t,this.theta=n}set(e,t,n){return this.radius=e,this.phi=t,this.theta=n,this}copy(e){return this.radius=e.radius,this.phi=e.phi,this.theta=e.theta,this}makeSafe(){return this.phi=dt(this.phi,1e-6,Math.PI-1e-6),this}setFromVector3(e){return this.setFromCartesianCoords(e.x,e.y,e.z)}setFromCartesianCoords(e,t,n){return this.radius=Math.sqrt(e*e+t*t+n*n),this.radius===0?(this.theta=0,this.phi=0):(this.theta=Math.atan2(e,n),this.phi=Math.acos(dt(t/this.radius,-1,1))),this}clone(){return new this.constructor().copy(this)}}const pu=new ye;class ir{constructor(e=new ye(1/0,1/0),t=new ye(-1/0,-1/0)){this.isBox2=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromPoints(e){this.makeEmpty();for(let t=0,n=e.length;t<n;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){const n=pu.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(n),this.max.copy(e).add(n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=1/0,this.max.x=this.max.y=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y}getCenter(e){return this.isEmpty()?e.set(0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,pu).distanceTo(e)}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}}const mu=new L,Vo=new L;class Eg{constructor(e=new L,t=new L){this.start=e,this.end=t}set(e,t){return this.start.copy(e),this.end.copy(t),this}copy(e){return this.start.copy(e.start),this.end.copy(e.end),this}getCenter(e){return e.addVectors(this.start,this.end).multiplyScalar(.5)}delta(e){return e.subVectors(this.end,this.start)}distanceSq(){return this.start.distanceToSquared(this.end)}distance(){return this.start.distanceTo(this.end)}at(e,t){return this.delta(t).multiplyScalar(e).add(this.start)}closestPointToPointParameter(e,t){mu.subVectors(e,this.start),Vo.subVectors(this.end,this.start);const n=Vo.dot(Vo);let s=Vo.dot(mu)/n;return t&&(s=dt(s,0,1)),s}closestPointToPoint(e,t,n){const i=this.closestPointToPointParameter(e,t);return this.delta(n).multiplyScalar(i).add(this.start)}applyMatrix4(e){return this.start.applyMatrix4(e),this.end.applyMatrix4(e),this}equals(e){return e.start.equals(this.start)&&e.end.equals(this.end)}clone(){return new this.constructor().copy(this)}}class gu extends vr{constructor(e=10,t=10,n=4473924,i=8947848){n=new ke(n),i=new ke(i);const s=t/2,o=e/t,a=e/2,l=[],c=[];for(let d=0,f=0,g=-a;d<=t;d++,g+=o){l.push(-a,0,g,a,0,g),l.push(g,0,-a,g,0,a);const v=d===s?n:i;v.toArray(c,f),f+=3,v.toArray(c,f),f+=3,v.toArray(c,f),f+=3,v.toArray(c,f),f+=3}const h=new yt;h.setAttribute("position",new Ne(l,3)),h.setAttribute("color",new Ne(c,3));const u=new Yn({vertexColors:!0,toneMapped:!1});super(h,u),this.type="GridHelper"}dispose(){this.geometry.dispose(),this.material.dispose()}}class Tg extends vr{constructor(e,t=16776960){const n=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),i=[1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,-1,-1,1,-1,-1,-1,-1,1,-1,-1],s=new yt;s.setIndex(new Rn(n,1)),s.setAttribute("position",new Ne(i,3)),super(s,new Yn({color:t,toneMapped:!1})),this.box=e,this.type="Box3Helper",this.geometry.computeBoundingSphere()}updateMatrixWorld(e){const t=this.box;t.isEmpty()||(t.getCenter(this.position),t.getSize(this.scale),this.scale.multiplyScalar(.5),super.updateMatrixWorld(e))}dispose(){this.geometry.dispose(),this.material.dispose()}}const _u=new L;let Go,bl;class uf extends Mt{constructor(e=new L(0,0,1),t=new L(0,0,0),n=1,i=16776960,s=n*.2,o=s*.2){super(),this.type="ArrowHelper",Go===void 0&&(Go=new yt,Go.setAttribute("position",new Ne([0,0,0,0,1,0],3)),bl=new sn(0,.5,1,5,1),bl.translate(0,-.5,0)),this.position.copy(t),this.line=new Gn(Go,new Yn({color:i,toneMapped:!1})),this.line.matrixAutoUpdate=!1,this.add(this.line),this.cone=new ve(bl,new zn({color:i,toneMapped:!1})),this.cone.matrixAutoUpdate=!1,this.add(this.cone),this.setDirection(e),this.setLength(n,s,o)}setDirection(e){if(e.y>.99999)this.quaternion.set(0,0,0,1);else if(e.y<-.99999)this.quaternion.set(1,0,0,0);else{_u.set(e.z,0,-e.x).normalize();const t=Math.acos(e.y);this.quaternion.setFromAxisAngle(_u,t)}}setLength(e,t=e*.2,n=t*.2){this.line.scale.set(1,Math.max(1e-4,e-t),1),this.line.updateMatrix(),this.cone.scale.set(n,t,n),this.cone.position.y=e,this.cone.updateMatrix()}setColor(e){this.line.material.color.set(e),this.cone.material.color.set(e)}copy(e){return super.copy(e,!1),this.line.copy(e.line),this.cone.copy(e.cone),this}dispose(){this.line.geometry.dispose(),this.line.material.dispose(),this.cone.geometry.dispose(),this.cone.material.dispose()}}class rh extends vr{constructor(e=1){const t=[0,0,0,e,0,0,0,0,0,0,e,0,0,0,0,0,0,e],n=[1,0,0,1,.6,0,0,1,0,.6,1,0,0,0,1,0,.6,1],i=new yt;i.setAttribute("position",new Ne(t,3)),i.setAttribute("color",new Ne(n,3));const s=new Yn({vertexColors:!0,toneMapped:!1});super(i,s),this.type="AxesHelper"}setColors(e,t,n){const i=new ke,s=this.geometry.attributes.color.array;return i.set(e),i.toArray(s,0),i.toArray(s,3),i.set(t),i.toArray(s,6),i.toArray(s,9),i.set(n),i.toArray(s,12),i.toArray(s,15),this.geometry.attributes.color.needsUpdate=!0,this}dispose(){this.geometry.dispose(),this.material.dispose()}}class df extends Ss{constructor(e,t=null){super(),this.object=e,this.domElement=t,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}}connect(){}disconnect(){}dispose(){}update(){}}function vu(r,e,t,n){const i=Ag(n);switch(t){case Fd:return r*e;case Bd:return r*e;case kd:return r*e*2;case zd:return r*e/i.components*i.byteLength;case Vc:return r*e/i.components*i.byteLength;case Hd:return r*e*2/i.components*i.byteLength;case Gc:return r*e*2/i.components*i.byteLength;case Od:return r*e*3/i.components*i.byteLength;case wn:return r*e*4/i.components*i.byteLength;case Wc:return r*e*4/i.components*i.byteLength;case la:case ca:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case ha:case ua:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case tc:case ic:return Math.max(r,16)*Math.max(e,8)/4;case ec:case nc:return Math.max(r,8)*Math.max(e,8)/2;case sc:case rc:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*8;case oc:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case ac:return Math.floor((r+3)/4)*Math.floor((e+3)/4)*16;case lc:return Math.floor((r+4)/5)*Math.floor((e+3)/4)*16;case cc:return Math.floor((r+4)/5)*Math.floor((e+4)/5)*16;case hc:return Math.floor((r+5)/6)*Math.floor((e+4)/5)*16;case uc:return Math.floor((r+5)/6)*Math.floor((e+5)/6)*16;case dc:return Math.floor((r+7)/8)*Math.floor((e+4)/5)*16;case fc:return Math.floor((r+7)/8)*Math.floor((e+5)/6)*16;case pc:return Math.floor((r+7)/8)*Math.floor((e+7)/8)*16;case mc:return Math.floor((r+9)/10)*Math.floor((e+4)/5)*16;case gc:return Math.floor((r+9)/10)*Math.floor((e+5)/6)*16;case _c:return Math.floor((r+9)/10)*Math.floor((e+7)/8)*16;case vc:return Math.floor((r+9)/10)*Math.floor((e+9)/10)*16;case xc:return Math.floor((r+11)/12)*Math.floor((e+9)/10)*16;case yc:return Math.floor((r+11)/12)*Math.floor((e+11)/12)*16;case da:case bc:case Mc:return Math.ceil(r/4)*Math.ceil(e/4)*16;case Vd:case wc:return Math.ceil(r/4)*Math.ceil(e/4)*8;case Sc:case Ec:return Math.ceil(r/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Ag(r){switch(r){case Oi:case Id:return{byteLength:1,components:1};case Xr:case Nd:case eo:return{byteLength:2,components:1};case zc:case Hc:return{byteLength:2,components:4};case vs:case kc:case pi:return{byteLength:4,components:1};case Ud:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:gs}}));typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=gs);/**
 * @license
 * Copyright 2010-2025 Three.js Authors
 * SPDX-License-Identifier: MIT
 */function ff(){let r=null,e=!1,t=null,n=null;function i(s,o){t(s,o),n=r.requestAnimationFrame(i)}return{start:function(){e!==!0&&t!==null&&(n=r.requestAnimationFrame(i),e=!0)},stop:function(){r.cancelAnimationFrame(n),e=!1},setAnimationLoop:function(s){t=s},setContext:function(s){r=s}}}function Rg(r){const e=new WeakMap;function t(a,l){const c=a.array,h=a.usage,u=c.byteLength,d=r.createBuffer();r.bindBuffer(l,d),r.bufferData(l,c,h),a.onUploadCallback();let f;if(c instanceof Float32Array)f=r.FLOAT;else if(c instanceof Uint16Array)a.isFloat16BufferAttribute?f=r.HALF_FLOAT:f=r.UNSIGNED_SHORT;else if(c instanceof Int16Array)f=r.SHORT;else if(c instanceof Uint32Array)f=r.UNSIGNED_INT;else if(c instanceof Int32Array)f=r.INT;else if(c instanceof Int8Array)f=r.BYTE;else if(c instanceof Uint8Array)f=r.UNSIGNED_BYTE;else if(c instanceof Uint8ClampedArray)f=r.UNSIGNED_BYTE;else throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+c);return{buffer:d,type:f,bytesPerElement:c.BYTES_PER_ELEMENT,version:a.version,size:u}}function n(a,l,c){const h=l.array,u=l.updateRanges;if(r.bindBuffer(c,a),u.length===0)r.bufferSubData(c,0,h);else{u.sort((f,g)=>f.start-g.start);let d=0;for(let f=1;f<u.length;f++){const g=u[d],v=u[f];v.start<=g.start+g.count+1?g.count=Math.max(g.count,v.start+v.count-g.start):(++d,u[d]=v)}u.length=d+1;for(let f=0,g=u.length;f<g;f++){const v=u[f];r.bufferSubData(c,v.start*h.BYTES_PER_ELEMENT,h,v.start,v.count)}l.clearUpdateRanges()}l.onUploadCallback()}function i(a){return a.isInterleavedBufferAttribute&&(a=a.data),e.get(a)}function s(a){a.isInterleavedBufferAttribute&&(a=a.data);const l=e.get(a);l&&(r.deleteBuffer(l.buffer),e.delete(a))}function o(a,l){if(a.isInterleavedBufferAttribute&&(a=a.data),a.isGLBufferAttribute){const h=e.get(a);(!h||h.version<a.version)&&e.set(a,{buffer:a.buffer,type:a.type,bytesPerElement:a.elementSize,version:a.version});return}const c=e.get(a);if(c===void 0)e.set(a,t(a,l));else if(c.version<a.version){if(c.size!==a.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");n(c.buffer,a,l),c.version=a.version}}return{get:i,remove:s,update:o}}var Cg=`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,Pg=`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,Lg=`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,Dg=`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,Ig=`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,Ng=`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,Ug=`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,Fg=`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,Og=`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,Bg=`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,kg=`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,zg=`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,Hg=`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,Vg=`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,Gg=`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,Wg=`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,Xg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,jg=`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,qg=`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,Yg=`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,Zg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,Kg=`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,$g=`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,Jg=`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,Qg=`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,e0=`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,t0=`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,n0=`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,i0=`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,s0=`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,r0="gl_FragColor = linearToOutputTexel( gl_FragColor );",o0=`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,a0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,l0=`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,c0=`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,h0=`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,u0=`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,d0=`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,f0=`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,p0=`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,m0=`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,g0=`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,_0=`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,v0=`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,x0=`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,y0=`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,b0=`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,M0=`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,w0=`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,S0=`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,E0=`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,T0=`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,A0=`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,R0=`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,C0=`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,P0=`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,L0=`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,D0=`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,I0=`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,N0=`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,U0=`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,F0=`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,O0=`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,B0=`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,k0=`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,z0=`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,H0=`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,V0=`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,G0=`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,W0=`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,X0=`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,j0=`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,q0=`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,Y0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,Z0=`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,K0=`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,$0=`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,J0=`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,Q0=`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,e_=`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,t_=`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,n_=`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,i_=`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,s_=`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,r_=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,o_=`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,a_=`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,l_=`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,c_=`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,h_=`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,u_=`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,d_=`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,f_=`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,p_=`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,m_=`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,g_=`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,__=`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,v_=`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,x_=`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,y_=`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,b_=`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,M_=`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,w_=`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		#else
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,S_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,E_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,T_=`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,A_=`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`;const R_=`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,C_=`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,P_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,L_=`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,D_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,I_=`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,N_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,U_=`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,F_=`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,O_=`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,B_=`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,k_=`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,z_=`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,H_=`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,V_=`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,G_=`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,W_=`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,X_=`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,j_=`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,q_=`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,Y_=`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,Z_=`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,K_=`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,$_=`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,J_=`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,Q_=`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,ev=`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,tv=`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,nv=`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,iv=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,sv=`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,rv=`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,ov=`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,av=`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,pt={alphahash_fragment:Cg,alphahash_pars_fragment:Pg,alphamap_fragment:Lg,alphamap_pars_fragment:Dg,alphatest_fragment:Ig,alphatest_pars_fragment:Ng,aomap_fragment:Ug,aomap_pars_fragment:Fg,batching_pars_vertex:Og,batching_vertex:Bg,begin_vertex:kg,beginnormal_vertex:zg,bsdfs:Hg,iridescence_fragment:Vg,bumpmap_pars_fragment:Gg,clipping_planes_fragment:Wg,clipping_planes_pars_fragment:Xg,clipping_planes_pars_vertex:jg,clipping_planes_vertex:qg,color_fragment:Yg,color_pars_fragment:Zg,color_pars_vertex:Kg,color_vertex:$g,common:Jg,cube_uv_reflection_fragment:Qg,defaultnormal_vertex:e0,displacementmap_pars_vertex:t0,displacementmap_vertex:n0,emissivemap_fragment:i0,emissivemap_pars_fragment:s0,colorspace_fragment:r0,colorspace_pars_fragment:o0,envmap_fragment:a0,envmap_common_pars_fragment:l0,envmap_pars_fragment:c0,envmap_pars_vertex:h0,envmap_physical_pars_fragment:b0,envmap_vertex:u0,fog_vertex:d0,fog_pars_vertex:f0,fog_fragment:p0,fog_pars_fragment:m0,gradientmap_pars_fragment:g0,lightmap_pars_fragment:_0,lights_lambert_fragment:v0,lights_lambert_pars_fragment:x0,lights_pars_begin:y0,lights_toon_fragment:M0,lights_toon_pars_fragment:w0,lights_phong_fragment:S0,lights_phong_pars_fragment:E0,lights_physical_fragment:T0,lights_physical_pars_fragment:A0,lights_fragment_begin:R0,lights_fragment_maps:C0,lights_fragment_end:P0,logdepthbuf_fragment:L0,logdepthbuf_pars_fragment:D0,logdepthbuf_pars_vertex:I0,logdepthbuf_vertex:N0,map_fragment:U0,map_pars_fragment:F0,map_particle_fragment:O0,map_particle_pars_fragment:B0,metalnessmap_fragment:k0,metalnessmap_pars_fragment:z0,morphinstance_vertex:H0,morphcolor_vertex:V0,morphnormal_vertex:G0,morphtarget_pars_vertex:W0,morphtarget_vertex:X0,normal_fragment_begin:j0,normal_fragment_maps:q0,normal_pars_fragment:Y0,normal_pars_vertex:Z0,normal_vertex:K0,normalmap_pars_fragment:$0,clearcoat_normal_fragment_begin:J0,clearcoat_normal_fragment_maps:Q0,clearcoat_pars_fragment:e_,iridescence_pars_fragment:t_,opaque_fragment:n_,packing:i_,premultiplied_alpha_fragment:s_,project_vertex:r_,dithering_fragment:o_,dithering_pars_fragment:a_,roughnessmap_fragment:l_,roughnessmap_pars_fragment:c_,shadowmap_pars_fragment:h_,shadowmap_pars_vertex:u_,shadowmap_vertex:d_,shadowmask_pars_fragment:f_,skinbase_vertex:p_,skinning_pars_vertex:m_,skinning_vertex:g_,skinnormal_vertex:__,specularmap_fragment:v_,specularmap_pars_fragment:x_,tonemapping_fragment:y_,tonemapping_pars_fragment:b_,transmission_fragment:M_,transmission_pars_fragment:w_,uv_pars_fragment:S_,uv_pars_vertex:E_,uv_vertex:T_,worldpos_vertex:A_,background_vert:R_,background_frag:C_,backgroundCube_vert:P_,backgroundCube_frag:L_,cube_vert:D_,cube_frag:I_,depth_vert:N_,depth_frag:U_,distanceRGBA_vert:F_,distanceRGBA_frag:O_,equirect_vert:B_,equirect_frag:k_,linedashed_vert:z_,linedashed_frag:H_,meshbasic_vert:V_,meshbasic_frag:G_,meshlambert_vert:W_,meshlambert_frag:X_,meshmatcap_vert:j_,meshmatcap_frag:q_,meshnormal_vert:Y_,meshnormal_frag:Z_,meshphong_vert:K_,meshphong_frag:$_,meshphysical_vert:J_,meshphysical_frag:Q_,meshtoon_vert:ev,meshtoon_frag:tv,points_vert:nv,points_frag:iv,shadow_vert:sv,shadow_frag:rv,sprite_vert:ov,sprite_frag:av},Se={common:{diffuse:{value:new ke(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new ct},alphaMap:{value:null},alphaMapTransform:{value:new ct},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new ct}},envmap:{envMap:{value:null},envMapRotation:{value:new ct},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new ct}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new ct}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new ct},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new ct},normalScale:{value:new ye(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new ct},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new ct}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new ct}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new ct}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ke(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new ke(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new ct},alphaTest:{value:0},uvTransform:{value:new ct}},sprite:{diffuse:{value:new ke(16777215)},opacity:{value:1},center:{value:new ye(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new ct},alphaMap:{value:null},alphaMapTransform:{value:new ct},alphaTest:{value:0}}},Nn={basic:{uniforms:Tn([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.fog]),vertexShader:pt.meshbasic_vert,fragmentShader:pt.meshbasic_frag},lambert:{uniforms:Tn([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,Se.lights,{emissive:{value:new ke(0)}}]),vertexShader:pt.meshlambert_vert,fragmentShader:pt.meshlambert_frag},phong:{uniforms:Tn([Se.common,Se.specularmap,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,Se.lights,{emissive:{value:new ke(0)},specular:{value:new ke(1118481)},shininess:{value:30}}]),vertexShader:pt.meshphong_vert,fragmentShader:pt.meshphong_frag},standard:{uniforms:Tn([Se.common,Se.envmap,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.roughnessmap,Se.metalnessmap,Se.fog,Se.lights,{emissive:{value:new ke(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:pt.meshphysical_vert,fragmentShader:pt.meshphysical_frag},toon:{uniforms:Tn([Se.common,Se.aomap,Se.lightmap,Se.emissivemap,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.gradientmap,Se.fog,Se.lights,{emissive:{value:new ke(0)}}]),vertexShader:pt.meshtoon_vert,fragmentShader:pt.meshtoon_frag},matcap:{uniforms:Tn([Se.common,Se.bumpmap,Se.normalmap,Se.displacementmap,Se.fog,{matcap:{value:null}}]),vertexShader:pt.meshmatcap_vert,fragmentShader:pt.meshmatcap_frag},points:{uniforms:Tn([Se.points,Se.fog]),vertexShader:pt.points_vert,fragmentShader:pt.points_frag},dashed:{uniforms:Tn([Se.common,Se.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:pt.linedashed_vert,fragmentShader:pt.linedashed_frag},depth:{uniforms:Tn([Se.common,Se.displacementmap]),vertexShader:pt.depth_vert,fragmentShader:pt.depth_frag},normal:{uniforms:Tn([Se.common,Se.bumpmap,Se.normalmap,Se.displacementmap,{opacity:{value:1}}]),vertexShader:pt.meshnormal_vert,fragmentShader:pt.meshnormal_frag},sprite:{uniforms:Tn([Se.sprite,Se.fog]),vertexShader:pt.sprite_vert,fragmentShader:pt.sprite_frag},background:{uniforms:{uvTransform:{value:new ct},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:pt.background_vert,fragmentShader:pt.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new ct}},vertexShader:pt.backgroundCube_vert,fragmentShader:pt.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:pt.cube_vert,fragmentShader:pt.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:pt.equirect_vert,fragmentShader:pt.equirect_frag},distanceRGBA:{uniforms:Tn([Se.common,Se.displacementmap,{referencePosition:{value:new L},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:pt.distanceRGBA_vert,fragmentShader:pt.distanceRGBA_frag},shadow:{uniforms:Tn([Se.lights,Se.fog,{color:{value:new ke(0)},opacity:{value:1}}]),vertexShader:pt.shadow_vert,fragmentShader:pt.shadow_frag}};Nn.physical={uniforms:Tn([Nn.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new ct},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new ct},clearcoatNormalScale:{value:new ye(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new ct},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new ct},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new ct},sheen:{value:0},sheenColor:{value:new ke(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new ct},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new ct},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new ct},transmissionSamplerSize:{value:new ye},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new ct},attenuationDistance:{value:0},attenuationColor:{value:new ke(0)},specularColor:{value:new ke(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new ct},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new ct},anisotropyVector:{value:new ye},anisotropyMap:{value:null},anisotropyMapTransform:{value:new ct}}]),vertexShader:pt.meshphysical_vert,fragmentShader:pt.meshphysical_frag};const Wo={r:0,b:0,g:0},rs=new Bt,lv=new Ee;function cv(r,e,t,n,i,s,o){const a=new ke(0);let l=s===!0?0:1,c,h,u=null,d=0,f=null;function g(y){let b=y.isScene===!0?y.background:null;return b&&b.isTexture&&(b=(y.backgroundBlurriness>0?t:e).get(b)),b}function v(y){let b=!1;const D=g(y);D===null?p(a,l):D&&D.isColor&&(p(D,1),b=!0);const R=r.xr.getEnvironmentBlendMode();R==="additive"?n.buffers.color.setClear(0,0,0,1,o):R==="alpha-blend"&&n.buffers.color.setClear(0,0,0,0,o),(r.autoClear||b)&&(n.buffers.depth.setTest(!0),n.buffers.depth.setMask(!0),n.buffers.color.setMask(!0),r.clear(r.autoClearColor,r.autoClearDepth,r.autoClearStencil))}function m(y,b){const D=g(b);D&&(D.isCubeTexture||D.mapping===Ra)?(h===void 0&&(h=new ve(new Zt(1,1,1),new _i({name:"BackgroundCubeMaterial",uniforms:_r(Nn.backgroundCube.uniforms),vertexShader:Nn.backgroundCube.vertexShader,fragmentShader:Nn.backgroundCube.fragmentShader,side:Un,depthTest:!1,depthWrite:!1,fog:!1})),h.geometry.deleteAttribute("normal"),h.geometry.deleteAttribute("uv"),h.onBeforeRender=function(R,P,M){this.matrixWorld.copyPosition(M.matrixWorld)},Object.defineProperty(h.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),i.update(h)),rs.copy(b.backgroundRotation),rs.x*=-1,rs.y*=-1,rs.z*=-1,D.isCubeTexture&&D.isRenderTargetTexture===!1&&(rs.y*=-1,rs.z*=-1),h.material.uniforms.envMap.value=D,h.material.uniforms.flipEnvMap.value=D.isCubeTexture&&D.isRenderTargetTexture===!1?-1:1,h.material.uniforms.backgroundBlurriness.value=b.backgroundBlurriness,h.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,h.material.uniforms.backgroundRotation.value.setFromMatrix4(lv.makeRotationFromEuler(rs)),h.material.toneMapped=rt.getTransfer(D.colorSpace)!==Nt,(u!==D||d!==D.version||f!==r.toneMapping)&&(h.material.needsUpdate=!0,u=D,d=D.version,f=r.toneMapping),h.layers.enableAll(),y.unshift(h,h.geometry,h.material,0,0,null)):D&&D.isTexture&&(c===void 0&&(c=new ve(new xr(2,2),new _i({name:"BackgroundMaterial",uniforms:_r(Nn.background.uniforms),vertexShader:Nn.background.vertexShader,fragmentShader:Nn.background.fragmentShader,side:Fi,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),Object.defineProperty(c.material,"map",{get:function(){return this.uniforms.t2D.value}}),i.update(c)),c.material.uniforms.t2D.value=D,c.material.uniforms.backgroundIntensity.value=b.backgroundIntensity,c.material.toneMapped=rt.getTransfer(D.colorSpace)!==Nt,D.matrixAutoUpdate===!0&&D.updateMatrix(),c.material.uniforms.uvTransform.value.copy(D.matrix),(u!==D||d!==D.version||f!==r.toneMapping)&&(c.material.needsUpdate=!0,u=D,d=D.version,f=r.toneMapping),c.layers.enableAll(),y.unshift(c,c.geometry,c.material,0,0,null))}function p(y,b){y.getRGB(Wo,qd(r)),n.buffers.color.setClear(Wo.r,Wo.g,Wo.b,b,o)}function w(){h!==void 0&&(h.geometry.dispose(),h.material.dispose(),h=void 0),c!==void 0&&(c.geometry.dispose(),c.material.dispose(),c=void 0)}return{getClearColor:function(){return a},setClearColor:function(y,b=1){a.set(y),l=b,p(a,l)},getClearAlpha:function(){return l},setClearAlpha:function(y){l=y,p(a,l)},render:v,addToRenderList:m,dispose:w}}function hv(r,e){const t=r.getParameter(r.MAX_VERTEX_ATTRIBS),n={},i=d(null);let s=i,o=!1;function a(x,T,F,k,G){let K=!1;const z=u(k,F,T);s!==z&&(s=z,c(s.object)),K=f(x,k,F,G),K&&g(x,k,F,G),G!==null&&e.update(G,r.ELEMENT_ARRAY_BUFFER),(K||o)&&(o=!1,b(x,T,F,k),G!==null&&r.bindBuffer(r.ELEMENT_ARRAY_BUFFER,e.get(G).buffer))}function l(){return r.createVertexArray()}function c(x){return r.bindVertexArray(x)}function h(x){return r.deleteVertexArray(x)}function u(x,T,F){const k=F.wireframe===!0;let G=n[x.id];G===void 0&&(G={},n[x.id]=G);let K=G[T.id];K===void 0&&(K={},G[T.id]=K);let z=K[k];return z===void 0&&(z=d(l()),K[k]=z),z}function d(x){const T=[],F=[],k=[];for(let G=0;G<t;G++)T[G]=0,F[G]=0,k[G]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:T,enabledAttributes:F,attributeDivisors:k,object:x,attributes:{},index:null}}function f(x,T,F,k){const G=s.attributes,K=T.attributes;let z=0;const Z=F.getAttributes();for(const V in Z)if(Z[V].location>=0){const ue=G[V];let ie=K[V];if(ie===void 0&&(V==="instanceMatrix"&&x.instanceMatrix&&(ie=x.instanceMatrix),V==="instanceColor"&&x.instanceColor&&(ie=x.instanceColor)),ue===void 0||ue.attribute!==ie||ie&&ue.data!==ie.data)return!0;z++}return s.attributesNum!==z||s.index!==k}function g(x,T,F,k){const G={},K=T.attributes;let z=0;const Z=F.getAttributes();for(const V in Z)if(Z[V].location>=0){let ue=K[V];ue===void 0&&(V==="instanceMatrix"&&x.instanceMatrix&&(ue=x.instanceMatrix),V==="instanceColor"&&x.instanceColor&&(ue=x.instanceColor));const ie={};ie.attribute=ue,ue&&ue.data&&(ie.data=ue.data),G[V]=ie,z++}s.attributes=G,s.attributesNum=z,s.index=k}function v(){const x=s.newAttributes;for(let T=0,F=x.length;T<F;T++)x[T]=0}function m(x){p(x,0)}function p(x,T){const F=s.newAttributes,k=s.enabledAttributes,G=s.attributeDivisors;F[x]=1,k[x]===0&&(r.enableVertexAttribArray(x),k[x]=1),G[x]!==T&&(r.vertexAttribDivisor(x,T),G[x]=T)}function w(){const x=s.newAttributes,T=s.enabledAttributes;for(let F=0,k=T.length;F<k;F++)T[F]!==x[F]&&(r.disableVertexAttribArray(F),T[F]=0)}function y(x,T,F,k,G,K,z){z===!0?r.vertexAttribIPointer(x,T,F,G,K):r.vertexAttribPointer(x,T,F,k,G,K)}function b(x,T,F,k){v();const G=k.attributes,K=F.getAttributes(),z=T.defaultAttributeValues;for(const Z in K){const V=K[Z];if(V.location>=0){let Y=G[Z];if(Y===void 0&&(Z==="instanceMatrix"&&x.instanceMatrix&&(Y=x.instanceMatrix),Z==="instanceColor"&&x.instanceColor&&(Y=x.instanceColor)),Y!==void 0){const ue=Y.normalized,ie=Y.itemSize,he=e.get(Y);if(he===void 0)continue;const se=he.buffer,H=he.type,j=he.bytesPerElement,J=H===r.INT||H===r.UNSIGNED_INT||Y.gpuType===kc;if(Y.isInterleavedBufferAttribute){const te=Y.data,ce=te.stride,be=Y.offset;if(te.isInstancedInterleavedBuffer){for(let xe=0;xe<V.locationSize;xe++)p(V.location+xe,te.meshPerAttribute);x.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=te.meshPerAttribute*te.count)}else for(let xe=0;xe<V.locationSize;xe++)m(V.location+xe);r.bindBuffer(r.ARRAY_BUFFER,se);for(let xe=0;xe<V.locationSize;xe++)y(V.location+xe,ie/V.locationSize,H,ue,ce*j,(be+ie/V.locationSize*xe)*j,J)}else{if(Y.isInstancedBufferAttribute){for(let te=0;te<V.locationSize;te++)p(V.location+te,Y.meshPerAttribute);x.isInstancedMesh!==!0&&k._maxInstanceCount===void 0&&(k._maxInstanceCount=Y.meshPerAttribute*Y.count)}else for(let te=0;te<V.locationSize;te++)m(V.location+te);r.bindBuffer(r.ARRAY_BUFFER,se);for(let te=0;te<V.locationSize;te++)y(V.location+te,ie/V.locationSize,H,ue,ie*j,ie/V.locationSize*te*j,J)}}else if(z!==void 0){const ue=z[Z];if(ue!==void 0)switch(ue.length){case 2:r.vertexAttrib2fv(V.location,ue);break;case 3:r.vertexAttrib3fv(V.location,ue);break;case 4:r.vertexAttrib4fv(V.location,ue);break;default:r.vertexAttrib1fv(V.location,ue)}}}}w()}function D(){M();for(const x in n){const T=n[x];for(const F in T){const k=T[F];for(const G in k)h(k[G].object),delete k[G];delete T[F]}delete n[x]}}function R(x){if(n[x.id]===void 0)return;const T=n[x.id];for(const F in T){const k=T[F];for(const G in k)h(k[G].object),delete k[G];delete T[F]}delete n[x.id]}function P(x){for(const T in n){const F=n[T];if(F[x.id]===void 0)continue;const k=F[x.id];for(const G in k)h(k[G].object),delete k[G];delete F[x.id]}}function M(){_(),o=!0,s!==i&&(s=i,c(s.object))}function _(){i.geometry=null,i.program=null,i.wireframe=!1}return{setup:a,reset:M,resetDefaultState:_,dispose:D,releaseStatesOfGeometry:R,releaseStatesOfProgram:P,initAttributes:v,enableAttribute:m,disableUnusedAttributes:w}}function uv(r,e,t){let n;function i(c){n=c}function s(c,h){r.drawArrays(n,c,h),t.update(h,n,1)}function o(c,h,u){u!==0&&(r.drawArraysInstanced(n,c,h,u),t.update(h,n,u))}function a(c,h,u){if(u===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(n,c,0,h,0,u);let f=0;for(let g=0;g<u;g++)f+=h[g];t.update(f,n,1)}function l(c,h,u,d){if(u===0)return;const f=e.get("WEBGL_multi_draw");if(f===null)for(let g=0;g<c.length;g++)o(c[g],h[g],d[g]);else{f.multiDrawArraysInstancedWEBGL(n,c,0,h,0,d,0,u);let g=0;for(let v=0;v<u;v++)g+=h[v]*d[v];t.update(g,n,1)}}this.setMode=i,this.render=s,this.renderInstances=o,this.renderMultiDraw=a,this.renderMultiDrawInstances=l}function dv(r,e,t,n){let i;function s(){if(i!==void 0)return i;if(e.has("EXT_texture_filter_anisotropic")===!0){const P=e.get("EXT_texture_filter_anisotropic");i=r.getParameter(P.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else i=0;return i}function o(P){return!(P!==wn&&n.convert(P)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_FORMAT))}function a(P){const M=P===eo&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(P!==Oi&&n.convert(P)!==r.getParameter(r.IMPLEMENTATION_COLOR_READ_TYPE)&&P!==pi&&!M)}function l(P){if(P==="highp"){if(r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.HIGH_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.HIGH_FLOAT).precision>0)return"highp";P="mediump"}return P==="mediump"&&r.getShaderPrecisionFormat(r.VERTEX_SHADER,r.MEDIUM_FLOAT).precision>0&&r.getShaderPrecisionFormat(r.FRAGMENT_SHADER,r.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let c=t.precision!==void 0?t.precision:"highp";const h=l(c);h!==c&&(console.warn("THREE.WebGLRenderer:",c,"not supported, using",h,"instead."),c=h);const u=t.logarithmicDepthBuffer===!0,d=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),f=r.getParameter(r.MAX_TEXTURE_IMAGE_UNITS),g=r.getParameter(r.MAX_VERTEX_TEXTURE_IMAGE_UNITS),v=r.getParameter(r.MAX_TEXTURE_SIZE),m=r.getParameter(r.MAX_CUBE_MAP_TEXTURE_SIZE),p=r.getParameter(r.MAX_VERTEX_ATTRIBS),w=r.getParameter(r.MAX_VERTEX_UNIFORM_VECTORS),y=r.getParameter(r.MAX_VARYING_VECTORS),b=r.getParameter(r.MAX_FRAGMENT_UNIFORM_VECTORS),D=g>0,R=r.getParameter(r.MAX_SAMPLES);return{isWebGL2:!0,getMaxAnisotropy:s,getMaxPrecision:l,textureFormatReadable:o,textureTypeReadable:a,precision:c,logarithmicDepthBuffer:u,reverseDepthBuffer:d,maxTextures:f,maxVertexTextures:g,maxTextureSize:v,maxCubemapSize:m,maxAttributes:p,maxVertexUniforms:w,maxVaryings:y,maxFragmentUniforms:b,vertexTextures:D,maxSamples:R}}function fv(r){const e=this;let t=null,n=0,i=!1,s=!1;const o=new Zi,a=new ct,l={value:null,needsUpdate:!1};this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(u,d){const f=u.length!==0||d||n!==0||i;return i=d,n=u.length,f},this.beginShadows=function(){s=!0,h(null)},this.endShadows=function(){s=!1},this.setGlobalState=function(u,d){t=h(u,d,0)},this.setState=function(u,d,f){const g=u.clippingPlanes,v=u.clipIntersection,m=u.clipShadows,p=r.get(u);if(!i||g===null||g.length===0||s&&!m)s?h(null):c();else{const w=s?0:n,y=w*4;let b=p.clippingState||null;l.value=b,b=h(g,d,y,f);for(let D=0;D!==y;++D)b[D]=t[D];p.clippingState=b,this.numIntersection=v?this.numPlanes:0,this.numPlanes+=w}};function c(){l.value!==t&&(l.value=t,l.needsUpdate=n>0),e.numPlanes=n,e.numIntersection=0}function h(u,d,f,g){const v=u!==null?u.length:0;let m=null;if(v!==0){if(m=l.value,g!==!0||m===null){const p=f+v*4,w=d.matrixWorldInverse;a.getNormalMatrix(w),(m===null||m.length<p)&&(m=new Float32Array(p));for(let y=0,b=f;y!==v;++y,b+=4)o.copy(u[y]).applyMatrix4(w,a),o.normal.toArray(m,b),m[b+3]=o.constant}l.value=m,l.needsUpdate=!0}return e.numPlanes=v,e.numIntersection=0,m}}function pv(r){let e=new WeakMap;function t(o,a){return a===_a?o.mapping=ur:a===Jl&&(o.mapping=dr),o}function n(o){if(o&&o.isTexture){const a=o.mapping;if(a===_a||a===Jl)if(e.has(o)){const l=e.get(o).texture;return t(l,o.mapping)}else{const l=o.image;if(l&&l.height>0){const c=new Sm(l.height);return c.fromEquirectangularTexture(r,o),e.set(o,c),o.addEventListener("dispose",i),t(c.texture,o.mapping)}else return null}}return o}function i(o){const a=o.target;a.removeEventListener("dispose",i);const l=e.get(a);l!==void 0&&(e.delete(a),l.dispose())}function s(){e=new WeakMap}return{get:n,dispose:s}}const sr=4,xu=[.125,.215,.35,.446,.526,.582],fs=20,Ml=new Na,yu=new ke;let wl=null,Sl=0,El=0,Tl=!1;const cs=(1+Math.sqrt(5))/2,Ys=1/cs,bu=[new L(-cs,Ys,0),new L(cs,Ys,0),new L(-Ys,0,cs),new L(Ys,0,cs),new L(0,cs,-Ys),new L(0,cs,Ys),new L(-1,1,-1),new L(1,1,-1),new L(-1,1,1),new L(1,1,1)],mv=new L;class Mu{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,n=.1,i=100,s={}){const{size:o=256,position:a=mv}=s;wl=this._renderer.getRenderTarget(),Sl=this._renderer.getActiveCubeFace(),El=this._renderer.getActiveMipmapLevel(),Tl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(o);const l=this._allocateTargets();return l.depthBuffer=!0,this._sceneToCubeUV(e,n,i,l,a),t>0&&this._blur(l,0,0,t),this._applyPMREM(l),this._cleanup(l),l}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Eu(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Su(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(wl,Sl,El),this._renderer.xr.enabled=Tl,e.scissorTest=!1,Xo(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===ur||e.mapping===dr?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),wl=this._renderer.getRenderTarget(),Sl=this._renderer.getActiveCubeFace(),El=this._renderer.getActiveMipmapLevel(),Tl=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;const n=t||this._allocateTargets();return this._textureToCubeUV(e,n),this._applyPMREM(n),this._cleanup(n),n}_allocateTargets(){const e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,n={magFilter:mn,minFilter:mn,generateMipmaps:!1,type:eo,format:wn,colorSpace:mr,depthBuffer:!1},i=wu(e,t,n);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=wu(e,t,n);const{_lodMax:s}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=gv(s)),this._blurMaterial=_v(s,e,t)}return i}_compileMaterial(e){const t=new ve(this._lodPlanes[0],e);this._renderer.compile(t,Ml)}_sceneToCubeUV(e,t,n,i,s){const l=new Qt(90,1,t,n),c=[1,-1,1,1,1,1],h=[1,1,1,-1,-1,-1],u=this._renderer,d=u.autoClear,f=u.toneMapping;u.getClearColor(yu),u.toneMapping=Qi,u.autoClear=!1;const g=new zn({name:"PMREM.Background",side:Un,depthWrite:!1,depthTest:!1}),v=new ve(new Zt,g);let m=!1;const p=e.background;p?p.isColor&&(g.color.copy(p),e.background=null,m=!0):(g.color.copy(yu),m=!0);for(let w=0;w<6;w++){const y=w%3;y===0?(l.up.set(0,c[w],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x+h[w],s.y,s.z)):y===1?(l.up.set(0,0,c[w]),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y+h[w],s.z)):(l.up.set(0,c[w],0),l.position.set(s.x,s.y,s.z),l.lookAt(s.x,s.y,s.z+h[w]));const b=this._cubeSize;Xo(i,y*b,w>2?b:0,b,b),u.setRenderTarget(i),m&&u.render(v,l),u.render(e,l)}v.geometry.dispose(),v.material.dispose(),u.toneMapping=f,u.autoClear=d,e.background=p}_textureToCubeUV(e,t){const n=this._renderer,i=e.mapping===ur||e.mapping===dr;i?(this._cubemapMaterial===null&&(this._cubemapMaterial=Eu()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Su());const s=i?this._cubemapMaterial:this._equirectMaterial,o=new ve(this._lodPlanes[0],s),a=s.uniforms;a.envMap.value=e;const l=this._cubeSize;Xo(t,0,0,3*l,2*l),n.setRenderTarget(t),n.render(o,Ml)}_applyPMREM(e){const t=this._renderer,n=t.autoClear;t.autoClear=!1;const i=this._lodPlanes.length;for(let s=1;s<i;s++){const o=Math.sqrt(this._sigmas[s]*this._sigmas[s]-this._sigmas[s-1]*this._sigmas[s-1]),a=bu[(i-s-1)%bu.length];this._blur(e,s-1,s,o,a)}t.autoClear=n}_blur(e,t,n,i,s){const o=this._pingPongRenderTarget;this._halfBlur(e,o,t,n,i,"latitudinal",s),this._halfBlur(o,e,n,n,i,"longitudinal",s)}_halfBlur(e,t,n,i,s,o,a){const l=this._renderer,c=this._blurMaterial;o!=="latitudinal"&&o!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");const h=3,u=new ve(this._lodPlanes[i],c),d=c.uniforms,f=this._sizeLods[n]-1,g=isFinite(s)?Math.PI/(2*f):2*Math.PI/(2*fs-1),v=s/g,m=isFinite(s)?1+Math.floor(h*v):fs;m>fs&&console.warn(`sigmaRadians, ${s}, is too large and will clip, as it requested ${m} samples when the maximum is set to ${fs}`);const p=[];let w=0;for(let P=0;P<fs;++P){const M=P/v,_=Math.exp(-M*M/2);p.push(_),P===0?w+=_:P<m&&(w+=2*_)}for(let P=0;P<p.length;P++)p[P]=p[P]/w;d.envMap.value=e.texture,d.samples.value=m,d.weights.value=p,d.latitudinal.value=o==="latitudinal",a&&(d.poleAxis.value=a);const{_lodMax:y}=this;d.dTheta.value=g,d.mipInt.value=y-n;const b=this._sizeLods[i],D=3*b*(i>y-sr?i-y+sr:0),R=4*(this._cubeSize-b);Xo(t,D,R,3*b,2*b),l.setRenderTarget(t),l.render(u,Ml)}}function gv(r){const e=[],t=[],n=[];let i=r;const s=r-sr+1+xu.length;for(let o=0;o<s;o++){const a=Math.pow(2,i);t.push(a);let l=1/a;o>r-sr?l=xu[o-r+sr-1]:o===0&&(l=0),n.push(l);const c=1/(a-2),h=-c,u=1+c,d=[h,h,u,h,u,u,h,h,u,u,h,u],f=6,g=6,v=3,m=2,p=1,w=new Float32Array(v*g*f),y=new Float32Array(m*g*f),b=new Float32Array(p*g*f);for(let R=0;R<f;R++){const P=R%3*2/3-1,M=R>2?0:-1,_=[P,M,0,P+2/3,M,0,P+2/3,M+1,0,P,M,0,P+2/3,M+1,0,P,M+1,0];w.set(_,v*g*R),y.set(d,m*g*R);const x=[R,R,R,R,R,R];b.set(x,p*g*R)}const D=new yt;D.setAttribute("position",new Rn(w,v)),D.setAttribute("uv",new Rn(y,m)),D.setAttribute("faceIndex",new Rn(b,p)),e.push(D),i>sr&&i--}return{lodPlanes:e,sizeLods:t,sigmas:n}}function wu(r,e,t){const n=new xs(r,e,t);return n.texture.mapping=Ra,n.texture.name="PMREM.cubeUv",n.scissorTest=!0,n}function Xo(r,e,t,n,i){r.viewport.set(e,t,n,i),r.scissor.set(e,t,n,i)}function _v(r,e,t){const n=new Float32Array(fs),i=new L(0,1,0);return new _i({name:"SphericalGaussianBlur",defines:{n:fs,CUBEUV_TEXEL_WIDTH:1/e,CUBEUV_TEXEL_HEIGHT:1/t,CUBEUV_MAX_MIP:`${r}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:n},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:i}},vertexShader:oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:Ji,depthTest:!1,depthWrite:!1})}function Su(){return new _i({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:Ji,depthTest:!1,depthWrite:!1})}function Eu(){return new _i({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:oh(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:Ji,depthTest:!1,depthWrite:!1})}function oh(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function vv(r){let e=new WeakMap,t=null;function n(a){if(a&&a.isTexture){const l=a.mapping,c=l===_a||l===Jl,h=l===ur||l===dr;if(c||h){let u=e.get(a);const d=u!==void 0?u.texture.pmremVersion:0;if(a.isRenderTargetTexture&&a.pmremVersion!==d)return t===null&&(t=new Mu(r)),u=c?t.fromEquirectangular(a,u):t.fromCubemap(a,u),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),u.texture;if(u!==void 0)return u.texture;{const f=a.image;return c&&f&&f.height>0||h&&f&&i(f)?(t===null&&(t=new Mu(r)),u=c?t.fromEquirectangular(a):t.fromCubemap(a),u.texture.pmremVersion=a.pmremVersion,e.set(a,u),a.addEventListener("dispose",s),u.texture):null}}}return a}function i(a){let l=0;const c=6;for(let h=0;h<c;h++)a[h]!==void 0&&l++;return l===c}function s(a){const l=a.target;l.removeEventListener("dispose",s);const c=e.get(l);c!==void 0&&(e.delete(l),c.dispose())}function o(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}return{get:n,dispose:o}}function xv(r){const e={};function t(n){if(e[n]!==void 0)return e[n];let i;switch(n){case"WEBGL_depth_texture":i=r.getExtension("WEBGL_depth_texture")||r.getExtension("MOZ_WEBGL_depth_texture")||r.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":i=r.getExtension("EXT_texture_filter_anisotropic")||r.getExtension("MOZ_EXT_texture_filter_anisotropic")||r.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":i=r.getExtension("WEBGL_compressed_texture_s3tc")||r.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":i=r.getExtension("WEBGL_compressed_texture_pvrtc")||r.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:i=r.getExtension(n)}return e[n]=i,i}return{has:function(n){return t(n)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(n){const i=t(n);return i===null&&ls("THREE.WebGLRenderer: "+n+" extension not supported."),i}}}function yv(r,e,t,n){const i={},s=new WeakMap;function o(u){const d=u.target;d.index!==null&&e.remove(d.index);for(const g in d.attributes)e.remove(d.attributes[g]);d.removeEventListener("dispose",o),delete i[d.id];const f=s.get(d);f&&(e.remove(f),s.delete(d)),n.releaseStatesOfGeometry(d),d.isInstancedBufferGeometry===!0&&delete d._maxInstanceCount,t.memory.geometries--}function a(u,d){return i[d.id]===!0||(d.addEventListener("dispose",o),i[d.id]=!0,t.memory.geometries++),d}function l(u){const d=u.attributes;for(const f in d)e.update(d[f],r.ARRAY_BUFFER)}function c(u){const d=[],f=u.index,g=u.attributes.position;let v=0;if(f!==null){const w=f.array;v=f.version;for(let y=0,b=w.length;y<b;y+=3){const D=w[y+0],R=w[y+1],P=w[y+2];d.push(D,R,R,P,P,D)}}else if(g!==void 0){const w=g.array;v=g.version;for(let y=0,b=w.length/3-1;y<b;y+=3){const D=y+0,R=y+1,P=y+2;d.push(D,R,R,P,P,D)}}else return;const m=new(Wd(d)?Kc:Zc)(d,1);m.version=v;const p=s.get(u);p&&e.remove(p),s.set(u,m)}function h(u){const d=s.get(u);if(d){const f=u.index;f!==null&&d.version<f.version&&c(u)}else c(u);return s.get(u)}return{get:a,update:l,getWireframeAttribute:h}}function bv(r,e,t){let n;function i(d){n=d}let s,o;function a(d){s=d.type,o=d.bytesPerElement}function l(d,f){r.drawElements(n,f,s,d*o),t.update(f,n,1)}function c(d,f,g){g!==0&&(r.drawElementsInstanced(n,f,s,d*o,g),t.update(f,n,g))}function h(d,f,g){if(g===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(n,f,0,s,d,0,g);let m=0;for(let p=0;p<g;p++)m+=f[p];t.update(m,n,1)}function u(d,f,g,v){if(g===0)return;const m=e.get("WEBGL_multi_draw");if(m===null)for(let p=0;p<d.length;p++)c(d[p]/o,f[p],v[p]);else{m.multiDrawElementsInstancedWEBGL(n,f,0,s,d,0,v,0,g);let p=0;for(let w=0;w<g;w++)p+=f[w]*v[w];t.update(p,n,1)}}this.setMode=i,this.setIndex=a,this.render=l,this.renderInstances=c,this.renderMultiDraw=h,this.renderMultiDrawInstances=u}function Mv(r){const e={geometries:0,textures:0},t={frame:0,calls:0,triangles:0,points:0,lines:0};function n(s,o,a){switch(t.calls++,o){case r.TRIANGLES:t.triangles+=a*(s/3);break;case r.LINES:t.lines+=a*(s/2);break;case r.LINE_STRIP:t.lines+=a*(s-1);break;case r.LINE_LOOP:t.lines+=a*s;break;case r.POINTS:t.points+=a*s;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",o);break}}function i(){t.calls=0,t.triangles=0,t.points=0,t.lines=0}return{memory:e,render:t,programs:null,autoReset:!0,reset:i,update:n}}function wv(r,e,t){const n=new WeakMap,i=new at;function s(o,a,l){const c=o.morphTargetInfluences,h=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,u=h!==void 0?h.length:0;let d=n.get(a);if(d===void 0||d.count!==u){let _=function(){P.dispose(),n.delete(a),a.removeEventListener("dispose",_)};d!==void 0&&d.texture.dispose();const f=a.morphAttributes.position!==void 0,g=a.morphAttributes.normal!==void 0,v=a.morphAttributes.color!==void 0,m=a.morphAttributes.position||[],p=a.morphAttributes.normal||[],w=a.morphAttributes.color||[];let y=0;f===!0&&(y=1),g===!0&&(y=2),v===!0&&(y=3);let b=a.attributes.position.count*y,D=1;b>e.maxTextureSize&&(D=Math.ceil(b/e.maxTextureSize),b=e.maxTextureSize);const R=new Float32Array(b*D*4*u),P=new Xd(R,b,D,u);P.type=pi,P.needsUpdate=!0;const M=y*4;for(let x=0;x<u;x++){const T=m[x],F=p[x],k=w[x],G=b*D*4*x;for(let K=0;K<T.count;K++){const z=K*M;f===!0&&(i.fromBufferAttribute(T,K),R[G+z+0]=i.x,R[G+z+1]=i.y,R[G+z+2]=i.z,R[G+z+3]=0),g===!0&&(i.fromBufferAttribute(F,K),R[G+z+4]=i.x,R[G+z+5]=i.y,R[G+z+6]=i.z,R[G+z+7]=0),v===!0&&(i.fromBufferAttribute(k,K),R[G+z+8]=i.x,R[G+z+9]=i.y,R[G+z+10]=i.z,R[G+z+11]=k.itemSize===4?i.w:1)}}d={count:u,texture:P,size:new ye(b,D)},n.set(a,d),a.addEventListener("dispose",_)}if(o.isInstancedMesh===!0&&o.morphTexture!==null)l.getUniforms().setValue(r,"morphTexture",o.morphTexture,t);else{let f=0;for(let v=0;v<c.length;v++)f+=c[v];const g=a.morphTargetsRelative?1:1-f;l.getUniforms().setValue(r,"morphTargetBaseInfluence",g),l.getUniforms().setValue(r,"morphTargetInfluences",c)}l.getUniforms().setValue(r,"morphTargetsTexture",d.texture,t),l.getUniforms().setValue(r,"morphTargetsTextureSize",d.size)}return{update:s}}function Sv(r,e,t,n){let i=new WeakMap;function s(l){const c=n.render.frame,h=l.geometry,u=e.get(l,h);if(i.get(u)!==c&&(e.update(u),i.set(u,c)),l.isInstancedMesh&&(l.hasEventListener("dispose",a)===!1&&l.addEventListener("dispose",a),i.get(l)!==c&&(t.update(l.instanceMatrix,r.ARRAY_BUFFER),l.instanceColor!==null&&t.update(l.instanceColor,r.ARRAY_BUFFER),i.set(l,c))),l.isSkinnedMesh){const d=l.skeleton;i.get(d)!==c&&(d.update(),i.set(d,c))}return u}function o(){i=new WeakMap}function a(l){const c=l.target;c.removeEventListener("dispose",a),t.remove(c.instanceMatrix),c.instanceColor!==null&&t.remove(c.instanceColor)}return{update:s,dispose:o}}const pf=new Wt,Tu=new tf(1,1),mf=new Xd,gf=new lm,_f=new Zd,Au=[],Ru=[],Cu=new Float32Array(16),Pu=new Float32Array(9),Lu=new Float32Array(4);function Mr(r,e,t){const n=r[0];if(n<=0||n>0)return r;const i=e*t;let s=Au[i];if(s===void 0&&(s=new Float32Array(i),Au[i]=s),e!==0){n.toArray(s,0);for(let o=1,a=0;o!==e;++o)a+=t,r[o].toArray(s,a)}return s}function on(r,e){if(r.length!==e.length)return!1;for(let t=0,n=r.length;t<n;t++)if(r[t]!==e[t])return!1;return!0}function an(r,e){for(let t=0,n=e.length;t<n;t++)r[t]=e[t]}function Fa(r,e){let t=Ru[e];t===void 0&&(t=new Int32Array(e),Ru[e]=t);for(let n=0;n!==e;++n)t[n]=r.allocateTextureUnit();return t}function Ev(r,e){const t=this.cache;t[0]!==e&&(r.uniform1f(this.addr,e),t[0]=e)}function Tv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(on(t,e))return;r.uniform2fv(this.addr,e),an(t,e)}}function Av(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)(t[0]!==e.r||t[1]!==e.g||t[2]!==e.b)&&(r.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(on(t,e))return;r.uniform3fv(this.addr,e),an(t,e)}}function Rv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(on(t,e))return;r.uniform4fv(this.addr,e),an(t,e)}}function Cv(r,e){const t=this.cache,n=e.elements;if(n===void 0){if(on(t,e))return;r.uniformMatrix2fv(this.addr,!1,e),an(t,e)}else{if(on(t,n))return;Lu.set(n),r.uniformMatrix2fv(this.addr,!1,Lu),an(t,n)}}function Pv(r,e){const t=this.cache,n=e.elements;if(n===void 0){if(on(t,e))return;r.uniformMatrix3fv(this.addr,!1,e),an(t,e)}else{if(on(t,n))return;Pu.set(n),r.uniformMatrix3fv(this.addr,!1,Pu),an(t,n)}}function Lv(r,e){const t=this.cache,n=e.elements;if(n===void 0){if(on(t,e))return;r.uniformMatrix4fv(this.addr,!1,e),an(t,e)}else{if(on(t,n))return;Cu.set(n),r.uniformMatrix4fv(this.addr,!1,Cu),an(t,n)}}function Dv(r,e){const t=this.cache;t[0]!==e&&(r.uniform1i(this.addr,e),t[0]=e)}function Iv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(on(t,e))return;r.uniform2iv(this.addr,e),an(t,e)}}function Nv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(on(t,e))return;r.uniform3iv(this.addr,e),an(t,e)}}function Uv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(on(t,e))return;r.uniform4iv(this.addr,e),an(t,e)}}function Fv(r,e){const t=this.cache;t[0]!==e&&(r.uniform1ui(this.addr,e),t[0]=e)}function Ov(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y)&&(r.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(on(t,e))return;r.uniform2uiv(this.addr,e),an(t,e)}}function Bv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z)&&(r.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(on(t,e))return;r.uniform3uiv(this.addr,e),an(t,e)}}function kv(r,e){const t=this.cache;if(e.x!==void 0)(t[0]!==e.x||t[1]!==e.y||t[2]!==e.z||t[3]!==e.w)&&(r.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(on(t,e))return;r.uniform4uiv(this.addr,e),an(t,e)}}function zv(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i);let s;this.type===r.SAMPLER_2D_SHADOW?(Tu.compareFunction=Gd,s=Tu):s=pf,t.setTexture2D(e||s,i)}function Hv(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTexture3D(e||gf,i)}function Vv(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTextureCube(e||_f,i)}function Gv(r,e,t){const n=this.cache,i=t.allocateTextureUnit();n[0]!==i&&(r.uniform1i(this.addr,i),n[0]=i),t.setTexture2DArray(e||mf,i)}function Wv(r){switch(r){case 5126:return Ev;case 35664:return Tv;case 35665:return Av;case 35666:return Rv;case 35674:return Cv;case 35675:return Pv;case 35676:return Lv;case 5124:case 35670:return Dv;case 35667:case 35671:return Iv;case 35668:case 35672:return Nv;case 35669:case 35673:return Uv;case 5125:return Fv;case 36294:return Ov;case 36295:return Bv;case 36296:return kv;case 35678:case 36198:case 36298:case 36306:case 35682:return zv;case 35679:case 36299:case 36307:return Hv;case 35680:case 36300:case 36308:case 36293:return Vv;case 36289:case 36303:case 36311:case 36292:return Gv}}function Xv(r,e){r.uniform1fv(this.addr,e)}function jv(r,e){const t=Mr(e,this.size,2);r.uniform2fv(this.addr,t)}function qv(r,e){const t=Mr(e,this.size,3);r.uniform3fv(this.addr,t)}function Yv(r,e){const t=Mr(e,this.size,4);r.uniform4fv(this.addr,t)}function Zv(r,e){const t=Mr(e,this.size,4);r.uniformMatrix2fv(this.addr,!1,t)}function Kv(r,e){const t=Mr(e,this.size,9);r.uniformMatrix3fv(this.addr,!1,t)}function $v(r,e){const t=Mr(e,this.size,16);r.uniformMatrix4fv(this.addr,!1,t)}function Jv(r,e){r.uniform1iv(this.addr,e)}function Qv(r,e){r.uniform2iv(this.addr,e)}function ex(r,e){r.uniform3iv(this.addr,e)}function tx(r,e){r.uniform4iv(this.addr,e)}function nx(r,e){r.uniform1uiv(this.addr,e)}function ix(r,e){r.uniform2uiv(this.addr,e)}function sx(r,e){r.uniform3uiv(this.addr,e)}function rx(r,e){r.uniform4uiv(this.addr,e)}function ox(r,e,t){const n=this.cache,i=e.length,s=Fa(t,i);on(n,s)||(r.uniform1iv(this.addr,s),an(n,s));for(let o=0;o!==i;++o)t.setTexture2D(e[o]||pf,s[o])}function ax(r,e,t){const n=this.cache,i=e.length,s=Fa(t,i);on(n,s)||(r.uniform1iv(this.addr,s),an(n,s));for(let o=0;o!==i;++o)t.setTexture3D(e[o]||gf,s[o])}function lx(r,e,t){const n=this.cache,i=e.length,s=Fa(t,i);on(n,s)||(r.uniform1iv(this.addr,s),an(n,s));for(let o=0;o!==i;++o)t.setTextureCube(e[o]||_f,s[o])}function cx(r,e,t){const n=this.cache,i=e.length,s=Fa(t,i);on(n,s)||(r.uniform1iv(this.addr,s),an(n,s));for(let o=0;o!==i;++o)t.setTexture2DArray(e[o]||mf,s[o])}function hx(r){switch(r){case 5126:return Xv;case 35664:return jv;case 35665:return qv;case 35666:return Yv;case 35674:return Zv;case 35675:return Kv;case 35676:return $v;case 5124:case 35670:return Jv;case 35667:case 35671:return Qv;case 35668:case 35672:return ex;case 35669:case 35673:return tx;case 5125:return nx;case 36294:return ix;case 36295:return sx;case 36296:return rx;case 35678:case 36198:case 36298:case 36306:case 35682:return ox;case 35679:case 36299:case 36307:return ax;case 35680:case 36300:case 36308:case 36293:return lx;case 36289:case 36303:case 36311:case 36292:return cx}}class ux{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.setValue=Wv(t.type)}}class dx{constructor(e,t,n){this.id=e,this.addr=n,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=hx(t.type)}}class fx{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,n){const i=this.seq;for(let s=0,o=i.length;s!==o;++s){const a=i[s];a.setValue(e,t[a.id],n)}}}const Al=/(\w+)(\])?(\[|\.)?/g;function Du(r,e){r.seq.push(e),r.map[e.id]=e}function px(r,e,t){const n=r.name,i=n.length;for(Al.lastIndex=0;;){const s=Al.exec(n),o=Al.lastIndex;let a=s[1];const l=s[2]==="]",c=s[3];if(l&&(a=a|0),c===void 0||c==="["&&o+2===i){Du(t,c===void 0?new ux(a,r,e):new dx(a,r,e));break}else{let u=t.map[a];u===void 0&&(u=new fx(a),Du(t,u)),t=u}}}class fa{constructor(e,t){this.seq=[],this.map={};const n=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let i=0;i<n;++i){const s=e.getActiveUniform(t,i),o=e.getUniformLocation(t,s.name);px(s,o,this)}}setValue(e,t,n,i){const s=this.map[t];s!==void 0&&s.setValue(e,n,i)}setOptional(e,t,n){const i=t[n];i!==void 0&&this.setValue(e,n,i)}static upload(e,t,n,i){for(let s=0,o=t.length;s!==o;++s){const a=t[s],l=n[a.id];l.needsUpdate!==!1&&a.setValue(e,l.value,i)}}static seqWithValue(e,t){const n=[];for(let i=0,s=e.length;i!==s;++i){const o=e[i];o.id in t&&n.push(o)}return n}}function Iu(r,e,t){const n=r.createShader(e);return r.shaderSource(n,t),r.compileShader(n),n}const mx=37297;let gx=0;function _x(r,e){const t=r.split(`
`),n=[],i=Math.max(e-6,0),s=Math.min(e+6,t.length);for(let o=i;o<s;o++){const a=o+1;n.push(`${a===e?">":" "} ${a}: ${t[o]}`)}return n.join(`
`)}const Nu=new ct;function vx(r){rt._getMatrix(Nu,rt.workingColorSpace,r);const e=`mat3( ${Nu.elements.map(t=>t.toFixed(4))} )`;switch(rt.getTransfer(r)){case xa:return[e,"LinearTransferOETF"];case Nt:return[e,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",r),[e,"LinearTransferOETF"]}}function Uu(r,e,t){const n=r.getShaderParameter(e,r.COMPILE_STATUS),i=r.getShaderInfoLog(e).trim();if(n&&i==="")return"";const s=/ERROR: 0:(\d+)/.exec(i);if(s){const o=parseInt(s[1]);return t.toUpperCase()+`

`+i+`

`+_x(r.getShaderSource(e),o)}else return i}function xx(r,e){const t=vx(e);return[`vec4 ${r}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function yx(r,e){let t;switch(e){case _p:t="Linear";break;case vp:t="Reinhard";break;case xp:t="Cineon";break;case yp:t="ACESFilmic";break;case Mp:t="AgX";break;case wp:t="Neutral";break;case bp:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+r+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}const jo=new L;function bx(){rt.getLuminanceCoefficients(jo);const r=jo.x.toFixed(4),e=jo.y.toFixed(4),t=jo.z.toFixed(4);return["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${r}, ${e}, ${t} );`,"	return dot( weights, rgb );","}"].join(`
`)}function Mx(r){return[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(Or).join(`
`)}function wx(r){const e=[];for(const t in r){const n=r[t];n!==!1&&e.push("#define "+t+" "+n)}return e.join(`
`)}function Sx(r,e){const t={},n=r.getProgramParameter(e,r.ACTIVE_ATTRIBUTES);for(let i=0;i<n;i++){const s=r.getActiveAttrib(e,i),o=s.name;let a=1;s.type===r.FLOAT_MAT2&&(a=2),s.type===r.FLOAT_MAT3&&(a=3),s.type===r.FLOAT_MAT4&&(a=4),t[o]={type:s.type,location:r.getAttribLocation(e,o),locationSize:a}}return t}function Or(r){return r!==""}function Fu(r,e){const t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return r.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function Ou(r,e){return r.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}const Ex=/^[ \t]*#include +<([\w\d./]+)>/gm;function Fc(r){return r.replace(Ex,Ax)}const Tx=new Map;function Ax(r,e){let t=pt[e];if(t===void 0){const n=Tx.get(e);if(n!==void 0)t=pt[n],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,n);else throw new Error("Can not resolve #include <"+e+">")}return Fc(t)}const Rx=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function Bu(r){return r.replace(Rx,Cx)}function Cx(r,e,t,n){let i="";for(let s=parseInt(e);s<parseInt(t);s++)i+=n.replace(/\[\s*i\s*\]/g,"[ "+s+" ]").replace(/UNROLLED_LOOP_INDEX/g,s);return i}function ku(r){let e=`precision ${r.precision} float;
	precision ${r.precision} int;
	precision ${r.precision} sampler2D;
	precision ${r.precision} samplerCube;
	precision ${r.precision} sampler3D;
	precision ${r.precision} sampler2DArray;
	precision ${r.precision} sampler2DShadow;
	precision ${r.precision} samplerCubeShadow;
	precision ${r.precision} sampler2DArrayShadow;
	precision ${r.precision} isampler2D;
	precision ${r.precision} isampler3D;
	precision ${r.precision} isamplerCube;
	precision ${r.precision} isampler2DArray;
	precision ${r.precision} usampler2D;
	precision ${r.precision} usampler3D;
	precision ${r.precision} usamplerCube;
	precision ${r.precision} usampler2DArray;
	`;return r.precision==="highp"?e+=`
#define HIGH_PRECISION`:r.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:r.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function Px(r){let e="SHADOWMAP_TYPE_BASIC";return r.shadowMapType===Ld?e="SHADOWMAP_TYPE_PCF":r.shadowMapType===Kf?e="SHADOWMAP_TYPE_PCF_SOFT":r.shadowMapType===Ci&&(e="SHADOWMAP_TYPE_VSM"),e}function Lx(r){let e="ENVMAP_TYPE_CUBE";if(r.envMap)switch(r.envMapMode){case ur:case dr:e="ENVMAP_TYPE_CUBE";break;case Ra:e="ENVMAP_TYPE_CUBE_UV";break}return e}function Dx(r){let e="ENVMAP_MODE_REFLECTION";if(r.envMap)switch(r.envMapMode){case dr:e="ENVMAP_MODE_REFRACTION";break}return e}function Ix(r){let e="ENVMAP_BLENDING_NONE";if(r.envMap)switch(r.combine){case Aa:e="ENVMAP_BLENDING_MULTIPLY";break;case mp:e="ENVMAP_BLENDING_MIX";break;case gp:e="ENVMAP_BLENDING_ADD";break}return e}function Nx(r){const e=r.envMapCubeUVHeight;if(e===null)return null;const t=Math.log2(e)-2,n=1/e;return{texelWidth:1/(3*Math.max(Math.pow(2,t),7*16)),texelHeight:n,maxMip:t}}function Ux(r,e,t,n){const i=r.getContext(),s=t.defines;let o=t.vertexShader,a=t.fragmentShader;const l=Px(t),c=Lx(t),h=Dx(t),u=Ix(t),d=Nx(t),f=Mx(t),g=wx(s),v=i.createProgram();let m,p,w=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(m=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Or).join(`
`),m.length>0&&(m+=`
`),p=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g].filter(Or).join(`
`),p.length>0&&(p+=`
`)):(m=[ku(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(Or).join(`
`),p=[ku(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,g,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+u:"",d?"#define CUBEUV_TEXEL_WIDTH "+d.texelWidth:"",d?"#define CUBEUV_TEXEL_HEIGHT "+d.texelHeight:"",d?"#define CUBEUV_MAX_MIP "+d.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==Qi?"#define TONE_MAPPING":"",t.toneMapping!==Qi?pt.tonemapping_pars_fragment:"",t.toneMapping!==Qi?yx("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",pt.colorspace_pars_fragment,xx("linearToOutputTexel",t.outputColorSpace),bx(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(Or).join(`
`)),o=Fc(o),o=Fu(o,t),o=Ou(o,t),a=Fc(a),a=Fu(a,t),a=Ou(a,t),o=Bu(o),a=Bu(a),t.isRawShaderMaterial!==!0&&(w=`#version 300 es
`,m=[f,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+m,p=["#define varying in",t.glslVersion===wh?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===wh?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+p);const y=w+m+o,b=w+p+a,D=Iu(i,i.VERTEX_SHADER,y),R=Iu(i,i.FRAGMENT_SHADER,b);i.attachShader(v,D),i.attachShader(v,R),t.index0AttributeName!==void 0?i.bindAttribLocation(v,0,t.index0AttributeName):t.morphTargets===!0&&i.bindAttribLocation(v,0,"position"),i.linkProgram(v);function P(T){if(r.debug.checkShaderErrors){const F=i.getProgramInfoLog(v).trim(),k=i.getShaderInfoLog(D).trim(),G=i.getShaderInfoLog(R).trim();let K=!0,z=!0;if(i.getProgramParameter(v,i.LINK_STATUS)===!1)if(K=!1,typeof r.debug.onShaderError=="function")r.debug.onShaderError(i,v,D,R);else{const Z=Uu(i,D,"vertex"),V=Uu(i,R,"fragment");console.error("THREE.WebGLProgram: Shader Error "+i.getError()+" - VALIDATE_STATUS "+i.getProgramParameter(v,i.VALIDATE_STATUS)+`

Material Name: `+T.name+`
Material Type: `+T.type+`

Program Info Log: `+F+`
`+Z+`
`+V)}else F!==""?console.warn("THREE.WebGLProgram: Program Info Log:",F):(k===""||G==="")&&(z=!1);z&&(T.diagnostics={runnable:K,programLog:F,vertexShader:{log:k,prefix:m},fragmentShader:{log:G,prefix:p}})}i.deleteShader(D),i.deleteShader(R),M=new fa(i,v),_=Sx(i,v)}let M;this.getUniforms=function(){return M===void 0&&P(this),M};let _;this.getAttributes=function(){return _===void 0&&P(this),_};let x=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return x===!1&&(x=i.getProgramParameter(v,mx)),x},this.destroy=function(){n.releaseStatesOfProgram(this),i.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=gx++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=D,this.fragmentShader=R,this}let Fx=0;class Ox{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){const t=e.vertexShader,n=e.fragmentShader,i=this._getShaderStage(t),s=this._getShaderStage(n),o=this._getShaderCacheForMaterial(e);return o.has(i)===!1&&(o.add(i),i.usedTimes++),o.has(s)===!1&&(o.add(s),s.usedTimes++),this}remove(e){const t=this.materialCache.get(e);for(const n of t)n.usedTimes--,n.usedTimes===0&&this.shaderCache.delete(n.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){const t=this.materialCache;let n=t.get(e);return n===void 0&&(n=new Set,t.set(e,n)),n}_getShaderStage(e){const t=this.shaderCache;let n=t.get(e);return n===void 0&&(n=new Bx(e),t.set(e,n)),n}}class Bx{constructor(e){this.id=Fx++,this.code=e,this.usedTimes=0}}function kx(r,e,t,n,i,s,o){const a=new Yc,l=new Ox,c=new Set,h=[],u=i.logarithmicDepthBuffer,d=i.vertexTextures;let f=i.precision;const g={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(_){return c.add(_),_===0?"uv":`uv${_}`}function m(_,x,T,F,k){const G=F.fog,K=k.geometry,z=_.isMeshStandardMaterial?F.environment:null,Z=(_.isMeshStandardMaterial?t:e).get(_.envMap||z),V=Z&&Z.mapping===Ra?Z.image.height:null,Y=g[_.type];_.precision!==null&&(f=i.getMaxPrecision(_.precision),f!==_.precision&&console.warn("THREE.WebGLProgram.getParameters:",_.precision,"not supported, using",f,"instead."));const ue=K.morphAttributes.position||K.morphAttributes.normal||K.morphAttributes.color,ie=ue!==void 0?ue.length:0;let he=0;K.morphAttributes.position!==void 0&&(he=1),K.morphAttributes.normal!==void 0&&(he=2),K.morphAttributes.color!==void 0&&(he=3);let se,H,j,J;if(Y){const ut=Nn[Y];se=ut.vertexShader,H=ut.fragmentShader}else se=_.vertexShader,H=_.fragmentShader,l.update(_),j=l.getVertexShaderID(_),J=l.getFragmentShaderID(_);const te=r.getRenderTarget(),ce=r.state.buffers.depth.getReversed(),be=k.isInstancedMesh===!0,xe=k.isBatchedMesh===!0,Re=!!_.map,Je=!!_.matcap,We=!!Z,B=!!_.aoMap,ht=!!_.lightMap,Le=!!_.bumpMap,tt=!!_.normalMap,me=!!_.displacementMap,Qe=!!_.emissiveMap,ze=!!_.metalnessMap,O=!!_.roughnessMap,A=_.anisotropy>0,$=_.clearcoat>0,ae=_.dispersion>0,de=_.iridescence>0,re=_.sheen>0,Ce=_.transmission>0,Me=A&&!!_.anisotropyMap,Fe=$&&!!_.clearcoatMap,gt=$&&!!_.clearcoatNormalMap,ge=$&&!!_.clearcoatRoughnessMap,Te=de&&!!_.iridescenceMap,qe=de&&!!_.iridescenceThicknessMap,et=re&&!!_.sheenColorMap,He=re&&!!_.sheenRoughnessMap,xt=!!_.specularMap,lt=!!_.specularColorMap,Lt=!!_.specularIntensityMap,X=Ce&&!!_.transmissionMap,Pe=Ce&&!!_.thicknessMap,oe=!!_.gradientMap,fe=!!_.alphaMap,Ue=_.alphaTest>0,De=!!_.alphaHash,ot=!!_.extensions;let zt=Qi;_.toneMapped&&(te===null||te.isXRRenderTarget===!0)&&(zt=r.toneMapping);const ln={shaderID:Y,shaderType:_.type,shaderName:_.name,vertexShader:se,fragmentShader:H,defines:_.defines,customVertexShaderID:j,customFragmentShaderID:J,isRawShaderMaterial:_.isRawShaderMaterial===!0,glslVersion:_.glslVersion,precision:f,batching:xe,batchingColor:xe&&k._colorsTexture!==null,instancing:be,instancingColor:be&&k.instanceColor!==null,instancingMorph:be&&k.morphTexture!==null,supportsVertexTextures:d,outputColorSpace:te===null?r.outputColorSpace:te.isXRRenderTarget===!0?te.texture.colorSpace:mr,alphaToCoverage:!!_.alphaToCoverage,map:Re,matcap:Je,envMap:We,envMapMode:We&&Z.mapping,envMapCubeUVHeight:V,aoMap:B,lightMap:ht,bumpMap:Le,normalMap:tt,displacementMap:d&&me,emissiveMap:Qe,normalMapObjectSpace:tt&&_.normalMapType===Cp,normalMapTangentSpace:tt&&_.normalMapType===Xc,metalnessMap:ze,roughnessMap:O,anisotropy:A,anisotropyMap:Me,clearcoat:$,clearcoatMap:Fe,clearcoatNormalMap:gt,clearcoatRoughnessMap:ge,dispersion:ae,iridescence:de,iridescenceMap:Te,iridescenceThicknessMap:qe,sheen:re,sheenColorMap:et,sheenRoughnessMap:He,specularMap:xt,specularColorMap:lt,specularIntensityMap:Lt,transmission:Ce,transmissionMap:X,thicknessMap:Pe,gradientMap:oe,opaque:_.transparent===!1&&_.blending===ar&&_.alphaToCoverage===!1,alphaMap:fe,alphaTest:Ue,alphaHash:De,combine:_.combine,mapUv:Re&&v(_.map.channel),aoMapUv:B&&v(_.aoMap.channel),lightMapUv:ht&&v(_.lightMap.channel),bumpMapUv:Le&&v(_.bumpMap.channel),normalMapUv:tt&&v(_.normalMap.channel),displacementMapUv:me&&v(_.displacementMap.channel),emissiveMapUv:Qe&&v(_.emissiveMap.channel),metalnessMapUv:ze&&v(_.metalnessMap.channel),roughnessMapUv:O&&v(_.roughnessMap.channel),anisotropyMapUv:Me&&v(_.anisotropyMap.channel),clearcoatMapUv:Fe&&v(_.clearcoatMap.channel),clearcoatNormalMapUv:gt&&v(_.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ge&&v(_.clearcoatRoughnessMap.channel),iridescenceMapUv:Te&&v(_.iridescenceMap.channel),iridescenceThicknessMapUv:qe&&v(_.iridescenceThicknessMap.channel),sheenColorMapUv:et&&v(_.sheenColorMap.channel),sheenRoughnessMapUv:He&&v(_.sheenRoughnessMap.channel),specularMapUv:xt&&v(_.specularMap.channel),specularColorMapUv:lt&&v(_.specularColorMap.channel),specularIntensityMapUv:Lt&&v(_.specularIntensityMap.channel),transmissionMapUv:X&&v(_.transmissionMap.channel),thicknessMapUv:Pe&&v(_.thicknessMap.channel),alphaMapUv:fe&&v(_.alphaMap.channel),vertexTangents:!!K.attributes.tangent&&(tt||A),vertexColors:_.vertexColors,vertexAlphas:_.vertexColors===!0&&!!K.attributes.color&&K.attributes.color.itemSize===4,pointsUvs:k.isPoints===!0&&!!K.attributes.uv&&(Re||fe),fog:!!G,useFog:_.fog===!0,fogExp2:!!G&&G.isFogExp2,flatShading:_.flatShading===!0,sizeAttenuation:_.sizeAttenuation===!0,logarithmicDepthBuffer:u,reverseDepthBuffer:ce,skinning:k.isSkinnedMesh===!0,morphTargets:K.morphAttributes.position!==void 0,morphNormals:K.morphAttributes.normal!==void 0,morphColors:K.morphAttributes.color!==void 0,morphTargetsCount:ie,morphTextureStride:he,numDirLights:x.directional.length,numPointLights:x.point.length,numSpotLights:x.spot.length,numSpotLightMaps:x.spotLightMap.length,numRectAreaLights:x.rectArea.length,numHemiLights:x.hemi.length,numDirLightShadows:x.directionalShadowMap.length,numPointLightShadows:x.pointShadowMap.length,numSpotLightShadows:x.spotShadowMap.length,numSpotLightShadowsWithMaps:x.numSpotLightShadowsWithMaps,numLightProbes:x.numLightProbes,numClippingPlanes:o.numPlanes,numClipIntersection:o.numIntersection,dithering:_.dithering,shadowMapEnabled:r.shadowMap.enabled&&T.length>0,shadowMapType:r.shadowMap.type,toneMapping:zt,decodeVideoTexture:Re&&_.map.isVideoTexture===!0&&rt.getTransfer(_.map.colorSpace)===Nt,decodeVideoTextureEmissive:Qe&&_.emissiveMap.isVideoTexture===!0&&rt.getTransfer(_.emissiveMap.colorSpace)===Nt,premultipliedAlpha:_.premultipliedAlpha,doubleSided:_.side===Xn,flipSided:_.side===Un,useDepthPacking:_.depthPacking>=0,depthPacking:_.depthPacking||0,index0AttributeName:_.index0AttributeName,extensionClipCullDistance:ot&&_.extensions.clipCullDistance===!0&&n.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ot&&_.extensions.multiDraw===!0||xe)&&n.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:n.has("KHR_parallel_shader_compile"),customProgramCacheKey:_.customProgramCacheKey()};return ln.vertexUv1s=c.has(1),ln.vertexUv2s=c.has(2),ln.vertexUv3s=c.has(3),c.clear(),ln}function p(_){const x=[];if(_.shaderID?x.push(_.shaderID):(x.push(_.customVertexShaderID),x.push(_.customFragmentShaderID)),_.defines!==void 0)for(const T in _.defines)x.push(T),x.push(_.defines[T]);return _.isRawShaderMaterial===!1&&(w(x,_),y(x,_),x.push(r.outputColorSpace)),x.push(_.customProgramCacheKey),x.join()}function w(_,x){_.push(x.precision),_.push(x.outputColorSpace),_.push(x.envMapMode),_.push(x.envMapCubeUVHeight),_.push(x.mapUv),_.push(x.alphaMapUv),_.push(x.lightMapUv),_.push(x.aoMapUv),_.push(x.bumpMapUv),_.push(x.normalMapUv),_.push(x.displacementMapUv),_.push(x.emissiveMapUv),_.push(x.metalnessMapUv),_.push(x.roughnessMapUv),_.push(x.anisotropyMapUv),_.push(x.clearcoatMapUv),_.push(x.clearcoatNormalMapUv),_.push(x.clearcoatRoughnessMapUv),_.push(x.iridescenceMapUv),_.push(x.iridescenceThicknessMapUv),_.push(x.sheenColorMapUv),_.push(x.sheenRoughnessMapUv),_.push(x.specularMapUv),_.push(x.specularColorMapUv),_.push(x.specularIntensityMapUv),_.push(x.transmissionMapUv),_.push(x.thicknessMapUv),_.push(x.combine),_.push(x.fogExp2),_.push(x.sizeAttenuation),_.push(x.morphTargetsCount),_.push(x.morphAttributeCount),_.push(x.numDirLights),_.push(x.numPointLights),_.push(x.numSpotLights),_.push(x.numSpotLightMaps),_.push(x.numHemiLights),_.push(x.numRectAreaLights),_.push(x.numDirLightShadows),_.push(x.numPointLightShadows),_.push(x.numSpotLightShadows),_.push(x.numSpotLightShadowsWithMaps),_.push(x.numLightProbes),_.push(x.shadowMapType),_.push(x.toneMapping),_.push(x.numClippingPlanes),_.push(x.numClipIntersection),_.push(x.depthPacking)}function y(_,x){a.disableAll(),x.supportsVertexTextures&&a.enable(0),x.instancing&&a.enable(1),x.instancingColor&&a.enable(2),x.instancingMorph&&a.enable(3),x.matcap&&a.enable(4),x.envMap&&a.enable(5),x.normalMapObjectSpace&&a.enable(6),x.normalMapTangentSpace&&a.enable(7),x.clearcoat&&a.enable(8),x.iridescence&&a.enable(9),x.alphaTest&&a.enable(10),x.vertexColors&&a.enable(11),x.vertexAlphas&&a.enable(12),x.vertexUv1s&&a.enable(13),x.vertexUv2s&&a.enable(14),x.vertexUv3s&&a.enable(15),x.vertexTangents&&a.enable(16),x.anisotropy&&a.enable(17),x.alphaHash&&a.enable(18),x.batching&&a.enable(19),x.dispersion&&a.enable(20),x.batchingColor&&a.enable(21),_.push(a.mask),a.disableAll(),x.fog&&a.enable(0),x.useFog&&a.enable(1),x.flatShading&&a.enable(2),x.logarithmicDepthBuffer&&a.enable(3),x.reverseDepthBuffer&&a.enable(4),x.skinning&&a.enable(5),x.morphTargets&&a.enable(6),x.morphNormals&&a.enable(7),x.morphColors&&a.enable(8),x.premultipliedAlpha&&a.enable(9),x.shadowMapEnabled&&a.enable(10),x.doubleSided&&a.enable(11),x.flipSided&&a.enable(12),x.useDepthPacking&&a.enable(13),x.dithering&&a.enable(14),x.transmission&&a.enable(15),x.sheen&&a.enable(16),x.opaque&&a.enable(17),x.pointsUvs&&a.enable(18),x.decodeVideoTexture&&a.enable(19),x.decodeVideoTextureEmissive&&a.enable(20),x.alphaToCoverage&&a.enable(21),_.push(a.mask)}function b(_){const x=g[_.type];let T;if(x){const F=Nn[x];T=$c.clone(F.uniforms)}else T=_.uniforms;return T}function D(_,x){let T;for(let F=0,k=h.length;F<k;F++){const G=h[F];if(G.cacheKey===x){T=G,++T.usedTimes;break}}return T===void 0&&(T=new Ux(r,x,_,s),h.push(T)),T}function R(_){if(--_.usedTimes===0){const x=h.indexOf(_);h[x]=h[h.length-1],h.pop(),_.destroy()}}function P(_){l.remove(_)}function M(){l.dispose()}return{getParameters:m,getProgramCacheKey:p,getUniforms:b,acquireProgram:D,releaseProgram:R,releaseShaderCache:P,programs:h,dispose:M}}function zx(){let r=new WeakMap;function e(o){return r.has(o)}function t(o){let a=r.get(o);return a===void 0&&(a={},r.set(o,a)),a}function n(o){r.delete(o)}function i(o,a,l){r.get(o)[a]=l}function s(){r=new WeakMap}return{has:e,get:t,remove:n,update:i,dispose:s}}function Hx(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.material.id!==e.material.id?r.material.id-e.material.id:r.z!==e.z?r.z-e.z:r.id-e.id}function zu(r,e){return r.groupOrder!==e.groupOrder?r.groupOrder-e.groupOrder:r.renderOrder!==e.renderOrder?r.renderOrder-e.renderOrder:r.z!==e.z?e.z-r.z:r.id-e.id}function Hu(){const r=[];let e=0;const t=[],n=[],i=[];function s(){e=0,t.length=0,n.length=0,i.length=0}function o(u,d,f,g,v,m){let p=r[e];return p===void 0?(p={id:u.id,object:u,geometry:d,material:f,groupOrder:g,renderOrder:u.renderOrder,z:v,group:m},r[e]=p):(p.id=u.id,p.object=u,p.geometry=d,p.material=f,p.groupOrder=g,p.renderOrder=u.renderOrder,p.z=v,p.group=m),e++,p}function a(u,d,f,g,v,m){const p=o(u,d,f,g,v,m);f.transmission>0?n.push(p):f.transparent===!0?i.push(p):t.push(p)}function l(u,d,f,g,v,m){const p=o(u,d,f,g,v,m);f.transmission>0?n.unshift(p):f.transparent===!0?i.unshift(p):t.unshift(p)}function c(u,d){t.length>1&&t.sort(u||Hx),n.length>1&&n.sort(d||zu),i.length>1&&i.sort(d||zu)}function h(){for(let u=e,d=r.length;u<d;u++){const f=r[u];if(f.id===null)break;f.id=null,f.object=null,f.geometry=null,f.material=null,f.group=null}}return{opaque:t,transmissive:n,transparent:i,init:s,push:a,unshift:l,finish:h,sort:c}}function Vx(){let r=new WeakMap;function e(n,i){const s=r.get(n);let o;return s===void 0?(o=new Hu,r.set(n,[o])):i>=s.length?(o=new Hu,s.push(o)):o=s[i],o}function t(){r=new WeakMap}return{get:e,dispose:t}}function Gx(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new L,color:new ke};break;case"SpotLight":t={position:new L,direction:new L,color:new ke,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new L,color:new ke,distance:0,decay:0};break;case"HemisphereLight":t={direction:new L,skyColor:new ke,groundColor:new ke};break;case"RectAreaLight":t={color:new ke,position:new L,halfWidth:new L,halfHeight:new L};break}return r[e.id]=t,t}}}function Wx(){const r={};return{get:function(e){if(r[e.id]!==void 0)return r[e.id];let t;switch(e.type){case"DirectionalLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ye};break;case"SpotLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ye};break;case"PointLight":t={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new ye,shadowCameraNear:1,shadowCameraFar:1e3};break}return r[e.id]=t,t}}}let Xx=0;function jx(r,e){return(e.castShadow?2:0)-(r.castShadow?2:0)+(e.map?1:0)-(r.map?1:0)}function qx(r){const e=new Gx,t=Wx(),n={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let c=0;c<9;c++)n.probe.push(new L);const i=new L,s=new Ee,o=new Ee;function a(c){let h=0,u=0,d=0;for(let _=0;_<9;_++)n.probe[_].set(0,0,0);let f=0,g=0,v=0,m=0,p=0,w=0,y=0,b=0,D=0,R=0,P=0;c.sort(jx);for(let _=0,x=c.length;_<x;_++){const T=c[_],F=T.color,k=T.intensity,G=T.distance,K=T.shadow&&T.shadow.map?T.shadow.map.texture:null;if(T.isAmbientLight)h+=F.r*k,u+=F.g*k,d+=F.b*k;else if(T.isLightProbe){for(let z=0;z<9;z++)n.probe[z].addScaledVector(T.sh.coefficients[z],k);P++}else if(T.isDirectionalLight){const z=e.get(T);if(z.color.copy(T.color).multiplyScalar(T.intensity),T.castShadow){const Z=T.shadow,V=t.get(T);V.shadowIntensity=Z.intensity,V.shadowBias=Z.bias,V.shadowNormalBias=Z.normalBias,V.shadowRadius=Z.radius,V.shadowMapSize=Z.mapSize,n.directionalShadow[f]=V,n.directionalShadowMap[f]=K,n.directionalShadowMatrix[f]=T.shadow.matrix,w++}n.directional[f]=z,f++}else if(T.isSpotLight){const z=e.get(T);z.position.setFromMatrixPosition(T.matrixWorld),z.color.copy(F).multiplyScalar(k),z.distance=G,z.coneCos=Math.cos(T.angle),z.penumbraCos=Math.cos(T.angle*(1-T.penumbra)),z.decay=T.decay,n.spot[v]=z;const Z=T.shadow;if(T.map&&(n.spotLightMap[D]=T.map,D++,Z.updateMatrices(T),T.castShadow&&R++),n.spotLightMatrix[v]=Z.matrix,T.castShadow){const V=t.get(T);V.shadowIntensity=Z.intensity,V.shadowBias=Z.bias,V.shadowNormalBias=Z.normalBias,V.shadowRadius=Z.radius,V.shadowMapSize=Z.mapSize,n.spotShadow[v]=V,n.spotShadowMap[v]=K,b++}v++}else if(T.isRectAreaLight){const z=e.get(T);z.color.copy(F).multiplyScalar(k),z.halfWidth.set(T.width*.5,0,0),z.halfHeight.set(0,T.height*.5,0),n.rectArea[m]=z,m++}else if(T.isPointLight){const z=e.get(T);if(z.color.copy(T.color).multiplyScalar(T.intensity),z.distance=T.distance,z.decay=T.decay,T.castShadow){const Z=T.shadow,V=t.get(T);V.shadowIntensity=Z.intensity,V.shadowBias=Z.bias,V.shadowNormalBias=Z.normalBias,V.shadowRadius=Z.radius,V.shadowMapSize=Z.mapSize,V.shadowCameraNear=Z.camera.near,V.shadowCameraFar=Z.camera.far,n.pointShadow[g]=V,n.pointShadowMap[g]=K,n.pointShadowMatrix[g]=T.shadow.matrix,y++}n.point[g]=z,g++}else if(T.isHemisphereLight){const z=e.get(T);z.skyColor.copy(T.color).multiplyScalar(k),z.groundColor.copy(T.groundColor).multiplyScalar(k),n.hemi[p]=z,p++}}m>0&&(r.has("OES_texture_float_linear")===!0?(n.rectAreaLTC1=Se.LTC_FLOAT_1,n.rectAreaLTC2=Se.LTC_FLOAT_2):(n.rectAreaLTC1=Se.LTC_HALF_1,n.rectAreaLTC2=Se.LTC_HALF_2)),n.ambient[0]=h,n.ambient[1]=u,n.ambient[2]=d;const M=n.hash;(M.directionalLength!==f||M.pointLength!==g||M.spotLength!==v||M.rectAreaLength!==m||M.hemiLength!==p||M.numDirectionalShadows!==w||M.numPointShadows!==y||M.numSpotShadows!==b||M.numSpotMaps!==D||M.numLightProbes!==P)&&(n.directional.length=f,n.spot.length=v,n.rectArea.length=m,n.point.length=g,n.hemi.length=p,n.directionalShadow.length=w,n.directionalShadowMap.length=w,n.pointShadow.length=y,n.pointShadowMap.length=y,n.spotShadow.length=b,n.spotShadowMap.length=b,n.directionalShadowMatrix.length=w,n.pointShadowMatrix.length=y,n.spotLightMatrix.length=b+D-R,n.spotLightMap.length=D,n.numSpotLightShadowsWithMaps=R,n.numLightProbes=P,M.directionalLength=f,M.pointLength=g,M.spotLength=v,M.rectAreaLength=m,M.hemiLength=p,M.numDirectionalShadows=w,M.numPointShadows=y,M.numSpotShadows=b,M.numSpotMaps=D,M.numLightProbes=P,n.version=Xx++)}function l(c,h){let u=0,d=0,f=0,g=0,v=0;const m=h.matrixWorldInverse;for(let p=0,w=c.length;p<w;p++){const y=c[p];if(y.isDirectionalLight){const b=n.directional[u];b.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),b.direction.sub(i),b.direction.transformDirection(m),u++}else if(y.isSpotLight){const b=n.spot[f];b.position.setFromMatrixPosition(y.matrixWorld),b.position.applyMatrix4(m),b.direction.setFromMatrixPosition(y.matrixWorld),i.setFromMatrixPosition(y.target.matrixWorld),b.direction.sub(i),b.direction.transformDirection(m),f++}else if(y.isRectAreaLight){const b=n.rectArea[g];b.position.setFromMatrixPosition(y.matrixWorld),b.position.applyMatrix4(m),o.identity(),s.copy(y.matrixWorld),s.premultiply(m),o.extractRotation(s),b.halfWidth.set(y.width*.5,0,0),b.halfHeight.set(0,y.height*.5,0),b.halfWidth.applyMatrix4(o),b.halfHeight.applyMatrix4(o),g++}else if(y.isPointLight){const b=n.point[d];b.position.setFromMatrixPosition(y.matrixWorld),b.position.applyMatrix4(m),d++}else if(y.isHemisphereLight){const b=n.hemi[v];b.direction.setFromMatrixPosition(y.matrixWorld),b.direction.transformDirection(m),v++}}}return{setup:a,setupView:l,state:n}}function Vu(r){const e=new qx(r),t=[],n=[];function i(h){c.camera=h,t.length=0,n.length=0}function s(h){t.push(h)}function o(h){n.push(h)}function a(){e.setup(t)}function l(h){e.setupView(t,h)}const c={lightsArray:t,shadowsArray:n,camera:null,lights:e,transmissionRenderTarget:{}};return{init:i,state:c,setupLights:a,setupLightsView:l,pushLight:s,pushShadow:o}}function Yx(r){let e=new WeakMap;function t(i,s=0){const o=e.get(i);let a;return o===void 0?(a=new Vu(r),e.set(i,[a])):s>=o.length?(a=new Vu(r),o.push(a)):a=o[s],a}function n(){e=new WeakMap}return{get:t,dispose:n}}const Zx=`void main() {
	gl_Position = vec4( position, 1.0 );
}`,Kx=`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`;function $x(r,e,t){let n=new Pa;const i=new ye,s=new ye,o=new at,a=new Km({depthPacking:Rp}),l=new $m,c={},h=t.maxTextureSize,u={[Fi]:Un,[Un]:Fi,[Xn]:Xn},d=new _i({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new ye},radius:{value:4}},vertexShader:Zx,fragmentShader:Kx}),f=d.clone();f.defines.HORIZONTAL_PASS=1;const g=new yt;g.setAttribute("position",new Rn(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));const v=new ve(g,d),m=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=Ld;let p=this.type;this.render=function(R,P,M){if(m.enabled===!1||m.autoUpdate===!1&&m.needsUpdate===!1||R.length===0)return;const _=r.getRenderTarget(),x=r.getActiveCubeFace(),T=r.getActiveMipmapLevel(),F=r.state;F.setBlending(Ji),F.buffers.color.setClear(1,1,1,1),F.buffers.depth.setTest(!0),F.setScissorTest(!1);const k=p!==Ci&&this.type===Ci,G=p===Ci&&this.type!==Ci;for(let K=0,z=R.length;K<z;K++){const Z=R[K],V=Z.shadow;if(V===void 0){console.warn("THREE.WebGLShadowMap:",Z,"has no shadow.");continue}if(V.autoUpdate===!1&&V.needsUpdate===!1)continue;i.copy(V.mapSize);const Y=V.getFrameExtents();if(i.multiply(Y),s.copy(V.mapSize),(i.x>h||i.y>h)&&(i.x>h&&(s.x=Math.floor(h/Y.x),i.x=s.x*Y.x,V.mapSize.x=s.x),i.y>h&&(s.y=Math.floor(h/Y.y),i.y=s.y*Y.y,V.mapSize.y=s.y)),V.map===null||k===!0||G===!0){const ie=this.type!==Ci?{minFilter:gn,magFilter:gn}:{};V.map!==null&&V.map.dispose(),V.map=new xs(i.x,i.y,ie),V.map.texture.name=Z.name+".shadowMap",V.camera.updateProjectionMatrix()}r.setRenderTarget(V.map),r.clear();const ue=V.getViewportCount();for(let ie=0;ie<ue;ie++){const he=V.getViewport(ie);o.set(s.x*he.x,s.y*he.y,s.x*he.z,s.y*he.w),F.viewport(o),V.updateMatrices(Z,ie),n=V.getFrustum(),b(P,M,V.camera,Z,this.type)}V.isPointLightShadow!==!0&&this.type===Ci&&w(V,M),V.needsUpdate=!1}p=this.type,m.needsUpdate=!1,r.setRenderTarget(_,x,T)};function w(R,P){const M=e.update(v);d.defines.VSM_SAMPLES!==R.blurSamples&&(d.defines.VSM_SAMPLES=R.blurSamples,f.defines.VSM_SAMPLES=R.blurSamples,d.needsUpdate=!0,f.needsUpdate=!0),R.mapPass===null&&(R.mapPass=new xs(i.x,i.y)),d.uniforms.shadow_pass.value=R.map.texture,d.uniforms.resolution.value=R.mapSize,d.uniforms.radius.value=R.radius,r.setRenderTarget(R.mapPass),r.clear(),r.renderBufferDirect(P,null,M,d,v,null),f.uniforms.shadow_pass.value=R.mapPass.texture,f.uniforms.resolution.value=R.mapSize,f.uniforms.radius.value=R.radius,r.setRenderTarget(R.map),r.clear(),r.renderBufferDirect(P,null,M,f,v,null)}function y(R,P,M,_){let x=null;const T=M.isPointLight===!0?R.customDistanceMaterial:R.customDepthMaterial;if(T!==void 0)x=T;else if(x=M.isPointLight===!0?l:a,r.localClippingEnabled&&P.clipShadows===!0&&Array.isArray(P.clippingPlanes)&&P.clippingPlanes.length!==0||P.displacementMap&&P.displacementScale!==0||P.alphaMap&&P.alphaTest>0||P.map&&P.alphaTest>0){const F=x.uuid,k=P.uuid;let G=c[F];G===void 0&&(G={},c[F]=G);let K=G[k];K===void 0&&(K=x.clone(),G[k]=K,P.addEventListener("dispose",D)),x=K}if(x.visible=P.visible,x.wireframe=P.wireframe,_===Ci?x.side=P.shadowSide!==null?P.shadowSide:P.side:x.side=P.shadowSide!==null?P.shadowSide:u[P.side],x.alphaMap=P.alphaMap,x.alphaTest=P.alphaTest,x.map=P.map,x.clipShadows=P.clipShadows,x.clippingPlanes=P.clippingPlanes,x.clipIntersection=P.clipIntersection,x.displacementMap=P.displacementMap,x.displacementScale=P.displacementScale,x.displacementBias=P.displacementBias,x.wireframeLinewidth=P.wireframeLinewidth,x.linewidth=P.linewidth,M.isPointLight===!0&&x.isMeshDistanceMaterial===!0){const F=r.properties.get(x);F.light=M}return x}function b(R,P,M,_,x){if(R.visible===!1)return;if(R.layers.test(P.layers)&&(R.isMesh||R.isLine||R.isPoints)&&(R.castShadow||R.receiveShadow&&x===Ci)&&(!R.frustumCulled||n.intersectsObject(R))){R.modelViewMatrix.multiplyMatrices(M.matrixWorldInverse,R.matrixWorld);const k=e.update(R),G=R.material;if(Array.isArray(G)){const K=k.groups;for(let z=0,Z=K.length;z<Z;z++){const V=K[z],Y=G[V.materialIndex];if(Y&&Y.visible){const ue=y(R,Y,_,x);R.onBeforeShadow(r,R,P,M,k,ue,V),r.renderBufferDirect(M,null,k,ue,R,V),R.onAfterShadow(r,R,P,M,k,ue,V)}}}else if(G.visible){const K=y(R,G,_,x);R.onBeforeShadow(r,R,P,M,k,K,null),r.renderBufferDirect(M,null,k,K,R,null),R.onAfterShadow(r,R,P,M,k,K,null)}}const F=R.children;for(let k=0,G=F.length;k<G;k++)b(F[k],P,M,_,x)}function D(R){R.target.removeEventListener("dispose",D);for(const M in c){const _=c[M],x=R.target.uuid;x in _&&(_[x].dispose(),delete _[x])}}}const Jx={[Xl]:jl,[ql]:Kl,[Yl]:$l,[hr]:Zl,[jl]:Xl,[Kl]:ql,[$l]:Yl,[Zl]:hr};function Qx(r,e){function t(){let X=!1;const Pe=new at;let oe=null;const fe=new at(0,0,0,0);return{setMask:function(Ue){oe!==Ue&&!X&&(r.colorMask(Ue,Ue,Ue,Ue),oe=Ue)},setLocked:function(Ue){X=Ue},setClear:function(Ue,De,ot,zt,ln){ln===!0&&(Ue*=zt,De*=zt,ot*=zt),Pe.set(Ue,De,ot,zt),fe.equals(Pe)===!1&&(r.clearColor(Ue,De,ot,zt),fe.copy(Pe))},reset:function(){X=!1,oe=null,fe.set(-1,0,0,0)}}}function n(){let X=!1,Pe=!1,oe=null,fe=null,Ue=null;return{setReversed:function(De){if(Pe!==De){const ot=e.get("EXT_clip_control");Pe?ot.clipControlEXT(ot.LOWER_LEFT_EXT,ot.ZERO_TO_ONE_EXT):ot.clipControlEXT(ot.LOWER_LEFT_EXT,ot.NEGATIVE_ONE_TO_ONE_EXT);const zt=Ue;Ue=null,this.setClear(zt)}Pe=De},getReversed:function(){return Pe},setTest:function(De){De?te(r.DEPTH_TEST):ce(r.DEPTH_TEST)},setMask:function(De){oe!==De&&!X&&(r.depthMask(De),oe=De)},setFunc:function(De){if(Pe&&(De=Jx[De]),fe!==De){switch(De){case Xl:r.depthFunc(r.NEVER);break;case jl:r.depthFunc(r.ALWAYS);break;case ql:r.depthFunc(r.LESS);break;case hr:r.depthFunc(r.LEQUAL);break;case Yl:r.depthFunc(r.EQUAL);break;case Zl:r.depthFunc(r.GEQUAL);break;case Kl:r.depthFunc(r.GREATER);break;case $l:r.depthFunc(r.NOTEQUAL);break;default:r.depthFunc(r.LEQUAL)}fe=De}},setLocked:function(De){X=De},setClear:function(De){Ue!==De&&(Pe&&(De=1-De),r.clearDepth(De),Ue=De)},reset:function(){X=!1,oe=null,fe=null,Ue=null,Pe=!1}}}function i(){let X=!1,Pe=null,oe=null,fe=null,Ue=null,De=null,ot=null,zt=null,ln=null;return{setTest:function(ut){X||(ut?te(r.STENCIL_TEST):ce(r.STENCIL_TEST))},setMask:function(ut){Pe!==ut&&!X&&(r.stencilMask(ut),Pe=ut)},setFunc:function(ut,Pn,$n){(oe!==ut||fe!==Pn||Ue!==$n)&&(r.stencilFunc(ut,Pn,$n),oe=ut,fe=Pn,Ue=$n)},setOp:function(ut,Pn,$n){(De!==ut||ot!==Pn||zt!==$n)&&(r.stencilOp(ut,Pn,$n),De=ut,ot=Pn,zt=$n)},setLocked:function(ut){X=ut},setClear:function(ut){ln!==ut&&(r.clearStencil(ut),ln=ut)},reset:function(){X=!1,Pe=null,oe=null,fe=null,Ue=null,De=null,ot=null,zt=null,ln=null}}}const s=new t,o=new n,a=new i,l=new WeakMap,c=new WeakMap;let h={},u={},d=new WeakMap,f=[],g=null,v=!1,m=null,p=null,w=null,y=null,b=null,D=null,R=null,P=new ke(0,0,0),M=0,_=!1,x=null,T=null,F=null,k=null,G=null;const K=r.getParameter(r.MAX_COMBINED_TEXTURE_IMAGE_UNITS);let z=!1,Z=0;const V=r.getParameter(r.VERSION);V.indexOf("WebGL")!==-1?(Z=parseFloat(/^WebGL (\d)/.exec(V)[1]),z=Z>=1):V.indexOf("OpenGL ES")!==-1&&(Z=parseFloat(/^OpenGL ES (\d)/.exec(V)[1]),z=Z>=2);let Y=null,ue={};const ie=r.getParameter(r.SCISSOR_BOX),he=r.getParameter(r.VIEWPORT),se=new at().fromArray(ie),H=new at().fromArray(he);function j(X,Pe,oe,fe){const Ue=new Uint8Array(4),De=r.createTexture();r.bindTexture(X,De),r.texParameteri(X,r.TEXTURE_MIN_FILTER,r.NEAREST),r.texParameteri(X,r.TEXTURE_MAG_FILTER,r.NEAREST);for(let ot=0;ot<oe;ot++)X===r.TEXTURE_3D||X===r.TEXTURE_2D_ARRAY?r.texImage3D(Pe,0,r.RGBA,1,1,fe,0,r.RGBA,r.UNSIGNED_BYTE,Ue):r.texImage2D(Pe+ot,0,r.RGBA,1,1,0,r.RGBA,r.UNSIGNED_BYTE,Ue);return De}const J={};J[r.TEXTURE_2D]=j(r.TEXTURE_2D,r.TEXTURE_2D,1),J[r.TEXTURE_CUBE_MAP]=j(r.TEXTURE_CUBE_MAP,r.TEXTURE_CUBE_MAP_POSITIVE_X,6),J[r.TEXTURE_2D_ARRAY]=j(r.TEXTURE_2D_ARRAY,r.TEXTURE_2D_ARRAY,1,1),J[r.TEXTURE_3D]=j(r.TEXTURE_3D,r.TEXTURE_3D,1,1),s.setClear(0,0,0,1),o.setClear(1),a.setClear(0),te(r.DEPTH_TEST),o.setFunc(hr),Le(!1),tt(ph),te(r.CULL_FACE),B(Ji);function te(X){h[X]!==!0&&(r.enable(X),h[X]=!0)}function ce(X){h[X]!==!1&&(r.disable(X),h[X]=!1)}function be(X,Pe){return u[X]!==Pe?(r.bindFramebuffer(X,Pe),u[X]=Pe,X===r.DRAW_FRAMEBUFFER&&(u[r.FRAMEBUFFER]=Pe),X===r.FRAMEBUFFER&&(u[r.DRAW_FRAMEBUFFER]=Pe),!0):!1}function xe(X,Pe){let oe=f,fe=!1;if(X){oe=d.get(Pe),oe===void 0&&(oe=[],d.set(Pe,oe));const Ue=X.textures;if(oe.length!==Ue.length||oe[0]!==r.COLOR_ATTACHMENT0){for(let De=0,ot=Ue.length;De<ot;De++)oe[De]=r.COLOR_ATTACHMENT0+De;oe.length=Ue.length,fe=!0}}else oe[0]!==r.BACK&&(oe[0]=r.BACK,fe=!0);fe&&r.drawBuffers(oe)}function Re(X){return g!==X?(r.useProgram(X),g=X,!0):!1}const Je={[us]:r.FUNC_ADD,[Jf]:r.FUNC_SUBTRACT,[Qf]:r.FUNC_REVERSE_SUBTRACT};Je[ep]=r.MIN,Je[tp]=r.MAX;const We={[np]:r.ZERO,[ip]:r.ONE,[sp]:r.SRC_COLOR,[Gl]:r.SRC_ALPHA,[hp]:r.SRC_ALPHA_SATURATE,[lp]:r.DST_COLOR,[op]:r.DST_ALPHA,[rp]:r.ONE_MINUS_SRC_COLOR,[Wl]:r.ONE_MINUS_SRC_ALPHA,[cp]:r.ONE_MINUS_DST_COLOR,[ap]:r.ONE_MINUS_DST_ALPHA,[up]:r.CONSTANT_COLOR,[dp]:r.ONE_MINUS_CONSTANT_COLOR,[fp]:r.CONSTANT_ALPHA,[pp]:r.ONE_MINUS_CONSTANT_ALPHA};function B(X,Pe,oe,fe,Ue,De,ot,zt,ln,ut){if(X===Ji){v===!0&&(ce(r.BLEND),v=!1);return}if(v===!1&&(te(r.BLEND),v=!0),X!==$f){if(X!==m||ut!==_){if((p!==us||b!==us)&&(r.blendEquation(r.FUNC_ADD),p=us,b=us),ut)switch(X){case ar:r.blendFuncSeparate(r.ONE,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case mh:r.blendFunc(r.ONE,r.ONE);break;case gh:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case _h:r.blendFuncSeparate(r.ZERO,r.SRC_COLOR,r.ZERO,r.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}else switch(X){case ar:r.blendFuncSeparate(r.SRC_ALPHA,r.ONE_MINUS_SRC_ALPHA,r.ONE,r.ONE_MINUS_SRC_ALPHA);break;case mh:r.blendFunc(r.SRC_ALPHA,r.ONE);break;case gh:r.blendFuncSeparate(r.ZERO,r.ONE_MINUS_SRC_COLOR,r.ZERO,r.ONE);break;case _h:r.blendFunc(r.ZERO,r.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",X);break}w=null,y=null,D=null,R=null,P.set(0,0,0),M=0,m=X,_=ut}return}Ue=Ue||Pe,De=De||oe,ot=ot||fe,(Pe!==p||Ue!==b)&&(r.blendEquationSeparate(Je[Pe],Je[Ue]),p=Pe,b=Ue),(oe!==w||fe!==y||De!==D||ot!==R)&&(r.blendFuncSeparate(We[oe],We[fe],We[De],We[ot]),w=oe,y=fe,D=De,R=ot),(zt.equals(P)===!1||ln!==M)&&(r.blendColor(zt.r,zt.g,zt.b,ln),P.copy(zt),M=ln),m=X,_=!1}function ht(X,Pe){X.side===Xn?ce(r.CULL_FACE):te(r.CULL_FACE);let oe=X.side===Un;Pe&&(oe=!oe),Le(oe),X.blending===ar&&X.transparent===!1?B(Ji):B(X.blending,X.blendEquation,X.blendSrc,X.blendDst,X.blendEquationAlpha,X.blendSrcAlpha,X.blendDstAlpha,X.blendColor,X.blendAlpha,X.premultipliedAlpha),o.setFunc(X.depthFunc),o.setTest(X.depthTest),o.setMask(X.depthWrite),s.setMask(X.colorWrite);const fe=X.stencilWrite;a.setTest(fe),fe&&(a.setMask(X.stencilWriteMask),a.setFunc(X.stencilFunc,X.stencilRef,X.stencilFuncMask),a.setOp(X.stencilFail,X.stencilZFail,X.stencilZPass)),Qe(X.polygonOffset,X.polygonOffsetFactor,X.polygonOffsetUnits),X.alphaToCoverage===!0?te(r.SAMPLE_ALPHA_TO_COVERAGE):ce(r.SAMPLE_ALPHA_TO_COVERAGE)}function Le(X){x!==X&&(X?r.frontFace(r.CW):r.frontFace(r.CCW),x=X)}function tt(X){X!==Yf?(te(r.CULL_FACE),X!==T&&(X===ph?r.cullFace(r.BACK):X===Zf?r.cullFace(r.FRONT):r.cullFace(r.FRONT_AND_BACK))):ce(r.CULL_FACE),T=X}function me(X){X!==F&&(z&&r.lineWidth(X),F=X)}function Qe(X,Pe,oe){X?(te(r.POLYGON_OFFSET_FILL),(k!==Pe||G!==oe)&&(r.polygonOffset(Pe,oe),k=Pe,G=oe)):ce(r.POLYGON_OFFSET_FILL)}function ze(X){X?te(r.SCISSOR_TEST):ce(r.SCISSOR_TEST)}function O(X){X===void 0&&(X=r.TEXTURE0+K-1),Y!==X&&(r.activeTexture(X),Y=X)}function A(X,Pe,oe){oe===void 0&&(Y===null?oe=r.TEXTURE0+K-1:oe=Y);let fe=ue[oe];fe===void 0&&(fe={type:void 0,texture:void 0},ue[oe]=fe),(fe.type!==X||fe.texture!==Pe)&&(Y!==oe&&(r.activeTexture(oe),Y=oe),r.bindTexture(X,Pe||J[X]),fe.type=X,fe.texture=Pe)}function $(){const X=ue[Y];X!==void 0&&X.type!==void 0&&(r.bindTexture(X.type,null),X.type=void 0,X.texture=void 0)}function ae(){try{r.compressedTexImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function de(){try{r.compressedTexImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function re(){try{r.texSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Ce(){try{r.texSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Me(){try{r.compressedTexSubImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Fe(){try{r.compressedTexSubImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function gt(){try{r.texStorage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function ge(){try{r.texStorage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function Te(){try{r.texImage2D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function qe(){try{r.texImage3D(...arguments)}catch(X){console.error("THREE.WebGLState:",X)}}function et(X){se.equals(X)===!1&&(r.scissor(X.x,X.y,X.z,X.w),se.copy(X))}function He(X){H.equals(X)===!1&&(r.viewport(X.x,X.y,X.z,X.w),H.copy(X))}function xt(X,Pe){let oe=c.get(Pe);oe===void 0&&(oe=new WeakMap,c.set(Pe,oe));let fe=oe.get(X);fe===void 0&&(fe=r.getUniformBlockIndex(Pe,X.name),oe.set(X,fe))}function lt(X,Pe){const fe=c.get(Pe).get(X);l.get(Pe)!==fe&&(r.uniformBlockBinding(Pe,fe,X.__bindingPointIndex),l.set(Pe,fe))}function Lt(){r.disable(r.BLEND),r.disable(r.CULL_FACE),r.disable(r.DEPTH_TEST),r.disable(r.POLYGON_OFFSET_FILL),r.disable(r.SCISSOR_TEST),r.disable(r.STENCIL_TEST),r.disable(r.SAMPLE_ALPHA_TO_COVERAGE),r.blendEquation(r.FUNC_ADD),r.blendFunc(r.ONE,r.ZERO),r.blendFuncSeparate(r.ONE,r.ZERO,r.ONE,r.ZERO),r.blendColor(0,0,0,0),r.colorMask(!0,!0,!0,!0),r.clearColor(0,0,0,0),r.depthMask(!0),r.depthFunc(r.LESS),o.setReversed(!1),r.clearDepth(1),r.stencilMask(4294967295),r.stencilFunc(r.ALWAYS,0,4294967295),r.stencilOp(r.KEEP,r.KEEP,r.KEEP),r.clearStencil(0),r.cullFace(r.BACK),r.frontFace(r.CCW),r.polygonOffset(0,0),r.activeTexture(r.TEXTURE0),r.bindFramebuffer(r.FRAMEBUFFER,null),r.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),r.bindFramebuffer(r.READ_FRAMEBUFFER,null),r.useProgram(null),r.lineWidth(1),r.scissor(0,0,r.canvas.width,r.canvas.height),r.viewport(0,0,r.canvas.width,r.canvas.height),h={},Y=null,ue={},u={},d=new WeakMap,f=[],g=null,v=!1,m=null,p=null,w=null,y=null,b=null,D=null,R=null,P=new ke(0,0,0),M=0,_=!1,x=null,T=null,F=null,k=null,G=null,se.set(0,0,r.canvas.width,r.canvas.height),H.set(0,0,r.canvas.width,r.canvas.height),s.reset(),o.reset(),a.reset()}return{buffers:{color:s,depth:o,stencil:a},enable:te,disable:ce,bindFramebuffer:be,drawBuffers:xe,useProgram:Re,setBlending:B,setMaterial:ht,setFlipSided:Le,setCullFace:tt,setLineWidth:me,setPolygonOffset:Qe,setScissorTest:ze,activeTexture:O,bindTexture:A,unbindTexture:$,compressedTexImage2D:ae,compressedTexImage3D:de,texImage2D:Te,texImage3D:qe,updateUBOMapping:xt,uniformBlockBinding:lt,texStorage2D:gt,texStorage3D:ge,texSubImage2D:re,texSubImage3D:Ce,compressedTexSubImage2D:Me,compressedTexSubImage3D:Fe,scissor:et,viewport:He,reset:Lt}}function ey(r,e,t,n,i,s,o){const a=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator>"u"?!1:/OculusBrowser/g.test(navigator.userAgent),c=new ye,h=new WeakMap;let u;const d=new WeakMap;let f=!1;try{f=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function g(O,A){return f?new OffscreenCanvas(O,A):jr("canvas")}function v(O,A,$){let ae=1;const de=ze(O);if((de.width>$||de.height>$)&&(ae=$/Math.max(de.width,de.height)),ae<1)if(typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&O instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&O instanceof ImageBitmap||typeof VideoFrame<"u"&&O instanceof VideoFrame){const re=Math.floor(ae*de.width),Ce=Math.floor(ae*de.height);u===void 0&&(u=g(re,Ce));const Me=A?g(re,Ce):u;return Me.width=re,Me.height=Ce,Me.getContext("2d").drawImage(O,0,0,re,Ce),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+de.width+"x"+de.height+") to ("+re+"x"+Ce+")."),Me}else return"data"in O&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+de.width+"x"+de.height+")."),O;return O}function m(O){return O.generateMipmaps}function p(O){r.generateMipmap(O)}function w(O){return O.isWebGLCubeRenderTarget?r.TEXTURE_CUBE_MAP:O.isWebGL3DRenderTarget?r.TEXTURE_3D:O.isWebGLArrayRenderTarget||O.isCompressedArrayTexture?r.TEXTURE_2D_ARRAY:r.TEXTURE_2D}function y(O,A,$,ae,de=!1){if(O!==null){if(r[O]!==void 0)return r[O];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+O+"'")}let re=A;if(A===r.RED&&($===r.FLOAT&&(re=r.R32F),$===r.HALF_FLOAT&&(re=r.R16F),$===r.UNSIGNED_BYTE&&(re=r.R8)),A===r.RED_INTEGER&&($===r.UNSIGNED_BYTE&&(re=r.R8UI),$===r.UNSIGNED_SHORT&&(re=r.R16UI),$===r.UNSIGNED_INT&&(re=r.R32UI),$===r.BYTE&&(re=r.R8I),$===r.SHORT&&(re=r.R16I),$===r.INT&&(re=r.R32I)),A===r.RG&&($===r.FLOAT&&(re=r.RG32F),$===r.HALF_FLOAT&&(re=r.RG16F),$===r.UNSIGNED_BYTE&&(re=r.RG8)),A===r.RG_INTEGER&&($===r.UNSIGNED_BYTE&&(re=r.RG8UI),$===r.UNSIGNED_SHORT&&(re=r.RG16UI),$===r.UNSIGNED_INT&&(re=r.RG32UI),$===r.BYTE&&(re=r.RG8I),$===r.SHORT&&(re=r.RG16I),$===r.INT&&(re=r.RG32I)),A===r.RGB_INTEGER&&($===r.UNSIGNED_BYTE&&(re=r.RGB8UI),$===r.UNSIGNED_SHORT&&(re=r.RGB16UI),$===r.UNSIGNED_INT&&(re=r.RGB32UI),$===r.BYTE&&(re=r.RGB8I),$===r.SHORT&&(re=r.RGB16I),$===r.INT&&(re=r.RGB32I)),A===r.RGBA_INTEGER&&($===r.UNSIGNED_BYTE&&(re=r.RGBA8UI),$===r.UNSIGNED_SHORT&&(re=r.RGBA16UI),$===r.UNSIGNED_INT&&(re=r.RGBA32UI),$===r.BYTE&&(re=r.RGBA8I),$===r.SHORT&&(re=r.RGBA16I),$===r.INT&&(re=r.RGBA32I)),A===r.RGB&&$===r.UNSIGNED_INT_5_9_9_9_REV&&(re=r.RGB9_E5),A===r.RGBA){const Ce=de?xa:rt.getTransfer(ae);$===r.FLOAT&&(re=r.RGBA32F),$===r.HALF_FLOAT&&(re=r.RGBA16F),$===r.UNSIGNED_BYTE&&(re=Ce===Nt?r.SRGB8_ALPHA8:r.RGBA8),$===r.UNSIGNED_SHORT_4_4_4_4&&(re=r.RGBA4),$===r.UNSIGNED_SHORT_5_5_5_1&&(re=r.RGB5_A1)}return(re===r.R16F||re===r.R32F||re===r.RG16F||re===r.RG32F||re===r.RGBA16F||re===r.RGBA32F)&&e.get("EXT_color_buffer_float"),re}function b(O,A){let $;return O?A===null||A===vs||A===fr?$=r.DEPTH24_STENCIL8:A===pi?$=r.DEPTH32F_STENCIL8:A===Xr&&($=r.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):A===null||A===vs||A===fr?$=r.DEPTH_COMPONENT24:A===pi?$=r.DEPTH_COMPONENT32F:A===Xr&&($=r.DEPTH_COMPONENT16),$}function D(O,A){return m(O)===!0||O.isFramebufferTexture&&O.minFilter!==gn&&O.minFilter!==mn?Math.log2(Math.max(A.width,A.height))+1:O.mipmaps!==void 0&&O.mipmaps.length>0?O.mipmaps.length:O.isCompressedTexture&&Array.isArray(O.image)?A.mipmaps.length:1}function R(O){const A=O.target;A.removeEventListener("dispose",R),M(A),A.isVideoTexture&&h.delete(A)}function P(O){const A=O.target;A.removeEventListener("dispose",P),x(A)}function M(O){const A=n.get(O);if(A.__webglInit===void 0)return;const $=O.source,ae=d.get($);if(ae){const de=ae[A.__cacheKey];de.usedTimes--,de.usedTimes===0&&_(O),Object.keys(ae).length===0&&d.delete($)}n.remove(O)}function _(O){const A=n.get(O);r.deleteTexture(A.__webglTexture);const $=O.source,ae=d.get($);delete ae[A.__cacheKey],o.memory.textures--}function x(O){const A=n.get(O);if(O.depthTexture&&(O.depthTexture.dispose(),n.remove(O.depthTexture)),O.isWebGLCubeRenderTarget)for(let ae=0;ae<6;ae++){if(Array.isArray(A.__webglFramebuffer[ae]))for(let de=0;de<A.__webglFramebuffer[ae].length;de++)r.deleteFramebuffer(A.__webglFramebuffer[ae][de]);else r.deleteFramebuffer(A.__webglFramebuffer[ae]);A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer[ae])}else{if(Array.isArray(A.__webglFramebuffer))for(let ae=0;ae<A.__webglFramebuffer.length;ae++)r.deleteFramebuffer(A.__webglFramebuffer[ae]);else r.deleteFramebuffer(A.__webglFramebuffer);if(A.__webglDepthbuffer&&r.deleteRenderbuffer(A.__webglDepthbuffer),A.__webglMultisampledFramebuffer&&r.deleteFramebuffer(A.__webglMultisampledFramebuffer),A.__webglColorRenderbuffer)for(let ae=0;ae<A.__webglColorRenderbuffer.length;ae++)A.__webglColorRenderbuffer[ae]&&r.deleteRenderbuffer(A.__webglColorRenderbuffer[ae]);A.__webglDepthRenderbuffer&&r.deleteRenderbuffer(A.__webglDepthRenderbuffer)}const $=O.textures;for(let ae=0,de=$.length;ae<de;ae++){const re=n.get($[ae]);re.__webglTexture&&(r.deleteTexture(re.__webglTexture),o.memory.textures--),n.remove($[ae])}n.remove(O)}let T=0;function F(){T=0}function k(){const O=T;return O>=i.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+O+" texture units while this GPU supports only "+i.maxTextures),T+=1,O}function G(O){const A=[];return A.push(O.wrapS),A.push(O.wrapT),A.push(O.wrapR||0),A.push(O.magFilter),A.push(O.minFilter),A.push(O.anisotropy),A.push(O.internalFormat),A.push(O.format),A.push(O.type),A.push(O.generateMipmaps),A.push(O.premultiplyAlpha),A.push(O.flipY),A.push(O.unpackAlignment),A.push(O.colorSpace),A.join()}function K(O,A){const $=n.get(O);if(O.isVideoTexture&&me(O),O.isRenderTargetTexture===!1&&O.version>0&&$.__version!==O.version){const ae=O.image;if(ae===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else if(ae.complete===!1)console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");else{H($,O,A);return}}t.bindTexture(r.TEXTURE_2D,$.__webglTexture,r.TEXTURE0+A)}function z(O,A){const $=n.get(O);if(O.version>0&&$.__version!==O.version){H($,O,A);return}t.bindTexture(r.TEXTURE_2D_ARRAY,$.__webglTexture,r.TEXTURE0+A)}function Z(O,A){const $=n.get(O);if(O.version>0&&$.__version!==O.version){H($,O,A);return}t.bindTexture(r.TEXTURE_3D,$.__webglTexture,r.TEXTURE0+A)}function V(O,A){const $=n.get(O);if(O.version>0&&$.__version!==O.version){j($,O,A);return}t.bindTexture(r.TEXTURE_CUBE_MAP,$.__webglTexture,r.TEXTURE0+A)}const Y={[Li]:r.REPEAT,[Bn]:r.CLAMP_TO_EDGE,[Ql]:r.MIRRORED_REPEAT},ue={[gn]:r.NEAREST,[Ep]:r.NEAREST_MIPMAP_NEAREST,[fo]:r.NEAREST_MIPMAP_LINEAR,[mn]:r.LINEAR,[ja]:r.LINEAR_MIPMAP_NEAREST,[Di]:r.LINEAR_MIPMAP_LINEAR},ie={[Pp]:r.NEVER,[Fp]:r.ALWAYS,[Lp]:r.LESS,[Gd]:r.LEQUAL,[Dp]:r.EQUAL,[Up]:r.GEQUAL,[Ip]:r.GREATER,[Np]:r.NOTEQUAL};function he(O,A){if(A.type===pi&&e.has("OES_texture_float_linear")===!1&&(A.magFilter===mn||A.magFilter===ja||A.magFilter===fo||A.magFilter===Di||A.minFilter===mn||A.minFilter===ja||A.minFilter===fo||A.minFilter===Di)&&console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),r.texParameteri(O,r.TEXTURE_WRAP_S,Y[A.wrapS]),r.texParameteri(O,r.TEXTURE_WRAP_T,Y[A.wrapT]),(O===r.TEXTURE_3D||O===r.TEXTURE_2D_ARRAY)&&r.texParameteri(O,r.TEXTURE_WRAP_R,Y[A.wrapR]),r.texParameteri(O,r.TEXTURE_MAG_FILTER,ue[A.magFilter]),r.texParameteri(O,r.TEXTURE_MIN_FILTER,ue[A.minFilter]),A.compareFunction&&(r.texParameteri(O,r.TEXTURE_COMPARE_MODE,r.COMPARE_REF_TO_TEXTURE),r.texParameteri(O,r.TEXTURE_COMPARE_FUNC,ie[A.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(A.magFilter===gn||A.minFilter!==fo&&A.minFilter!==Di||A.type===pi&&e.has("OES_texture_float_linear")===!1)return;if(A.anisotropy>1||n.get(A).__currentAnisotropy){const $=e.get("EXT_texture_filter_anisotropic");r.texParameterf(O,$.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(A.anisotropy,i.getMaxAnisotropy())),n.get(A).__currentAnisotropy=A.anisotropy}}}function se(O,A){let $=!1;O.__webglInit===void 0&&(O.__webglInit=!0,A.addEventListener("dispose",R));const ae=A.source;let de=d.get(ae);de===void 0&&(de={},d.set(ae,de));const re=G(A);if(re!==O.__cacheKey){de[re]===void 0&&(de[re]={texture:r.createTexture(),usedTimes:0},o.memory.textures++,$=!0),de[re].usedTimes++;const Ce=de[O.__cacheKey];Ce!==void 0&&(de[O.__cacheKey].usedTimes--,Ce.usedTimes===0&&_(A)),O.__cacheKey=re,O.__webglTexture=de[re].texture}return $}function H(O,A,$){let ae=r.TEXTURE_2D;(A.isDataArrayTexture||A.isCompressedArrayTexture)&&(ae=r.TEXTURE_2D_ARRAY),A.isData3DTexture&&(ae=r.TEXTURE_3D);const de=se(O,A),re=A.source;t.bindTexture(ae,O.__webglTexture,r.TEXTURE0+$);const Ce=n.get(re);if(re.version!==Ce.__version||de===!0){t.activeTexture(r.TEXTURE0+$);const Me=rt.getPrimaries(rt.workingColorSpace),Fe=A.colorSpace===Ki?null:rt.getPrimaries(A.colorSpace),gt=A.colorSpace===Ki||Me===Fe?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,gt);let ge=v(A.image,!1,i.maxTextureSize);ge=Qe(A,ge);const Te=s.convert(A.format,A.colorSpace),qe=s.convert(A.type);let et=y(A.internalFormat,Te,qe,A.colorSpace,A.isVideoTexture);he(ae,A);let He;const xt=A.mipmaps,lt=A.isVideoTexture!==!0,Lt=Ce.__version===void 0||de===!0,X=re.dataReady,Pe=D(A,ge);if(A.isDepthTexture)et=b(A.format===pr,A.type),Lt&&(lt?t.texStorage2D(r.TEXTURE_2D,1,et,ge.width,ge.height):t.texImage2D(r.TEXTURE_2D,0,et,ge.width,ge.height,0,Te,qe,null));else if(A.isDataTexture)if(xt.length>0){lt&&Lt&&t.texStorage2D(r.TEXTURE_2D,Pe,et,xt[0].width,xt[0].height);for(let oe=0,fe=xt.length;oe<fe;oe++)He=xt[oe],lt?X&&t.texSubImage2D(r.TEXTURE_2D,oe,0,0,He.width,He.height,Te,qe,He.data):t.texImage2D(r.TEXTURE_2D,oe,et,He.width,He.height,0,Te,qe,He.data);A.generateMipmaps=!1}else lt?(Lt&&t.texStorage2D(r.TEXTURE_2D,Pe,et,ge.width,ge.height),X&&t.texSubImage2D(r.TEXTURE_2D,0,0,0,ge.width,ge.height,Te,qe,ge.data)):t.texImage2D(r.TEXTURE_2D,0,et,ge.width,ge.height,0,Te,qe,ge.data);else if(A.isCompressedTexture)if(A.isCompressedArrayTexture){lt&&Lt&&t.texStorage3D(r.TEXTURE_2D_ARRAY,Pe,et,xt[0].width,xt[0].height,ge.depth);for(let oe=0,fe=xt.length;oe<fe;oe++)if(He=xt[oe],A.format!==wn)if(Te!==null)if(lt){if(X)if(A.layerUpdates.size>0){const Ue=vu(He.width,He.height,A.format,A.type);for(const De of A.layerUpdates){const ot=He.data.subarray(De*Ue/He.data.BYTES_PER_ELEMENT,(De+1)*Ue/He.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,oe,0,0,De,He.width,He.height,1,Te,ot)}A.clearLayerUpdates()}else t.compressedTexSubImage3D(r.TEXTURE_2D_ARRAY,oe,0,0,0,He.width,He.height,ge.depth,Te,He.data)}else t.compressedTexImage3D(r.TEXTURE_2D_ARRAY,oe,et,He.width,He.height,ge.depth,0,He.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else lt?X&&t.texSubImage3D(r.TEXTURE_2D_ARRAY,oe,0,0,0,He.width,He.height,ge.depth,Te,qe,He.data):t.texImage3D(r.TEXTURE_2D_ARRAY,oe,et,He.width,He.height,ge.depth,0,Te,qe,He.data)}else{lt&&Lt&&t.texStorage2D(r.TEXTURE_2D,Pe,et,xt[0].width,xt[0].height);for(let oe=0,fe=xt.length;oe<fe;oe++)He=xt[oe],A.format!==wn?Te!==null?lt?X&&t.compressedTexSubImage2D(r.TEXTURE_2D,oe,0,0,He.width,He.height,Te,He.data):t.compressedTexImage2D(r.TEXTURE_2D,oe,et,He.width,He.height,0,He.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):lt?X&&t.texSubImage2D(r.TEXTURE_2D,oe,0,0,He.width,He.height,Te,qe,He.data):t.texImage2D(r.TEXTURE_2D,oe,et,He.width,He.height,0,Te,qe,He.data)}else if(A.isDataArrayTexture)if(lt){if(Lt&&t.texStorage3D(r.TEXTURE_2D_ARRAY,Pe,et,ge.width,ge.height,ge.depth),X)if(A.layerUpdates.size>0){const oe=vu(ge.width,ge.height,A.format,A.type);for(const fe of A.layerUpdates){const Ue=ge.data.subarray(fe*oe/ge.data.BYTES_PER_ELEMENT,(fe+1)*oe/ge.data.BYTES_PER_ELEMENT);t.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,fe,ge.width,ge.height,1,Te,qe,Ue)}A.clearLayerUpdates()}else t.texSubImage3D(r.TEXTURE_2D_ARRAY,0,0,0,0,ge.width,ge.height,ge.depth,Te,qe,ge.data)}else t.texImage3D(r.TEXTURE_2D_ARRAY,0,et,ge.width,ge.height,ge.depth,0,Te,qe,ge.data);else if(A.isData3DTexture)lt?(Lt&&t.texStorage3D(r.TEXTURE_3D,Pe,et,ge.width,ge.height,ge.depth),X&&t.texSubImage3D(r.TEXTURE_3D,0,0,0,0,ge.width,ge.height,ge.depth,Te,qe,ge.data)):t.texImage3D(r.TEXTURE_3D,0,et,ge.width,ge.height,ge.depth,0,Te,qe,ge.data);else if(A.isFramebufferTexture){if(Lt)if(lt)t.texStorage2D(r.TEXTURE_2D,Pe,et,ge.width,ge.height);else{let oe=ge.width,fe=ge.height;for(let Ue=0;Ue<Pe;Ue++)t.texImage2D(r.TEXTURE_2D,Ue,et,oe,fe,0,Te,qe,null),oe>>=1,fe>>=1}}else if(xt.length>0){if(lt&&Lt){const oe=ze(xt[0]);t.texStorage2D(r.TEXTURE_2D,Pe,et,oe.width,oe.height)}for(let oe=0,fe=xt.length;oe<fe;oe++)He=xt[oe],lt?X&&t.texSubImage2D(r.TEXTURE_2D,oe,0,0,Te,qe,He):t.texImage2D(r.TEXTURE_2D,oe,et,Te,qe,He);A.generateMipmaps=!1}else if(lt){if(Lt){const oe=ze(ge);t.texStorage2D(r.TEXTURE_2D,Pe,et,oe.width,oe.height)}X&&t.texSubImage2D(r.TEXTURE_2D,0,0,0,Te,qe,ge)}else t.texImage2D(r.TEXTURE_2D,0,et,Te,qe,ge);m(A)&&p(ae),Ce.__version=re.version,A.onUpdate&&A.onUpdate(A)}O.__version=A.version}function j(O,A,$){if(A.image.length!==6)return;const ae=se(O,A),de=A.source;t.bindTexture(r.TEXTURE_CUBE_MAP,O.__webglTexture,r.TEXTURE0+$);const re=n.get(de);if(de.version!==re.__version||ae===!0){t.activeTexture(r.TEXTURE0+$);const Ce=rt.getPrimaries(rt.workingColorSpace),Me=A.colorSpace===Ki?null:rt.getPrimaries(A.colorSpace),Fe=A.colorSpace===Ki||Ce===Me?r.NONE:r.BROWSER_DEFAULT_WEBGL;r.pixelStorei(r.UNPACK_FLIP_Y_WEBGL,A.flipY),r.pixelStorei(r.UNPACK_PREMULTIPLY_ALPHA_WEBGL,A.premultiplyAlpha),r.pixelStorei(r.UNPACK_ALIGNMENT,A.unpackAlignment),r.pixelStorei(r.UNPACK_COLORSPACE_CONVERSION_WEBGL,Fe);const gt=A.isCompressedTexture||A.image[0].isCompressedTexture,ge=A.image[0]&&A.image[0].isDataTexture,Te=[];for(let fe=0;fe<6;fe++)!gt&&!ge?Te[fe]=v(A.image[fe],!0,i.maxCubemapSize):Te[fe]=ge?A.image[fe].image:A.image[fe],Te[fe]=Qe(A,Te[fe]);const qe=Te[0],et=s.convert(A.format,A.colorSpace),He=s.convert(A.type),xt=y(A.internalFormat,et,He,A.colorSpace),lt=A.isVideoTexture!==!0,Lt=re.__version===void 0||ae===!0,X=de.dataReady;let Pe=D(A,qe);he(r.TEXTURE_CUBE_MAP,A);let oe;if(gt){lt&&Lt&&t.texStorage2D(r.TEXTURE_CUBE_MAP,Pe,xt,qe.width,qe.height);for(let fe=0;fe<6;fe++){oe=Te[fe].mipmaps;for(let Ue=0;Ue<oe.length;Ue++){const De=oe[Ue];A.format!==wn?et!==null?lt?X&&t.compressedTexSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,0,0,De.width,De.height,et,De.data):t.compressedTexImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,xt,De.width,De.height,0,De.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):lt?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,0,0,De.width,De.height,et,He,De.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue,xt,De.width,De.height,0,et,He,De.data)}}}else{if(oe=A.mipmaps,lt&&Lt){oe.length>0&&Pe++;const fe=ze(Te[0]);t.texStorage2D(r.TEXTURE_CUBE_MAP,Pe,xt,fe.width,fe.height)}for(let fe=0;fe<6;fe++)if(ge){lt?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,Te[fe].width,Te[fe].height,et,He,Te[fe].data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,xt,Te[fe].width,Te[fe].height,0,et,He,Te[fe].data);for(let Ue=0;Ue<oe.length;Ue++){const ot=oe[Ue].image[fe].image;lt?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,0,0,ot.width,ot.height,et,He,ot.data):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,xt,ot.width,ot.height,0,et,He,ot.data)}}else{lt?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,0,0,et,He,Te[fe]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,0,xt,et,He,Te[fe]);for(let Ue=0;Ue<oe.length;Ue++){const De=oe[Ue];lt?X&&t.texSubImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,0,0,et,He,De.image[fe]):t.texImage2D(r.TEXTURE_CUBE_MAP_POSITIVE_X+fe,Ue+1,xt,et,He,De.image[fe])}}}m(A)&&p(r.TEXTURE_CUBE_MAP),re.__version=de.version,A.onUpdate&&A.onUpdate(A)}O.__version=A.version}function J(O,A,$,ae,de,re){const Ce=s.convert($.format,$.colorSpace),Me=s.convert($.type),Fe=y($.internalFormat,Ce,Me,$.colorSpace),gt=n.get(A),ge=n.get($);if(ge.__renderTarget=A,!gt.__hasExternalTextures){const Te=Math.max(1,A.width>>re),qe=Math.max(1,A.height>>re);de===r.TEXTURE_3D||de===r.TEXTURE_2D_ARRAY?t.texImage3D(de,re,Fe,Te,qe,A.depth,0,Ce,Me,null):t.texImage2D(de,re,Fe,Te,qe,0,Ce,Me,null)}t.bindFramebuffer(r.FRAMEBUFFER,O),tt(A)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,ae,de,ge.__webglTexture,0,Le(A)):(de===r.TEXTURE_2D||de>=r.TEXTURE_CUBE_MAP_POSITIVE_X&&de<=r.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&r.framebufferTexture2D(r.FRAMEBUFFER,ae,de,ge.__webglTexture,re),t.bindFramebuffer(r.FRAMEBUFFER,null)}function te(O,A,$){if(r.bindRenderbuffer(r.RENDERBUFFER,O),A.depthBuffer){const ae=A.depthTexture,de=ae&&ae.isDepthTexture?ae.type:null,re=b(A.stencilBuffer,de),Ce=A.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Me=Le(A);tt(A)?a.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,Me,re,A.width,A.height):$?r.renderbufferStorageMultisample(r.RENDERBUFFER,Me,re,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,re,A.width,A.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,Ce,r.RENDERBUFFER,O)}else{const ae=A.textures;for(let de=0;de<ae.length;de++){const re=ae[de],Ce=s.convert(re.format,re.colorSpace),Me=s.convert(re.type),Fe=y(re.internalFormat,Ce,Me,re.colorSpace),gt=Le(A);$&&tt(A)===!1?r.renderbufferStorageMultisample(r.RENDERBUFFER,gt,Fe,A.width,A.height):tt(A)?a.renderbufferStorageMultisampleEXT(r.RENDERBUFFER,gt,Fe,A.width,A.height):r.renderbufferStorage(r.RENDERBUFFER,Fe,A.width,A.height)}}r.bindRenderbuffer(r.RENDERBUFFER,null)}function ce(O,A){if(A&&A.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(r.FRAMEBUFFER,O),!(A.depthTexture&&A.depthTexture.isDepthTexture))throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");const ae=n.get(A.depthTexture);ae.__renderTarget=A,(!ae.__webglTexture||A.depthTexture.image.width!==A.width||A.depthTexture.image.height!==A.height)&&(A.depthTexture.image.width=A.width,A.depthTexture.image.height=A.height,A.depthTexture.needsUpdate=!0),K(A.depthTexture,0);const de=ae.__webglTexture,re=Le(A);if(A.depthTexture.format===lr)tt(A)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,de,0,re):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_ATTACHMENT,r.TEXTURE_2D,de,0);else if(A.depthTexture.format===pr)tt(A)?a.framebufferTexture2DMultisampleEXT(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,de,0,re):r.framebufferTexture2D(r.FRAMEBUFFER,r.DEPTH_STENCIL_ATTACHMENT,r.TEXTURE_2D,de,0);else throw new Error("Unknown depthTexture format")}function be(O){const A=n.get(O),$=O.isWebGLCubeRenderTarget===!0;if(A.__boundDepthTexture!==O.depthTexture){const ae=O.depthTexture;if(A.__depthDisposeCallback&&A.__depthDisposeCallback(),ae){const de=()=>{delete A.__boundDepthTexture,delete A.__depthDisposeCallback,ae.removeEventListener("dispose",de)};ae.addEventListener("dispose",de),A.__depthDisposeCallback=de}A.__boundDepthTexture=ae}if(O.depthTexture&&!A.__autoAllocateDepthBuffer){if($)throw new Error("target.depthTexture not supported in Cube render targets");ce(A.__webglFramebuffer,O)}else if($){A.__webglDepthbuffer=[];for(let ae=0;ae<6;ae++)if(t.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer[ae]),A.__webglDepthbuffer[ae]===void 0)A.__webglDepthbuffer[ae]=r.createRenderbuffer(),te(A.__webglDepthbuffer[ae],O,!1);else{const de=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,re=A.__webglDepthbuffer[ae];r.bindRenderbuffer(r.RENDERBUFFER,re),r.framebufferRenderbuffer(r.FRAMEBUFFER,de,r.RENDERBUFFER,re)}}else if(t.bindFramebuffer(r.FRAMEBUFFER,A.__webglFramebuffer),A.__webglDepthbuffer===void 0)A.__webglDepthbuffer=r.createRenderbuffer(),te(A.__webglDepthbuffer,O,!1);else{const ae=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,de=A.__webglDepthbuffer;r.bindRenderbuffer(r.RENDERBUFFER,de),r.framebufferRenderbuffer(r.FRAMEBUFFER,ae,r.RENDERBUFFER,de)}t.bindFramebuffer(r.FRAMEBUFFER,null)}function xe(O,A,$){const ae=n.get(O);A!==void 0&&J(ae.__webglFramebuffer,O,O.texture,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,0),$!==void 0&&be(O)}function Re(O){const A=O.texture,$=n.get(O),ae=n.get(A);O.addEventListener("dispose",P);const de=O.textures,re=O.isWebGLCubeRenderTarget===!0,Ce=de.length>1;if(Ce||(ae.__webglTexture===void 0&&(ae.__webglTexture=r.createTexture()),ae.__version=A.version,o.memory.textures++),re){$.__webglFramebuffer=[];for(let Me=0;Me<6;Me++)if(A.mipmaps&&A.mipmaps.length>0){$.__webglFramebuffer[Me]=[];for(let Fe=0;Fe<A.mipmaps.length;Fe++)$.__webglFramebuffer[Me][Fe]=r.createFramebuffer()}else $.__webglFramebuffer[Me]=r.createFramebuffer()}else{if(A.mipmaps&&A.mipmaps.length>0){$.__webglFramebuffer=[];for(let Me=0;Me<A.mipmaps.length;Me++)$.__webglFramebuffer[Me]=r.createFramebuffer()}else $.__webglFramebuffer=r.createFramebuffer();if(Ce)for(let Me=0,Fe=de.length;Me<Fe;Me++){const gt=n.get(de[Me]);gt.__webglTexture===void 0&&(gt.__webglTexture=r.createTexture(),o.memory.textures++)}if(O.samples>0&&tt(O)===!1){$.__webglMultisampledFramebuffer=r.createFramebuffer(),$.__webglColorRenderbuffer=[],t.bindFramebuffer(r.FRAMEBUFFER,$.__webglMultisampledFramebuffer);for(let Me=0;Me<de.length;Me++){const Fe=de[Me];$.__webglColorRenderbuffer[Me]=r.createRenderbuffer(),r.bindRenderbuffer(r.RENDERBUFFER,$.__webglColorRenderbuffer[Me]);const gt=s.convert(Fe.format,Fe.colorSpace),ge=s.convert(Fe.type),Te=y(Fe.internalFormat,gt,ge,Fe.colorSpace,O.isXRRenderTarget===!0),qe=Le(O);r.renderbufferStorageMultisample(r.RENDERBUFFER,qe,Te,O.width,O.height),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Me,r.RENDERBUFFER,$.__webglColorRenderbuffer[Me])}r.bindRenderbuffer(r.RENDERBUFFER,null),O.depthBuffer&&($.__webglDepthRenderbuffer=r.createRenderbuffer(),te($.__webglDepthRenderbuffer,O,!0)),t.bindFramebuffer(r.FRAMEBUFFER,null)}}if(re){t.bindTexture(r.TEXTURE_CUBE_MAP,ae.__webglTexture),he(r.TEXTURE_CUBE_MAP,A);for(let Me=0;Me<6;Me++)if(A.mipmaps&&A.mipmaps.length>0)for(let Fe=0;Fe<A.mipmaps.length;Fe++)J($.__webglFramebuffer[Me][Fe],O,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe);else J($.__webglFramebuffer[Me],O,A,r.COLOR_ATTACHMENT0,r.TEXTURE_CUBE_MAP_POSITIVE_X+Me,0);m(A)&&p(r.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(Ce){for(let Me=0,Fe=de.length;Me<Fe;Me++){const gt=de[Me],ge=n.get(gt);t.bindTexture(r.TEXTURE_2D,ge.__webglTexture),he(r.TEXTURE_2D,gt),J($.__webglFramebuffer,O,gt,r.COLOR_ATTACHMENT0+Me,r.TEXTURE_2D,0),m(gt)&&p(r.TEXTURE_2D)}t.unbindTexture()}else{let Me=r.TEXTURE_2D;if((O.isWebGL3DRenderTarget||O.isWebGLArrayRenderTarget)&&(Me=O.isWebGL3DRenderTarget?r.TEXTURE_3D:r.TEXTURE_2D_ARRAY),t.bindTexture(Me,ae.__webglTexture),he(Me,A),A.mipmaps&&A.mipmaps.length>0)for(let Fe=0;Fe<A.mipmaps.length;Fe++)J($.__webglFramebuffer[Fe],O,A,r.COLOR_ATTACHMENT0,Me,Fe);else J($.__webglFramebuffer,O,A,r.COLOR_ATTACHMENT0,Me,0);m(A)&&p(Me),t.unbindTexture()}O.depthBuffer&&be(O)}function Je(O){const A=O.textures;for(let $=0,ae=A.length;$<ae;$++){const de=A[$];if(m(de)){const re=w(O),Ce=n.get(de).__webglTexture;t.bindTexture(re,Ce),p(re),t.unbindTexture()}}}const We=[],B=[];function ht(O){if(O.samples>0){if(tt(O)===!1){const A=O.textures,$=O.width,ae=O.height;let de=r.COLOR_BUFFER_BIT;const re=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT,Ce=n.get(O),Me=A.length>1;if(Me)for(let Fe=0;Fe<A.length;Fe++)t.bindFramebuffer(r.FRAMEBUFFER,Ce.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.RENDERBUFFER,null),t.bindFramebuffer(r.FRAMEBUFFER,Ce.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.TEXTURE_2D,null,0);t.bindFramebuffer(r.READ_FRAMEBUFFER,Ce.__webglMultisampledFramebuffer),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ce.__webglFramebuffer);for(let Fe=0;Fe<A.length;Fe++){if(O.resolveDepthBuffer&&(O.depthBuffer&&(de|=r.DEPTH_BUFFER_BIT),O.stencilBuffer&&O.resolveStencilBuffer&&(de|=r.STENCIL_BUFFER_BIT)),Me){r.framebufferRenderbuffer(r.READ_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.RENDERBUFFER,Ce.__webglColorRenderbuffer[Fe]);const gt=n.get(A[Fe]).__webglTexture;r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0,r.TEXTURE_2D,gt,0)}r.blitFramebuffer(0,0,$,ae,0,0,$,ae,de,r.NEAREST),l===!0&&(We.length=0,B.length=0,We.push(r.COLOR_ATTACHMENT0+Fe),O.depthBuffer&&O.resolveDepthBuffer===!1&&(We.push(re),B.push(re),r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,B)),r.invalidateFramebuffer(r.READ_FRAMEBUFFER,We))}if(t.bindFramebuffer(r.READ_FRAMEBUFFER,null),t.bindFramebuffer(r.DRAW_FRAMEBUFFER,null),Me)for(let Fe=0;Fe<A.length;Fe++){t.bindFramebuffer(r.FRAMEBUFFER,Ce.__webglMultisampledFramebuffer),r.framebufferRenderbuffer(r.FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.RENDERBUFFER,Ce.__webglColorRenderbuffer[Fe]);const gt=n.get(A[Fe]).__webglTexture;t.bindFramebuffer(r.FRAMEBUFFER,Ce.__webglFramebuffer),r.framebufferTexture2D(r.DRAW_FRAMEBUFFER,r.COLOR_ATTACHMENT0+Fe,r.TEXTURE_2D,gt,0)}t.bindFramebuffer(r.DRAW_FRAMEBUFFER,Ce.__webglMultisampledFramebuffer)}else if(O.depthBuffer&&O.resolveDepthBuffer===!1&&l){const A=O.stencilBuffer?r.DEPTH_STENCIL_ATTACHMENT:r.DEPTH_ATTACHMENT;r.invalidateFramebuffer(r.DRAW_FRAMEBUFFER,[A])}}}function Le(O){return Math.min(i.maxSamples,O.samples)}function tt(O){const A=n.get(O);return O.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&A.__useRenderToTexture!==!1}function me(O){const A=o.render.frame;h.get(O)!==A&&(h.set(O,A),O.update())}function Qe(O,A){const $=O.colorSpace,ae=O.format,de=O.type;return O.isCompressedTexture===!0||O.isVideoTexture===!0||$!==mr&&$!==Ki&&(rt.getTransfer($)===Nt?(ae!==wn||de!==Oi)&&console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",$)),A}function ze(O){return typeof HTMLImageElement<"u"&&O instanceof HTMLImageElement?(c.width=O.naturalWidth||O.width,c.height=O.naturalHeight||O.height):typeof VideoFrame<"u"&&O instanceof VideoFrame?(c.width=O.displayWidth,c.height=O.displayHeight):(c.width=O.width,c.height=O.height),c}this.allocateTextureUnit=k,this.resetTextureUnits=F,this.setTexture2D=K,this.setTexture2DArray=z,this.setTexture3D=Z,this.setTextureCube=V,this.rebindTextures=xe,this.setupRenderTarget=Re,this.updateRenderTargetMipmap=Je,this.updateMultisampleRenderTarget=ht,this.setupDepthRenderbuffer=be,this.setupFrameBufferTexture=J,this.useMultisampledRTT=tt}function ty(r,e){function t(n,i=Ki){let s;const o=rt.getTransfer(i);if(n===Oi)return r.UNSIGNED_BYTE;if(n===zc)return r.UNSIGNED_SHORT_4_4_4_4;if(n===Hc)return r.UNSIGNED_SHORT_5_5_5_1;if(n===Ud)return r.UNSIGNED_INT_5_9_9_9_REV;if(n===Id)return r.BYTE;if(n===Nd)return r.SHORT;if(n===Xr)return r.UNSIGNED_SHORT;if(n===kc)return r.INT;if(n===vs)return r.UNSIGNED_INT;if(n===pi)return r.FLOAT;if(n===eo)return r.HALF_FLOAT;if(n===Fd)return r.ALPHA;if(n===Od)return r.RGB;if(n===wn)return r.RGBA;if(n===Bd)return r.LUMINANCE;if(n===kd)return r.LUMINANCE_ALPHA;if(n===lr)return r.DEPTH_COMPONENT;if(n===pr)return r.DEPTH_STENCIL;if(n===zd)return r.RED;if(n===Vc)return r.RED_INTEGER;if(n===Hd)return r.RG;if(n===Gc)return r.RG_INTEGER;if(n===Wc)return r.RGBA_INTEGER;if(n===la||n===ca||n===ha||n===ua)if(o===Nt)if(s=e.get("WEBGL_compressed_texture_s3tc_srgb"),s!==null){if(n===la)return s.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(n===ca)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(n===ha)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(n===ua)return s.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else return null;else if(s=e.get("WEBGL_compressed_texture_s3tc"),s!==null){if(n===la)return s.COMPRESSED_RGB_S3TC_DXT1_EXT;if(n===ca)return s.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(n===ha)return s.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(n===ua)return s.COMPRESSED_RGBA_S3TC_DXT5_EXT}else return null;if(n===ec||n===tc||n===nc||n===ic)if(s=e.get("WEBGL_compressed_texture_pvrtc"),s!==null){if(n===ec)return s.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(n===tc)return s.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(n===nc)return s.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(n===ic)return s.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}else return null;if(n===sc||n===rc||n===oc)if(s=e.get("WEBGL_compressed_texture_etc"),s!==null){if(n===sc||n===rc)return o===Nt?s.COMPRESSED_SRGB8_ETC2:s.COMPRESSED_RGB8_ETC2;if(n===oc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:s.COMPRESSED_RGBA8_ETC2_EAC}else return null;if(n===ac||n===lc||n===cc||n===hc||n===uc||n===dc||n===fc||n===pc||n===mc||n===gc||n===_c||n===vc||n===xc||n===yc)if(s=e.get("WEBGL_compressed_texture_astc"),s!==null){if(n===ac)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:s.COMPRESSED_RGBA_ASTC_4x4_KHR;if(n===lc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:s.COMPRESSED_RGBA_ASTC_5x4_KHR;if(n===cc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:s.COMPRESSED_RGBA_ASTC_5x5_KHR;if(n===hc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:s.COMPRESSED_RGBA_ASTC_6x5_KHR;if(n===uc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:s.COMPRESSED_RGBA_ASTC_6x6_KHR;if(n===dc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:s.COMPRESSED_RGBA_ASTC_8x5_KHR;if(n===fc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:s.COMPRESSED_RGBA_ASTC_8x6_KHR;if(n===pc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:s.COMPRESSED_RGBA_ASTC_8x8_KHR;if(n===mc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:s.COMPRESSED_RGBA_ASTC_10x5_KHR;if(n===gc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:s.COMPRESSED_RGBA_ASTC_10x6_KHR;if(n===_c)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:s.COMPRESSED_RGBA_ASTC_10x8_KHR;if(n===vc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:s.COMPRESSED_RGBA_ASTC_10x10_KHR;if(n===xc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:s.COMPRESSED_RGBA_ASTC_12x10_KHR;if(n===yc)return o===Nt?s.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:s.COMPRESSED_RGBA_ASTC_12x12_KHR}else return null;if(n===da||n===bc||n===Mc)if(s=e.get("EXT_texture_compression_bptc"),s!==null){if(n===da)return o===Nt?s.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:s.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(n===bc)return s.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(n===Mc)return s.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}else return null;if(n===Vd||n===wc||n===Sc||n===Ec)if(s=e.get("EXT_texture_compression_rgtc"),s!==null){if(n===da)return s.COMPRESSED_RED_RGTC1_EXT;if(n===wc)return s.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(n===Sc)return s.COMPRESSED_RED_GREEN_RGTC2_EXT;if(n===Ec)return s.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}else return null;return n===fr?r.UNSIGNED_INT_24_8:r[n]!==void 0?r[n]:null}return{convert:t}}const ny=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,iy=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;class sy{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,n){if(this.texture===null){const i=new Wt,s=e.properties.get(i);s.__webglTexture=t.texture,(t.depthNear!==n.depthNear||t.depthFar!==n.depthFar)&&(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=i}}getMesh(e){if(this.texture!==null&&this.mesh===null){const t=e.cameras[0].viewport,n=new _i({vertexShader:ny,fragmentShader:iy,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new ve(new xr(20,20),n)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}}class ry extends Ss{constructor(e,t){super();const n=this;let i=null,s=1,o=null,a="local-floor",l=1,c=null,h=null,u=null,d=null,f=null,g=null;const v=new sy,m=t.getContextAttributes();let p=null,w=null;const y=[],b=[],D=new ye;let R=null;const P=new Qt;P.viewport=new at;const M=new Qt;M.viewport=new at;const _=[P,M],x=new pg;let T=null,F=null;this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(H){let j=y[H];return j===void 0&&(j=new fl,y[H]=j),j.getTargetRaySpace()},this.getControllerGrip=function(H){let j=y[H];return j===void 0&&(j=new fl,y[H]=j),j.getGripSpace()},this.getHand=function(H){let j=y[H];return j===void 0&&(j=new fl,y[H]=j),j.getHandSpace()};function k(H){const j=b.indexOf(H.inputSource);if(j===-1)return;const J=y[j];J!==void 0&&(J.update(H.inputSource,H.frame,c||o),J.dispatchEvent({type:H.type,data:H.inputSource}))}function G(){i.removeEventListener("select",k),i.removeEventListener("selectstart",k),i.removeEventListener("selectend",k),i.removeEventListener("squeeze",k),i.removeEventListener("squeezestart",k),i.removeEventListener("squeezeend",k),i.removeEventListener("end",G),i.removeEventListener("inputsourceschange",K);for(let H=0;H<y.length;H++){const j=b[H];j!==null&&(b[H]=null,y[H].disconnect(j))}T=null,F=null,v.reset(),e.setRenderTarget(p),f=null,d=null,u=null,i=null,w=null,se.stop(),n.isPresenting=!1,e.setPixelRatio(R),e.setSize(D.width,D.height,!1),n.dispatchEvent({type:"sessionend"})}this.setFramebufferScaleFactor=function(H){s=H,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(H){a=H,n.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||o},this.setReferenceSpace=function(H){c=H},this.getBaseLayer=function(){return d!==null?d:f},this.getBinding=function(){return u},this.getFrame=function(){return g},this.getSession=function(){return i},this.setSession=async function(H){if(i=H,i!==null){if(p=e.getRenderTarget(),i.addEventListener("select",k),i.addEventListener("selectstart",k),i.addEventListener("selectend",k),i.addEventListener("squeeze",k),i.addEventListener("squeezestart",k),i.addEventListener("squeezeend",k),i.addEventListener("end",G),i.addEventListener("inputsourceschange",K),m.xrCompatible!==!0&&await t.makeXRCompatible(),R=e.getPixelRatio(),e.getSize(D),typeof XRWebGLBinding<"u"&&"createProjectionLayer"in XRWebGLBinding.prototype){let J=null,te=null,ce=null;m.depth&&(ce=m.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,J=m.stencil?pr:lr,te=m.stencil?fr:vs);const be={colorFormat:t.RGBA8,depthFormat:ce,scaleFactor:s};u=new XRWebGLBinding(i,t),d=u.createProjectionLayer(be),i.updateRenderState({layers:[d]}),e.setPixelRatio(1),e.setSize(d.textureWidth,d.textureHeight,!1),w=new xs(d.textureWidth,d.textureHeight,{format:wn,type:Oi,depthTexture:new tf(d.textureWidth,d.textureHeight,te,void 0,void 0,void 0,void 0,void 0,void 0,J),stencilBuffer:m.stencil,colorSpace:e.outputColorSpace,samples:m.antialias?4:0,resolveDepthBuffer:d.ignoreDepthValues===!1,resolveStencilBuffer:d.ignoreDepthValues===!1})}else{const J={antialias:m.antialias,alpha:!0,depth:m.depth,stencil:m.stencil,framebufferScaleFactor:s};f=new XRWebGLLayer(i,t,J),i.updateRenderState({baseLayer:f}),e.setPixelRatio(1),e.setSize(f.framebufferWidth,f.framebufferHeight,!1),w=new xs(f.framebufferWidth,f.framebufferHeight,{format:wn,type:Oi,colorSpace:e.outputColorSpace,stencilBuffer:m.stencil,resolveDepthBuffer:f.ignoreDepthValues===!1,resolveStencilBuffer:f.ignoreDepthValues===!1})}w.isXRRenderTarget=!0,this.setFoveation(l),c=null,o=await i.requestReferenceSpace(a),se.setContext(i),se.start(),n.isPresenting=!0,n.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(i!==null)return i.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};function K(H){for(let j=0;j<H.removed.length;j++){const J=H.removed[j],te=b.indexOf(J);te>=0&&(b[te]=null,y[te].disconnect(J))}for(let j=0;j<H.added.length;j++){const J=H.added[j];let te=b.indexOf(J);if(te===-1){for(let be=0;be<y.length;be++)if(be>=b.length){b.push(J),te=be;break}else if(b[be]===null){b[be]=J,te=be;break}if(te===-1)break}const ce=y[te];ce&&ce.connect(J)}}const z=new L,Z=new L;function V(H,j,J){z.setFromMatrixPosition(j.matrixWorld),Z.setFromMatrixPosition(J.matrixWorld);const te=z.distanceTo(Z),ce=j.projectionMatrix.elements,be=J.projectionMatrix.elements,xe=ce[14]/(ce[10]-1),Re=ce[14]/(ce[10]+1),Je=(ce[9]+1)/ce[5],We=(ce[9]-1)/ce[5],B=(ce[8]-1)/ce[0],ht=(be[8]+1)/be[0],Le=xe*B,tt=xe*ht,me=te/(-B+ht),Qe=me*-B;if(j.matrixWorld.decompose(H.position,H.quaternion,H.scale),H.translateX(Qe),H.translateZ(me),H.matrixWorld.compose(H.position,H.quaternion,H.scale),H.matrixWorldInverse.copy(H.matrixWorld).invert(),ce[10]===-1)H.projectionMatrix.copy(j.projectionMatrix),H.projectionMatrixInverse.copy(j.projectionMatrixInverse);else{const ze=xe+me,O=Re+me,A=Le-Qe,$=tt+(te-Qe),ae=Je*Re/O*ze,de=We*Re/O*ze;H.projectionMatrix.makePerspective(A,$,ae,de,ze,O),H.projectionMatrixInverse.copy(H.projectionMatrix).invert()}}function Y(H,j){j===null?H.matrixWorld.copy(H.matrix):H.matrixWorld.multiplyMatrices(j.matrixWorld,H.matrix),H.matrixWorldInverse.copy(H.matrixWorld).invert()}this.updateCamera=function(H){if(i===null)return;let j=H.near,J=H.far;v.texture!==null&&(v.depthNear>0&&(j=v.depthNear),v.depthFar>0&&(J=v.depthFar)),x.near=M.near=P.near=j,x.far=M.far=P.far=J,(T!==x.near||F!==x.far)&&(i.updateRenderState({depthNear:x.near,depthFar:x.far}),T=x.near,F=x.far),P.layers.mask=H.layers.mask|2,M.layers.mask=H.layers.mask|4,x.layers.mask=P.layers.mask|M.layers.mask;const te=H.parent,ce=x.cameras;Y(x,te);for(let be=0;be<ce.length;be++)Y(ce[be],te);ce.length===2?V(x,P,M):x.projectionMatrix.copy(P.projectionMatrix),ue(H,x,te)};function ue(H,j,J){J===null?H.matrix.copy(j.matrixWorld):(H.matrix.copy(J.matrixWorld),H.matrix.invert(),H.matrix.multiply(j.matrixWorld)),H.matrix.decompose(H.position,H.quaternion,H.scale),H.updateMatrixWorld(!0),H.projectionMatrix.copy(j.projectionMatrix),H.projectionMatrixInverse.copy(j.projectionMatrixInverse),H.isPerspectiveCamera&&(H.fov=gr*2*Math.atan(1/H.projectionMatrix.elements[5]),H.zoom=1)}this.getCamera=function(){return x},this.getFoveation=function(){if(!(d===null&&f===null))return l},this.setFoveation=function(H){l=H,d!==null&&(d.fixedFoveation=H),f!==null&&f.fixedFoveation!==void 0&&(f.fixedFoveation=H)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(x)};let ie=null;function he(H,j){if(h=j.getViewerPose(c||o),g=j,h!==null){const J=h.views;f!==null&&(e.setRenderTargetFramebuffer(w,f.framebuffer),e.setRenderTarget(w));let te=!1;J.length!==x.cameras.length&&(x.cameras.length=0,te=!0);for(let xe=0;xe<J.length;xe++){const Re=J[xe];let Je=null;if(f!==null)Je=f.getViewport(Re);else{const B=u.getViewSubImage(d,Re);Je=B.viewport,xe===0&&(e.setRenderTargetTextures(w,B.colorTexture,d.ignoreDepthValues?void 0:B.depthStencilTexture),e.setRenderTarget(w))}let We=_[xe];We===void 0&&(We=new Qt,We.layers.enable(xe),We.viewport=new at,_[xe]=We),We.matrix.fromArray(Re.transform.matrix),We.matrix.decompose(We.position,We.quaternion,We.scale),We.projectionMatrix.fromArray(Re.projectionMatrix),We.projectionMatrixInverse.copy(We.projectionMatrix).invert(),We.viewport.set(Je.x,Je.y,Je.width,Je.height),xe===0&&(x.matrix.copy(We.matrix),x.matrix.decompose(x.position,x.quaternion,x.scale)),te===!0&&x.cameras.push(We)}const ce=i.enabledFeatures;if(ce&&ce.includes("depth-sensing")&&i.depthUsage=="gpu-optimized"&&u){const xe=u.getDepthInformation(J[0]);xe&&xe.isValid&&xe.texture&&v.init(e,xe,i.renderState)}}for(let J=0;J<y.length;J++){const te=b[J],ce=y[J];te!==null&&ce!==void 0&&ce.update(te,j,c||o)}ie&&ie(H,j),j.detectedPlanes&&n.dispatchEvent({type:"planesdetected",data:j}),g=null}const se=new ff;se.setAnimationLoop(he),this.setAnimationLoop=function(H){ie=H},this.dispose=function(){}}}const os=new Bt,oy=new Ee;function ay(r,e){function t(m,p){m.matrixAutoUpdate===!0&&m.updateMatrix(),p.value.copy(m.matrix)}function n(m,p){p.color.getRGB(m.fogColor.value,qd(r)),p.isFog?(m.fogNear.value=p.near,m.fogFar.value=p.far):p.isFogExp2&&(m.fogDensity.value=p.density)}function i(m,p,w,y,b){p.isMeshBasicMaterial||p.isMeshLambertMaterial?s(m,p):p.isMeshToonMaterial?(s(m,p),u(m,p)):p.isMeshPhongMaterial?(s(m,p),h(m,p)):p.isMeshStandardMaterial?(s(m,p),d(m,p),p.isMeshPhysicalMaterial&&f(m,p,b)):p.isMeshMatcapMaterial?(s(m,p),g(m,p)):p.isMeshDepthMaterial?s(m,p):p.isMeshDistanceMaterial?(s(m,p),v(m,p)):p.isMeshNormalMaterial?s(m,p):p.isLineBasicMaterial?(o(m,p),p.isLineDashedMaterial&&a(m,p)):p.isPointsMaterial?l(m,p,w,y):p.isSpriteMaterial?c(m,p):p.isShadowMaterial?(m.color.value.copy(p.color),m.opacity.value=p.opacity):p.isShaderMaterial&&(p.uniformsNeedUpdate=!1)}function s(m,p){m.opacity.value=p.opacity,p.color&&m.diffuse.value.copy(p.color),p.emissive&&m.emissive.value.copy(p.emissive).multiplyScalar(p.emissiveIntensity),p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.bumpMap&&(m.bumpMap.value=p.bumpMap,t(p.bumpMap,m.bumpMapTransform),m.bumpScale.value=p.bumpScale,p.side===Un&&(m.bumpScale.value*=-1)),p.normalMap&&(m.normalMap.value=p.normalMap,t(p.normalMap,m.normalMapTransform),m.normalScale.value.copy(p.normalScale),p.side===Un&&m.normalScale.value.negate()),p.displacementMap&&(m.displacementMap.value=p.displacementMap,t(p.displacementMap,m.displacementMapTransform),m.displacementScale.value=p.displacementScale,m.displacementBias.value=p.displacementBias),p.emissiveMap&&(m.emissiveMap.value=p.emissiveMap,t(p.emissiveMap,m.emissiveMapTransform)),p.specularMap&&(m.specularMap.value=p.specularMap,t(p.specularMap,m.specularMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest);const w=e.get(p),y=w.envMap,b=w.envMapRotation;y&&(m.envMap.value=y,os.copy(b),os.x*=-1,os.y*=-1,os.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(os.y*=-1,os.z*=-1),m.envMapRotation.value.setFromMatrix4(oy.makeRotationFromEuler(os)),m.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,m.reflectivity.value=p.reflectivity,m.ior.value=p.ior,m.refractionRatio.value=p.refractionRatio),p.lightMap&&(m.lightMap.value=p.lightMap,m.lightMapIntensity.value=p.lightMapIntensity,t(p.lightMap,m.lightMapTransform)),p.aoMap&&(m.aoMap.value=p.aoMap,m.aoMapIntensity.value=p.aoMapIntensity,t(p.aoMap,m.aoMapTransform))}function o(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform))}function a(m,p){m.dashSize.value=p.dashSize,m.totalSize.value=p.dashSize+p.gapSize,m.scale.value=p.scale}function l(m,p,w,y){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.size.value=p.size*w,m.scale.value=y*.5,p.map&&(m.map.value=p.map,t(p.map,m.uvTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function c(m,p){m.diffuse.value.copy(p.color),m.opacity.value=p.opacity,m.rotation.value=p.rotation,p.map&&(m.map.value=p.map,t(p.map,m.mapTransform)),p.alphaMap&&(m.alphaMap.value=p.alphaMap,t(p.alphaMap,m.alphaMapTransform)),p.alphaTest>0&&(m.alphaTest.value=p.alphaTest)}function h(m,p){m.specular.value.copy(p.specular),m.shininess.value=Math.max(p.shininess,1e-4)}function u(m,p){p.gradientMap&&(m.gradientMap.value=p.gradientMap)}function d(m,p){m.metalness.value=p.metalness,p.metalnessMap&&(m.metalnessMap.value=p.metalnessMap,t(p.metalnessMap,m.metalnessMapTransform)),m.roughness.value=p.roughness,p.roughnessMap&&(m.roughnessMap.value=p.roughnessMap,t(p.roughnessMap,m.roughnessMapTransform)),p.envMap&&(m.envMapIntensity.value=p.envMapIntensity)}function f(m,p,w){m.ior.value=p.ior,p.sheen>0&&(m.sheenColor.value.copy(p.sheenColor).multiplyScalar(p.sheen),m.sheenRoughness.value=p.sheenRoughness,p.sheenColorMap&&(m.sheenColorMap.value=p.sheenColorMap,t(p.sheenColorMap,m.sheenColorMapTransform)),p.sheenRoughnessMap&&(m.sheenRoughnessMap.value=p.sheenRoughnessMap,t(p.sheenRoughnessMap,m.sheenRoughnessMapTransform))),p.clearcoat>0&&(m.clearcoat.value=p.clearcoat,m.clearcoatRoughness.value=p.clearcoatRoughness,p.clearcoatMap&&(m.clearcoatMap.value=p.clearcoatMap,t(p.clearcoatMap,m.clearcoatMapTransform)),p.clearcoatRoughnessMap&&(m.clearcoatRoughnessMap.value=p.clearcoatRoughnessMap,t(p.clearcoatRoughnessMap,m.clearcoatRoughnessMapTransform)),p.clearcoatNormalMap&&(m.clearcoatNormalMap.value=p.clearcoatNormalMap,t(p.clearcoatNormalMap,m.clearcoatNormalMapTransform),m.clearcoatNormalScale.value.copy(p.clearcoatNormalScale),p.side===Un&&m.clearcoatNormalScale.value.negate())),p.dispersion>0&&(m.dispersion.value=p.dispersion),p.iridescence>0&&(m.iridescence.value=p.iridescence,m.iridescenceIOR.value=p.iridescenceIOR,m.iridescenceThicknessMinimum.value=p.iridescenceThicknessRange[0],m.iridescenceThicknessMaximum.value=p.iridescenceThicknessRange[1],p.iridescenceMap&&(m.iridescenceMap.value=p.iridescenceMap,t(p.iridescenceMap,m.iridescenceMapTransform)),p.iridescenceThicknessMap&&(m.iridescenceThicknessMap.value=p.iridescenceThicknessMap,t(p.iridescenceThicknessMap,m.iridescenceThicknessMapTransform))),p.transmission>0&&(m.transmission.value=p.transmission,m.transmissionSamplerMap.value=w.texture,m.transmissionSamplerSize.value.set(w.width,w.height),p.transmissionMap&&(m.transmissionMap.value=p.transmissionMap,t(p.transmissionMap,m.transmissionMapTransform)),m.thickness.value=p.thickness,p.thicknessMap&&(m.thicknessMap.value=p.thicknessMap,t(p.thicknessMap,m.thicknessMapTransform)),m.attenuationDistance.value=p.attenuationDistance,m.attenuationColor.value.copy(p.attenuationColor)),p.anisotropy>0&&(m.anisotropyVector.value.set(p.anisotropy*Math.cos(p.anisotropyRotation),p.anisotropy*Math.sin(p.anisotropyRotation)),p.anisotropyMap&&(m.anisotropyMap.value=p.anisotropyMap,t(p.anisotropyMap,m.anisotropyMapTransform))),m.specularIntensity.value=p.specularIntensity,m.specularColor.value.copy(p.specularColor),p.specularColorMap&&(m.specularColorMap.value=p.specularColorMap,t(p.specularColorMap,m.specularColorMapTransform)),p.specularIntensityMap&&(m.specularIntensityMap.value=p.specularIntensityMap,t(p.specularIntensityMap,m.specularIntensityMapTransform))}function g(m,p){p.matcap&&(m.matcap.value=p.matcap)}function v(m,p){const w=e.get(p).light;m.referencePosition.value.setFromMatrixPosition(w.matrixWorld),m.nearDistance.value=w.shadow.camera.near,m.farDistance.value=w.shadow.camera.far}return{refreshFogUniforms:n,refreshMaterialUniforms:i}}function ly(r,e,t,n){let i={},s={},o=[];const a=r.getParameter(r.MAX_UNIFORM_BUFFER_BINDINGS);function l(w,y){const b=y.program;n.uniformBlockBinding(w,b)}function c(w,y){let b=i[w.id];b===void 0&&(g(w),b=h(w),i[w.id]=b,w.addEventListener("dispose",m));const D=y.program;n.updateUBOMapping(w,D);const R=e.render.frame;s[w.id]!==R&&(d(w),s[w.id]=R)}function h(w){const y=u();w.__bindingPointIndex=y;const b=r.createBuffer(),D=w.__size,R=w.usage;return r.bindBuffer(r.UNIFORM_BUFFER,b),r.bufferData(r.UNIFORM_BUFFER,D,R),r.bindBuffer(r.UNIFORM_BUFFER,null),r.bindBufferBase(r.UNIFORM_BUFFER,y,b),b}function u(){for(let w=0;w<a;w++)if(o.indexOf(w)===-1)return o.push(w),w;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}function d(w){const y=i[w.id],b=w.uniforms,D=w.__cache;r.bindBuffer(r.UNIFORM_BUFFER,y);for(let R=0,P=b.length;R<P;R++){const M=Array.isArray(b[R])?b[R]:[b[R]];for(let _=0,x=M.length;_<x;_++){const T=M[_];if(f(T,R,_,D)===!0){const F=T.__offset,k=Array.isArray(T.value)?T.value:[T.value];let G=0;for(let K=0;K<k.length;K++){const z=k[K],Z=v(z);typeof z=="number"||typeof z=="boolean"?(T.__data[0]=z,r.bufferSubData(r.UNIFORM_BUFFER,F+G,T.__data)):z.isMatrix3?(T.__data[0]=z.elements[0],T.__data[1]=z.elements[1],T.__data[2]=z.elements[2],T.__data[3]=0,T.__data[4]=z.elements[3],T.__data[5]=z.elements[4],T.__data[6]=z.elements[5],T.__data[7]=0,T.__data[8]=z.elements[6],T.__data[9]=z.elements[7],T.__data[10]=z.elements[8],T.__data[11]=0):(z.toArray(T.__data,G),G+=Z.storage/Float32Array.BYTES_PER_ELEMENT)}r.bufferSubData(r.UNIFORM_BUFFER,F,T.__data)}}}r.bindBuffer(r.UNIFORM_BUFFER,null)}function f(w,y,b,D){const R=w.value,P=y+"_"+b;if(D[P]===void 0)return typeof R=="number"||typeof R=="boolean"?D[P]=R:D[P]=R.clone(),!0;{const M=D[P];if(typeof R=="number"||typeof R=="boolean"){if(M!==R)return D[P]=R,!0}else if(M.equals(R)===!1)return M.copy(R),!0}return!1}function g(w){const y=w.uniforms;let b=0;const D=16;for(let P=0,M=y.length;P<M;P++){const _=Array.isArray(y[P])?y[P]:[y[P]];for(let x=0,T=_.length;x<T;x++){const F=_[x],k=Array.isArray(F.value)?F.value:[F.value];for(let G=0,K=k.length;G<K;G++){const z=k[G],Z=v(z),V=b%D,Y=V%Z.boundary,ue=V+Y;b+=Y,ue!==0&&D-ue<Z.storage&&(b+=D-ue),F.__data=new Float32Array(Z.storage/Float32Array.BYTES_PER_ELEMENT),F.__offset=b,b+=Z.storage}}}const R=b%D;return R>0&&(b+=D-R),w.__size=b,w.__cache={},this}function v(w){const y={boundary:0,storage:0};return typeof w=="number"||typeof w=="boolean"?(y.boundary=4,y.storage=4):w.isVector2?(y.boundary=8,y.storage=8):w.isVector3||w.isColor?(y.boundary=16,y.storage=12):w.isVector4?(y.boundary=16,y.storage=16):w.isMatrix3?(y.boundary=48,y.storage=48):w.isMatrix4?(y.boundary=64,y.storage=64):w.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",w),y}function m(w){const y=w.target;y.removeEventListener("dispose",m);const b=o.indexOf(y.__bindingPointIndex);o.splice(b,1),r.deleteBuffer(i[y.id]),delete i[y.id],delete s[y.id]}function p(){for(const w in i)r.deleteBuffer(i[w]);o=[],i={},s={}}return{bind:l,update:c,dispose:p}}class cy{constructor(e={}){const{canvas:t=Qp(),context:n=null,depth:i=!0,stencil:s=!1,alpha:o=!1,antialias:a=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:u=!1,reverseDepthBuffer:d=!1}=e;this.isWebGLRenderer=!0;let f;if(n!==null){if(typeof WebGLRenderingContext<"u"&&n instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");f=n.getContextAttributes().alpha}else f=o;const g=new Uint32Array(4),v=new Int32Array(4);let m=null,p=null;const w=[],y=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=vt,this.toneMapping=Qi,this.toneMappingExposure=1;const b=this;let D=!1,R=0,P=0,M=null,_=-1,x=null;const T=new at,F=new at;let k=null;const G=new ke(0);let K=0,z=t.width,Z=t.height,V=1,Y=null,ue=null;const ie=new at(0,0,z,Z),he=new at(0,0,z,Z);let se=!1;const H=new Pa;let j=!1,J=!1;this.transmissionResolutionScale=1;const te=new Ee,ce=new Ee,be=new L,xe=new at,Re={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};let Je=!1;function We(){return M===null?V:1}let B=n;function ht(I,W){return t.getContext(I,W)}try{const I={alpha:!0,depth:i,stencil:s,antialias:a,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:u};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${gs}`),t.addEventListener("webglcontextlost",fe,!1),t.addEventListener("webglcontextrestored",Ue,!1),t.addEventListener("webglcontextcreationerror",De,!1),B===null){const W="webgl2";if(B=ht(W,I),B===null)throw ht(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(I){throw console.error("THREE.WebGLRenderer: "+I.message),I}let Le,tt,me,Qe,ze,O,A,$,ae,de,re,Ce,Me,Fe,gt,ge,Te,qe,et,He,xt,lt,Lt,X;function Pe(){Le=new xv(B),Le.init(),lt=new ty(B,Le),tt=new dv(B,Le,e,lt),me=new Qx(B,Le),tt.reverseDepthBuffer&&d&&me.buffers.depth.setReversed(!0),Qe=new Mv(B),ze=new zx,O=new ey(B,Le,me,ze,tt,lt,Qe),A=new pv(b),$=new vv(b),ae=new Rg(B),Lt=new hv(B,ae),de=new yv(B,ae,Qe,Lt),re=new Sv(B,de,ae,Qe),et=new wv(B,tt,O),ge=new fv(ze),Ce=new kx(b,A,$,Le,tt,Lt,ge),Me=new ay(b,ze),Fe=new Vx,gt=new Yx(Le),qe=new cv(b,A,$,me,re,f,l),Te=new $x(b,re,tt),X=new ly(B,Qe,tt,me),He=new uv(B,Le,Qe),xt=new bv(B,Le,Qe),Qe.programs=Ce.programs,b.capabilities=tt,b.extensions=Le,b.properties=ze,b.renderLists=Fe,b.shadowMap=Te,b.state=me,b.info=Qe}Pe();const oe=new ry(b,B);this.xr=oe,this.getContext=function(){return B},this.getContextAttributes=function(){return B.getContextAttributes()},this.forceContextLoss=function(){const I=Le.get("WEBGL_lose_context");I&&I.loseContext()},this.forceContextRestore=function(){const I=Le.get("WEBGL_lose_context");I&&I.restoreContext()},this.getPixelRatio=function(){return V},this.setPixelRatio=function(I){I!==void 0&&(V=I,this.setSize(z,Z,!1))},this.getSize=function(I){return I.set(z,Z)},this.setSize=function(I,W,Q=!0){if(oe.isPresenting){console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.");return}z=I,Z=W,t.width=Math.floor(I*V),t.height=Math.floor(W*V),Q===!0&&(t.style.width=I+"px",t.style.height=W+"px"),this.setViewport(0,0,I,W)},this.getDrawingBufferSize=function(I){return I.set(z*V,Z*V).floor()},this.setDrawingBufferSize=function(I,W,Q){z=I,Z=W,V=Q,t.width=Math.floor(I*Q),t.height=Math.floor(W*Q),this.setViewport(0,0,I,W)},this.getCurrentViewport=function(I){return I.copy(T)},this.getViewport=function(I){return I.copy(ie)},this.setViewport=function(I,W,Q,ee){I.isVector4?ie.set(I.x,I.y,I.z,I.w):ie.set(I,W,Q,ee),me.viewport(T.copy(ie).multiplyScalar(V).round())},this.getScissor=function(I){return I.copy(he)},this.setScissor=function(I,W,Q,ee){I.isVector4?he.set(I.x,I.y,I.z,I.w):he.set(I,W,Q,ee),me.scissor(F.copy(he).multiplyScalar(V).round())},this.getScissorTest=function(){return se},this.setScissorTest=function(I){me.setScissorTest(se=I)},this.setOpaqueSort=function(I){Y=I},this.setTransparentSort=function(I){ue=I},this.getClearColor=function(I){return I.copy(qe.getClearColor())},this.setClearColor=function(){qe.setClearColor(...arguments)},this.getClearAlpha=function(){return qe.getClearAlpha()},this.setClearAlpha=function(){qe.setClearAlpha(...arguments)},this.clear=function(I=!0,W=!0,Q=!0){let ee=0;if(I){let q=!1;if(M!==null){const _e=M.texture.format;q=_e===Wc||_e===Gc||_e===Vc}if(q){const _e=M.texture.type,Ae=_e===Oi||_e===vs||_e===Xr||_e===fr||_e===zc||_e===Hc,Oe=qe.getClearColor(),Ve=qe.getClearAlpha(),it=Oe.r,st=Oe.g,Ye=Oe.b;Ae?(g[0]=it,g[1]=st,g[2]=Ye,g[3]=Ve,B.clearBufferuiv(B.COLOR,0,g)):(v[0]=it,v[1]=st,v[2]=Ye,v[3]=Ve,B.clearBufferiv(B.COLOR,0,v))}else ee|=B.COLOR_BUFFER_BIT}W&&(ee|=B.DEPTH_BUFFER_BIT),Q&&(ee|=B.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),B.clear(ee)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",fe,!1),t.removeEventListener("webglcontextrestored",Ue,!1),t.removeEventListener("webglcontextcreationerror",De,!1),qe.dispose(),Fe.dispose(),gt.dispose(),ze.dispose(),A.dispose(),$.dispose(),re.dispose(),Lt.dispose(),X.dispose(),Ce.dispose(),oe.dispose(),oe.removeEventListener("sessionstart",oo),oe.removeEventListener("sessionend",ao),yi.stop()};function fe(I){I.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),D=!0}function Ue(){console.log("THREE.WebGLRenderer: Context Restored."),D=!1;const I=Qe.autoReset,W=Te.enabled,Q=Te.autoUpdate,ee=Te.needsUpdate,q=Te.type;Pe(),Qe.autoReset=I,Te.enabled=W,Te.autoUpdate=Q,Te.needsUpdate=ee,Te.type=q}function De(I){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",I.statusMessage)}function ot(I){const W=I.target;W.removeEventListener("dispose",ot),zt(W)}function zt(I){ln(I),ze.remove(I)}function ln(I){const W=ze.get(I).programs;W!==void 0&&(W.forEach(function(Q){Ce.releaseProgram(Q)}),I.isShaderMaterial&&Ce.releaseShaderCache(I))}this.renderBufferDirect=function(I,W,Q,ee,q,_e){W===null&&(W=Re);const Ae=q.isMesh&&q.matrixWorld.determinant()<0,Oe=za(I,W,Q,ee,q);me.setMaterial(ee,Ae);let Ve=Q.index,it=1;if(ee.wireframe===!0){if(Ve=de.getWireframeAttribute(Q),Ve===void 0)return;it=2}const st=Q.drawRange,Ye=Q.attributes.position;let ft=st.start*it,Et=(st.start+st.count)*it;_e!==null&&(ft=Math.max(ft,_e.start*it),Et=Math.min(Et,(_e.start+_e.count)*it)),Ve!==null?(ft=Math.max(ft,0),Et=Math.min(Et,Ve.count)):Ye!=null&&(ft=Math.max(ft,0),Et=Math.min(Et,Ye.count));const Xt=Et-ft;if(Xt<0||Xt===1/0)return;Lt.setup(q,ee,Oe,Q,Ve);let Vt,bt=He;if(Ve!==null&&(Vt=ae.get(Ve),bt=xt,bt.setIndex(Vt)),q.isMesh)ee.wireframe===!0?(me.setLineWidth(ee.wireframeLinewidth*We()),bt.setMode(B.LINES)):bt.setMode(B.TRIANGLES);else if(q.isLine){let Ke=ee.linewidth;Ke===void 0&&(Ke=1),me.setLineWidth(Ke*We()),q.isLineSegments?bt.setMode(B.LINES):q.isLineLoop?bt.setMode(B.LINE_LOOP):bt.setMode(B.LINE_STRIP)}else q.isPoints?bt.setMode(B.POINTS):q.isSprite&&bt.setMode(B.TRIANGLES);if(q.isBatchedMesh)if(q._multiDrawInstances!==null)ls("THREE.WebGLRenderer: renderMultiDrawInstances has been deprecated and will be removed in r184. Append to renderMultiDraw arguments and use indirection."),bt.renderMultiDrawInstances(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount,q._multiDrawInstances);else if(Le.get("WEBGL_multi_draw"))bt.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else{const Ke=q._multiDrawStarts,en=q._multiDrawCounts,Tt=q._multiDrawCount,Ln=Ve?ae.get(Ve).bytesPerElement:1,kt=ze.get(ee).currentProgram.getUniforms();for(let hn=0;hn<Tt;hn++)kt.setValue(B,"_gl_DrawID",hn),bt.render(Ke[hn]/Ln,en[hn])}else if(q.isInstancedMesh)bt.renderInstances(ft,Xt,q.count);else if(Q.isInstancedBufferGeometry){const Ke=Q._maxInstanceCount!==void 0?Q._maxInstanceCount:1/0,en=Math.min(Q.instanceCount,Ke);bt.renderInstances(ft,Xt,en)}else bt.render(ft,Xt)};function ut(I,W,Q){I.transparent===!0&&I.side===Xn&&I.forceSinglePass===!1?(I.side=Un,I.needsUpdate=!0,As(I,W,Q),I.side=Fi,I.needsUpdate=!0,As(I,W,Q),I.side=Xn):As(I,W,Q)}this.compile=function(I,W,Q=null){Q===null&&(Q=I),p=gt.get(Q),p.init(W),y.push(p),Q.traverseVisible(function(q){q.isLight&&q.layers.test(W.layers)&&(p.pushLight(q),q.castShadow&&p.pushShadow(q))}),I!==Q&&I.traverseVisible(function(q){q.isLight&&q.layers.test(W.layers)&&(p.pushLight(q),q.castShadow&&p.pushShadow(q))}),p.setupLights();const ee=new Set;return I.traverse(function(q){if(!(q.isMesh||q.isPoints||q.isLine||q.isSprite))return;const _e=q.material;if(_e)if(Array.isArray(_e))for(let Ae=0;Ae<_e.length;Ae++){const Oe=_e[Ae];ut(Oe,Q,q),ee.add(Oe)}else ut(_e,Q,q),ee.add(_e)}),p=y.pop(),ee},this.compileAsync=function(I,W,Q=null){const ee=this.compile(I,W,Q);return new Promise(q=>{function _e(){if(ee.forEach(function(Ae){ze.get(Ae).currentProgram.isReady()&&ee.delete(Ae)}),ee.size===0){q(I);return}setTimeout(_e,10)}Le.get("KHR_parallel_shader_compile")!==null?_e():setTimeout(_e,10)})};let Pn=null;function $n(I){Pn&&Pn(I)}function oo(){yi.stop()}function ao(){yi.start()}const yi=new ff;yi.setAnimationLoop($n),typeof self<"u"&&yi.setContext(self),this.setAnimationLoop=function(I){Pn=I,oe.setAnimationLoop(I),I===null?yi.stop():yi.start()},oe.addEventListener("sessionstart",oo),oe.addEventListener("sessionend",ao),this.render=function(I,W){if(W!==void 0&&W.isCamera!==!0){console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");return}if(D===!0)return;if(I.matrixWorldAutoUpdate===!0&&I.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),oe.enabled===!0&&oe.isPresenting===!0&&(oe.cameraAutoUpdate===!0&&oe.updateCamera(W),W=oe.getCamera()),I.isScene===!0&&I.onBeforeRender(b,I,W,M),p=gt.get(I,y.length),p.init(W),y.push(p),ce.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),H.setFromProjectionMatrix(ce),J=this.localClippingEnabled,j=ge.init(this.clippingPlanes,J),m=Fe.get(I,w.length),m.init(),w.push(m),oe.enabled===!0&&oe.isPresenting===!0){const _e=b.xr.getDepthSensingMesh();_e!==null&&wr(_e,W,-1/0,b.sortObjects)}wr(I,W,0,b.sortObjects),m.finish(),b.sortObjects===!0&&m.sort(Y,ue),Je=oe.enabled===!1||oe.isPresenting===!1||oe.hasDepthSensing()===!1,Je&&qe.addToRenderList(m,I),this.info.render.frame++,j===!0&&ge.beginShadows();const Q=p.state.shadowsArray;Te.render(Q,I,W),j===!0&&ge.endShadows(),this.info.autoReset===!0&&this.info.reset();const ee=m.opaque,q=m.transmissive;if(p.setupLights(),W.isArrayCamera){const _e=W.cameras;if(q.length>0)for(let Ae=0,Oe=_e.length;Ae<Oe;Ae++){const Ve=_e[Ae];Sr(ee,q,I,Ve)}Je&&qe.render(I);for(let Ae=0,Oe=_e.length;Ae<Oe;Ae++){const Ve=_e[Ae];lo(m,I,Ve,Ve.viewport)}}else q.length>0&&Sr(ee,q,I,W),Je&&qe.render(I),lo(m,I,W);M!==null&&P===0&&(O.updateMultisampleRenderTarget(M),O.updateRenderTargetMipmap(M)),I.isScene===!0&&I.onAfterRender(b,I,W),Lt.resetDefaultState(),_=-1,x=null,y.pop(),y.length>0?(p=y[y.length-1],j===!0&&ge.setGlobalState(b.clippingPlanes,p.state.camera)):p=null,w.pop(),w.length>0?m=w[w.length-1]:m=null};function wr(I,W,Q,ee){if(I.visible===!1)return;if(I.layers.test(W.layers)){if(I.isGroup)Q=I.renderOrder;else if(I.isLOD)I.autoUpdate===!0&&I.update(W);else if(I.isLight)p.pushLight(I),I.castShadow&&p.pushShadow(I);else if(I.isSprite){if(!I.frustumCulled||H.intersectsSprite(I)){ee&&xe.setFromMatrixPosition(I.matrixWorld).applyMatrix4(ce);const Ae=re.update(I),Oe=I.material;Oe.visible&&m.push(I,Ae,Oe,Q,xe.z,null)}}else if((I.isMesh||I.isLine||I.isPoints)&&(!I.frustumCulled||H.intersectsObject(I))){const Ae=re.update(I),Oe=I.material;if(ee&&(I.boundingSphere!==void 0?(I.boundingSphere===null&&I.computeBoundingSphere(),xe.copy(I.boundingSphere.center)):(Ae.boundingSphere===null&&Ae.computeBoundingSphere(),xe.copy(Ae.boundingSphere.center)),xe.applyMatrix4(I.matrixWorld).applyMatrix4(ce)),Array.isArray(Oe)){const Ve=Ae.groups;for(let it=0,st=Ve.length;it<st;it++){const Ye=Ve[it],ft=Oe[Ye.materialIndex];ft&&ft.visible&&m.push(I,Ae,ft,Q,xe.z,Ye)}}else Oe.visible&&m.push(I,Ae,Oe,Q,xe.z,null)}}const _e=I.children;for(let Ae=0,Oe=_e.length;Ae<Oe;Ae++)wr(_e[Ae],W,Q,ee)}function lo(I,W,Q,ee){const q=I.opaque,_e=I.transmissive,Ae=I.transparent;p.setupLightsView(Q),j===!0&&ge.setGlobalState(b.clippingPlanes,Q),ee&&me.viewport(T.copy(ee)),q.length>0&&Ts(q,W,Q),_e.length>0&&Ts(_e,W,Q),Ae.length>0&&Ts(Ae,W,Q),me.buffers.depth.setTest(!0),me.buffers.depth.setMask(!0),me.buffers.color.setMask(!0),me.setPolygonOffset(!1)}function Sr(I,W,Q,ee){if((Q.isScene===!0?Q.overrideMaterial:null)!==null)return;p.state.transmissionRenderTarget[ee.id]===void 0&&(p.state.transmissionRenderTarget[ee.id]=new xs(1,1,{generateMipmaps:!0,type:Le.has("EXT_color_buffer_half_float")||Le.has("EXT_color_buffer_float")?eo:Oi,minFilter:Di,samples:4,stencilBuffer:s,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:rt.workingColorSpace}));const _e=p.state.transmissionRenderTarget[ee.id],Ae=ee.viewport||T;_e.setSize(Ae.z*b.transmissionResolutionScale,Ae.w*b.transmissionResolutionScale);const Oe=b.getRenderTarget();b.setRenderTarget(_e),b.getClearColor(G),K=b.getClearAlpha(),K<1&&b.setClearColor(16777215,.5),b.clear(),Je&&qe.render(Q);const Ve=b.toneMapping;b.toneMapping=Qi;const it=ee.viewport;if(ee.viewport!==void 0&&(ee.viewport=void 0),p.setupLightsView(ee),j===!0&&ge.setGlobalState(b.clippingPlanes,ee),Ts(I,Q,ee),O.updateMultisampleRenderTarget(_e),O.updateRenderTargetMipmap(_e),Le.has("WEBGL_multisampled_render_to_texture")===!1){let st=!1;for(let Ye=0,ft=W.length;Ye<ft;Ye++){const Et=W[Ye],Xt=Et.object,Vt=Et.geometry,bt=Et.material,Ke=Et.group;if(bt.side===Xn&&Xt.layers.test(ee.layers)){const en=bt.side;bt.side=Un,bt.needsUpdate=!0,Er(Xt,Q,ee,Vt,bt,Ke),bt.side=en,bt.needsUpdate=!0,st=!0}}st===!0&&(O.updateMultisampleRenderTarget(_e),O.updateRenderTargetMipmap(_e))}b.setRenderTarget(Oe),b.setClearColor(G,K),it!==void 0&&(ee.viewport=it),b.toneMapping=Ve}function Ts(I,W,Q){const ee=W.isScene===!0?W.overrideMaterial:null;for(let q=0,_e=I.length;q<_e;q++){const Ae=I[q],Oe=Ae.object,Ve=Ae.geometry,it=ee===null?Ae.material:ee,st=Ae.group;Oe.layers.test(Q.layers)&&Er(Oe,W,Q,Ve,it,st)}}function Er(I,W,Q,ee,q,_e){I.onBeforeRender(b,W,Q,ee,q,_e),I.modelViewMatrix.multiplyMatrices(Q.matrixWorldInverse,I.matrixWorld),I.normalMatrix.getNormalMatrix(I.modelViewMatrix),q.onBeforeRender(b,W,Q,ee,I,_e),q.transparent===!0&&q.side===Xn&&q.forceSinglePass===!1?(q.side=Un,q.needsUpdate=!0,b.renderBufferDirect(Q,W,ee,q,I,_e),q.side=Fi,q.needsUpdate=!0,b.renderBufferDirect(Q,W,ee,q,I,_e),q.side=Xn):b.renderBufferDirect(Q,W,ee,q,I,_e),I.onAfterRender(b,W,Q,ee,q,_e)}function As(I,W,Q){W.isScene!==!0&&(W=Re);const ee=ze.get(I),q=p.state.lights,_e=p.state.shadowsArray,Ae=q.state.version,Oe=Ce.getParameters(I,q.state,_e,W,Q),Ve=Ce.getProgramCacheKey(Oe);let it=ee.programs;ee.environment=I.isMeshStandardMaterial?W.environment:null,ee.fog=W.fog,ee.envMap=(I.isMeshStandardMaterial?$:A).get(I.envMap||ee.environment),ee.envMapRotation=ee.environment!==null&&I.envMap===null?W.environmentRotation:I.envMapRotation,it===void 0&&(I.addEventListener("dispose",ot),it=new Map,ee.programs=it);let st=it.get(Ve);if(st!==void 0){if(ee.currentProgram===st&&ee.lightsStateVersion===Ae)return ho(I,Oe),st}else Oe.uniforms=Ce.getUniforms(I),I.onBeforeCompile(Oe,b),st=Ce.acquireProgram(Oe,Ve),it.set(Ve,st),ee.uniforms=Oe.uniforms;const Ye=ee.uniforms;return(!I.isShaderMaterial&&!I.isRawShaderMaterial||I.clipping===!0)&&(Ye.clippingPlanes=ge.uniform),ho(I,Oe),ee.needsLights=Va(I),ee.lightsStateVersion=Ae,ee.needsLights&&(Ye.ambientLightColor.value=q.state.ambient,Ye.lightProbe.value=q.state.probe,Ye.directionalLights.value=q.state.directional,Ye.directionalLightShadows.value=q.state.directionalShadow,Ye.spotLights.value=q.state.spot,Ye.spotLightShadows.value=q.state.spotShadow,Ye.rectAreaLights.value=q.state.rectArea,Ye.ltc_1.value=q.state.rectAreaLTC1,Ye.ltc_2.value=q.state.rectAreaLTC2,Ye.pointLights.value=q.state.point,Ye.pointLightShadows.value=q.state.pointShadow,Ye.hemisphereLights.value=q.state.hemi,Ye.directionalShadowMap.value=q.state.directionalShadowMap,Ye.directionalShadowMatrix.value=q.state.directionalShadowMatrix,Ye.spotShadowMap.value=q.state.spotShadowMap,Ye.spotLightMatrix.value=q.state.spotLightMatrix,Ye.spotLightMap.value=q.state.spotLightMap,Ye.pointShadowMap.value=q.state.pointShadowMap,Ye.pointShadowMatrix.value=q.state.pointShadowMatrix),ee.currentProgram=st,ee.uniformsList=null,st}function co(I){if(I.uniformsList===null){const W=I.currentProgram.getUniforms();I.uniformsList=fa.seqWithValue(W.seq,I.uniforms)}return I.uniformsList}function ho(I,W){const Q=ze.get(I);Q.outputColorSpace=W.outputColorSpace,Q.batching=W.batching,Q.batchingColor=W.batchingColor,Q.instancing=W.instancing,Q.instancingColor=W.instancingColor,Q.instancingMorph=W.instancingMorph,Q.skinning=W.skinning,Q.morphTargets=W.morphTargets,Q.morphNormals=W.morphNormals,Q.morphColors=W.morphColors,Q.morphTargetsCount=W.morphTargetsCount,Q.numClippingPlanes=W.numClippingPlanes,Q.numIntersection=W.numClipIntersection,Q.vertexAlphas=W.vertexAlphas,Q.vertexTangents=W.vertexTangents,Q.toneMapping=W.toneMapping}function za(I,W,Q,ee,q){W.isScene!==!0&&(W=Re),O.resetTextureUnits();const _e=W.fog,Ae=ee.isMeshStandardMaterial?W.environment:null,Oe=M===null?b.outputColorSpace:M.isXRRenderTarget===!0?M.texture.colorSpace:mr,Ve=(ee.isMeshStandardMaterial?$:A).get(ee.envMap||Ae),it=ee.vertexColors===!0&&!!Q.attributes.color&&Q.attributes.color.itemSize===4,st=!!Q.attributes.tangent&&(!!ee.normalMap||ee.anisotropy>0),Ye=!!Q.morphAttributes.position,ft=!!Q.morphAttributes.normal,Et=!!Q.morphAttributes.color;let Xt=Qi;ee.toneMapped&&(M===null||M.isXRRenderTarget===!0)&&(Xt=b.toneMapping);const Vt=Q.morphAttributes.position||Q.morphAttributes.normal||Q.morphAttributes.color,bt=Vt!==void 0?Vt.length:0,Ke=ze.get(ee),en=p.state.lights;if(j===!0&&(J===!0||I!==x)){const $t=I===x&&ee.id===_;ge.setState(ee,I,$t)}let Tt=!1;ee.version===Ke.__version?(Ke.needsLights&&Ke.lightsStateVersion!==en.state.version||Ke.outputColorSpace!==Oe||q.isBatchedMesh&&Ke.batching===!1||!q.isBatchedMesh&&Ke.batching===!0||q.isBatchedMesh&&Ke.batchingColor===!0&&q.colorTexture===null||q.isBatchedMesh&&Ke.batchingColor===!1&&q.colorTexture!==null||q.isInstancedMesh&&Ke.instancing===!1||!q.isInstancedMesh&&Ke.instancing===!0||q.isSkinnedMesh&&Ke.skinning===!1||!q.isSkinnedMesh&&Ke.skinning===!0||q.isInstancedMesh&&Ke.instancingColor===!0&&q.instanceColor===null||q.isInstancedMesh&&Ke.instancingColor===!1&&q.instanceColor!==null||q.isInstancedMesh&&Ke.instancingMorph===!0&&q.morphTexture===null||q.isInstancedMesh&&Ke.instancingMorph===!1&&q.morphTexture!==null||Ke.envMap!==Ve||ee.fog===!0&&Ke.fog!==_e||Ke.numClippingPlanes!==void 0&&(Ke.numClippingPlanes!==ge.numPlanes||Ke.numIntersection!==ge.numIntersection)||Ke.vertexAlphas!==it||Ke.vertexTangents!==st||Ke.morphTargets!==Ye||Ke.morphNormals!==ft||Ke.morphColors!==Et||Ke.toneMapping!==Xt||Ke.morphTargetsCount!==bt)&&(Tt=!0):(Tt=!0,Ke.__version=ee.version);let Ln=Ke.currentProgram;Tt===!0&&(Ln=As(ee,W,q));let kt=!1,hn=!1,es=!1;const Ft=Ln.getUniforms(),Sn=Ke.uniforms;if(me.useProgram(Ln.program)&&(kt=!0,hn=!0,es=!0),ee.id!==_&&(_=ee.id,hn=!0),kt||x!==I){me.buffers.depth.getReversed()?(te.copy(I.projectionMatrix),tm(te),nm(te),Ft.setValue(B,"projectionMatrix",te)):Ft.setValue(B,"projectionMatrix",I.projectionMatrix),Ft.setValue(B,"viewMatrix",I.matrixWorldInverse);const tn=Ft.map.cameraPosition;tn!==void 0&&tn.setValue(B,be.setFromMatrixPosition(I.matrixWorld)),tt.logarithmicDepthBuffer&&Ft.setValue(B,"logDepthBufFC",2/(Math.log(I.far+1)/Math.LN2)),(ee.isMeshPhongMaterial||ee.isMeshToonMaterial||ee.isMeshLambertMaterial||ee.isMeshBasicMaterial||ee.isMeshStandardMaterial||ee.isShaderMaterial)&&Ft.setValue(B,"isOrthographic",I.isOrthographicCamera===!0),x!==I&&(x=I,hn=!0,es=!0)}if(q.isSkinnedMesh){Ft.setOptional(B,q,"bindMatrix"),Ft.setOptional(B,q,"bindMatrixInverse");const $t=q.skeleton;$t&&($t.boneTexture===null&&$t.computeBoneTexture(),Ft.setValue(B,"boneTexture",$t.boneTexture,O))}q.isBatchedMesh&&(Ft.setOptional(B,q,"batchingTexture"),Ft.setValue(B,"batchingTexture",q._matricesTexture,O),Ft.setOptional(B,q,"batchingIdTexture"),Ft.setValue(B,"batchingIdTexture",q._indirectTexture,O),Ft.setOptional(B,q,"batchingColorTexture"),q._colorsTexture!==null&&Ft.setValue(B,"batchingColorTexture",q._colorsTexture,O));const _n=Q.morphAttributes;if((_n.position!==void 0||_n.normal!==void 0||_n.color!==void 0)&&et.update(q,Q,Ln),(hn||Ke.receiveShadow!==q.receiveShadow)&&(Ke.receiveShadow=q.receiveShadow,Ft.setValue(B,"receiveShadow",q.receiveShadow)),ee.isMeshGouraudMaterial&&ee.envMap!==null&&(Sn.envMap.value=Ve,Sn.flipEnvMap.value=Ve.isCubeTexture&&Ve.isRenderTargetTexture===!1?-1:1),ee.isMeshStandardMaterial&&ee.envMap===null&&W.environment!==null&&(Sn.envMapIntensity.value=W.environmentIntensity),hn&&(Ft.setValue(B,"toneMappingExposure",b.toneMappingExposure),Ke.needsLights&&Ha(Sn,es),_e&&ee.fog===!0&&Me.refreshFogUniforms(Sn,_e),Me.refreshMaterialUniforms(Sn,ee,V,Z,p.state.transmissionRenderTarget[I.id]),fa.upload(B,co(Ke),Sn,O)),ee.isShaderMaterial&&ee.uniformsNeedUpdate===!0&&(fa.upload(B,co(Ke),Sn,O),ee.uniformsNeedUpdate=!1),ee.isSpriteMaterial&&Ft.setValue(B,"center",q.center),Ft.setValue(B,"modelViewMatrix",q.modelViewMatrix),Ft.setValue(B,"normalMatrix",q.normalMatrix),Ft.setValue(B,"modelMatrix",q.matrixWorld),ee.isShaderMaterial||ee.isRawShaderMaterial){const $t=ee.uniformsGroups;for(let tn=0,Rs=$t.length;tn<Rs;tn++){const bi=$t[tn];X.update(bi,Ln),X.bind(bi,Ln)}}return Ln}function Ha(I,W){I.ambientLightColor.needsUpdate=W,I.lightProbe.needsUpdate=W,I.directionalLights.needsUpdate=W,I.directionalLightShadows.needsUpdate=W,I.pointLights.needsUpdate=W,I.pointLightShadows.needsUpdate=W,I.spotLights.needsUpdate=W,I.spotLightShadows.needsUpdate=W,I.rectAreaLights.needsUpdate=W,I.hemisphereLights.needsUpdate=W}function Va(I){return I.isMeshLambertMaterial||I.isMeshToonMaterial||I.isMeshPhongMaterial||I.isMeshStandardMaterial||I.isShadowMaterial||I.isShaderMaterial&&I.lights===!0}this.getActiveCubeFace=function(){return R},this.getActiveMipmapLevel=function(){return P},this.getRenderTarget=function(){return M},this.setRenderTargetTextures=function(I,W,Q){ze.get(I.texture).__webglTexture=W,ze.get(I.depthTexture).__webglTexture=Q;const ee=ze.get(I);ee.__hasExternalTextures=!0,ee.__autoAllocateDepthBuffer=Q===void 0,ee.__autoAllocateDepthBuffer||Le.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),ee.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(I,W){const Q=ze.get(I);Q.__webglFramebuffer=W,Q.__useDefaultFramebuffer=W===void 0};const Ga=B.createFramebuffer();this.setRenderTarget=function(I,W=0,Q=0){M=I,R=W,P=Q;let ee=!0,q=null,_e=!1,Ae=!1;if(I){const Ve=ze.get(I);if(Ve.__useDefaultFramebuffer!==void 0)me.bindFramebuffer(B.FRAMEBUFFER,null),ee=!1;else if(Ve.__webglFramebuffer===void 0)O.setupRenderTarget(I);else if(Ve.__hasExternalTextures)O.rebindTextures(I,ze.get(I.texture).__webglTexture,ze.get(I.depthTexture).__webglTexture);else if(I.depthBuffer){const Ye=I.depthTexture;if(Ve.__boundDepthTexture!==Ye){if(Ye!==null&&ze.has(Ye)&&(I.width!==Ye.image.width||I.height!==Ye.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");O.setupDepthRenderbuffer(I)}}const it=I.texture;(it.isData3DTexture||it.isDataArrayTexture||it.isCompressedArrayTexture)&&(Ae=!0);const st=ze.get(I).__webglFramebuffer;I.isWebGLCubeRenderTarget?(Array.isArray(st[W])?q=st[W][Q]:q=st[W],_e=!0):I.samples>0&&O.useMultisampledRTT(I)===!1?q=ze.get(I).__webglMultisampledFramebuffer:Array.isArray(st)?q=st[Q]:q=st,T.copy(I.viewport),F.copy(I.scissor),k=I.scissorTest}else T.copy(ie).multiplyScalar(V).floor(),F.copy(he).multiplyScalar(V).floor(),k=se;if(Q!==0&&(q=Ga),me.bindFramebuffer(B.FRAMEBUFFER,q)&&ee&&me.drawBuffers(I,q),me.viewport(T),me.scissor(F),me.setScissorTest(k),_e){const Ve=ze.get(I.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_CUBE_MAP_POSITIVE_X+W,Ve.__webglTexture,Q)}else if(Ae){const Ve=ze.get(I.texture),it=W;B.framebufferTextureLayer(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,Ve.__webglTexture,Q,it)}else if(I!==null&&Q!==0){const Ve=ze.get(I.texture);B.framebufferTexture2D(B.FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,Ve.__webglTexture,Q)}_=-1},this.readRenderTargetPixels=function(I,W,Q,ee,q,_e,Ae){if(!(I&&I.isWebGLRenderTarget)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");return}let Oe=ze.get(I).__webglFramebuffer;if(I.isWebGLCubeRenderTarget&&Ae!==void 0&&(Oe=Oe[Ae]),Oe){me.bindFramebuffer(B.FRAMEBUFFER,Oe);try{const Ve=I.texture,it=Ve.format,st=Ve.type;if(!tt.textureFormatReadable(it)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");return}if(!tt.textureTypeReadable(st)){console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");return}W>=0&&W<=I.width-ee&&Q>=0&&Q<=I.height-q&&B.readPixels(W,Q,ee,q,lt.convert(it),lt.convert(st),_e)}finally{const Ve=M!==null?ze.get(M).__webglFramebuffer:null;me.bindFramebuffer(B.FRAMEBUFFER,Ve)}}},this.readRenderTargetPixelsAsync=async function(I,W,Q,ee,q,_e,Ae){if(!(I&&I.isWebGLRenderTarget))throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let Oe=ze.get(I).__webglFramebuffer;if(I.isWebGLCubeRenderTarget&&Ae!==void 0&&(Oe=Oe[Ae]),Oe){const Ve=I.texture,it=Ve.format,st=Ve.type;if(!tt.textureFormatReadable(it))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!tt.textureTypeReadable(st))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(W>=0&&W<=I.width-ee&&Q>=0&&Q<=I.height-q){me.bindFramebuffer(B.FRAMEBUFFER,Oe);const Ye=B.createBuffer();B.bindBuffer(B.PIXEL_PACK_BUFFER,Ye),B.bufferData(B.PIXEL_PACK_BUFFER,_e.byteLength,B.STREAM_READ),B.readPixels(W,Q,ee,q,lt.convert(it),lt.convert(st),0);const ft=M!==null?ze.get(M).__webglFramebuffer:null;me.bindFramebuffer(B.FRAMEBUFFER,ft);const Et=B.fenceSync(B.SYNC_GPU_COMMANDS_COMPLETE,0);return B.flush(),await em(B,Et,4),B.bindBuffer(B.PIXEL_PACK_BUFFER,Ye),B.getBufferSubData(B.PIXEL_PACK_BUFFER,0,_e),B.deleteBuffer(Ye),B.deleteSync(Et),_e}else throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(I,W=null,Q=0){I.isTexture!==!0&&(ls("WebGLRenderer: copyFramebufferToTexture function signature has changed."),W=arguments[0]||null,I=arguments[1]);const ee=Math.pow(2,-Q),q=Math.floor(I.image.width*ee),_e=Math.floor(I.image.height*ee),Ae=W!==null?W.x:0,Oe=W!==null?W.y:0;O.setTexture2D(I,0),B.copyTexSubImage2D(B.TEXTURE_2D,Q,0,0,Ae,Oe,q,_e),me.unbindTexture()};const Wa=B.createFramebuffer(),Xa=B.createFramebuffer();this.copyTextureToTexture=function(I,W,Q=null,ee=null,q=0,_e=null){I.isTexture!==!0&&(ls("WebGLRenderer: copyTextureToTexture function signature has changed."),ee=arguments[0]||null,I=arguments[1],W=arguments[2],_e=arguments[3]||0,Q=null),_e===null&&(q!==0?(ls("WebGLRenderer: copyTextureToTexture function signature has changed to support src and dst mipmap levels."),_e=q,q=0):_e=0);let Ae,Oe,Ve,it,st,Ye,ft,Et,Xt;const Vt=I.isCompressedTexture?I.mipmaps[_e]:I.image;if(Q!==null)Ae=Q.max.x-Q.min.x,Oe=Q.max.y-Q.min.y,Ve=Q.isBox3?Q.max.z-Q.min.z:1,it=Q.min.x,st=Q.min.y,Ye=Q.isBox3?Q.min.z:0;else{const _n=Math.pow(2,-q);Ae=Math.floor(Vt.width*_n),Oe=Math.floor(Vt.height*_n),I.isDataArrayTexture?Ve=Vt.depth:I.isData3DTexture?Ve=Math.floor(Vt.depth*_n):Ve=1,it=0,st=0,Ye=0}ee!==null?(ft=ee.x,Et=ee.y,Xt=ee.z):(ft=0,Et=0,Xt=0);const bt=lt.convert(W.format),Ke=lt.convert(W.type);let en;W.isData3DTexture?(O.setTexture3D(W,0),en=B.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(O.setTexture2DArray(W,0),en=B.TEXTURE_2D_ARRAY):(O.setTexture2D(W,0),en=B.TEXTURE_2D),B.pixelStorei(B.UNPACK_FLIP_Y_WEBGL,W.flipY),B.pixelStorei(B.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),B.pixelStorei(B.UNPACK_ALIGNMENT,W.unpackAlignment);const Tt=B.getParameter(B.UNPACK_ROW_LENGTH),Ln=B.getParameter(B.UNPACK_IMAGE_HEIGHT),kt=B.getParameter(B.UNPACK_SKIP_PIXELS),hn=B.getParameter(B.UNPACK_SKIP_ROWS),es=B.getParameter(B.UNPACK_SKIP_IMAGES);B.pixelStorei(B.UNPACK_ROW_LENGTH,Vt.width),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,Vt.height),B.pixelStorei(B.UNPACK_SKIP_PIXELS,it),B.pixelStorei(B.UNPACK_SKIP_ROWS,st),B.pixelStorei(B.UNPACK_SKIP_IMAGES,Ye);const Ft=I.isDataArrayTexture||I.isData3DTexture,Sn=W.isDataArrayTexture||W.isData3DTexture;if(I.isDepthTexture){const _n=ze.get(I),$t=ze.get(W),tn=ze.get(_n.__renderTarget),Rs=ze.get($t.__renderTarget);me.bindFramebuffer(B.READ_FRAMEBUFFER,tn.__webglFramebuffer),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,Rs.__webglFramebuffer);for(let bi=0;bi<Ve;bi++)Ft&&(B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,ze.get(I).__webglTexture,q,Ye+bi),B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,ze.get(W).__webglTexture,_e,Xt+bi)),B.blitFramebuffer(it,st,Ae,Oe,ft,Et,Ae,Oe,B.DEPTH_BUFFER_BIT,B.NEAREST);me.bindFramebuffer(B.READ_FRAMEBUFFER,null),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else if(q!==0||I.isRenderTargetTexture||ze.has(I)){const _n=ze.get(I),$t=ze.get(W);me.bindFramebuffer(B.READ_FRAMEBUFFER,Wa),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,Xa);for(let tn=0;tn<Ve;tn++)Ft?B.framebufferTextureLayer(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,_n.__webglTexture,q,Ye+tn):B.framebufferTexture2D(B.READ_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,_n.__webglTexture,q),Sn?B.framebufferTextureLayer(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,$t.__webglTexture,_e,Xt+tn):B.framebufferTexture2D(B.DRAW_FRAMEBUFFER,B.COLOR_ATTACHMENT0,B.TEXTURE_2D,$t.__webglTexture,_e),q!==0?B.blitFramebuffer(it,st,Ae,Oe,ft,Et,Ae,Oe,B.COLOR_BUFFER_BIT,B.NEAREST):Sn?B.copyTexSubImage3D(en,_e,ft,Et,Xt+tn,it,st,Ae,Oe):B.copyTexSubImage2D(en,_e,ft,Et,it,st,Ae,Oe);me.bindFramebuffer(B.READ_FRAMEBUFFER,null),me.bindFramebuffer(B.DRAW_FRAMEBUFFER,null)}else Sn?I.isDataTexture||I.isData3DTexture?B.texSubImage3D(en,_e,ft,Et,Xt,Ae,Oe,Ve,bt,Ke,Vt.data):W.isCompressedArrayTexture?B.compressedTexSubImage3D(en,_e,ft,Et,Xt,Ae,Oe,Ve,bt,Vt.data):B.texSubImage3D(en,_e,ft,Et,Xt,Ae,Oe,Ve,bt,Ke,Vt):I.isDataTexture?B.texSubImage2D(B.TEXTURE_2D,_e,ft,Et,Ae,Oe,bt,Ke,Vt.data):I.isCompressedTexture?B.compressedTexSubImage2D(B.TEXTURE_2D,_e,ft,Et,Vt.width,Vt.height,bt,Vt.data):B.texSubImage2D(B.TEXTURE_2D,_e,ft,Et,Ae,Oe,bt,Ke,Vt);B.pixelStorei(B.UNPACK_ROW_LENGTH,Tt),B.pixelStorei(B.UNPACK_IMAGE_HEIGHT,Ln),B.pixelStorei(B.UNPACK_SKIP_PIXELS,kt),B.pixelStorei(B.UNPACK_SKIP_ROWS,hn),B.pixelStorei(B.UNPACK_SKIP_IMAGES,es),_e===0&&W.generateMipmaps&&B.generateMipmap(en),me.unbindTexture()},this.copyTextureToTexture3D=function(I,W,Q=null,ee=null,q=0){return I.isTexture!==!0&&(ls("WebGLRenderer: copyTextureToTexture3D function signature has changed."),Q=arguments[0]||null,ee=arguments[1]||null,I=arguments[2],W=arguments[3],q=arguments[4]||0),ls('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(I,W,Q,ee,q)},this.initRenderTarget=function(I){ze.get(I).__webglFramebuffer===void 0&&O.setupRenderTarget(I)},this.initTexture=function(I){I.isCubeTexture?O.setTextureCube(I,0):I.isData3DTexture?O.setTexture3D(I,0):I.isDataArrayTexture||I.isCompressedArrayTexture?O.setTexture2DArray(I,0):O.setTexture2D(I,0),me.unbindTexture()},this.resetState=function(){R=0,P=0,M=null,me.reset(),Lt.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return Ii}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;const t=this.getContext();t.drawingBufferColorspace=rt._getDrawingBufferColorSpace(e),t.unpackColorSpace=rt._getUnpackColorSpace()}}const Gu={type:"change"},ah={type:"start"},vf={type:"end"},qo=new Es,Wu=new Zi,hy=Math.cos(70*Pt.DEG2RAD),nn=new L,In=2*Math.PI,Ut={NONE:-1,ROTATE:0,DOLLY:1,PAN:2,TOUCH_ROTATE:3,TOUCH_PAN:4,TOUCH_DOLLY_PAN:5,TOUCH_DOLLY_ROTATE:6},Rl=1e-6;class uy extends df{constructor(e,t=null){super(e,t),this.state=Ut.NONE,this.enabled=!0,this.target=new L,this.cursor=new L,this.minDistance=0,this.maxDistance=1/0,this.minZoom=0,this.maxZoom=1/0,this.minTargetRadius=0,this.maxTargetRadius=1/0,this.minPolarAngle=0,this.maxPolarAngle=Math.PI,this.minAzimuthAngle=-1/0,this.maxAzimuthAngle=1/0,this.enableDamping=!1,this.dampingFactor=.05,this.enableZoom=!0,this.zoomSpeed=1,this.enableRotate=!0,this.rotateSpeed=1,this.keyRotateSpeed=1,this.enablePan=!0,this.panSpeed=1,this.screenSpacePanning=!0,this.keyPanSpeed=7,this.zoomToCursor=!1,this.autoRotate=!1,this.autoRotateSpeed=2,this.keys={LEFT:"ArrowLeft",UP:"ArrowUp",RIGHT:"ArrowRight",BOTTOM:"ArrowDown"},this.mouseButtons={LEFT:Ni.ROTATE,MIDDLE:Ni.DOLLY,RIGHT:Ni.PAN},this.touches={ONE:$i.ROTATE,TWO:$i.DOLLY_PAN},this.target0=this.target.clone(),this.position0=this.object.position.clone(),this.zoom0=this.object.zoom,this._domElementKeyEvents=null,this._lastPosition=new L,this._lastQuaternion=new St,this._lastTargetPosition=new L,this._quat=new St().setFromUnitVectors(e.up,new L(0,1,0)),this._quatInverse=this._quat.clone().invert(),this._spherical=new fu,this._sphericalDelta=new fu,this._scale=1,this._panOffset=new L,this._rotateStart=new ye,this._rotateEnd=new ye,this._rotateDelta=new ye,this._panStart=new ye,this._panEnd=new ye,this._panDelta=new ye,this._dollyStart=new ye,this._dollyEnd=new ye,this._dollyDelta=new ye,this._dollyDirection=new L,this._mouse=new ye,this._performCursorZoom=!1,this._pointers=[],this._pointerPositions={},this._controlActive=!1,this._onPointerMove=fy.bind(this),this._onPointerDown=dy.bind(this),this._onPointerUp=py.bind(this),this._onContextMenu=by.bind(this),this._onMouseWheel=_y.bind(this),this._onKeyDown=vy.bind(this),this._onTouchStart=xy.bind(this),this._onTouchMove=yy.bind(this),this._onMouseDown=my.bind(this),this._onMouseMove=gy.bind(this),this._interceptControlDown=My.bind(this),this._interceptControlUp=wy.bind(this),this.domElement!==null&&this.connect(),this.update()}connect(){this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointercancel",this._onPointerUp),this.domElement.addEventListener("contextmenu",this._onContextMenu),this.domElement.addEventListener("wheel",this._onMouseWheel,{passive:!1}),this.domElement.getRootNode().addEventListener("keydown",this._interceptControlDown,{passive:!0,capture:!0}),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.removeEventListener("pointercancel",this._onPointerUp),this.domElement.removeEventListener("wheel",this._onMouseWheel),this.domElement.removeEventListener("contextmenu",this._onContextMenu),this.stopListenToKeyEvents(),this.domElement.getRootNode().removeEventListener("keydown",this._interceptControlDown,{capture:!0}),this.domElement.style.touchAction="auto"}dispose(){this.disconnect()}getPolarAngle(){return this._spherical.phi}getAzimuthalAngle(){return this._spherical.theta}getDistance(){return this.object.position.distanceTo(this.target)}listenToKeyEvents(e){e.addEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=e}stopListenToKeyEvents(){this._domElementKeyEvents!==null&&(this._domElementKeyEvents.removeEventListener("keydown",this._onKeyDown),this._domElementKeyEvents=null)}saveState(){this.target0.copy(this.target),this.position0.copy(this.object.position),this.zoom0=this.object.zoom}reset(){this.target.copy(this.target0),this.object.position.copy(this.position0),this.object.zoom=this.zoom0,this.object.updateProjectionMatrix(),this.dispatchEvent(Gu),this.update(),this.state=Ut.NONE}update(e=null){const t=this.object.position;nn.copy(t).sub(this.target),nn.applyQuaternion(this._quat),this._spherical.setFromVector3(nn),this.autoRotate&&this.state===Ut.NONE&&this._rotateLeft(this._getAutoRotationAngle(e)),this.enableDamping?(this._spherical.theta+=this._sphericalDelta.theta*this.dampingFactor,this._spherical.phi+=this._sphericalDelta.phi*this.dampingFactor):(this._spherical.theta+=this._sphericalDelta.theta,this._spherical.phi+=this._sphericalDelta.phi);let n=this.minAzimuthAngle,i=this.maxAzimuthAngle;isFinite(n)&&isFinite(i)&&(n<-Math.PI?n+=In:n>Math.PI&&(n-=In),i<-Math.PI?i+=In:i>Math.PI&&(i-=In),n<=i?this._spherical.theta=Math.max(n,Math.min(i,this._spherical.theta)):this._spherical.theta=this._spherical.theta>(n+i)/2?Math.max(n,this._spherical.theta):Math.min(i,this._spherical.theta)),this._spherical.phi=Math.max(this.minPolarAngle,Math.min(this.maxPolarAngle,this._spherical.phi)),this._spherical.makeSafe(),this.enableDamping===!0?this.target.addScaledVector(this._panOffset,this.dampingFactor):this.target.add(this._panOffset),this.target.sub(this.cursor),this.target.clampLength(this.minTargetRadius,this.maxTargetRadius),this.target.add(this.cursor);let s=!1;if(this.zoomToCursor&&this._performCursorZoom||this.object.isOrthographicCamera)this._spherical.radius=this._clampDistance(this._spherical.radius);else{const o=this._spherical.radius;this._spherical.radius=this._clampDistance(this._spherical.radius*this._scale),s=o!=this._spherical.radius}if(nn.setFromSpherical(this._spherical),nn.applyQuaternion(this._quatInverse),t.copy(this.target).add(nn),this.object.lookAt(this.target),this.enableDamping===!0?(this._sphericalDelta.theta*=1-this.dampingFactor,this._sphericalDelta.phi*=1-this.dampingFactor,this._panOffset.multiplyScalar(1-this.dampingFactor)):(this._sphericalDelta.set(0,0,0),this._panOffset.set(0,0,0)),this.zoomToCursor&&this._performCursorZoom){let o=null;if(this.object.isPerspectiveCamera){const a=nn.length();o=this._clampDistance(a*this._scale);const l=a-o;this.object.position.addScaledVector(this._dollyDirection,l),this.object.updateMatrixWorld(),s=!!l}else if(this.object.isOrthographicCamera){const a=new L(this._mouse.x,this._mouse.y,0);a.unproject(this.object);const l=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),this.object.updateProjectionMatrix(),s=l!==this.object.zoom;const c=new L(this._mouse.x,this._mouse.y,0);c.unproject(this.object),this.object.position.sub(c).add(a),this.object.updateMatrixWorld(),o=nn.length()}else console.warn("WARNING: OrbitControls.js encountered an unknown camera type - zoom to cursor disabled."),this.zoomToCursor=!1;o!==null&&(this.screenSpacePanning?this.target.set(0,0,-1).transformDirection(this.object.matrix).multiplyScalar(o).add(this.object.position):(qo.origin.copy(this.object.position),qo.direction.set(0,0,-1).transformDirection(this.object.matrix),Math.abs(this.object.up.dot(qo.direction))<hy?this.object.lookAt(this.target):(Wu.setFromNormalAndCoplanarPoint(this.object.up,this.target),qo.intersectPlane(Wu,this.target))))}else if(this.object.isOrthographicCamera){const o=this.object.zoom;this.object.zoom=Math.max(this.minZoom,Math.min(this.maxZoom,this.object.zoom/this._scale)),o!==this.object.zoom&&(this.object.updateProjectionMatrix(),s=!0)}return this._scale=1,this._performCursorZoom=!1,s||this._lastPosition.distanceToSquared(this.object.position)>Rl||8*(1-this._lastQuaternion.dot(this.object.quaternion))>Rl||this._lastTargetPosition.distanceToSquared(this.target)>Rl?(this.dispatchEvent(Gu),this._lastPosition.copy(this.object.position),this._lastQuaternion.copy(this.object.quaternion),this._lastTargetPosition.copy(this.target),!0):!1}_getAutoRotationAngle(e){return e!==null?In/60*this.autoRotateSpeed*e:In/60/60*this.autoRotateSpeed}_getZoomScale(e){const t=Math.abs(e*.01);return Math.pow(.95,this.zoomSpeed*t)}_rotateLeft(e){this._sphericalDelta.theta-=e}_rotateUp(e){this._sphericalDelta.phi-=e}_panLeft(e,t){nn.setFromMatrixColumn(t,0),nn.multiplyScalar(-e),this._panOffset.add(nn)}_panUp(e,t){this.screenSpacePanning===!0?nn.setFromMatrixColumn(t,1):(nn.setFromMatrixColumn(t,0),nn.crossVectors(this.object.up,nn)),nn.multiplyScalar(e),this._panOffset.add(nn)}_pan(e,t){const n=this.domElement;if(this.object.isPerspectiveCamera){const i=this.object.position;nn.copy(i).sub(this.target);let s=nn.length();s*=Math.tan(this.object.fov/2*Math.PI/180),this._panLeft(2*e*s/n.clientHeight,this.object.matrix),this._panUp(2*t*s/n.clientHeight,this.object.matrix)}else this.object.isOrthographicCamera?(this._panLeft(e*(this.object.right-this.object.left)/this.object.zoom/n.clientWidth,this.object.matrix),this._panUp(t*(this.object.top-this.object.bottom)/this.object.zoom/n.clientHeight,this.object.matrix)):(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - pan disabled."),this.enablePan=!1)}_dollyOut(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale/=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_dollyIn(e){this.object.isPerspectiveCamera||this.object.isOrthographicCamera?this._scale*=e:(console.warn("WARNING: OrbitControls.js encountered an unknown camera type - dolly/zoom disabled."),this.enableZoom=!1)}_updateZoomParameters(e,t){if(!this.zoomToCursor)return;this._performCursorZoom=!0;const n=this.domElement.getBoundingClientRect(),i=e-n.left,s=t-n.top,o=n.width,a=n.height;this._mouse.x=i/o*2-1,this._mouse.y=-(s/a)*2+1,this._dollyDirection.set(this._mouse.x,this._mouse.y,1).unproject(this.object).sub(this.object.position).normalize()}_clampDistance(e){return Math.max(this.minDistance,Math.min(this.maxDistance,e))}_handleMouseDownRotate(e){this._rotateStart.set(e.clientX,e.clientY)}_handleMouseDownDolly(e){this._updateZoomParameters(e.clientX,e.clientX),this._dollyStart.set(e.clientX,e.clientY)}_handleMouseDownPan(e){this._panStart.set(e.clientX,e.clientY)}_handleMouseMoveRotate(e){this._rotateEnd.set(e.clientX,e.clientY),this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(In*this._rotateDelta.x/t.clientHeight),this._rotateUp(In*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd),this.update()}_handleMouseMoveDolly(e){this._dollyEnd.set(e.clientX,e.clientY),this._dollyDelta.subVectors(this._dollyEnd,this._dollyStart),this._dollyDelta.y>0?this._dollyOut(this._getZoomScale(this._dollyDelta.y)):this._dollyDelta.y<0&&this._dollyIn(this._getZoomScale(this._dollyDelta.y)),this._dollyStart.copy(this._dollyEnd),this.update()}_handleMouseMovePan(e){this._panEnd.set(e.clientX,e.clientY),this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd),this.update()}_handleMouseWheel(e){this._updateZoomParameters(e.clientX,e.clientY),e.deltaY<0?this._dollyIn(this._getZoomScale(e.deltaY)):e.deltaY>0&&this._dollyOut(this._getZoomScale(e.deltaY)),this.update()}_handleKeyDown(e){let t=!1;switch(e.code){case this.keys.UP:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,this.keyPanSpeed),t=!0;break;case this.keys.BOTTOM:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateUp(-In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(0,-this.keyPanSpeed),t=!0;break;case this.keys.LEFT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(this.keyPanSpeed,0),t=!0;break;case this.keys.RIGHT:e.ctrlKey||e.metaKey||e.shiftKey?this.enableRotate&&this._rotateLeft(-In*this.keyRotateSpeed/this.domElement.clientHeight):this.enablePan&&this._pan(-this.keyPanSpeed,0),t=!0;break}t&&(e.preventDefault(),this.update())}_handleTouchStartRotate(e){if(this._pointers.length===1)this._rotateStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),i=.5*(e.pageY+t.y);this._rotateStart.set(n,i)}}_handleTouchStartPan(e){if(this._pointers.length===1)this._panStart.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),i=.5*(e.pageY+t.y);this._panStart.set(n,i)}}_handleTouchStartDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,i=e.pageY-t.y,s=Math.sqrt(n*n+i*i);this._dollyStart.set(0,s)}_handleTouchStartDollyPan(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enablePan&&this._handleTouchStartPan(e)}_handleTouchStartDollyRotate(e){this.enableZoom&&this._handleTouchStartDolly(e),this.enableRotate&&this._handleTouchStartRotate(e)}_handleTouchMoveRotate(e){if(this._pointers.length==1)this._rotateEnd.set(e.pageX,e.pageY);else{const n=this._getSecondPointerPosition(e),i=.5*(e.pageX+n.x),s=.5*(e.pageY+n.y);this._rotateEnd.set(i,s)}this._rotateDelta.subVectors(this._rotateEnd,this._rotateStart).multiplyScalar(this.rotateSpeed);const t=this.domElement;this._rotateLeft(In*this._rotateDelta.x/t.clientHeight),this._rotateUp(In*this._rotateDelta.y/t.clientHeight),this._rotateStart.copy(this._rotateEnd)}_handleTouchMovePan(e){if(this._pointers.length===1)this._panEnd.set(e.pageX,e.pageY);else{const t=this._getSecondPointerPosition(e),n=.5*(e.pageX+t.x),i=.5*(e.pageY+t.y);this._panEnd.set(n,i)}this._panDelta.subVectors(this._panEnd,this._panStart).multiplyScalar(this.panSpeed),this._pan(this._panDelta.x,this._panDelta.y),this._panStart.copy(this._panEnd)}_handleTouchMoveDolly(e){const t=this._getSecondPointerPosition(e),n=e.pageX-t.x,i=e.pageY-t.y,s=Math.sqrt(n*n+i*i);this._dollyEnd.set(0,s),this._dollyDelta.set(0,Math.pow(this._dollyEnd.y/this._dollyStart.y,this.zoomSpeed)),this._dollyOut(this._dollyDelta.y),this._dollyStart.copy(this._dollyEnd);const o=(e.pageX+t.x)*.5,a=(e.pageY+t.y)*.5;this._updateZoomParameters(o,a)}_handleTouchMoveDollyPan(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enablePan&&this._handleTouchMovePan(e)}_handleTouchMoveDollyRotate(e){this.enableZoom&&this._handleTouchMoveDolly(e),this.enableRotate&&this._handleTouchMoveRotate(e)}_addPointer(e){this._pointers.push(e.pointerId)}_removePointer(e){delete this._pointerPositions[e.pointerId];for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId){this._pointers.splice(t,1);return}}_isTrackingPointer(e){for(let t=0;t<this._pointers.length;t++)if(this._pointers[t]==e.pointerId)return!0;return!1}_trackPointer(e){let t=this._pointerPositions[e.pointerId];t===void 0&&(t=new ye,this._pointerPositions[e.pointerId]=t),t.set(e.pageX,e.pageY)}_getSecondPointerPosition(e){const t=e.pointerId===this._pointers[0]?this._pointers[1]:this._pointers[0];return this._pointerPositions[t]}_customWheelEvent(e){const t=e.deltaMode,n={clientX:e.clientX,clientY:e.clientY,deltaY:e.deltaY};switch(t){case 1:n.deltaY*=16;break;case 2:n.deltaY*=100;break}return e.ctrlKey&&!this._controlActive&&(n.deltaY*=10),n}}function dy(r){this.enabled!==!1&&(this._pointers.length===0&&(this.domElement.setPointerCapture(r.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.domElement.addEventListener("pointerup",this._onPointerUp)),!this._isTrackingPointer(r)&&(this._addPointer(r),r.pointerType==="touch"?this._onTouchStart(r):this._onMouseDown(r)))}function fy(r){this.enabled!==!1&&(r.pointerType==="touch"?this._onTouchMove(r):this._onMouseMove(r))}function py(r){switch(this._removePointer(r),this._pointers.length){case 0:this.domElement.releasePointerCapture(r.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.dispatchEvent(vf),this.state=Ut.NONE;break;case 1:const e=this._pointers[0],t=this._pointerPositions[e];this._onTouchStart({pointerId:e,pageX:t.x,pageY:t.y});break}}function my(r){let e;switch(r.button){case 0:e=this.mouseButtons.LEFT;break;case 1:e=this.mouseButtons.MIDDLE;break;case 2:e=this.mouseButtons.RIGHT;break;default:e=-1}switch(e){case Ni.DOLLY:if(this.enableZoom===!1)return;this._handleMouseDownDolly(r),this.state=Ut.DOLLY;break;case Ni.ROTATE:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=Ut.PAN}else{if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=Ut.ROTATE}break;case Ni.PAN:if(r.ctrlKey||r.metaKey||r.shiftKey){if(this.enableRotate===!1)return;this._handleMouseDownRotate(r),this.state=Ut.ROTATE}else{if(this.enablePan===!1)return;this._handleMouseDownPan(r),this.state=Ut.PAN}break;default:this.state=Ut.NONE}this.state!==Ut.NONE&&this.dispatchEvent(ah)}function gy(r){switch(this.state){case Ut.ROTATE:if(this.enableRotate===!1)return;this._handleMouseMoveRotate(r);break;case Ut.DOLLY:if(this.enableZoom===!1)return;this._handleMouseMoveDolly(r);break;case Ut.PAN:if(this.enablePan===!1)return;this._handleMouseMovePan(r);break}}function _y(r){this.enabled===!1||this.enableZoom===!1||this.state!==Ut.NONE||(r.preventDefault(),this.dispatchEvent(ah),this._handleMouseWheel(this._customWheelEvent(r)),this.dispatchEvent(vf))}function vy(r){this.enabled!==!1&&this._handleKeyDown(r)}function xy(r){switch(this._trackPointer(r),this._pointers.length){case 1:switch(this.touches.ONE){case $i.ROTATE:if(this.enableRotate===!1)return;this._handleTouchStartRotate(r),this.state=Ut.TOUCH_ROTATE;break;case $i.PAN:if(this.enablePan===!1)return;this._handleTouchStartPan(r),this.state=Ut.TOUCH_PAN;break;default:this.state=Ut.NONE}break;case 2:switch(this.touches.TWO){case $i.DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchStartDollyPan(r),this.state=Ut.TOUCH_DOLLY_PAN;break;case $i.DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchStartDollyRotate(r),this.state=Ut.TOUCH_DOLLY_ROTATE;break;default:this.state=Ut.NONE}break;default:this.state=Ut.NONE}this.state!==Ut.NONE&&this.dispatchEvent(ah)}function yy(r){switch(this._trackPointer(r),this.state){case Ut.TOUCH_ROTATE:if(this.enableRotate===!1)return;this._handleTouchMoveRotate(r),this.update();break;case Ut.TOUCH_PAN:if(this.enablePan===!1)return;this._handleTouchMovePan(r),this.update();break;case Ut.TOUCH_DOLLY_PAN:if(this.enableZoom===!1&&this.enablePan===!1)return;this._handleTouchMoveDollyPan(r),this.update();break;case Ut.TOUCH_DOLLY_ROTATE:if(this.enableZoom===!1&&this.enableRotate===!1)return;this._handleTouchMoveDollyRotate(r),this.update();break;default:this.state=Ut.NONE}}function by(r){this.enabled!==!1&&r.preventDefault()}function My(r){r.key==="Control"&&(this._controlActive=!0,this.domElement.getRootNode().addEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}function wy(r){r.key==="Control"&&(this._controlActive=!1,this.domElement.getRootNode().removeEventListener("keyup",this._interceptControlUp,{passive:!0,capture:!0}))}const as=new Ua,yn=new L,Xi=new L,Gt=new St,Xu={X:new L(1,0,0),Y:new L(0,1,0),Z:new L(0,0,1)},Cl={type:"change"},ju={type:"mouseDown",mode:null},qu={type:"mouseUp",mode:null},Yu={type:"objectChange"};class Sy extends df{constructor(e,t=null){super(void 0,t);const n=new Py(this);this._root=n;const i=new Ly;this._gizmo=i,n.add(i);const s=new Dy;this._plane=s,n.add(s);const o=this;function a(y,b){let D=b;Object.defineProperty(o,y,{get:function(){return D!==void 0?D:b},set:function(R){D!==R&&(D=R,s[y]=R,i[y]=R,o.dispatchEvent({type:y+"-changed",value:R}),o.dispatchEvent(Cl))}}),o[y]=b,s[y]=b,i[y]=b}a("camera",e),a("object",void 0),a("enabled",!0),a("axis",null),a("mode","translate"),a("translationSnap",null),a("rotationSnap",null),a("scaleSnap",null),a("space","world"),a("size",1),a("dragging",!1),a("showX",!0),a("showY",!0),a("showZ",!0),a("minX",-1/0),a("maxX",1/0),a("minY",-1/0),a("maxY",1/0),a("minZ",-1/0),a("maxZ",1/0);const l=new L,c=new L,h=new St,u=new St,d=new L,f=new St,g=new L,v=new L,m=new L,p=0,w=new L;a("worldPosition",l),a("worldPositionStart",c),a("worldQuaternion",h),a("worldQuaternionStart",u),a("cameraPosition",d),a("cameraQuaternion",f),a("pointStart",g),a("pointEnd",v),a("rotationAxis",m),a("rotationAngle",p),a("eye",w),this._offset=new L,this._startNorm=new L,this._endNorm=new L,this._cameraScale=new L,this._parentPosition=new L,this._parentQuaternion=new St,this._parentQuaternionInv=new St,this._parentScale=new L,this._worldScaleStart=new L,this._worldQuaternionInv=new St,this._worldScale=new L,this._positionStart=new L,this._quaternionStart=new St,this._scaleStart=new L,this._getPointer=Ey.bind(this),this._onPointerDown=Ay.bind(this),this._onPointerHover=Ty.bind(this),this._onPointerMove=Ry.bind(this),this._onPointerUp=Cy.bind(this),t!==null&&this.connect()}connect(){this.domElement.addEventListener("pointerdown",this._onPointerDown),this.domElement.addEventListener("pointermove",this._onPointerHover),this.domElement.addEventListener("pointerup",this._onPointerUp),this.domElement.style.touchAction="none"}disconnect(){this.domElement.removeEventListener("pointerdown",this._onPointerDown),this.domElement.removeEventListener("pointermove",this._onPointerHover),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.domElement.removeEventListener("pointerup",this._onPointerUp),this.domElement.style.touchAction="auto"}getHelper(){return this._root}pointerHover(e){if(this.object===void 0||this.dragging===!0)return;e!==null&&as.setFromCamera(e,this.camera);const t=Pl(this._gizmo.picker[this.mode],as);t?this.axis=t.object.name:this.axis=null}pointerDown(e){if(!(this.object===void 0||this.dragging===!0||e!=null&&e.button!==0)&&this.axis!==null){e!==null&&as.setFromCamera(e,this.camera);const t=Pl(this._plane,as,!0);t&&(this.object.updateMatrixWorld(),this.object.parent.updateMatrixWorld(),this._positionStart.copy(this.object.position),this._quaternionStart.copy(this.object.quaternion),this._scaleStart.copy(this.object.scale),this.object.matrixWorld.decompose(this.worldPositionStart,this.worldQuaternionStart,this._worldScaleStart),this.pointStart.copy(t.point).sub(this.worldPositionStart)),this.dragging=!0,ju.mode=this.mode,this.dispatchEvent(ju)}}pointerMove(e){const t=this.axis,n=this.mode,i=this.object;let s=this.space;if(n==="scale"?s="local":(t==="E"||t==="XYZE"||t==="XYZ")&&(s="world"),i===void 0||t===null||this.dragging===!1||e!==null&&e.button!==-1)return;e!==null&&as.setFromCamera(e,this.camera);const o=Pl(this._plane,as,!0);if(o){if(this.pointEnd.copy(o.point).sub(this.worldPositionStart),n==="translate")this._offset.copy(this.pointEnd).sub(this.pointStart),s==="local"&&t!=="XYZ"&&this._offset.applyQuaternion(this._worldQuaternionInv),t.indexOf("X")===-1&&(this._offset.x=0),t.indexOf("Y")===-1&&(this._offset.y=0),t.indexOf("Z")===-1&&(this._offset.z=0),s==="local"&&t!=="XYZ"?this._offset.applyQuaternion(this._quaternionStart).divide(this._parentScale):this._offset.applyQuaternion(this._parentQuaternionInv).divide(this._parentScale),i.position.copy(this._offset).add(this._positionStart),this.translationSnap&&(s==="local"&&(i.position.applyQuaternion(Gt.copy(this._quaternionStart).invert()),t.search("X")!==-1&&(i.position.x=Math.round(i.position.x/this.translationSnap)*this.translationSnap),t.search("Y")!==-1&&(i.position.y=Math.round(i.position.y/this.translationSnap)*this.translationSnap),t.search("Z")!==-1&&(i.position.z=Math.round(i.position.z/this.translationSnap)*this.translationSnap),i.position.applyQuaternion(this._quaternionStart)),s==="world"&&(i.parent&&i.position.add(yn.setFromMatrixPosition(i.parent.matrixWorld)),t.search("X")!==-1&&(i.position.x=Math.round(i.position.x/this.translationSnap)*this.translationSnap),t.search("Y")!==-1&&(i.position.y=Math.round(i.position.y/this.translationSnap)*this.translationSnap),t.search("Z")!==-1&&(i.position.z=Math.round(i.position.z/this.translationSnap)*this.translationSnap),i.parent&&i.position.sub(yn.setFromMatrixPosition(i.parent.matrixWorld)))),i.position.x=Math.max(this.minX,Math.min(this.maxX,i.position.x)),i.position.y=Math.max(this.minY,Math.min(this.maxY,i.position.y)),i.position.z=Math.max(this.minZ,Math.min(this.maxZ,i.position.z));else if(n==="scale"){if(t.search("XYZ")!==-1){let a=this.pointEnd.length()/this.pointStart.length();this.pointEnd.dot(this.pointStart)<0&&(a*=-1),Xi.set(a,a,a)}else yn.copy(this.pointStart),Xi.copy(this.pointEnd),yn.applyQuaternion(this._worldQuaternionInv),Xi.applyQuaternion(this._worldQuaternionInv),Xi.divide(yn),t.search("X")===-1&&(Xi.x=1),t.search("Y")===-1&&(Xi.y=1),t.search("Z")===-1&&(Xi.z=1);i.scale.copy(this._scaleStart).multiply(Xi),this.scaleSnap&&(t.search("X")!==-1&&(i.scale.x=Math.round(i.scale.x/this.scaleSnap)*this.scaleSnap||this.scaleSnap),t.search("Y")!==-1&&(i.scale.y=Math.round(i.scale.y/this.scaleSnap)*this.scaleSnap||this.scaleSnap),t.search("Z")!==-1&&(i.scale.z=Math.round(i.scale.z/this.scaleSnap)*this.scaleSnap||this.scaleSnap))}else if(n==="rotate"){this._offset.copy(this.pointEnd).sub(this.pointStart);const a=20/this.worldPosition.distanceTo(yn.setFromMatrixPosition(this.camera.matrixWorld));let l=!1;t==="XYZE"?(this.rotationAxis.copy(this._offset).cross(this.eye).normalize(),this.rotationAngle=this._offset.dot(yn.copy(this.rotationAxis).cross(this.eye))*a):(t==="X"||t==="Y"||t==="Z")&&(this.rotationAxis.copy(Xu[t]),yn.copy(Xu[t]),s==="local"&&yn.applyQuaternion(this.worldQuaternion),yn.cross(this.eye),yn.length()===0?l=!0:this.rotationAngle=this._offset.dot(yn.normalize())*a),(t==="E"||l)&&(this.rotationAxis.copy(this.eye),this.rotationAngle=this.pointEnd.angleTo(this.pointStart),this._startNorm.copy(this.pointStart).normalize(),this._endNorm.copy(this.pointEnd).normalize(),this.rotationAngle*=this._endNorm.cross(this._startNorm).dot(this.eye)<0?1:-1),this.rotationSnap&&(this.rotationAngle=Math.round(this.rotationAngle/this.rotationSnap)*this.rotationSnap),s==="local"&&t!=="E"&&t!=="XYZE"?(i.quaternion.copy(this._quaternionStart),i.quaternion.multiply(Gt.setFromAxisAngle(this.rotationAxis,this.rotationAngle)).normalize()):(this.rotationAxis.applyQuaternion(this._parentQuaternionInv),i.quaternion.copy(Gt.setFromAxisAngle(this.rotationAxis,this.rotationAngle)),i.quaternion.multiply(this._quaternionStart).normalize())}this.dispatchEvent(Cl),this.dispatchEvent(Yu)}}pointerUp(e){e!==null&&e.button!==0||(this.dragging&&this.axis!==null&&(qu.mode=this.mode,this.dispatchEvent(qu)),this.dragging=!1,this.axis=null)}dispose(){this.disconnect(),this._root.dispose()}attach(e){return this.object=e,this._root.visible=!0,this}detach(){return this.object=void 0,this.axis=null,this._root.visible=!1,this}reset(){this.enabled&&this.dragging&&(this.object.position.copy(this._positionStart),this.object.quaternion.copy(this._quaternionStart),this.object.scale.copy(this._scaleStart),this.dispatchEvent(Cl),this.dispatchEvent(Yu),this.pointStart.copy(this.pointEnd))}getRaycaster(){return as}getMode(){return this.mode}setMode(e){this.mode=e}setTranslationSnap(e){this.translationSnap=e}setRotationSnap(e){this.rotationSnap=e}setScaleSnap(e){this.scaleSnap=e}setSize(e){this.size=e}setSpace(e){this.space=e}}function Ey(r){if(this.domElement.ownerDocument.pointerLockElement)return{x:0,y:0,button:r.button};{const e=this.domElement.getBoundingClientRect();return{x:(r.clientX-e.left)/e.width*2-1,y:-(r.clientY-e.top)/e.height*2+1,button:r.button}}}function Ty(r){if(this.enabled)switch(r.pointerType){case"mouse":case"pen":this.pointerHover(this._getPointer(r));break}}function Ay(r){this.enabled&&(document.pointerLockElement||this.domElement.setPointerCapture(r.pointerId),this.domElement.addEventListener("pointermove",this._onPointerMove),this.pointerHover(this._getPointer(r)),this.pointerDown(this._getPointer(r)))}function Ry(r){this.enabled&&this.pointerMove(this._getPointer(r))}function Cy(r){this.enabled&&(this.domElement.releasePointerCapture(r.pointerId),this.domElement.removeEventListener("pointermove",this._onPointerMove),this.pointerUp(this._getPointer(r)))}function Pl(r,e,t){const n=e.intersectObject(r,!0);for(let i=0;i<n.length;i++)if(n[i].object.visible||t)return n[i];return!1}const Yo=new Bt,Ot=new L(0,1,0),Zu=new L(0,0,0),Ku=new Ee,Zo=new St,pa=new St,li=new L,$u=new Ee,Br=new L(1,0,0),hs=new L(0,1,0),kr=new L(0,0,1),Ko=new L,Ur=new L,Fr=new L;class Py extends Mt{constructor(e){super(),this.isTransformControlsRoot=!0,this.controls=e,this.visible=!1}updateMatrixWorld(e){const t=this.controls;t.object!==void 0&&(t.object.updateMatrixWorld(),t.object.parent===null?console.error("TransformControls: The attached 3D object must be a part of the scene graph."):t.object.parent.matrixWorld.decompose(t._parentPosition,t._parentQuaternion,t._parentScale),t.object.matrixWorld.decompose(t.worldPosition,t.worldQuaternion,t._worldScale),t._parentQuaternionInv.copy(t._parentQuaternion).invert(),t._worldQuaternionInv.copy(t.worldQuaternion).invert()),t.camera.updateMatrixWorld(),t.camera.matrixWorld.decompose(t.cameraPosition,t.cameraQuaternion,t._cameraScale),t.camera.isOrthographicCamera?t.camera.getWorldDirection(t.eye).negate():t.eye.copy(t.cameraPosition).sub(t.worldPosition).normalize(),super.updateMatrixWorld(e)}dispose(){this.traverse(function(e){e.geometry&&e.geometry.dispose(),e.material&&e.material.dispose()})}}class Ly extends Mt{constructor(){super(),this.isTransformControlsGizmo=!0,this.type="TransformControlsGizmo";const e=new zn({depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1,transparent:!0}),t=new Yn({depthTest:!1,depthWrite:!1,fog:!1,toneMapped:!1,transparent:!0}),n=e.clone();n.opacity=.15;const i=t.clone();i.opacity=.5;const s=e.clone();s.color.setHex(16711680);const o=e.clone();o.color.setHex(65280);const a=e.clone();a.color.setHex(255);const l=e.clone();l.color.setHex(16711680),l.opacity=.5;const c=e.clone();c.color.setHex(65280),c.opacity=.5;const h=e.clone();h.color.setHex(255),h.opacity=.5;const u=e.clone();u.opacity=.25;const d=e.clone();d.color.setHex(16776960),d.opacity=.25,e.clone().color.setHex(16776960);const g=e.clone();g.color.setHex(7895160);const v=new sn(0,.04,.1,12);v.translate(0,.05,0);const m=new Zt(.08,.08,.08);m.translate(0,.04,0);const p=new yt;p.setAttribute("position",new Ne([0,0,0,1,0,0],3));const w=new sn(.0075,.0075,.5,3);w.translate(0,.25,0);function y(K,z){const Z=new ds(K,.0075,3,64,z*Math.PI*2);return Z.rotateY(Math.PI/2),Z.rotateX(Math.PI/2),Z}function b(){const K=new yt;return K.setAttribute("position",new Ne([0,0,0,1,1,1],3)),K}const D={X:[[new ve(v,s),[.5,0,0],[0,0,-Math.PI/2]],[new ve(v,s),[-.5,0,0],[0,0,Math.PI/2]],[new ve(w,s),[0,0,0],[0,0,-Math.PI/2]]],Y:[[new ve(v,o),[0,.5,0]],[new ve(v,o),[0,-.5,0],[Math.PI,0,0]],[new ve(w,o)]],Z:[[new ve(v,a),[0,0,.5],[Math.PI/2,0,0]],[new ve(v,a),[0,0,-.5],[-Math.PI/2,0,0]],[new ve(w,a),null,[Math.PI/2,0,0]]],XYZ:[[new ve(new nr(.1,0),u.clone()),[0,0,0]]],XY:[[new ve(new Zt(.15,.15,.01),h.clone()),[.15,.15,0]]],YZ:[[new ve(new Zt(.15,.15,.01),l.clone()),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Zt(.15,.15,.01),c.clone()),[.15,0,.15],[-Math.PI/2,0,0]]]},R={X:[[new ve(new sn(.2,0,.6,4),n),[.3,0,0],[0,0,-Math.PI/2]],[new ve(new sn(.2,0,.6,4),n),[-.3,0,0],[0,0,Math.PI/2]]],Y:[[new ve(new sn(.2,0,.6,4),n),[0,.3,0]],[new ve(new sn(.2,0,.6,4),n),[0,-.3,0],[0,0,Math.PI]]],Z:[[new ve(new sn(.2,0,.6,4),n),[0,0,.3],[Math.PI/2,0,0]],[new ve(new sn(.2,0,.6,4),n),[0,0,-.3],[-Math.PI/2,0,0]]],XYZ:[[new ve(new nr(.2,0),n)]],XY:[[new ve(new Zt(.2,.2,.01),n),[.15,.15,0]]],YZ:[[new ve(new Zt(.2,.2,.01),n),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Zt(.2,.2,.01),n),[.15,0,.15],[-Math.PI/2,0,0]]]},P={START:[[new ve(new nr(.01,2),i),null,null,null,"helper"]],END:[[new ve(new nr(.01,2),i),null,null,null,"helper"]],DELTA:[[new Gn(b(),i),null,null,null,"helper"]],X:[[new Gn(p,i.clone()),[-1e3,0,0],null,[1e6,1,1],"helper"]],Y:[[new Gn(p,i.clone()),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],"helper"]],Z:[[new Gn(p,i.clone()),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],"helper"]]},M={XYZE:[[new ve(y(.5,1),g),null,[0,Math.PI/2,0]]],X:[[new ve(y(.5,.5),s)]],Y:[[new ve(y(.5,.5),o),null,[0,0,-Math.PI/2]]],Z:[[new ve(y(.5,.5),a),null,[0,Math.PI/2,0]]],E:[[new ve(y(.75,1),d),null,[0,Math.PI/2,0]]]},_={AXIS:[[new Gn(p,i.clone()),[-1e3,0,0],null,[1e6,1,1],"helper"]]},x={XYZE:[[new ve(new to(.25,10,8),n)]],X:[[new ve(new ds(.5,.1,4,24),n),[0,0,0],[0,-Math.PI/2,-Math.PI/2]]],Y:[[new ve(new ds(.5,.1,4,24),n),[0,0,0],[Math.PI/2,0,0]]],Z:[[new ve(new ds(.5,.1,4,24),n),[0,0,0],[0,0,-Math.PI/2]]],E:[[new ve(new ds(.75,.1,2,24),n)]]},T={X:[[new ve(m,s),[.5,0,0],[0,0,-Math.PI/2]],[new ve(w,s),[0,0,0],[0,0,-Math.PI/2]],[new ve(m,s),[-.5,0,0],[0,0,Math.PI/2]]],Y:[[new ve(m,o),[0,.5,0]],[new ve(w,o)],[new ve(m,o),[0,-.5,0],[0,0,Math.PI]]],Z:[[new ve(m,a),[0,0,.5],[Math.PI/2,0,0]],[new ve(w,a),[0,0,0],[Math.PI/2,0,0]],[new ve(m,a),[0,0,-.5],[-Math.PI/2,0,0]]],XY:[[new ve(new Zt(.15,.15,.01),h),[.15,.15,0]]],YZ:[[new ve(new Zt(.15,.15,.01),l),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Zt(.15,.15,.01),c),[.15,0,.15],[-Math.PI/2,0,0]]],XYZ:[[new ve(new Zt(.1,.1,.1),u.clone())]]},F={X:[[new ve(new sn(.2,0,.6,4),n),[.3,0,0],[0,0,-Math.PI/2]],[new ve(new sn(.2,0,.6,4),n),[-.3,0,0],[0,0,Math.PI/2]]],Y:[[new ve(new sn(.2,0,.6,4),n),[0,.3,0]],[new ve(new sn(.2,0,.6,4),n),[0,-.3,0],[0,0,Math.PI]]],Z:[[new ve(new sn(.2,0,.6,4),n),[0,0,.3],[Math.PI/2,0,0]],[new ve(new sn(.2,0,.6,4),n),[0,0,-.3],[-Math.PI/2,0,0]]],XY:[[new ve(new Zt(.2,.2,.01),n),[.15,.15,0]]],YZ:[[new ve(new Zt(.2,.2,.01),n),[0,.15,.15],[0,Math.PI/2,0]]],XZ:[[new ve(new Zt(.2,.2,.01),n),[.15,0,.15],[-Math.PI/2,0,0]]],XYZ:[[new ve(new Zt(.2,.2,.2),n),[0,0,0]]]},k={X:[[new Gn(p,i.clone()),[-1e3,0,0],null,[1e6,1,1],"helper"]],Y:[[new Gn(p,i.clone()),[0,-1e3,0],[0,0,Math.PI/2],[1e6,1,1],"helper"]],Z:[[new Gn(p,i.clone()),[0,0,-1e3],[0,-Math.PI/2,0],[1e6,1,1],"helper"]]};function G(K){const z=new Mt;for(const Z in K)for(let V=K[Z].length;V--;){const Y=K[Z][V][0].clone(),ue=K[Z][V][1],ie=K[Z][V][2],he=K[Z][V][3],se=K[Z][V][4];Y.name=Z,Y.tag=se,ue&&Y.position.set(ue[0],ue[1],ue[2]),ie&&Y.rotation.set(ie[0],ie[1],ie[2]),he&&Y.scale.set(he[0],he[1],he[2]),Y.updateMatrix();const H=Y.geometry.clone();H.applyMatrix4(Y.matrix),Y.geometry=H,Y.renderOrder=1/0,Y.position.set(0,0,0),Y.rotation.set(0,0,0),Y.scale.set(1,1,1),z.add(Y)}return z}this.gizmo={},this.picker={},this.helper={},this.add(this.gizmo.translate=G(D)),this.add(this.gizmo.rotate=G(M)),this.add(this.gizmo.scale=G(T)),this.add(this.picker.translate=G(R)),this.add(this.picker.rotate=G(x)),this.add(this.picker.scale=G(F)),this.add(this.helper.translate=G(P)),this.add(this.helper.rotate=G(_)),this.add(this.helper.scale=G(k)),this.picker.translate.visible=!1,this.picker.rotate.visible=!1,this.picker.scale.visible=!1}updateMatrixWorld(e){const n=(this.mode==="scale"?"local":this.space)==="local"?this.worldQuaternion:pa;this.gizmo.translate.visible=this.mode==="translate",this.gizmo.rotate.visible=this.mode==="rotate",this.gizmo.scale.visible=this.mode==="scale",this.helper.translate.visible=this.mode==="translate",this.helper.rotate.visible=this.mode==="rotate",this.helper.scale.visible=this.mode==="scale";let i=[];i=i.concat(this.picker[this.mode].children),i=i.concat(this.gizmo[this.mode].children),i=i.concat(this.helper[this.mode].children);for(let s=0;s<i.length;s++){const o=i[s];o.visible=!0,o.rotation.set(0,0,0),o.position.copy(this.worldPosition);let a;if(this.camera.isOrthographicCamera?a=(this.camera.top-this.camera.bottom)/this.camera.zoom:a=this.worldPosition.distanceTo(this.cameraPosition)*Math.min(1.9*Math.tan(Math.PI*this.camera.fov/360)/this.camera.zoom,7),o.scale.set(1,1,1).multiplyScalar(a*this.size/4),o.tag==="helper"){o.visible=!1,o.name==="AXIS"?(o.visible=!!this.axis,this.axis==="X"&&(Gt.setFromEuler(Yo.set(0,0,0)),o.quaternion.copy(n).multiply(Gt),Math.abs(Ot.copy(Br).applyQuaternion(n).dot(this.eye))>.9&&(o.visible=!1)),this.axis==="Y"&&(Gt.setFromEuler(Yo.set(0,0,Math.PI/2)),o.quaternion.copy(n).multiply(Gt),Math.abs(Ot.copy(hs).applyQuaternion(n).dot(this.eye))>.9&&(o.visible=!1)),this.axis==="Z"&&(Gt.setFromEuler(Yo.set(0,Math.PI/2,0)),o.quaternion.copy(n).multiply(Gt),Math.abs(Ot.copy(kr).applyQuaternion(n).dot(this.eye))>.9&&(o.visible=!1)),this.axis==="XYZE"&&(Gt.setFromEuler(Yo.set(0,Math.PI/2,0)),Ot.copy(this.rotationAxis),o.quaternion.setFromRotationMatrix(Ku.lookAt(Zu,Ot,hs)),o.quaternion.multiply(Gt),o.visible=this.dragging),this.axis==="E"&&(o.visible=!1)):o.name==="START"?(o.position.copy(this.worldPositionStart),o.visible=this.dragging):o.name==="END"?(o.position.copy(this.worldPosition),o.visible=this.dragging):o.name==="DELTA"?(o.position.copy(this.worldPositionStart),o.quaternion.copy(this.worldQuaternionStart),yn.set(1e-10,1e-10,1e-10).add(this.worldPositionStart).sub(this.worldPosition).multiplyScalar(-1),yn.applyQuaternion(this.worldQuaternionStart.clone().invert()),o.scale.copy(yn),o.visible=this.dragging):(o.quaternion.copy(n),this.dragging?o.position.copy(this.worldPositionStart):o.position.copy(this.worldPosition),this.axis&&(o.visible=this.axis.search(o.name)!==-1));continue}o.quaternion.copy(n),this.mode==="translate"||this.mode==="scale"?(o.name==="X"&&Math.abs(Ot.copy(Br).applyQuaternion(n).dot(this.eye))>.99&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="Y"&&Math.abs(Ot.copy(hs).applyQuaternion(n).dot(this.eye))>.99&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="Z"&&Math.abs(Ot.copy(kr).applyQuaternion(n).dot(this.eye))>.99&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="XY"&&Math.abs(Ot.copy(kr).applyQuaternion(n).dot(this.eye))<.2&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="YZ"&&Math.abs(Ot.copy(Br).applyQuaternion(n).dot(this.eye))<.2&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1),o.name==="XZ"&&Math.abs(Ot.copy(hs).applyQuaternion(n).dot(this.eye))<.2&&(o.scale.set(1e-10,1e-10,1e-10),o.visible=!1)):this.mode==="rotate"&&(Zo.copy(n),Ot.copy(this.eye).applyQuaternion(Gt.copy(n).invert()),o.name.search("E")!==-1&&o.quaternion.setFromRotationMatrix(Ku.lookAt(this.eye,Zu,hs)),o.name==="X"&&(Gt.setFromAxisAngle(Br,Math.atan2(-Ot.y,Ot.z)),Gt.multiplyQuaternions(Zo,Gt),o.quaternion.copy(Gt)),o.name==="Y"&&(Gt.setFromAxisAngle(hs,Math.atan2(Ot.x,Ot.z)),Gt.multiplyQuaternions(Zo,Gt),o.quaternion.copy(Gt)),o.name==="Z"&&(Gt.setFromAxisAngle(kr,Math.atan2(Ot.y,Ot.x)),Gt.multiplyQuaternions(Zo,Gt),o.quaternion.copy(Gt))),o.visible=o.visible&&(o.name.indexOf("X")===-1||this.showX),o.visible=o.visible&&(o.name.indexOf("Y")===-1||this.showY),o.visible=o.visible&&(o.name.indexOf("Z")===-1||this.showZ),o.visible=o.visible&&(o.name.indexOf("E")===-1||this.showX&&this.showY&&this.showZ),o.material._color=o.material._color||o.material.color.clone(),o.material._opacity=o.material._opacity||o.material.opacity,o.material.color.copy(o.material._color),o.material.opacity=o.material._opacity,this.enabled&&this.axis&&(o.name===this.axis||this.axis.split("").some(function(l){return o.name===l}))&&(o.material.color.setHex(16776960),o.material.opacity=1)}super.updateMatrixWorld(e)}}class Dy extends ve{constructor(){super(new xr(1e5,1e5,2,2),new zn({visible:!1,wireframe:!0,side:Xn,transparent:!0,opacity:.1,toneMapped:!1})),this.isTransformControlsPlane=!0,this.type="TransformControlsPlane"}updateMatrixWorld(e){let t=this.space;switch(this.position.copy(this.worldPosition),this.mode==="scale"&&(t="local"),Ko.copy(Br).applyQuaternion(t==="local"?this.worldQuaternion:pa),Ur.copy(hs).applyQuaternion(t==="local"?this.worldQuaternion:pa),Fr.copy(kr).applyQuaternion(t==="local"?this.worldQuaternion:pa),Ot.copy(Ur),this.mode){case"translate":case"scale":switch(this.axis){case"X":Ot.copy(this.eye).cross(Ko),li.copy(Ko).cross(Ot);break;case"Y":Ot.copy(this.eye).cross(Ur),li.copy(Ur).cross(Ot);break;case"Z":Ot.copy(this.eye).cross(Fr),li.copy(Fr).cross(Ot);break;case"XY":li.copy(Fr);break;case"YZ":li.copy(Ko);break;case"XZ":Ot.copy(Fr),li.copy(Ur);break;case"XYZ":case"E":li.set(0,0,0);break}break;case"rotate":default:li.set(0,0,0)}li.length()===0?this.quaternion.copy(this.cameraQuaternion):($u.lookAt(yn.set(0,0,0),li,Ot),this.quaternion.setFromRotationMatrix($u)),super.updateMatrixWorld(e)}}function xf(r,e,t){const n=t.length-r-1;if(e>=t[n])return n-1;if(e<=t[r])return r;let i=r,s=n,o=Math.floor((i+s)/2);for(;e<t[o]||e>=t[o+1];)e<t[o]?s=o:i=o,o=Math.floor((i+s)/2);return o}function Iy(r,e,t,n){const i=[],s=[],o=[];i[0]=1;for(let a=1;a<=t;++a){s[a]=e-n[r+1-a],o[a]=n[r+a]-e;let l=0;for(let c=0;c<a;++c){const h=o[c+1],u=s[a-c],d=i[c]/(h+u);i[c]=l+h*d,l=u*d}i[a]=l}return i}function Ny(r,e,t,n){const i=xf(r,n,e),s=Iy(i,n,r,e),o=new at(0,0,0,0);for(let a=0;a<=r;++a){const l=t[i-r+a],c=s[a],h=l.w*c;o.x+=l.x*h,o.y+=l.y*h,o.z+=l.z*h,o.w+=l.w*c}return o}function Uy(r,e,t,n,i){const s=[];for(let u=0;u<=t;++u)s[u]=0;const o=[];for(let u=0;u<=n;++u)o[u]=s.slice(0);const a=[];for(let u=0;u<=t;++u)a[u]=s.slice(0);a[0][0]=1;const l=s.slice(0),c=s.slice(0);for(let u=1;u<=t;++u){l[u]=e-i[r+1-u],c[u]=i[r+u]-e;let d=0;for(let f=0;f<u;++f){const g=c[f+1],v=l[u-f];a[u][f]=g+v;const m=a[f][u-1]/a[u][f];a[f][u]=d+g*m,d=v*m}a[u][u]=d}for(let u=0;u<=t;++u)o[0][u]=a[u][t];for(let u=0;u<=t;++u){let d=0,f=1;const g=[];for(let v=0;v<=t;++v)g[v]=s.slice(0);g[0][0]=1;for(let v=1;v<=n;++v){let m=0;const p=u-v,w=t-v;u>=v&&(g[f][0]=g[d][0]/a[w+1][p],m=g[f][0]*a[p][w]);const y=p>=-1?1:-p,b=u-1<=w?v-1:t-u;for(let R=y;R<=b;++R)g[f][R]=(g[d][R]-g[d][R-1])/a[w+1][p+R],m+=g[f][R]*a[p+R][w];u<=w&&(g[f][v]=-g[d][v-1]/a[w+1][u],m+=g[f][v]*a[u][w]),o[v][u]=m;const D=d;d=f,f=D}}let h=t;for(let u=1;u<=n;++u){for(let d=0;d<=t;++d)o[u][d]*=h;h*=t-u}return o}function Fy(r,e,t,n,i){const s=i<r?i:r,o=[],a=xf(r,n,e),l=Uy(a,n,r,s,e),c=[];for(let h=0;h<t.length;++h){const u=t[h].clone(),d=u.w;u.x*=d,u.y*=d,u.z*=d,c[h]=u}for(let h=0;h<=s;++h){const u=c[a-r].clone().multiplyScalar(l[h][0]);for(let d=1;d<=r;++d)u.add(c[a-r+d].clone().multiplyScalar(l[h][d]));o[h]=u}for(let h=s+1;h<=i+1;++h)o[h]=new at(0,0,0);return o}function Oy(r,e){let t=1;for(let i=2;i<=r;++i)t*=i;let n=1;for(let i=2;i<=e;++i)n*=i;for(let i=2;i<=r-e;++i)n*=i;return t/n}function By(r){const e=r.length,t=[],n=[];for(let s=0;s<e;++s){const o=r[s];t[s]=new L(o.x,o.y,o.z),n[s]=o.w}const i=[];for(let s=0;s<e;++s){const o=t[s].clone();for(let a=1;a<=s;++a)o.sub(i[s-a].clone().multiplyScalar(Oy(s,a)*n[a]));i[s]=o.divideScalar(n[0])}return i}function ky(r,e,t,n,i){const s=Fy(r,e,t,n,i);return By(s)}class zy extends Lm{constructor(e,t,n,i,s){super();const o=t?t.length-1:0,a=n?n.length:0;this.degree=e,this.knots=t,this.controlPoints=[],this.startKnot=i||0,this.endKnot=s||o;for(let l=0;l<a;++l){const c=n[l];this.controlPoints[l]=new at(c.x,c.y,c.z,c.w)}}getPoint(e,t=new L){const n=t,i=this.knots[this.startKnot]+e*(this.knots[this.endKnot]-this.knots[this.startKnot]),s=Ny(this.degree,this.knots,this.controlPoints,i);return s.w!==1&&s.divideScalar(s.w),n.set(s.x,s.y,s.z)}getTangent(e,t=new L){const n=t,i=this.knots[0]+e*(this.knots[this.knots.length-1]-this.knots[0]),s=ky(this.degree,this.knots,this.controlPoints,i,1);return n.copy(s[1]).normalize(),n}toJSON(){const e=super.toJSON();return e.degree=this.degree,e.knots=[...this.knots],e.controlPoints=this.controlPoints.map(t=>t.toArray()),e.startKnot=this.startKnot,e.endKnot=this.endKnot,e}fromJSON(e){return super.fromJSON(e),this.degree=e.degree,this.knots=[...e.knots],this.controlPoints=e.controlPoints.map(t=>new at(t[0],t[1],t[2],t[3])),this.startKnot=e.startKnot,this.endKnot=e.endKnot,this}}/*!
fflate - fast JavaScript compression/decompression
<https://101arrowz.github.io/fflate>
Licensed under MIT. https://github.com/101arrowz/fflate/blob/master/LICENSE
version 0.8.2
*/var qn=Uint8Array,rr=Uint16Array,Hy=Int32Array,yf=new qn([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0,0,0,0]),bf=new qn([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13,0,0]),Vy=new qn([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),Mf=function(r,e){for(var t=new rr(31),n=0;n<31;++n)t[n]=e+=1<<r[n-1];for(var i=new Hy(t[30]),n=1;n<30;++n)for(var s=t[n];s<t[n+1];++s)i[s]=s-t[n]<<5|n;return{b:t,r:i}},wf=Mf(yf,2),Sf=wf.b,Gy=wf.r;Sf[28]=258,Gy[258]=28;var Wy=Mf(bf,0),Xy=Wy.b,Oc=new rr(32768);for(var Ht=0;Ht<32768;++Ht){var ji=(Ht&43690)>>1|(Ht&21845)<<1;ji=(ji&52428)>>2|(ji&13107)<<2,ji=(ji&61680)>>4|(ji&3855)<<4,Oc[Ht]=((ji&65280)>>8|(ji&255)<<8)>>1}var Gr=function(r,e,t){for(var n=r.length,i=0,s=new rr(e);i<n;++i)r[i]&&++s[r[i]-1];var o=new rr(e);for(i=1;i<e;++i)o[i]=o[i-1]+s[i-1]<<1;var a;if(t){a=new rr(1<<e);var l=15-e;for(i=0;i<n;++i)if(r[i])for(var c=i<<4|r[i],h=e-r[i],u=o[r[i]-1]++<<h,d=u|(1<<h)-1;u<=d;++u)a[Oc[u]>>l]=c}else for(a=new rr(n),i=0;i<n;++i)r[i]&&(a[i]=Oc[o[r[i]-1]++]>>15-r[i]);return a},so=new qn(288);for(var Ht=0;Ht<144;++Ht)so[Ht]=8;for(var Ht=144;Ht<256;++Ht)so[Ht]=9;for(var Ht=256;Ht<280;++Ht)so[Ht]=7;for(var Ht=280;Ht<288;++Ht)so[Ht]=8;var Ef=new qn(32);for(var Ht=0;Ht<32;++Ht)Ef[Ht]=5;var jy=Gr(so,9,1),qy=Gr(Ef,5,1),Ll=function(r){for(var e=r[0],t=1;t<r.length;++t)r[t]>e&&(e=r[t]);return e},ti=function(r,e,t){var n=e/8|0;return(r[n]|r[n+1]<<8)>>(e&7)&t},Dl=function(r,e){var t=e/8|0;return(r[t]|r[t+1]<<8|r[t+2]<<16)>>(e&7)},Yy=function(r){return(r+7)/8|0},Zy=function(r,e,t){return(t==null||t>r.length)&&(t=r.length),new qn(r.subarray(e,t))},Ky=["unexpected EOF","invalid block type","invalid length/literal","invalid distance","stream finished","no stream handler",,"no callback","invalid UTF-8 data","extra field too long","date not in range 1980-2099","filename too long","stream finishing","invalid zip data"],ii=function(r,e,t){var n=new Error(e||Ky[r]);if(n.code=r,Error.captureStackTrace&&Error.captureStackTrace(n,ii),!t)throw n;return n},$y=function(r,e,t,n){var i=r.length,s=0;if(!i||e.f&&!e.l)return t||new qn(0);var o=!t,a=o||e.i!=2,l=e.i;o&&(t=new qn(i*3));var c=function(Re){var Je=t.length;if(Re>Je){var We=new qn(Math.max(Je*2,Re));We.set(t),t=We}},h=e.f||0,u=e.p||0,d=e.b||0,f=e.l,g=e.d,v=e.m,m=e.n,p=i*8;do{if(!f){h=ti(r,u,1);var w=ti(r,u+1,3);if(u+=3,w)if(w==1)f=jy,g=qy,v=9,m=5;else if(w==2){var R=ti(r,u,31)+257,P=ti(r,u+10,15)+4,M=R+ti(r,u+5,31)+1;u+=14;for(var _=new qn(M),x=new qn(19),T=0;T<P;++T)x[Vy[T]]=ti(r,u+T*3,7);u+=P*3;for(var F=Ll(x),k=(1<<F)-1,G=Gr(x,F,1),T=0;T<M;){var K=G[ti(r,u,k)];u+=K&15;var y=K>>4;if(y<16)_[T++]=y;else{var z=0,Z=0;for(y==16?(Z=3+ti(r,u,3),u+=2,z=_[T-1]):y==17?(Z=3+ti(r,u,7),u+=3):y==18&&(Z=11+ti(r,u,127),u+=7);Z--;)_[T++]=z}}var V=_.subarray(0,R),Y=_.subarray(R);v=Ll(V),m=Ll(Y),f=Gr(V,v,1),g=Gr(Y,m,1)}else ii(1);else{var y=Yy(u)+4,b=r[y-4]|r[y-3]<<8,D=y+b;if(D>i){l&&ii(0);break}a&&c(d+b),t.set(r.subarray(y,D),d),e.b=d+=b,e.p=u=D*8,e.f=h;continue}if(u>p){l&&ii(0);break}}a&&c(d+131072);for(var ue=(1<<v)-1,ie=(1<<m)-1,he=u;;he=u){var z=f[Dl(r,u)&ue],se=z>>4;if(u+=z&15,u>p){l&&ii(0);break}if(z||ii(2),se<256)t[d++]=se;else if(se==256){he=u,f=null;break}else{var H=se-254;if(se>264){var T=se-257,j=yf[T];H=ti(r,u,(1<<j)-1)+Sf[T],u+=j}var J=g[Dl(r,u)&ie],te=J>>4;J||ii(3),u+=J&15;var Y=Xy[te];if(te>3){var j=bf[te];Y+=Dl(r,u)&(1<<j)-1,u+=j}if(u>p){l&&ii(0);break}a&&c(d+131072);var ce=d+H;if(d<Y){var be=s-Y,xe=Math.min(Y,ce);for(be+d<0&&ii(3);d<xe;++d)t[d]=n[be+d]}for(;d<ce;++d)t[d]=t[d-Y]}}e.l=f,e.p=he,e.b=d,e.f=h,f&&(h=1,e.m=v,e.d=g,e.n=m)}while(!h);return d!=t.length&&o?Zy(t,0,d):t.subarray(0,d)},Jy=new qn(0),Qy=function(r,e){return((r[0]&15)!=8||r[0]>>4>7||(r[0]<<8|r[1])%31)&&ii(6,"invalid zlib data"),(r[1]>>5&1)==1&&ii(6,"invalid zlib data: "+(r[1]&32?"need":"unexpected")+" dictionary"),(r[1]>>3&4)+2};function eb(r,e){return $y(r.subarray(Qy(r),-4),{i:2},e,e)}var tb=typeof TextDecoder<"u"&&new TextDecoder,nb=0;try{tb.decode(Jy,{stream:!0}),nb=1}catch{}let ib=class extends Mt{constructor(e,t){super(),this.isViewHelper=!0,this.animating=!1,this.center=new L;const n=new ke("#ff4466"),i=new ke("#88ff44"),s=new ke("#4488ff"),o=new ke("#000000"),a={},l=[],c=new Ua,h=new ye,u=new Mt,d=new Na(-2,2,2,-2,0,4);d.position.set(0,0,2);const f=new sn(.04,.04,.8,5).rotateZ(-Math.PI/2).translate(.4,0,0),g=new ve(f,ie(n)),v=new ve(f,ie(i)),m=new ve(f,ie(s));v.rotation.z=Math.PI/2,m.rotation.y=-Math.PI/2,this.add(g),this.add(m),this.add(v);const p=he(n),w=he(i),y=he(s),b=he(o),D=new qs(p),R=new qs(w),P=new qs(y),M=new qs(b),_=new qs(b),x=new qs(b);D.position.x=1,R.position.y=1,P.position.z=1,M.position.x=-1,_.position.y=-1,x.position.z=-1,M.material.opacity=.2,_.material.opacity=.2,x.material.opacity=.2,D.userData.type="posX",R.userData.type="posY",P.userData.type="posZ",M.userData.type="negX",_.userData.type="negY",x.userData.type="negZ",this.add(D),this.add(R),this.add(P),this.add(M),this.add(_),this.add(x),l.push(D),l.push(R),l.push(P),l.push(M),l.push(_),l.push(x);const T=new L,F=128,k=2*Math.PI;this.render=function(H){this.quaternion.copy(e.quaternion).invert(),this.updateMatrixWorld(),T.set(0,0,1),T.applyQuaternion(e.quaternion);const j=t.offsetWidth-F;H.clearDepth(),H.getViewport(V),H.setViewport(j,0,F,F),H.render(this,d),H.setViewport(V.x,V.y,V.z,V.w)};const G=new L,K=new St,z=new St,Z=new St,V=new at;let Y=0;this.handleClick=function(H){if(this.animating===!0)return!1;const j=t.getBoundingClientRect(),J=j.left+(t.offsetWidth-F),te=j.top+(t.offsetHeight-F);h.x=(H.clientX-J)/(j.right-J)*2-1,h.y=-((H.clientY-te)/(j.bottom-te))*2+1,c.setFromCamera(h,d);const ce=c.intersectObjects(l);if(ce.length>0){const xe=ce[0].object;return ue(xe,this.center),this.animating=!0,!0}else return!1},this.setLabels=function(H,j,J){a.labelX=H,a.labelY=j,a.labelZ=J,se()},this.setLabelStyle=function(H,j,J){a.font=H,a.color=j,a.radius=J,se()},this.update=function(H){const j=H*k;z.rotateTowards(Z,j),e.position.set(0,0,1).applyQuaternion(z).multiplyScalar(Y).add(this.center),e.quaternion.rotateTowards(K,j),z.angleTo(Z)===0&&(this.animating=!1)},this.dispose=function(){f.dispose(),g.material.dispose(),v.material.dispose(),m.material.dispose(),D.material.map.dispose(),R.material.map.dispose(),P.material.map.dispose(),M.material.map.dispose(),_.material.map.dispose(),x.material.map.dispose(),D.material.dispose(),R.material.dispose(),P.material.dispose(),M.material.dispose(),_.material.dispose(),x.material.dispose()};function ue(H,j){switch(H.userData.type){case"posX":G.set(1,0,0),K.setFromEuler(new Bt(0,Math.PI*.5,0));break;case"posY":G.set(0,1,0),K.setFromEuler(new Bt(-Math.PI*.5,0,0));break;case"posZ":G.set(0,0,1),K.setFromEuler(new Bt);break;case"negX":G.set(-1,0,0),K.setFromEuler(new Bt(0,-Math.PI*.5,0));break;case"negY":G.set(0,-1,0),K.setFromEuler(new Bt(Math.PI*.5,0,0));break;case"negZ":G.set(0,0,-1),K.setFromEuler(new Bt(0,Math.PI,0));break;default:console.error("ViewHelper: Invalid axis.")}Y=e.position.distanceTo(j),G.multiplyScalar(Y).add(j),u.position.copy(j),u.lookAt(e.position),z.copy(u.quaternion),u.lookAt(G),Z.copy(u.quaternion)}function ie(H){return new zn({color:H,toneMapped:!1})}function he(H,j){const{font:J="24px Arial",color:te="#000000",radius:ce=14}=a,be=document.createElement("canvas");be.width=64,be.height=64;const xe=be.getContext("2d");xe.beginPath(),xe.arc(32,32,ce,0,2*Math.PI),xe.closePath(),xe.fillStyle=H.getStyle(),xe.fill(),j&&(xe.font=J,xe.textAlign="center",xe.fillStyle=te,xe.fillText(j,32,41));const Re=new Pm(be);return Re.colorSpace=vt,new $d({map:Re,toneMapped:!1})}function se(){D.material.map.dispose(),R.material.map.dispose(),P.material.map.dispose(),D.material.dispose(),R.material.dispose(),P.material.dispose(),D.material=he(n,a.labelX),R.material=he(i,a.labelY),P.material=he(s,a.labelZ)}}};const Ju=new Cn,$o=new L;class Tf extends fg{constructor(){super(),this.isLineSegmentsGeometry=!0,this.type="LineSegmentsGeometry";const e=[-1,2,0,1,2,0,-1,1,0,1,1,0,-1,0,0,1,0,0,-1,-1,0,1,-1,0],t=[-1,2,1,2,-1,1,1,1,-1,-1,1,-1,-1,-2,1,-2],n=[0,2,1,2,3,1,2,4,3,4,5,3,4,6,5,6,7,5];this.setIndex(n),this.setAttribute("position",new Ne(e,3)),this.setAttribute("uv",new Ne(t,2))}applyMatrix4(e){const t=this.attributes.instanceStart,n=this.attributes.instanceEnd;return t!==void 0&&(t.applyMatrix4(e),n.applyMatrix4(e),t.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}setPositions(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));const n=new Nc(t,6,1);return this.setAttribute("instanceStart",new mi(n,3,0)),this.setAttribute("instanceEnd",new mi(n,3,3)),this.instanceCount=this.attributes.instanceStart.count,this.computeBoundingBox(),this.computeBoundingSphere(),this}setColors(e){let t;e instanceof Float32Array?t=e:Array.isArray(e)&&(t=new Float32Array(e));const n=new Nc(t,6,1);return this.setAttribute("instanceColorStart",new mi(n,3,0)),this.setAttribute("instanceColorEnd",new mi(n,3,3)),this}fromWireframeGeometry(e){return this.setPositions(e.attributes.position.array),this}fromEdgesGeometry(e){return this.setPositions(e.attributes.position.array),this}fromMesh(e){return this.fromWireframeGeometry(new Zm(e.geometry)),this}fromLineSegments(e){const t=e.geometry;return this.setPositions(t.attributes.position.array),this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new Cn);const e=this.attributes.instanceStart,t=this.attributes.instanceEnd;e!==void 0&&t!==void 0&&(this.boundingBox.setFromBufferAttribute(e),Ju.setFromBufferAttribute(t),this.boundingBox.union(Ju))}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new vi),this.boundingBox===null&&this.computeBoundingBox();const e=this.attributes.instanceStart,t=this.attributes.instanceEnd;if(e!==void 0&&t!==void 0){const n=this.boundingSphere.center;this.boundingBox.getCenter(n);let i=0;for(let s=0,o=e.count;s<o;s++)$o.fromBufferAttribute(e,s),i=Math.max(i,n.distanceToSquared($o)),$o.fromBufferAttribute(t,s),i=Math.max(i,n.distanceToSquared($o));this.boundingSphere.radius=Math.sqrt(i),isNaN(this.boundingSphere.radius)&&console.error("THREE.LineSegmentsGeometry.computeBoundingSphere(): Computed radius is NaN. The instanced position data is likely to have NaN values.",this)}}toJSON(){}applyMatrix(e){return console.warn("THREE.LineSegmentsGeometry: applyMatrix() has been renamed to applyMatrix4()."),this.applyMatrix4(e)}}Se.line={worldUnits:{value:1},linewidth:{value:1},resolution:{value:new ye(1,1)},dashOffset:{value:0},dashScale:{value:1},dashSize:{value:1},gapSize:{value:1}};Nn.line={uniforms:$c.merge([Se.common,Se.fog,Se.line]),vertexShader:`
		#include <common>
		#include <color_pars_vertex>
		#include <fog_pars_vertex>
		#include <logdepthbuf_pars_vertex>
		#include <clipping_planes_pars_vertex>

		uniform float linewidth;
		uniform vec2 resolution;

		attribute vec3 instanceStart;
		attribute vec3 instanceEnd;

		attribute vec3 instanceColorStart;
		attribute vec3 instanceColorEnd;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#ifdef USE_DASH

			uniform float dashScale;
			attribute float instanceDistanceStart;
			attribute float instanceDistanceEnd;
			varying float vLineDistance;

		#endif

		void trimSegment( const in vec4 start, inout vec4 end ) {

			// trim end segment so it terminates between the camera plane and the near plane

			// conservative estimate of the near plane
			float a = projectionMatrix[ 2 ][ 2 ]; // 3nd entry in 3th column
			float b = projectionMatrix[ 3 ][ 2 ]; // 3nd entry in 4th column
			float nearEstimate = - 0.5 * b / a;

			float alpha = ( nearEstimate - start.z ) / ( end.z - start.z );

			end.xyz = mix( start.xyz, end.xyz, alpha );

		}

		void main() {

			#ifdef USE_COLOR

				vColor.xyz = ( position.y < 0.5 ) ? instanceColorStart : instanceColorEnd;

			#endif

			#ifdef USE_DASH

				vLineDistance = ( position.y < 0.5 ) ? dashScale * instanceDistanceStart : dashScale * instanceDistanceEnd;
				vUv = uv;

			#endif

			float aspect = resolution.x / resolution.y;

			// camera space
			vec4 start = modelViewMatrix * vec4( instanceStart, 1.0 );
			vec4 end = modelViewMatrix * vec4( instanceEnd, 1.0 );

			#ifdef WORLD_UNITS

				worldStart = start.xyz;
				worldEnd = end.xyz;

			#else

				vUv = uv;

			#endif

			// special case for perspective projection, and segments that terminate either in, or behind, the camera plane
			// clearly the gpu firmware has a way of addressing this issue when projecting into ndc space
			// but we need to perform ndc-space calculations in the shader, so we must address this issue directly
			// perhaps there is a more elegant solution -- WestLangley

			bool perspective = ( projectionMatrix[ 2 ][ 3 ] == - 1.0 ); // 4th entry in the 3rd column

			if ( perspective ) {

				if ( start.z < 0.0 && end.z >= 0.0 ) {

					trimSegment( start, end );

				} else if ( end.z < 0.0 && start.z >= 0.0 ) {

					trimSegment( end, start );

				}

			}

			// clip space
			vec4 clipStart = projectionMatrix * start;
			vec4 clipEnd = projectionMatrix * end;

			// ndc space
			vec3 ndcStart = clipStart.xyz / clipStart.w;
			vec3 ndcEnd = clipEnd.xyz / clipEnd.w;

			// direction
			vec2 dir = ndcEnd.xy - ndcStart.xy;

			// account for clip-space aspect ratio
			dir.x *= aspect;
			dir = normalize( dir );

			#ifdef WORLD_UNITS

				vec3 worldDir = normalize( end.xyz - start.xyz );
				vec3 tmpFwd = normalize( mix( start.xyz, end.xyz, 0.5 ) );
				vec3 worldUp = normalize( cross( worldDir, tmpFwd ) );
				vec3 worldFwd = cross( worldDir, worldUp );
				worldPos = position.y < 0.5 ? start: end;

				// height offset
				float hw = linewidth * 0.5;
				worldPos.xyz += position.x < 0.0 ? hw * worldUp : - hw * worldUp;

				// don't extend the line if we're rendering dashes because we
				// won't be rendering the endcaps
				#ifndef USE_DASH

					// cap extension
					worldPos.xyz += position.y < 0.5 ? - hw * worldDir : hw * worldDir;

					// add width to the box
					worldPos.xyz += worldFwd * hw;

					// endcaps
					if ( position.y > 1.0 || position.y < 0.0 ) {

						worldPos.xyz -= worldFwd * 2.0 * hw;

					}

				#endif

				// project the worldpos
				vec4 clip = projectionMatrix * worldPos;

				// shift the depth of the projected points so the line
				// segments overlap neatly
				vec3 clipPose = ( position.y < 0.5 ) ? ndcStart : ndcEnd;
				clip.z = clipPose.z * clip.w;

			#else

				vec2 offset = vec2( dir.y, - dir.x );
				// undo aspect ratio adjustment
				dir.x /= aspect;
				offset.x /= aspect;

				// sign flip
				if ( position.x < 0.0 ) offset *= - 1.0;

				// endcaps
				if ( position.y < 0.0 ) {

					offset += - dir;

				} else if ( position.y > 1.0 ) {

					offset += dir;

				}

				// adjust for linewidth
				offset *= linewidth;

				// adjust for clip-space to screen-space conversion // maybe resolution should be based on viewport ...
				offset /= resolution.y;

				// select end
				vec4 clip = ( position.y < 0.5 ) ? clipStart : clipEnd;

				// back to clip space
				offset *= clip.w;

				clip.xy += offset;

			#endif

			gl_Position = clip;

			vec4 mvPosition = ( position.y < 0.5 ) ? start : end; // this is an approximation

			#include <logdepthbuf_vertex>
			#include <clipping_planes_vertex>
			#include <fog_vertex>

		}
		`,fragmentShader:`
		uniform vec3 diffuse;
		uniform float opacity;
		uniform float linewidth;

		#ifdef USE_DASH

			uniform float dashOffset;
			uniform float dashSize;
			uniform float gapSize;

		#endif

		varying float vLineDistance;

		#ifdef WORLD_UNITS

			varying vec4 worldPos;
			varying vec3 worldStart;
			varying vec3 worldEnd;

			#ifdef USE_DASH

				varying vec2 vUv;

			#endif

		#else

			varying vec2 vUv;

		#endif

		#include <common>
		#include <color_pars_fragment>
		#include <fog_pars_fragment>
		#include <logdepthbuf_pars_fragment>
		#include <clipping_planes_pars_fragment>

		vec2 closestLineToLine(vec3 p1, vec3 p2, vec3 p3, vec3 p4) {

			float mua;
			float mub;

			vec3 p13 = p1 - p3;
			vec3 p43 = p4 - p3;

			vec3 p21 = p2 - p1;

			float d1343 = dot( p13, p43 );
			float d4321 = dot( p43, p21 );
			float d1321 = dot( p13, p21 );
			float d4343 = dot( p43, p43 );
			float d2121 = dot( p21, p21 );

			float denom = d2121 * d4343 - d4321 * d4321;

			float numer = d1343 * d4321 - d1321 * d4343;

			mua = numer / denom;
			mua = clamp( mua, 0.0, 1.0 );
			mub = ( d1343 + d4321 * ( mua ) ) / d4343;
			mub = clamp( mub, 0.0, 1.0 );

			return vec2( mua, mub );

		}

		void main() {

			#include <clipping_planes_fragment>

			#ifdef USE_DASH

				if ( vUv.y < - 1.0 || vUv.y > 1.0 ) discard; // discard endcaps

				if ( mod( vLineDistance + dashOffset, dashSize + gapSize ) > dashSize ) discard; // todo - FIX

			#endif

			float alpha = opacity;

			#ifdef WORLD_UNITS

				// Find the closest points on the view ray and the line segment
				vec3 rayEnd = normalize( worldPos.xyz ) * 1e5;
				vec3 lineDir = worldEnd - worldStart;
				vec2 params = closestLineToLine( worldStart, worldEnd, vec3( 0.0, 0.0, 0.0 ), rayEnd );

				vec3 p1 = worldStart + lineDir * params.x;
				vec3 p2 = rayEnd * params.y;
				vec3 delta = p1 - p2;
				float len = length( delta );
				float norm = len / linewidth;

				#ifndef USE_DASH

					#ifdef USE_ALPHA_TO_COVERAGE

						float dnorm = fwidth( norm );
						alpha = 1.0 - smoothstep( 0.5 - dnorm, 0.5 + dnorm, norm );

					#else

						if ( norm > 0.5 ) {

							discard;

						}

					#endif

				#endif

			#else

				#ifdef USE_ALPHA_TO_COVERAGE

					// artifacts appear on some hardware if a derivative is taken within a conditional
					float a = vUv.x;
					float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
					float len2 = a * a + b * b;
					float dlen = fwidth( len2 );

					if ( abs( vUv.y ) > 1.0 ) {

						alpha = 1.0 - smoothstep( 1.0 - dlen, 1.0 + dlen, len2 );

					}

				#else

					if ( abs( vUv.y ) > 1.0 ) {

						float a = vUv.x;
						float b = ( vUv.y > 0.0 ) ? vUv.y - 1.0 : vUv.y + 1.0;
						float len2 = a * a + b * b;

						if ( len2 > 1.0 ) discard;

					}

				#endif

			#endif

			vec4 diffuseColor = vec4( diffuse, alpha );

			#include <logdepthbuf_fragment>
			#include <color_fragment>

			gl_FragColor = vec4( diffuseColor.rgb, alpha );

			#include <tonemapping_fragment>
			#include <colorspace_fragment>
			#include <fog_fragment>
			#include <premultiplied_alpha_fragment>

		}
		`};class Ta extends _i{constructor(e){super({type:"LineMaterial",uniforms:$c.clone(Nn.line.uniforms),vertexShader:Nn.line.vertexShader,fragmentShader:Nn.line.fragmentShader,clipping:!0}),this.isLineMaterial=!0,this.setValues(e)}get color(){return this.uniforms.diffuse.value}set color(e){this.uniforms.diffuse.value=e}get worldUnits(){return"WORLD_UNITS"in this.defines}set worldUnits(e){e===!0?this.defines.WORLD_UNITS="":delete this.defines.WORLD_UNITS}get linewidth(){return this.uniforms.linewidth.value}set linewidth(e){this.uniforms.linewidth&&(this.uniforms.linewidth.value=e)}get dashed(){return"USE_DASH"in this.defines}set dashed(e){e===!0!==this.dashed&&(this.needsUpdate=!0),e===!0?this.defines.USE_DASH="":delete this.defines.USE_DASH}get dashScale(){return this.uniforms.dashScale.value}set dashScale(e){this.uniforms.dashScale.value=e}get dashSize(){return this.uniforms.dashSize.value}set dashSize(e){this.uniforms.dashSize.value=e}get dashOffset(){return this.uniforms.dashOffset.value}set dashOffset(e){this.uniforms.dashOffset.value=e}get gapSize(){return this.uniforms.gapSize.value}set gapSize(e){this.uniforms.gapSize.value=e}get opacity(){return this.uniforms.opacity.value}set opacity(e){this.uniforms&&(this.uniforms.opacity.value=e)}get resolution(){return this.uniforms.resolution.value}set resolution(e){this.uniforms.resolution.value.copy(e)}get alphaToCoverage(){return"USE_ALPHA_TO_COVERAGE"in this.defines}set alphaToCoverage(e){this.defines&&(e===!0!==this.alphaToCoverage&&(this.needsUpdate=!0),e===!0?this.defines.USE_ALPHA_TO_COVERAGE="":delete this.defines.USE_ALPHA_TO_COVERAGE)}}const Il=new at,Qu=new L,ed=new L,un=new at,dn=new at,ci=new at,Nl=new L,Ul=new Ee,fn=new Eg,td=new L,Jo=new Cn,Qo=new vi,hi=new at;let fi,_s;function nd(r,e,t){return hi.set(0,0,-e,1).applyMatrix4(r.projectionMatrix),hi.multiplyScalar(1/hi.w),hi.x=_s/t.width,hi.y=_s/t.height,hi.applyMatrix4(r.projectionMatrixInverse),hi.multiplyScalar(1/hi.w),Math.abs(Math.max(hi.x,hi.y))}function sb(r,e){const t=r.matrixWorld,n=r.geometry,i=n.attributes.instanceStart,s=n.attributes.instanceEnd,o=Math.min(n.instanceCount,i.count);for(let a=0,l=o;a<l;a++){fn.start.fromBufferAttribute(i,a),fn.end.fromBufferAttribute(s,a),fn.applyMatrix4(t);const c=new L,h=new L;fi.distanceSqToSegment(fn.start,fn.end,h,c),h.distanceTo(c)<_s*.5&&e.push({point:h,pointOnLine:c,distance:fi.origin.distanceTo(h),object:r,face:null,faceIndex:a,uv:null,uv1:null})}}function rb(r,e,t){const n=e.projectionMatrix,s=r.material.resolution,o=r.matrixWorld,a=r.geometry,l=a.attributes.instanceStart,c=a.attributes.instanceEnd,h=Math.min(a.instanceCount,l.count),u=-e.near;fi.at(1,ci),ci.w=1,ci.applyMatrix4(e.matrixWorldInverse),ci.applyMatrix4(n),ci.multiplyScalar(1/ci.w),ci.x*=s.x/2,ci.y*=s.y/2,ci.z=0,Nl.copy(ci),Ul.multiplyMatrices(e.matrixWorldInverse,o);for(let d=0,f=h;d<f;d++){if(un.fromBufferAttribute(l,d),dn.fromBufferAttribute(c,d),un.w=1,dn.w=1,un.applyMatrix4(Ul),dn.applyMatrix4(Ul),un.z>u&&dn.z>u)continue;if(un.z>u){const y=un.z-dn.z,b=(un.z-u)/y;un.lerp(dn,b)}else if(dn.z>u){const y=dn.z-un.z,b=(dn.z-u)/y;dn.lerp(un,b)}un.applyMatrix4(n),dn.applyMatrix4(n),un.multiplyScalar(1/un.w),dn.multiplyScalar(1/dn.w),un.x*=s.x/2,un.y*=s.y/2,dn.x*=s.x/2,dn.y*=s.y/2,fn.start.copy(un),fn.start.z=0,fn.end.copy(dn),fn.end.z=0;const v=fn.closestPointToPointParameter(Nl,!0);fn.at(v,td);const m=Pt.lerp(un.z,dn.z,v),p=m>=-1&&m<=1,w=Nl.distanceTo(td)<_s*.5;if(p&&w){fn.start.fromBufferAttribute(l,d),fn.end.fromBufferAttribute(c,d),fn.start.applyMatrix4(o),fn.end.applyMatrix4(o);const y=new L,b=new L;fi.distanceSqToSegment(fn.start,fn.end,b,y),t.push({point:b,pointOnLine:y,distance:fi.origin.distanceTo(b),object:r,face:null,faceIndex:d,uv:null,uv1:null})}}}class ob extends ve{constructor(e=new Tf,t=new Ta({color:Math.random()*16777215})){super(e,t),this.isLineSegments2=!0,this.type="LineSegments2"}computeLineDistances(){const e=this.geometry,t=e.attributes.instanceStart,n=e.attributes.instanceEnd,i=new Float32Array(2*t.count);for(let o=0,a=0,l=t.count;o<l;o++,a+=2)Qu.fromBufferAttribute(t,o),ed.fromBufferAttribute(n,o),i[a]=a===0?0:i[a-1],i[a+1]=i[a]+Qu.distanceTo(ed);const s=new Nc(i,2,1);return e.setAttribute("instanceDistanceStart",new mi(s,1,0)),e.setAttribute("instanceDistanceEnd",new mi(s,1,1)),this}raycast(e,t){const n=this.material.worldUnits,i=e.camera;i===null&&!n&&console.error('LineSegments2: "Raycaster.camera" needs to be set in order to raycast against LineSegments2 while worldUnits is set to false.');const s=e.params.Line2!==void 0&&e.params.Line2.threshold||0;fi=e.ray;const o=this.matrixWorld,a=this.geometry,l=this.material;_s=l.linewidth+s,a.boundingSphere===null&&a.computeBoundingSphere(),Qo.copy(a.boundingSphere).applyMatrix4(o);let c;if(n)c=_s*.5;else{const u=Math.max(i.near,Qo.distanceToPoint(fi.origin));c=nd(i,u,l.resolution)}if(Qo.radius+=c,fi.intersectsSphere(Qo)===!1)return;a.boundingBox===null&&a.computeBoundingBox(),Jo.copy(a.boundingBox).applyMatrix4(o);let h;if(n)h=_s*.5;else{const u=Math.max(i.near,Jo.distanceToPoint(fi.origin));h=nd(i,u,l.resolution)}Jo.expandByScalar(h),fi.intersectsBox(Jo)!==!1&&(n?sb(this,t):rb(this,i,t))}onBeforeRender(e){const t=this.material.uniforms;t&&t.resolution&&(e.getViewport(Il),this.material.uniforms.resolution.value.set(Il.z,Il.w))}}class Bc extends Tf{constructor(){super(),this.isLineGeometry=!0,this.type="LineGeometry"}setPositions(e){const t=e.length-3,n=new Float32Array(2*t);for(let i=0;i<t;i+=3)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5];return super.setPositions(n),this}setColors(e){const t=e.length-3,n=new Float32Array(2*t);for(let i=0;i<t;i+=3)n[2*i]=e[i],n[2*i+1]=e[i+1],n[2*i+2]=e[i+2],n[2*i+3]=e[i+3],n[2*i+4]=e[i+4],n[2*i+5]=e[i+5];return super.setColors(n),this}setFromPoints(e){const t=e.length-1,n=new Float32Array(6*t);for(let i=0;i<t;i++)n[6*i]=e[i].x,n[6*i+1]=e[i].y,n[6*i+2]=e[i].z||0,n[6*i+3]=e[i+1].x,n[6*i+4]=e[i+1].y,n[6*i+5]=e[i+1].z||0;return super.setPositions(n),this}fromLine(e){const t=e.geometry;return this.setPositions(t.attributes.position.array),this}}class id extends ob{constructor(e=new Bc,t=new Ta({color:Math.random()*16777215})){super(e,t),this.isLine2=!0,this.type="Line2"}}class sd extends lg{constructor(e){super(e)}parse(e){function t(z){switch(z.image_type){case d:case v:if(z.colormap_length>256||z.colormap_size!==24||z.colormap_type!==1)throw new Error("THREE.TGALoader: Invalid type colormap data for indexed type.");break;case f:case g:case m:case p:if(z.colormap_type)throw new Error("THREE.TGALoader: Invalid type colormap data for colormap type.");break;case u:throw new Error("THREE.TGALoader: No data.");default:throw new Error("THREE.TGALoader: Invalid type "+z.image_type)}if(z.width<=0||z.height<=0)throw new Error("THREE.TGALoader: Invalid image size.");if(z.pixel_size!==8&&z.pixel_size!==16&&z.pixel_size!==24&&z.pixel_size!==32)throw new Error("THREE.TGALoader: Invalid pixel size "+z.pixel_size)}function n(z,Z,V,Y,ue){let ie,he;const se=V.pixel_size>>3,H=V.width*V.height*se;if(Z&&(he=ue.subarray(Y,Y+=V.colormap_length*(V.colormap_size>>3))),z){ie=new Uint8Array(H);let j,J,te,ce=0;const be=new Uint8Array(se);for(;ce<H;)if(j=ue[Y++],J=(j&127)+1,j&128){for(te=0;te<se;++te)be[te]=ue[Y++];for(te=0;te<J;++te)ie.set(be,ce+te*se);ce+=se*J}else{for(J*=se,te=0;te<J;++te)ie[ce+te]=ue[Y++];ce+=J}}else ie=ue.subarray(Y,Y+=Z?V.width*V.height:H);return{pixel_data:ie,palettes:he}}function i(z,Z,V,Y,ue,ie,he,se,H){const j=H;let J,te=0,ce,be;const xe=x.width;for(be=Z;be!==Y;be+=V)for(ce=ue;ce!==he;ce+=ie,te++)J=se[te],z[(ce+xe*be)*4+3]=255,z[(ce+xe*be)*4+2]=j[J*3+0],z[(ce+xe*be)*4+1]=j[J*3+1],z[(ce+xe*be)*4+0]=j[J*3+2];return z}function s(z,Z,V,Y,ue,ie,he,se){let H,j=0,J,te;const ce=x.width;for(te=Z;te!==Y;te+=V)for(J=ue;J!==he;J+=ie,j+=2)H=se[j+0]+(se[j+1]<<8),z[(J+ce*te)*4+0]=(H&31744)>>7,z[(J+ce*te)*4+1]=(H&992)>>2,z[(J+ce*te)*4+2]=(H&31)<<3,z[(J+ce*te)*4+3]=H&32768?0:255;return z}function o(z,Z,V,Y,ue,ie,he,se){let H=0,j,J;const te=x.width;for(J=Z;J!==Y;J+=V)for(j=ue;j!==he;j+=ie,H+=3)z[(j+te*J)*4+3]=255,z[(j+te*J)*4+2]=se[H+0],z[(j+te*J)*4+1]=se[H+1],z[(j+te*J)*4+0]=se[H+2];return z}function a(z,Z,V,Y,ue,ie,he,se){let H=0,j,J;const te=x.width;for(J=Z;J!==Y;J+=V)for(j=ue;j!==he;j+=ie,H+=4)z[(j+te*J)*4+2]=se[H+0],z[(j+te*J)*4+1]=se[H+1],z[(j+te*J)*4+0]=se[H+2],z[(j+te*J)*4+3]=se[H+3];return z}function l(z,Z,V,Y,ue,ie,he,se){let H,j=0,J,te;const ce=x.width;for(te=Z;te!==Y;te+=V)for(J=ue;J!==he;J+=ie,j++)H=se[j],z[(J+ce*te)*4+0]=H,z[(J+ce*te)*4+1]=H,z[(J+ce*te)*4+2]=H,z[(J+ce*te)*4+3]=255;return z}function c(z,Z,V,Y,ue,ie,he,se){let H=0,j,J;const te=x.width;for(J=Z;J!==Y;J+=V)for(j=ue;j!==he;j+=ie,H+=2)z[(j+te*J)*4+0]=se[H+0],z[(j+te*J)*4+1]=se[H+0],z[(j+te*J)*4+2]=se[H+0],z[(j+te*J)*4+3]=se[H+1];return z}function h(z,Z,V,Y,ue){let ie,he,se,H,j,J;switch((x.flags&w)>>y){default:case R:ie=0,se=1,j=Z,he=0,H=1,J=V;break;case b:ie=0,se=1,j=Z,he=V-1,H=-1,J=-1;break;case P:ie=Z-1,se=-1,j=-1,he=0,H=1,J=V;break;case D:ie=Z-1,se=-1,j=-1,he=V-1,H=-1,J=-1;break}if(k)switch(x.pixel_size){case 8:l(z,he,H,J,ie,se,j,Y);break;case 16:c(z,he,H,J,ie,se,j,Y);break;default:throw new Error("THREE.TGALoader: Format not supported.")}else switch(x.pixel_size){case 8:i(z,he,H,J,ie,se,j,Y,ue);break;case 16:s(z,he,H,J,ie,se,j,Y);break;case 24:o(z,he,H,J,ie,se,j,Y);break;case 32:a(z,he,H,J,ie,se,j,Y);break;default:throw new Error("THREE.TGALoader: Format not supported.")}return z}const u=0,d=1,f=2,g=3,v=9,m=10,p=11,w=48,y=4,b=0,D=1,R=2,P=3;if(e.length<19)throw new Error("THREE.TGALoader: Not enough data to contain header.");let M=0;const _=new Uint8Array(e),x={id_length:_[M++],colormap_type:_[M++],image_type:_[M++],colormap_index:_[M++]|_[M++]<<8,colormap_length:_[M++]|_[M++]<<8,colormap_size:_[M++],origin:[_[M++]|_[M++]<<8,_[M++]|_[M++]<<8],width:_[M++]|_[M++]<<8,height:_[M++]|_[M++]<<8,pixel_size:_[M++],flags:_[M++]};if(t(x),x.id_length+M>e.length)throw new Error("THREE.TGALoader: No data.");M+=x.id_length;let T=!1,F=!1,k=!1;switch(x.image_type){case v:T=!0,F=!0;break;case d:F=!0;break;case m:T=!0;break;case f:break;case p:T=!0,k=!0;break;case g:k=!0;break}const G=new Uint8Array(x.width*x.height*4),K=n(T,F,x,M,_);return h(G,x.width,x.height,K.pixel_data,K.palettes),{data:G,width:x.width,height:x.height,flipY:!0,generateMipmaps:!0,minFilter:Di}}}class ab extends Zn{load(e,t,n,i){const s=this,o=s.path===""?nh.extractUrlBase(e):s.path,a=new no(s.manager);a.setPath(s.path),a.setRequestHeader(s.requestHeader),a.setWithCredentials(s.withCredentials),a.load(e,function(l){try{t(s.parse(l,o))}catch(c){i?i(c):console.error(c),s.manager.itemError(e)}},n,i)}parse(e,t){function n(E,S){const N=[],C=E.childNodes;for(let U=0,ne=C.length;U<ne;U++){const le=C[U];le.nodeName===S&&N.push(le)}return N}function i(E){if(E.length===0)return[];const S=E.trim().split(/\s+/),N=new Array(S.length);for(let C=0,U=S.length;C<U;C++)N[C]=S[C];return N}function s(E){if(E.length===0)return[];const S=E.trim().split(/\s+/),N=new Array(S.length);for(let C=0,U=S.length;C<U;C++)N[C]=parseFloat(S[C]);return N}function o(E){if(E.length===0)return[];const S=E.trim().split(/\s+/),N=new Array(S.length);for(let C=0,U=S.length;C<U;C++)N[C]=parseInt(S[C]);return N}function a(E){return E.substring(1)}function l(){return"three_default_"+bi++}function c(E){return Object.keys(E).length===0}function h(E){return{unit:u(n(E,"unit")[0]),upAxis:d(n(E,"up_axis")[0])}}function u(E){return E!==void 0&&E.hasAttribute("meter")===!0?parseFloat(E.getAttribute("meter")):1}function d(E){return E!==void 0?E.textContent:"Y_UP"}function f(E,S,N,C){const U=n(E,S)[0];if(U!==void 0){const ne=n(U,N);for(let le=0;le<ne.length;le++)C(ne[le])}}function g(E,S){for(const N in E){const C=E[N];C.build=S(E[N])}}function v(E,S){return E.build!==void 0||(E.build=S(E)),E.build}function m(E){const S={sources:{},samplers:{},channels:{}};let N=!1;for(let C=0,U=E.childNodes.length;C<U;C++){const ne=E.childNodes[C];if(ne.nodeType!==1)continue;let le;switch(ne.nodeName){case"source":le=ne.getAttribute("id"),S.sources[le]=oe(ne);break;case"sampler":le=ne.getAttribute("id"),S.samplers[le]=p(ne);break;case"channel":le=ne.getAttribute("target"),S.channels[le]=w(ne);break;case"animation":m(ne),N=!0;break;default:console.log(ne)}}N===!1&&(nt.animations[E.getAttribute("id")||Pt.generateUUID()]=S)}function p(E){const S={inputs:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const ne=a(U.getAttribute("source")),le=U.getAttribute("semantic");S.inputs[le]=ne;break}}return S}function w(E){const S={};let C=E.getAttribute("target").split("/");const U=C.shift();let ne=C.shift();const le=ne.indexOf("(")!==-1,Be=ne.indexOf(".")!==-1;if(Be)C=ne.split("."),ne=C.shift(),S.member=C.shift();else if(le){const we=ne.split("(");ne=we.shift();for(let Ie=0;Ie<we.length;Ie++)we[Ie]=parseInt(we[Ie].replace(/\)/,""));S.indices=we}return S.id=U,S.sid=ne,S.arraySyntax=le,S.memberSyntax=Be,S.sampler=a(E.getAttribute("source")),S}function y(E){const S=[],N=E.channels,C=E.samplers,U=E.sources;for(const ne in N)if(N.hasOwnProperty(ne)){const le=N[ne],Be=C[le.sampler],we=Be.inputs.INPUT,Ie=Be.inputs.OUTPUT,je=U[we],pe=U[Ie],Xe=D(le,je,pe);x(Xe,S)}return S}function b(E){return v(nt.animations[E],y)}function D(E,S,N){const C=nt.nodes[E.id],U=ft(C.id),ne=C.transforms[E.sid],le=C.matrix.clone().transpose();let Be,we,Ie,je,pe,Xe;const Ge={};switch(ne){case"matrix":for(Ie=0,je=S.array.length;Ie<je;Ie++)if(Be=S.array[Ie],we=Ie*N.stride,Ge[Be]===void 0&&(Ge[Be]={}),E.arraySyntax===!0){const jt=N.array[we],Dt=E.indices[0]+4*E.indices[1];Ge[Be][Dt]=jt}else for(pe=0,Xe=N.stride;pe<Xe;pe++)Ge[Be][pe]=N.array[we+pe];break;case"translate":console.warn('THREE.ColladaLoader: Animation transform type "%s" not yet implemented.',ne);break;case"rotate":console.warn('THREE.ColladaLoader: Animation transform type "%s" not yet implemented.',ne);break;case"scale":console.warn('THREE.ColladaLoader: Animation transform type "%s" not yet implemented.',ne);break}const $e=R(Ge,le);return{name:U.uuid,keyframes:$e}}function R(E,S){const N=[];for(const U in E)N.push({time:parseFloat(U),value:E[U]});N.sort(C);for(let U=0;U<16;U++)T(N,U,S.elements[U]);return N;function C(U,ne){return U.time-ne.time}}const P=new L,M=new L,_=new St;function x(E,S){const N=E.keyframes,C=E.name,U=[],ne=[],le=[],Be=[];for(let we=0,Ie=N.length;we<Ie;we++){const je=N[we],pe=je.time,Xe=je.value;W.fromArray(Xe).transpose(),W.decompose(P,_,M),U.push(pe),ne.push(P.x,P.y,P.z),le.push(_.x,_.y,_.z,_.w),Be.push(M.x,M.y,M.z)}return ne.length>0&&S.push(new Ms(C+".position",U,ne)),le.length>0&&S.push(new bs(C+".quaternion",U,le)),Be.length>0&&S.push(new Ms(C+".scale",U,Be)),S}function T(E,S,N){let C,U=!0,ne,le;for(ne=0,le=E.length;ne<le;ne++)C=E[ne],C.value[S]===void 0?C.value[S]=null:U=!1;if(U===!0)for(ne=0,le=E.length;ne<le;ne++)C=E[ne],C.value[S]=N;else F(E,S)}function F(E,S){let N,C;for(let U=0,ne=E.length;U<ne;U++){const le=E[U];if(le.value[S]===null){if(N=k(E,U,S),C=G(E,U,S),N===null){le.value[S]=C.value[S];continue}if(C===null){le.value[S]=N.value[S];continue}K(le,N,C,S)}}}function k(E,S,N){for(;S>=0;){const C=E[S];if(C.value[N]!==null)return C;S--}return null}function G(E,S,N){for(;S<E.length;){const C=E[S];if(C.value[N]!==null)return C;S++}return null}function K(E,S,N,C){if(N.time-S.time===0){E.value[C]=S.value[C];return}E.value[C]=(E.time-S.time)*(N.value[C]-S.value[C])/(N.time-S.time)+S.value[C]}function z(E){const S={name:E.getAttribute("id")||"default",start:parseFloat(E.getAttribute("start")||0),end:parseFloat(E.getAttribute("end")||0),animations:[]};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"instance_animation":S.animations.push(a(U.getAttribute("url")));break}}nt.clips[E.getAttribute("id")]=S}function Z(E){const S=[],N=E.name,C=E.end-E.start||-1,U=E.animations;for(let ne=0,le=U.length;ne<le;ne++){const Be=b(U[ne]);for(let we=0,Ie=Be.length;we<Ie;we++)S.push(Be[we])}return new Dc(N,C,S)}function V(E){return v(nt.clips[E],Z)}function Y(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"skin":S.id=a(U.getAttribute("source")),S.skin=ue(U);break;case"morph":S.id=a(U.getAttribute("source")),console.warn("THREE.ColladaLoader: Morph target animation not supported yet.");break}}nt.controllers[E.getAttribute("id")]=S}function ue(E){const S={sources:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"bind_shape_matrix":S.bindShapeMatrix=s(U.textContent);break;case"source":const ne=U.getAttribute("id");S.sources[ne]=oe(U);break;case"joints":S.joints=ie(U);break;case"vertex_weights":S.vertexWeights=he(U);break}}return S}function ie(E){const S={inputs:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const ne=U.getAttribute("semantic"),le=a(U.getAttribute("source"));S.inputs[ne]=le;break}}return S}function he(E){const S={inputs:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const ne=U.getAttribute("semantic"),le=a(U.getAttribute("source")),Be=parseInt(U.getAttribute("offset"));S.inputs[ne]={id:le,offset:Be};break;case"vcount":S.vcount=o(U.textContent);break;case"v":S.v=o(U.textContent);break}}return S}function se(E){const S={id:E.id},N=nt.geometries[S.id];return E.skin!==void 0&&(S.skin=H(E.skin),N.sources.skinIndices=S.skin.indices,N.sources.skinWeights=S.skin.weights),S}function H(E){const N={joints:[],indices:{array:[],stride:4},weights:{array:[],stride:4}},C=E.sources,U=E.vertexWeights,ne=U.vcount,le=U.v,Be=U.inputs.JOINT.offset,we=U.inputs.WEIGHT.offset,Ie=E.sources[E.joints.inputs.JOINT],je=E.sources[E.joints.inputs.INV_BIND_MATRIX],pe=C[U.inputs.WEIGHT.id].array;let Xe=0,Ge,$e,Ze;for(Ge=0,Ze=ne.length;Ge<Ze;Ge++){const Dt=ne[Ge],At=[];for($e=0;$e<Dt;$e++){const Rt=le[Xe+Be],Mi=le[Xe+we],Dn=pe[Mi];At.push({index:Rt,weight:Dn}),Xe+=2}for(At.sort(jt),$e=0;$e<4;$e++){const Rt=At[$e];Rt!==void 0?(N.indices.array.push(Rt.index),N.weights.array.push(Rt.weight)):(N.indices.array.push(0),N.weights.array.push(0))}}for(E.bindShapeMatrix?N.bindMatrix=new Ee().fromArray(E.bindShapeMatrix).transpose():N.bindMatrix=new Ee().identity(),Ge=0,Ze=Ie.array.length;Ge<Ze;Ge++){const Dt=Ie.array[Ge],At=new Ee().fromArray(je.array,Ge*je.stride).transpose();N.joints.push({name:Dt,boneInverse:At})}return N;function jt(Dt,At){return At.weight-Dt.weight}}function j(E){return v(nt.controllers[E],se)}function J(E){const S={init_from:n(E,"init_from")[0].textContent};nt.images[E.getAttribute("id")]=S}function te(E){return E.build!==void 0?E.build:E.init_from}function ce(E){const S=nt.images[E];return S!==void 0?v(S,te):(console.warn("THREE.ColladaLoader: Couldn't find image with ID:",E),null)}function be(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"profile_COMMON":S.profile=xe(U);break}}nt.effects[E.getAttribute("id")]=S}function xe(E){const S={surfaces:{},samplers:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"newparam":Re(U,S);break;case"technique":S.technique=B(U);break;case"extra":S.extra=ze(U);break}}return S}function Re(E,S){const N=E.getAttribute("sid");for(let C=0,U=E.childNodes.length;C<U;C++){const ne=E.childNodes[C];if(ne.nodeType===1)switch(ne.nodeName){case"surface":S.surfaces[N]=Je(ne);break;case"sampler2D":S.samplers[N]=We(ne);break}}}function Je(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"init_from":S.init_from=U.textContent;break}}return S}function We(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"source":S.source=U.textContent;break}}return S}function B(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"constant":case"lambert":case"blinn":case"phong":S.type=U.nodeName,S.parameters=ht(U);break;case"extra":S.extra=ze(U);break}}return S}function ht(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"emission":case"diffuse":case"specular":case"bump":case"ambient":case"shininess":case"transparency":S[U.nodeName]=Le(U);break;case"transparent":S[U.nodeName]={opaque:U.hasAttribute("opaque")?U.getAttribute("opaque"):"A_ONE",data:Le(U)};break}}return S}function Le(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"color":S[U.nodeName]=s(U.textContent);break;case"float":S[U.nodeName]=parseFloat(U.textContent);break;case"texture":S[U.nodeName]={id:U.getAttribute("texture"),extra:tt(U)};break}}return S}function tt(E){const S={technique:{}};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"extra":me(U,S);break}}return S}function me(E,S){for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"technique":Qe(U,S);break}}}function Qe(E,S){for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"repeatU":case"repeatV":case"offsetU":case"offsetV":S.technique[U.nodeName]=parseFloat(U.textContent);break;case"wrapU":case"wrapV":U.textContent.toUpperCase()==="TRUE"?S.technique[U.nodeName]=1:U.textContent.toUpperCase()==="FALSE"?S.technique[U.nodeName]=0:S.technique[U.nodeName]=parseInt(U.textContent);break;case"bump":S[U.nodeName]=A(U);break}}}function ze(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"technique":S.technique=O(U);break}}return S}function O(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"double_sided":S[U.nodeName]=parseInt(U.textContent);break;case"bump":S[U.nodeName]=A(U);break}}return S}function A(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"texture":S[U.nodeName]={id:U.getAttribute("texture"),texcoord:U.getAttribute("texcoord"),extra:tt(U)};break}}return S}function $(E){return E}function ae(E){return v(nt.effects[E],$)}function de(E){const S={name:E.getAttribute("name")};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"instance_effect":S.url=a(U.getAttribute("url"));break}}nt.materials[E.getAttribute("id")]=S}function re(E){let S,N=E.slice((E.lastIndexOf(".")-1>>>0)+2);switch(N=N.toLowerCase(),N){case"tga":S=_n;break;default:S=Sn}return S}function Ce(E){const S=ae(E.url),N=S.profile.technique;let C;switch(N.type){case"phong":case"blinn":C=new kn;break;case"lambert":C=new Kr;break;default:C=new zn;break}C.name=E.name||"";function U(we,Ie=null){const je=S.profile.samplers[we.id];let pe=null;if(je!==void 0){const Xe=S.profile.surfaces[je.source];pe=ce(Xe.init_from)}else console.warn("THREE.ColladaLoader: Undefined sampler. Access image directly (see #12530)."),pe=ce(we.id);if(pe!==null){const Xe=re(pe);if(Xe!==void 0){const Ge=Xe.load(pe),$e=we.extra;if($e!==void 0&&$e.technique!==void 0&&c($e.technique)===!1){const Ze=$e.technique;Ge.wrapS=Ze.wrapU?Li:Bn,Ge.wrapT=Ze.wrapV?Li:Bn,Ge.offset.set(Ze.offsetU||0,Ze.offsetV||0),Ge.repeat.set(Ze.repeatU||1,Ze.repeatV||1)}else Ge.wrapS=Li,Ge.wrapT=Li;return Ie!==null&&(Ge.colorSpace=Ie),Ge}else return console.warn("THREE.ColladaLoader: Loader for texture %s not found.",pe),null}else return console.warn("THREE.ColladaLoader: Couldn't create texture with ID:",we.id),null}const ne=N.parameters;for(const we in ne){const Ie=ne[we];switch(we){case"diffuse":Ie.color&&C.color.fromArray(Ie.color),Ie.texture&&(C.map=U(Ie.texture,vt));break;case"specular":Ie.color&&C.specular&&C.specular.fromArray(Ie.color),Ie.texture&&(C.specularMap=U(Ie.texture));break;case"bump":Ie.texture&&(C.normalMap=U(Ie.texture));break;case"ambient":Ie.texture&&(C.lightMap=U(Ie.texture,vt));break;case"shininess":Ie.float&&C.shininess&&(C.shininess=Ie.float);break;case"emission":Ie.color&&C.emissive&&C.emissive.fromArray(Ie.color),Ie.texture&&(C.emissiveMap=U(Ie.texture,vt));break}}rt.toWorkingColorSpace(C.color,vt),C.specular&&rt.toWorkingColorSpace(C.specular,vt),C.emissive&&rt.toWorkingColorSpace(C.emissive,vt);let le=ne.transparent,Be=ne.transparency;if(Be===void 0&&le&&(Be={float:1}),le===void 0&&Be&&(le={opaque:"A_ONE",data:{color:[1,1,1,1]}}),le&&Be)if(le.data.texture)C.transparent=!0;else{const we=le.data.color;switch(le.opaque){case"A_ONE":C.opacity=we[3]*Be.float;break;case"RGB_ZERO":C.opacity=1-we[0]*Be.float;break;case"A_ZERO":C.opacity=1-we[3]*Be.float;break;case"RGB_ONE":C.opacity=we[0]*Be.float;break;default:console.warn('THREE.ColladaLoader: Invalid opaque type "%s" of transparent tag.',le.opaque)}C.opacity<1&&(C.transparent=!0)}if(N.extra!==void 0&&N.extra.technique!==void 0){const we=N.extra.technique;for(const Ie in we){const je=we[Ie];switch(Ie){case"double_sided":C.side=je===1?Xn:Fi;break;case"bump":C.normalMap=U(je.texture),C.normalScale=new ye(1,1);break}}}return C}function Me(E){return v(nt.materials[E],Ce)}function Fe(E){const S={name:E.getAttribute("name")};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"optics":S.optics=gt(U);break}}nt.cameras[E.getAttribute("id")]=S}function gt(E){for(let S=0;S<E.childNodes.length;S++){const N=E.childNodes[S];switch(N.nodeName){case"technique_common":return ge(N)}}return{}}function ge(E){const S={};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];switch(C.nodeName){case"perspective":case"orthographic":S.technique=C.nodeName,S.parameters=Te(C);break}}return S}function Te(E){const S={};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];switch(C.nodeName){case"xfov":case"yfov":case"xmag":case"ymag":case"znear":case"zfar":case"aspect_ratio":S[C.nodeName]=parseFloat(C.textContent);break}}return S}function qe(E){let S;switch(E.optics.technique){case"perspective":S=new Qt(E.optics.parameters.yfov,E.optics.parameters.aspect_ratio,E.optics.parameters.znear,E.optics.parameters.zfar);break;case"orthographic":let N=E.optics.parameters.ymag,C=E.optics.parameters.xmag;const U=E.optics.parameters.aspect_ratio;C=C===void 0?N*U:C,N=N===void 0?C/U:N,C*=.5,N*=.5,S=new Na(-C,C,N,-N,E.optics.parameters.znear,E.optics.parameters.zfar);break;default:S=new Qt;break}return S.name=E.name||"",S}function et(E){const S=nt.cameras[E];return S!==void 0?v(S,qe):(console.warn("THREE.ColladaLoader: Couldn't find camera with ID:",E),null)}function He(E){let S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"technique_common":S=xt(U);break}}nt.lights[E.getAttribute("id")]=S}function xt(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"directional":case"point":case"spot":case"ambient":S.technique=U.nodeName,S.parameters=lt(U)}}return S}function lt(E){const S={};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"color":const ne=s(U.textContent);S.color=new ke().fromArray(ne),rt.toWorkingColorSpace(S.color,vt);break;case"falloff_angle":S.falloffAngle=parseFloat(U.textContent);break;case"quadratic_attenuation":const le=parseFloat(U.textContent);S.distance=le?Math.sqrt(1/le):0;break}}return S}function Lt(E){let S;switch(E.technique){case"directional":S=new Ea;break;case"point":S=new Ic;break;case"spot":S=new hf;break;case"ambient":S=new th;break}return E.parameters.color&&S.color.copy(E.parameters.color),E.parameters.distance&&(S.distance=E.parameters.distance),S}function X(E){const S=nt.lights[E];return S!==void 0?v(S,Lt):(console.warn("THREE.ColladaLoader: Couldn't find light with ID:",E),null)}function Pe(E){const S={name:E.getAttribute("name"),sources:{},vertices:{},primitives:[]},N=n(E,"mesh")[0];if(N!==void 0){for(let C=0;C<N.childNodes.length;C++){const U=N.childNodes[C];if(U.nodeType!==1)continue;const ne=U.getAttribute("id");switch(U.nodeName){case"source":S.sources[ne]=oe(U);break;case"vertices":S.vertices=fe(U);break;case"polygons":console.warn("THREE.ColladaLoader: Unsupported primitive type: ",U.nodeName);break;case"lines":case"linestrips":case"polylist":case"triangles":S.primitives.push(Ue(U));break;default:console.log(U)}}nt.geometries[E.getAttribute("id")]=S}}function oe(E){const S={array:[],stride:3};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"float_array":S.array=s(C.textContent);break;case"Name_array":S.array=i(C.textContent);break;case"technique_common":const U=n(C,"accessor")[0];U!==void 0&&(S.stride=parseInt(U.getAttribute("stride")));break}}return S}function fe(E){const S={};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];C.nodeType===1&&(S[C.getAttribute("semantic")]=a(C.getAttribute("source")))}return S}function Ue(E){const S={type:E.nodeName,material:E.getAttribute("material"),count:parseInt(E.getAttribute("count")),inputs:{},stride:0,hasUV:!1};for(let N=0,C=E.childNodes.length;N<C;N++){const U=E.childNodes[N];if(U.nodeType===1)switch(U.nodeName){case"input":const ne=a(U.getAttribute("source")),le=U.getAttribute("semantic"),Be=parseInt(U.getAttribute("offset")),we=parseInt(U.getAttribute("set")),Ie=we>0?le+we:le;S.inputs[Ie]={id:ne,offset:Be},S.stride=Math.max(S.stride,Be+1),le==="TEXCOORD"&&(S.hasUV=!0);break;case"vcount":S.vcount=o(U.textContent);break;case"p":S.p=o(U.textContent);break}}return S}function De(E){const S={};for(let N=0;N<E.length;N++){const C=E[N];S[C.type]===void 0&&(S[C.type]=[]),S[C.type].push(C)}return S}function ot(E){let S=0;for(let N=0,C=E.length;N<C;N++)E[N].hasUV===!0&&S++;S>0&&S<E.length&&(E.uvsNeedsFix=!0)}function zt(E){const S={},N=E.sources,C=E.vertices,U=E.primitives;if(U.length===0)return{};const ne=De(U);for(const le in ne){const Be=ne[le];ot(Be),S[le]=ln(Be,N,C)}return S}function ln(E,S,N){const C={},U={array:[],stride:0},ne={array:[],stride:0},le={array:[],stride:0},Be={array:[],stride:0},we={array:[],stride:0},Ie={array:[],stride:4},je={array:[],stride:4},pe=new yt,Xe=[];let Ge=0;for(let $e=0;$e<E.length;$e++){const Ze=E[$e],jt=Ze.inputs;let Dt=0;switch(Ze.type){case"lines":case"linestrips":Dt=Ze.count*2;break;case"triangles":Dt=Ze.count*3;break;case"polylist":for(let At=0;At<Ze.count;At++){const Rt=Ze.vcount[At];switch(Rt){case 3:Dt+=3;break;case 4:Dt+=6;break;default:Dt+=(Rt-2)*3;break}}break;default:console.warn("THREE.ColladaLoader: Unknown primitive type:",Ze.type)}pe.addGroup(Ge,Dt,$e),Ge+=Dt,Ze.material&&Xe.push(Ze.material);for(const At in jt){const Rt=jt[At];switch(At){case"VERTEX":for(const Mi in N){const Dn=N[Mi];switch(Mi){case"POSITION":const Cs=U.array.length;if(ut(Ze,S[Dn],Rt.offset,U.array),U.stride=S[Dn].stride,S.skinWeights&&S.skinIndices&&(ut(Ze,S.skinIndices,Rt.offset,Ie.array),ut(Ze,S.skinWeights,Rt.offset,je.array)),Ze.hasUV===!1&&E.uvsNeedsFix===!0){const kf=(U.array.length-Cs)/U.stride;for(let fh=0;fh<kf;fh++)le.array.push(0,0)}break;case"NORMAL":ut(Ze,S[Dn],Rt.offset,ne.array),ne.stride=S[Dn].stride;break;case"COLOR":ut(Ze,S[Dn],Rt.offset,we.array),we.stride=S[Dn].stride;break;case"TEXCOORD":ut(Ze,S[Dn],Rt.offset,le.array),le.stride=S[Dn].stride;break;case"TEXCOORD1":ut(Ze,S[Dn],Rt.offset,Be.array),le.stride=S[Dn].stride;break;default:console.warn('THREE.ColladaLoader: Semantic "%s" not handled in geometry build process.',Mi)}}break;case"NORMAL":ut(Ze,S[Rt.id],Rt.offset,ne.array),ne.stride=S[Rt.id].stride;break;case"COLOR":ut(Ze,S[Rt.id],Rt.offset,we.array,!0),we.stride=S[Rt.id].stride;break;case"TEXCOORD":ut(Ze,S[Rt.id],Rt.offset,le.array),le.stride=S[Rt.id].stride;break;case"TEXCOORD1":ut(Ze,S[Rt.id],Rt.offset,Be.array),Be.stride=S[Rt.id].stride;break}}}return U.array.length>0&&pe.setAttribute("position",new Ne(U.array,U.stride)),ne.array.length>0&&pe.setAttribute("normal",new Ne(ne.array,ne.stride)),we.array.length>0&&pe.setAttribute("color",new Ne(we.array,we.stride)),le.array.length>0&&pe.setAttribute("uv",new Ne(le.array,le.stride)),Be.array.length>0&&pe.setAttribute("uv1",new Ne(Be.array,Be.stride)),Ie.array.length>0&&pe.setAttribute("skinIndex",new Ne(Ie.array,Ie.stride)),je.array.length>0&&pe.setAttribute("skinWeight",new Ne(je.array,je.stride)),C.data=pe,C.type=E[0].type,C.materialKeys=Xe,C}function ut(E,S,N,C,U=!1){const ne=E.p,le=E.stride,Be=E.vcount;function we(pe){let Xe=ne[pe+N]*je;const Ge=Xe+je;for(;Xe<Ge;Xe++)C.push(Ie[Xe]);if(U){const $e=C.length-je-1;$t.setRGB(C[$e+0],C[$e+1],C[$e+2],vt),C[$e+0]=$t.r,C[$e+1]=$t.g,C[$e+2]=$t.b}}const Ie=S.array,je=S.stride;if(E.vcount!==void 0){let pe=0;for(let Xe=0,Ge=Be.length;Xe<Ge;Xe++){const $e=Be[Xe];if($e===4){const Ze=pe+le*0,jt=pe+le*1,Dt=pe+le*2,At=pe+le*3;we(Ze),we(jt),we(At),we(jt),we(Dt),we(At)}else if($e===3){const Ze=pe+le*0,jt=pe+le*1,Dt=pe+le*2;we(Ze),we(jt),we(Dt)}else if($e>4)for(let Ze=1,jt=$e-2;Ze<=jt;Ze++){const Dt=pe+le*0,At=pe+le*Ze,Rt=pe+le*(Ze+1);we(Dt),we(At),we(Rt)}pe+=le*$e}}else for(let pe=0,Xe=ne.length;pe<Xe;pe+=le)we(pe)}function Pn(E){return v(nt.geometries[E],zt)}function $n(E){const S={name:E.getAttribute("name")||"",joints:{},links:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"technique_common":yi(C,S);break}}nt.kinematicsModels[E.getAttribute("id")]=S}function oo(E){return E.build!==void 0?E.build:E}function ao(E){return v(nt.kinematicsModels[E],oo)}function yi(E,S){for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"joint":S.joints[C.getAttribute("sid")]=wr(C);break;case"link":S.links.push(Sr(C));break}}}function wr(E){let S;for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"prismatic":case"revolute":S=lo(C);break}}return S}function lo(E){const S={sid:E.getAttribute("sid"),name:E.getAttribute("name")||"",axis:new L,limits:{min:0,max:0},type:E.nodeName,static:!1,zeroPosition:0,middlePosition:0};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"axis":const U=s(C.textContent);S.axis.fromArray(U);break;case"limits":const ne=C.getElementsByTagName("max")[0],le=C.getElementsByTagName("min")[0];S.limits.max=parseFloat(ne.textContent),S.limits.min=parseFloat(le.textContent);break}}return S.limits.min>=S.limits.max&&(S.static=!0),S.middlePosition=(S.limits.min+S.limits.max)/2,S}function Sr(E){const S={sid:E.getAttribute("sid"),name:E.getAttribute("name")||"",attachments:[],transforms:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"attachment_full":S.attachments.push(Ts(C));break;case"matrix":case"translate":case"rotate":S.transforms.push(Er(C));break}}return S}function Ts(E){const S={joint:E.getAttribute("joint").split("/").pop(),transforms:[],links:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"link":S.links.push(Sr(C));break;case"matrix":case"translate":case"rotate":S.transforms.push(Er(C));break}}return S}function Er(E){const S={type:E.nodeName},N=s(E.textContent);switch(S.type){case"matrix":S.obj=new Ee,S.obj.fromArray(N).transpose();break;case"translate":S.obj=new L,S.obj.fromArray(N);break;case"rotate":S.obj=new L,S.obj.fromArray(N),S.angle=Pt.degToRad(N[3]);break}return S}function As(E){const S={name:E.getAttribute("name")||"",rigidBodies:{}};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"rigid_body":S.rigidBodies[C.getAttribute("name")]={},co(C,S.rigidBodies[C.getAttribute("name")]);break}}nt.physicsModels[E.getAttribute("id")]=S}function co(E,S){for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"technique_common":ho(C,S);break}}}function ho(E,S){for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"inertia":S.inertia=s(C.textContent);break;case"mass":S.mass=s(C.textContent)[0];break}}}function za(E){const S={bindJointAxis:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"bind_joint_axis":S.bindJointAxis.push(Ha(C));break}}nt.kinematicsScenes[a(E.getAttribute("url"))]=S}function Ha(E){const S={target:E.getAttribute("target").split("/").pop()};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType===1)switch(C.nodeName){case"axis":const U=C.getElementsByTagName("param")[0];S.axis=U.textContent;const ne=S.axis.split("inst_").pop().split("axis")[0];S.jointIndex=ne.substring(0,ne.length-1);break}}return S}function Va(E){return E.build!==void 0?E.build:E}function Ga(E){return v(nt.kinematicsScenes[E],Va)}function Wa(){const E=Object.keys(nt.kinematicsModels)[0],S=Object.keys(nt.kinematicsScenes)[0],N=Object.keys(nt.visualScenes)[0];if(E===void 0||S===void 0)return;const C=ao(E),U=Ga(S),ne=bt(N),le=U.bindJointAxis,Be={};for(let je=0,pe=le.length;je<pe;je++){const Xe=le[je],Ge=kt.querySelector('[sid="'+Xe.target+'"]');if(Ge){const $e=Ge.parentElement;we(Xe.jointIndex,$e)}}function we(je,pe){const Xe=pe.getAttribute("name"),Ge=C.joints[je];ne.traverse(function($e){$e.name===Xe&&(Be[je]={object:$e,transforms:Xa(pe),joint:Ge,position:Ge.zeroPosition})})}const Ie=new Ee;Rs={joints:C&&C.joints,getJointValue:function(je){const pe=Be[je];if(pe)return pe.position;console.warn("THREE.ColladaLoader: Joint "+je+" doesn't exist.")},setJointValue:function(je,pe){const Xe=Be[je];if(Xe){const Ge=Xe.joint;if(pe>Ge.limits.max||pe<Ge.limits.min)console.warn("THREE.ColladaLoader: Joint "+je+" value "+pe+" outside of limits (min: "+Ge.limits.min+", max: "+Ge.limits.max+").");else if(Ge.static)console.warn("THREE.ColladaLoader: Joint "+je+" is static.");else{const $e=Xe.object,Ze=Ge.axis,jt=Xe.transforms;W.identity();for(let Dt=0;Dt<jt.length;Dt++){const At=jt[Dt];if(At.sid&&At.sid.indexOf(je)!==-1)switch(Ge.type){case"revolute":W.multiply(Ie.makeRotationAxis(Ze,Pt.degToRad(pe)));break;case"prismatic":W.multiply(Ie.makeTranslation(Ze.x*pe,Ze.y*pe,Ze.z*pe));break;default:console.warn("THREE.ColladaLoader: Unknown joint type: "+Ge.type);break}else switch(At.type){case"matrix":W.multiply(At.obj);break;case"translate":W.multiply(Ie.makeTranslation(At.obj.x,At.obj.y,At.obj.z));break;case"scale":W.scale(At.obj);break;case"rotate":W.multiply(Ie.makeRotationAxis(At.obj,At.angle));break}}$e.matrix.copy(W),$e.matrix.decompose($e.position,$e.quaternion,$e.scale),Be[je].position=pe}}else console.log("THREE.ColladaLoader: "+je+" does not exist.")}}}function Xa(E){const S=[],N=kt.querySelector('[id="'+E.id+'"]');for(let C=0;C<N.childNodes.length;C++){const U=N.childNodes[C];if(U.nodeType!==1)continue;let ne,le;switch(U.nodeName){case"matrix":ne=s(U.textContent);const Be=new Ee().fromArray(ne).transpose();S.push({sid:U.getAttribute("sid"),type:U.nodeName,obj:Be});break;case"translate":case"scale":ne=s(U.textContent),le=new L().fromArray(ne),S.push({sid:U.getAttribute("sid"),type:U.nodeName,obj:le});break;case"rotate":ne=s(U.textContent),le=new L().fromArray(ne);const we=Pt.degToRad(ne[3]);S.push({sid:U.getAttribute("sid"),type:U.nodeName,obj:le,angle:we});break}}return S}function I(E){const S=E.getElementsByTagName("node");for(let N=0;N<S.length;N++){const C=S[N];C.hasAttribute("id")===!1&&C.setAttribute("id",l())}}const W=new Ee,Q=new L;function ee(E){const S={name:E.getAttribute("name")||"",type:E.getAttribute("type"),id:E.getAttribute("id"),sid:E.getAttribute("sid"),matrix:new Ee,nodes:[],instanceCameras:[],instanceControllers:[],instanceLights:[],instanceGeometries:[],instanceNodes:[],transforms:{}};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];if(C.nodeType!==1)continue;let U;switch(C.nodeName){case"node":S.nodes.push(C.getAttribute("id")),ee(C);break;case"instance_camera":S.instanceCameras.push(a(C.getAttribute("url")));break;case"instance_controller":S.instanceControllers.push(q(C));break;case"instance_light":S.instanceLights.push(a(C.getAttribute("url")));break;case"instance_geometry":S.instanceGeometries.push(q(C));break;case"instance_node":S.instanceNodes.push(a(C.getAttribute("url")));break;case"matrix":U=s(C.textContent),S.matrix.multiply(W.fromArray(U).transpose()),S.transforms[C.getAttribute("sid")]=C.nodeName;break;case"translate":U=s(C.textContent),Q.fromArray(U),S.matrix.multiply(W.makeTranslation(Q.x,Q.y,Q.z)),S.transforms[C.getAttribute("sid")]=C.nodeName;break;case"rotate":U=s(C.textContent);const ne=Pt.degToRad(U[3]);S.matrix.multiply(W.makeRotationAxis(Q.fromArray(U),ne)),S.transforms[C.getAttribute("sid")]=C.nodeName;break;case"scale":U=s(C.textContent),S.matrix.scale(Q.fromArray(U)),S.transforms[C.getAttribute("sid")]=C.nodeName;break;case"extra":break;default:console.log(C)}}return Ye(S.id)?console.warn("THREE.ColladaLoader: There is already a node with ID %s. Exclude current node from further processing.",S.id):nt.nodes[S.id]=S,S}function q(E){const S={id:a(E.getAttribute("url")),materials:{},skeletons:[]};for(let N=0;N<E.childNodes.length;N++){const C=E.childNodes[N];switch(C.nodeName){case"bind_material":const U=C.getElementsByTagName("instance_material");for(let ne=0;ne<U.length;ne++){const le=U[ne],Be=le.getAttribute("symbol"),we=le.getAttribute("target");S.materials[Be]=a(we)}break;case"skeleton":S.skeletons.push(a(C.textContent));break}}return S}function _e(E,S){const N=[],C=[];let U,ne,le;for(U=0;U<E.length;U++){const Ie=E[U];let je;if(Ye(Ie))je=ft(Ie),Ae(je,S,N);else if(Vt(Ie)){const Xe=nt.visualScenes[Ie].children;for(let Ge=0;Ge<Xe.length;Ge++){const $e=Xe[Ge];if($e.type==="JOINT"){const Ze=ft($e.id);Ae(Ze,S,N)}}}else console.error("THREE.ColladaLoader: Unable to find root bone of skeleton with ID:",Ie)}for(U=0;U<S.length;U++)for(ne=0;ne<N.length;ne++)if(le=N[ne],le.bone.name===S[U].name){C[U]=le,le.processed=!0;break}for(U=0;U<N.length;U++)le=N[U],le.processed===!1&&(C.push(le),le.processed=!0);const Be=[],we=[];for(U=0;U<C.length;U++)le=C[U],Be.push(le.bone),we.push(le.boneInverse);return new Ca(Be,we)}function Ae(E,S,N){E.traverse(function(C){if(C.isBone===!0){let U;for(let ne=0;ne<S.length;ne++){const le=S[ne];if(le.name===C.name){U=le.boneInverse;break}}U===void 0&&(U=new Ee),N.push({bone:C,boneInverse:U,processed:!1})}})}function Oe(E){const S=[],N=E.matrix,C=E.nodes,U=E.type,ne=E.instanceCameras,le=E.instanceControllers,Be=E.instanceLights,we=E.instanceGeometries,Ie=E.instanceNodes;for(let pe=0,Xe=C.length;pe<Xe;pe++)S.push(ft(C[pe]));for(let pe=0,Xe=ne.length;pe<Xe;pe++){const Ge=et(ne[pe]);Ge!==null&&S.push(Ge.clone())}for(let pe=0,Xe=le.length;pe<Xe;pe++){const Ge=le[pe],$e=j(Ge.id),Ze=Pn($e.id),jt=st(Ze,Ge.materials),Dt=Ge.skeletons,At=$e.skin.joints,Rt=_e(Dt,At);for(let Mi=0,Dn=jt.length;Mi<Dn;Mi++){const Cs=jt[Mi];Cs.isSkinnedMesh&&(Cs.bind(Rt,$e.skin.bindMatrix),Cs.normalizeSkinWeights()),S.push(Cs)}}for(let pe=0,Xe=Be.length;pe<Xe;pe++){const Ge=X(Be[pe]);Ge!==null&&S.push(Ge.clone())}for(let pe=0,Xe=we.length;pe<Xe;pe++){const Ge=we[pe],$e=Pn(Ge.id),Ze=st($e,Ge.materials);for(let jt=0,Dt=Ze.length;jt<Dt;jt++)S.push(Ze[jt])}for(let pe=0,Xe=Ie.length;pe<Xe;pe++)S.push(ft(Ie[pe]).clone());let je;if(C.length===0&&S.length===1)je=S[0];else{je=U==="JOINT"?new ba:new wt;for(let pe=0;pe<S.length;pe++)je.add(S[pe])}return je.name=U==="JOINT"?E.sid:E.name,je.matrix.copy(N),je.matrix.decompose(je.position,je.quaternion,je.scale),je}const Ve=new zn({name:Zn.DEFAULT_MATERIAL_NAME,color:16711935});function it(E,S){const N=[];for(let C=0,U=E.length;C<U;C++){const ne=S[E[C]];ne===void 0?(console.warn("THREE.ColladaLoader: Material with key %s not found. Apply fallback material.",E[C]),N.push(Ve)):N.push(Me(ne))}return N}function st(E,S){const N=[];for(const C in E){const U=E[C],ne=it(U.materialKeys,S);if(ne.length===0&&(C==="lines"||C==="linestrips"?ne.push(new Yn):ne.push(new kn)),C==="lines"||C==="linestrips")for(let Ie=0,je=ne.length;Ie<je;Ie++){const pe=ne[Ie];if(pe.isMeshPhongMaterial===!0||pe.isMeshLambertMaterial===!0){const Xe=new Yn;Xe.color.copy(pe.color),Xe.opacity=pe.opacity,Xe.transparent=pe.transparent,ne[Ie]=Xe}}const le=U.data.attributes.skinIndex!==void 0,Be=ne.length===1?ne[0]:ne;let we;switch(C){case"lines":we=new vr(U.data,Be);break;case"linestrips":we=new Gn(U.data,Be);break;case"triangles":case"polylist":le?we=new Qd(U.data,Be):we=new ve(U.data,Be);break}N.push(we)}return N}function Ye(E){return nt.nodes[E]!==void 0}function ft(E){return v(nt.nodes[E],Oe)}function Et(E){const S={name:E.getAttribute("name"),children:[]};I(E);const N=n(E,"node");for(let C=0;C<N.length;C++)S.children.push(ee(N[C]));nt.visualScenes[E.getAttribute("id")]=S}function Xt(E){const S=new wt;S.name=E.name;const N=E.children;for(let C=0;C<N.length;C++){const U=N[C];S.add(ft(U.id))}return S}function Vt(E){return nt.visualScenes[E]!==void 0}function bt(E){return v(nt.visualScenes[E],Xt)}function Ke(E){const S=n(E,"instance_visual_scene")[0];return bt(a(S.getAttribute("url")))}function en(){const E=nt.clips;if(c(E)===!0){if(c(nt.animations)===!1){const S=[];for(const N in nt.animations){const C=b(N);for(let U=0,ne=C.length;U<ne;U++)S.push(C[U])}tn.push(new Dc("default",-1,S))}}else for(const S in E)tn.push(V(S))}function Tt(E){let S="";const N=[E];for(;N.length;){const C=N.shift();C.nodeType===Node.TEXT_NODE?S+=C.textContent:(S+=`
`,N.push(...C.childNodes))}return S.trim()}if(e.length===0)return{scene:new Rc};const Ln=new DOMParser().parseFromString(e,"application/xml"),kt=n(Ln,"COLLADA")[0],hn=Ln.getElementsByTagName("parsererror")[0];if(hn!==void 0){const E=n(hn,"div")[0];let S;return E?S=E.textContent:S=Tt(hn),console.error(`THREE.ColladaLoader: Failed to parse collada file.
`,S),null}const es=kt.getAttribute("version");console.debug("THREE.ColladaLoader: File version",es);const Ft=h(n(kt,"asset")[0]),Sn=new Ia(this.manager);Sn.setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin);let _n;sd&&(_n=new sd(this.manager),_n.setPath(this.resourcePath||t));const $t=new ke,tn=[];let Rs={},bi=0;const nt={animations:{},clips:{},controllers:{},images:{},effects:{},materials:{},cameras:{},lights:{},geometries:{},nodes:{},visualScenes:{},kinematicsModels:{},physicsModels:{},kinematicsScenes:{}};f(kt,"library_animations","animation",m),f(kt,"library_animation_clips","animation_clip",z),f(kt,"library_controllers","controller",Y),f(kt,"library_images","image",J),f(kt,"library_effects","effect",be),f(kt,"library_materials","material",de),f(kt,"library_cameras","camera",Fe),f(kt,"library_lights","light",He),f(kt,"library_geometries","geometry",Pe),f(kt,"library_nodes","node",ee),f(kt,"library_visual_scenes","visual_scene",Et),f(kt,"library_kinematics_models","kinematics_model",$n),f(kt,"library_physics_models","physics_model",As),f(kt,"scene","instance_kinematics_scene",za),g(nt.animations,y),g(nt.clips,Z),g(nt.controllers,se),g(nt.images,te),g(nt.effects,$),g(nt.materials,Ce),g(nt.cameras,qe),g(nt.lights,Lt),g(nt.geometries,zt),g(nt.visualScenes,Xt),en(),Wa();const uo=Ke(n(kt,"scene")[0]);return uo.animations=tn,Ft.upAxis==="Z_UP"&&(console.warn("THREE.ColladaLoader: You are loading an asset with a Z-UP coordinate system. The loader just rotates the asset to transform it into Y-UP. The vertex data are not converted, see #24289."),uo.rotation.set(-Math.PI/2,0,0)),uo.scale.multiplyScalar(Ft.unit),{get animations(){return console.warn("THREE.ColladaLoader: Please access animations over scene.animations now."),tn},kinematics:Rs,library:nt,scene:uo}}}let mt,Kt,An;class Af extends Zn{constructor(e){super(e)}load(e,t,n,i){const s=this,o=s.path===""?nh.extractUrlBase(e):s.path,a=new no(this.manager);a.setPath(s.path),a.setResponseType("arraybuffer"),a.setRequestHeader(s.requestHeader),a.setWithCredentials(s.withCredentials),a.load(e,function(l){try{t(s.parse(l,o))}catch(c){i?i(c):console.error(c),s.manager.itemError(e)}},n,i)}parse(e,t){if(fb(e))mt=new db().parse(e);else{const i=Pf(e);if(!pb(i))throw new Error("THREE.FBXLoader: Unknown format.");if(od(i)<7e3)throw new Error("THREE.FBXLoader: FBX version not supported, FileVersion: "+od(i));mt=new ub().parse(i)}const n=new Ia(this.manager).setPath(this.resourcePath||t).setCrossOrigin(this.crossOrigin);return new lb(n,this.manager).parse(mt)}}class lb{constructor(e,t){this.textureLoader=e,this.manager=t}parse(){Kt=this.parseConnections();const e=this.parseImages(),t=this.parseTextures(e),n=this.parseMaterials(t),i=this.parseDeformers(),s=new cb().parse(i);return this.parseScene(i,s,n),An}parseConnections(){const e=new Map;return"Connections"in mt&&mt.Connections.connections.forEach(function(n){const i=n[0],s=n[1],o=n[2];e.has(i)||e.set(i,{parents:[],children:[]});const a={ID:s,relationship:o};e.get(i).parents.push(a),e.has(s)||e.set(s,{parents:[],children:[]});const l={ID:i,relationship:o};e.get(s).children.push(l)}),e}parseImages(){const e={},t={};if("Video"in mt.Objects){const n=mt.Objects.Video;for(const i in n){const s=n[i],o=parseInt(i);if(e[o]=s.RelativeFilename||s.Filename,"Content"in s){const a=s.Content instanceof ArrayBuffer&&s.Content.byteLength>0,l=typeof s.Content=="string"&&s.Content!=="";if(a||l){const c=this.parseImage(n[i]);t[s.RelativeFilename||s.Filename]=c}}}}for(const n in e){const i=e[n];t[i]!==void 0?e[n]=t[i]:e[n]=e[n].split("\\").pop()}return e}parseImage(e){const t=e.Content,n=e.RelativeFilename||e.Filename,i=n.slice(n.lastIndexOf(".")+1).toLowerCase();let s;switch(i){case"bmp":s="image/bmp";break;case"jpg":case"jpeg":s="image/jpeg";break;case"png":s="image/png";break;case"tif":s="image/tiff";break;case"tga":this.manager.getHandler(".tga")===null&&console.warn("FBXLoader: TGA loader not found, skipping ",n),s="image/tga";break;default:console.warn('FBXLoader: Image type "'+i+'" is not supported.');return}if(typeof t=="string")return"data:"+s+";base64,"+t;{const o=new Uint8Array(t);return window.URL.createObjectURL(new Blob([o],{type:s}))}}parseTextures(e){const t=new Map;if("Texture"in mt.Objects){const n=mt.Objects.Texture;for(const i in n){const s=this.parseTexture(n[i],e);t.set(parseInt(i),s)}}return t}parseTexture(e,t){const n=this.loadTexture(e,t);n.ID=e.id,n.name=e.attrName;const i=e.WrapModeU,s=e.WrapModeV,o=i!==void 0?i.value:0,a=s!==void 0?s.value:0;if(n.wrapS=o===0?Li:Bn,n.wrapT=a===0?Li:Bn,"Scaling"in e){const l=e.Scaling.value;n.repeat.x=l[0],n.repeat.y=l[1]}if("Translation"in e){const l=e.Translation.value;n.offset.x=l[0],n.offset.y=l[1]}return n}loadTexture(e,t){const n=new Set(["tga","tif","tiff","exr","dds","hdr","ktx2"]),i=e.FileName.split(".").pop().toLowerCase(),s=n.has(i)?this.manager.getHandler(`.${i}`):this.textureLoader;if(!s)return console.warn(`FBXLoader: ${i.toUpperCase()} loader not found, creating placeholder texture for`,e.RelativeFilename),new Wt;const o=s.path;o||s.setPath(this.textureLoader.path);const a=Kt.get(e.id).children;let l;a!==void 0&&a.length>0&&t[a[0].ID]!==void 0&&(l=t[a[0].ID],(l.indexOf("blob:")===0||l.indexOf("data:")===0)&&s.setPath(void 0));const c=s.load(l);return s.setPath(o),c}parseMaterials(e){const t=new Map;if("Material"in mt.Objects){const n=mt.Objects.Material;for(const i in n){const s=this.parseMaterial(n[i],e);s!==null&&t.set(parseInt(i),s)}}return t}parseMaterial(e,t){const n=e.id,i=e.attrName;let s=e.ShadingModel;if(typeof s=="object"&&(s=s.value),!Kt.has(n))return null;const o=this.parseParameters(e,t,n);let a;switch(s.toLowerCase()){case"phong":a=new kn;break;case"lambert":a=new Kr;break;default:console.warn('THREE.FBXLoader: unknown material type "%s". Defaulting to MeshPhongMaterial.',s),a=new kn;break}return a.setValues(o),a.name=i,a}parseParameters(e,t,n){const i={};e.BumpFactor&&(i.bumpScale=e.BumpFactor.value),e.Diffuse?i.color=rt.toWorkingColorSpace(new ke().fromArray(e.Diffuse.value),vt):e.DiffuseColor&&(e.DiffuseColor.type==="Color"||e.DiffuseColor.type==="ColorRGB")&&(i.color=rt.toWorkingColorSpace(new ke().fromArray(e.DiffuseColor.value),vt)),e.DisplacementFactor&&(i.displacementScale=e.DisplacementFactor.value),e.Emissive?i.emissive=rt.toWorkingColorSpace(new ke().fromArray(e.Emissive.value),vt):e.EmissiveColor&&(e.EmissiveColor.type==="Color"||e.EmissiveColor.type==="ColorRGB")&&(i.emissive=rt.toWorkingColorSpace(new ke().fromArray(e.EmissiveColor.value),vt)),e.EmissiveFactor&&(i.emissiveIntensity=parseFloat(e.EmissiveFactor.value)),i.opacity=1-(e.TransparencyFactor?parseFloat(e.TransparencyFactor.value):0),(i.opacity===1||i.opacity===0)&&(i.opacity=e.Opacity?parseFloat(e.Opacity.value):null,i.opacity===null&&(i.opacity=1-(e.TransparentColor?parseFloat(e.TransparentColor.value[0]):0))),i.opacity<1&&(i.transparent=!0),e.ReflectionFactor&&(i.reflectivity=e.ReflectionFactor.value),e.Shininess&&(i.shininess=e.Shininess.value),e.Specular?i.specular=rt.toWorkingColorSpace(new ke().fromArray(e.Specular.value),vt):e.SpecularColor&&e.SpecularColor.type==="Color"&&(i.specular=rt.toWorkingColorSpace(new ke().fromArray(e.SpecularColor.value),vt));const s=this;return Kt.get(n).children.forEach(function(o){const a=o.relationship;switch(a){case"Bump":i.bumpMap=s.getTexture(t,o.ID);break;case"Maya|TEX_ao_map":i.aoMap=s.getTexture(t,o.ID);break;case"DiffuseColor":case"Maya|TEX_color_map":i.map=s.getTexture(t,o.ID),i.map!==void 0&&(i.map.colorSpace=vt);break;case"DisplacementColor":i.displacementMap=s.getTexture(t,o.ID);break;case"EmissiveColor":i.emissiveMap=s.getTexture(t,o.ID),i.emissiveMap!==void 0&&(i.emissiveMap.colorSpace=vt);break;case"NormalMap":case"Maya|TEX_normal_map":i.normalMap=s.getTexture(t,o.ID);break;case"ReflectionColor":i.envMap=s.getTexture(t,o.ID),i.envMap!==void 0&&(i.envMap.mapping=_a,i.envMap.colorSpace=vt);break;case"SpecularColor":i.specularMap=s.getTexture(t,o.ID),i.specularMap!==void 0&&(i.specularMap.colorSpace=vt);break;case"TransparentColor":case"TransparencyFactor":i.alphaMap=s.getTexture(t,o.ID),i.transparent=!0;break;case"AmbientColor":case"ShininessExponent":case"SpecularFactor":case"VectorDisplacementColor":default:console.warn("THREE.FBXLoader: %s map is not supported in three.js, skipping texture.",a);break}}),i}getTexture(e,t){return"LayeredTexture"in mt.Objects&&t in mt.Objects.LayeredTexture&&(console.warn("THREE.FBXLoader: layered textures are not supported in three.js. Discarding all but first layer."),t=Kt.get(t).children[0].ID),e.get(t)}parseDeformers(){const e={},t={};if("Deformer"in mt.Objects){const n=mt.Objects.Deformer;for(const i in n){const s=n[i],o=Kt.get(parseInt(i));if(s.attrType==="Skin"){const a=this.parseSkeleton(o,n);a.ID=i,o.parents.length>1&&console.warn("THREE.FBXLoader: skeleton attached to more than one geometry is not supported."),a.geometryID=o.parents[0].ID,e[i]=a}else if(s.attrType==="BlendShape"){const a={id:i};a.rawTargets=this.parseMorphTargets(o,n),a.id=i,o.parents.length>1&&console.warn("THREE.FBXLoader: morph target attached to more than one geometry is not supported."),t[i]=a}}}return{skeletons:e,morphTargets:t}}parseSkeleton(e,t){const n=[];return e.children.forEach(function(i){const s=t[i.ID];if(s.attrType!=="Cluster")return;const o={ID:i.ID,indices:[],weights:[],transformLink:new Ee().fromArray(s.TransformLink.a)};"Indexes"in s&&(o.indices=s.Indexes.a,o.weights=s.Weights.a),n.push(o)}),{rawBones:n,bones:[]}}parseMorphTargets(e,t){const n=[];for(let i=0;i<e.children.length;i++){const s=e.children[i],o=t[s.ID],a={name:o.attrName,initialWeight:o.DeformPercent,id:o.id,fullWeights:o.FullWeights.a};if(o.attrType!=="BlendShapeChannel")return;a.geoID=Kt.get(parseInt(s.ID)).children.filter(function(l){return l.relationship===void 0})[0].ID,n.push(a)}return n}parseScene(e,t,n){An=new wt;const i=this.parseModels(e.skeletons,t,n),s=mt.Objects.Model,o=this;i.forEach(function(l){const c=s[l.ID];o.setLookAtProperties(l,c),Kt.get(l.ID).parents.forEach(function(u){const d=i.get(u.ID);d!==void 0&&d.add(l)}),l.parent===null&&An.add(l)}),this.bindSkeleton(e.skeletons,t,i),this.addGlobalSceneSettings(),An.traverse(function(l){if(l.userData.transformData){l.parent&&(l.userData.transformData.parentMatrix=l.parent.matrix,l.userData.transformData.parentMatrixWorld=l.parent.matrixWorld);const c=Cf(l.userData.transformData);l.applyMatrix4(c),l.updateWorldMatrix()}});const a=new hb().parse();An.children.length===1&&An.children[0].isGroup&&(An.children[0].animations=a,An=An.children[0]),An.animations=a}parseModels(e,t,n){const i=new Map,s=mt.Objects.Model;for(const o in s){const a=parseInt(o),l=s[o],c=Kt.get(a);let h=this.buildSkeleton(c,e,a,l.attrName);if(!h){switch(l.attrType){case"Camera":h=this.createCamera(c);break;case"Light":h=this.createLight(c);break;case"Mesh":h=this.createMesh(c,t,n);break;case"NurbsCurve":h=this.createCurve(c,t);break;case"LimbNode":case"Root":h=new ba;break;case"Null":default:h=new wt;break}h.name=l.attrName?Ct.sanitizeNodeName(l.attrName):"",h.userData.originalName=l.attrName,h.ID=a}this.getTransformData(h,l),i.set(a,h)}return i}buildSkeleton(e,t,n,i){let s=null;return e.parents.forEach(function(o){for(const a in t){const l=t[a];l.rawBones.forEach(function(c,h){if(c.ID===o.ID){const u=s;s=new ba,s.matrixWorld.copy(c.transformLink),s.name=i?Ct.sanitizeNodeName(i):"",s.userData.originalName=i,s.ID=n,l.bones[h]=s,u!==null&&s.add(u)}})}}),s}createCamera(e){let t,n;if(e.children.forEach(function(i){const s=mt.Objects.NodeAttribute[i.ID];s!==void 0&&(n=s)}),n===void 0)t=new Mt;else{let i=0;n.CameraProjectionType!==void 0&&n.CameraProjectionType.value===1&&(i=1);let s=1;n.NearPlane!==void 0&&(s=n.NearPlane.value/1e3);let o=1e3;n.FarPlane!==void 0&&(o=n.FarPlane.value/1e3);let a=window.innerWidth,l=window.innerHeight;n.AspectWidth!==void 0&&n.AspectHeight!==void 0&&(a=n.AspectWidth.value,l=n.AspectHeight.value);const c=a/l;let h=45;n.FieldOfView!==void 0&&(h=n.FieldOfView.value);const u=n.FocalLength?n.FocalLength.value:null;switch(i){case 0:t=new Qt(h,c,s,o),u!==null&&t.setFocalLength(u);break;case 1:console.warn("THREE.FBXLoader: Orthographic cameras not supported yet."),t=new Mt;break;default:console.warn("THREE.FBXLoader: Unknown camera type "+i+"."),t=new Mt;break}}return t}createLight(e){let t,n;if(e.children.forEach(function(i){const s=mt.Objects.NodeAttribute[i.ID];s!==void 0&&(n=s)}),n===void 0)t=new Mt;else{let i;n.LightType===void 0?i=0:i=n.LightType.value;let s=16777215;n.Color!==void 0&&(s=rt.toWorkingColorSpace(new ke().fromArray(n.Color.value),vt));let o=n.Intensity===void 0?1:n.Intensity.value/100;n.CastLightOnObject!==void 0&&n.CastLightOnObject.value===0&&(o=0);let a=0;n.FarAttenuationEnd!==void 0&&(n.EnableFarAttenuation!==void 0&&n.EnableFarAttenuation.value===0?a=0:a=n.FarAttenuationEnd.value);const l=1;switch(i){case 0:t=new Ic(s,o,a,l);break;case 1:t=new Ea(s,o);break;case 2:let c=Math.PI/3;n.InnerAngle!==void 0&&(c=Pt.degToRad(n.InnerAngle.value));let h=0;n.OuterAngle!==void 0&&(h=Pt.degToRad(n.OuterAngle.value),h=Math.max(h,1)),t=new hf(s,o,a,c,h,l);break;default:console.warn("THREE.FBXLoader: Unknown light type "+n.LightType.value+", defaulting to a PointLight."),t=new Ic(s,o);break}n.CastShadows!==void 0&&n.CastShadows.value===1&&(t.castShadow=!0)}return t}createMesh(e,t,n){let i,s=null,o=null;const a=[];if(e.children.forEach(function(l){t.has(l.ID)&&(s=t.get(l.ID)),n.has(l.ID)&&a.push(n.get(l.ID))}),a.length>1?o=a:a.length>0?o=a[0]:(o=new kn({name:Zn.DEFAULT_MATERIAL_NAME,color:13421772}),a.push(o)),"color"in s.attributes&&a.forEach(function(l){l.vertexColors=!0}),s.groups.length>0){let l=!1;for(let c=0,h=s.groups.length;c<h;c++){const u=s.groups[c];(u.materialIndex<0||u.materialIndex>=a.length)&&(u.materialIndex=a.length,l=!0)}if(l){const c=new kn;a.push(c)}}return s.FBX_Deformer?(i=new Qd(s,o),i.normalizeSkinWeights()):i=new ve(s,o),i}createCurve(e,t){const n=e.children.reduce(function(s,o){return t.has(o.ID)&&(s=t.get(o.ID)),s},null),i=new Yn({name:Zn.DEFAULT_MATERIAL_NAME,color:3342591,linewidth:1});return new Gn(n,i)}getTransformData(e,t){const n={};"InheritType"in t&&(n.inheritType=parseInt(t.InheritType.value)),"RotationOrder"in t?n.eulerOrder=Jr(t.RotationOrder.value):n.eulerOrder=Jr(0),"Lcl_Translation"in t&&(n.translation=t.Lcl_Translation.value),"PreRotation"in t&&(n.preRotation=t.PreRotation.value),"Lcl_Rotation"in t&&(n.rotation=t.Lcl_Rotation.value),"PostRotation"in t&&(n.postRotation=t.PostRotation.value),"Lcl_Scaling"in t&&(n.scale=t.Lcl_Scaling.value),"ScalingOffset"in t&&(n.scalingOffset=t.ScalingOffset.value),"ScalingPivot"in t&&(n.scalingPivot=t.ScalingPivot.value),"RotationOffset"in t&&(n.rotationOffset=t.RotationOffset.value),"RotationPivot"in t&&(n.rotationPivot=t.RotationPivot.value),e.userData.transformData=n}setLookAtProperties(e,t){"LookAtProperty"in t&&Kt.get(e.ID).children.forEach(function(i){if(i.relationship==="LookAtProperty"){const s=mt.Objects.Model[i.ID];if("Lcl_Translation"in s){const o=s.Lcl_Translation.value;e.target!==void 0?(e.target.position.fromArray(o),An.add(e.target)):e.lookAt(new L().fromArray(o))}}})}bindSkeleton(e,t,n){const i=this.parsePoseNodes();for(const s in e){const o=e[s];Kt.get(parseInt(o.ID)).parents.forEach(function(l){if(t.has(l.ID)){const c=l.ID;Kt.get(c).parents.forEach(function(u){n.has(u.ID)&&n.get(u.ID).bind(new Ca(o.bones),i[u.ID])})}})}}parsePoseNodes(){const e={};if("Pose"in mt.Objects){const t=mt.Objects.Pose;for(const n in t)if(t[n].attrType==="BindPose"&&t[n].NbPoseNodes>0){const i=t[n].PoseNode;Array.isArray(i)?i.forEach(function(s){e[s.Node]=new Ee().fromArray(s.Matrix.a)}):e[i.Node]=new Ee().fromArray(i.Matrix.a)}}return e}addGlobalSceneSettings(){if("GlobalSettings"in mt){if("AmbientColor"in mt.GlobalSettings){const e=mt.GlobalSettings.AmbientColor.value,t=e[0],n=e[1],i=e[2];if(t!==0||n!==0||i!==0){const s=new ke().setRGB(t,n,i,vt);An.add(new th(s,1))}}"UnitScaleFactor"in mt.GlobalSettings&&(An.userData.unitScaleFactor=mt.GlobalSettings.UnitScaleFactor.value)}}}class cb{constructor(){this.negativeMaterialIndices=!1}parse(e){const t=new Map;if("Geometry"in mt.Objects){const n=mt.Objects.Geometry;for(const i in n){const s=Kt.get(parseInt(i)),o=this.parseGeometry(s,n[i],e);t.set(parseInt(i),o)}}return this.negativeMaterialIndices===!0&&console.warn("THREE.FBXLoader: The FBX file contains invalid (negative) material indices. The asset might not render as expected."),t}parseGeometry(e,t,n){switch(t.attrType){case"Mesh":return this.parseMeshGeometry(e,t,n);case"NurbsCurve":return this.parseNurbsGeometry(t)}}parseMeshGeometry(e,t,n){const i=n.skeletons,s=[],o=e.parents.map(function(u){return mt.Objects.Model[u.ID]});if(o.length===0)return;const a=e.children.reduce(function(u,d){return i[d.ID]!==void 0&&(u=i[d.ID]),u},null);e.children.forEach(function(u){n.morphTargets[u.ID]!==void 0&&s.push(n.morphTargets[u.ID])});const l=o[0],c={};"RotationOrder"in l&&(c.eulerOrder=Jr(l.RotationOrder.value)),"InheritType"in l&&(c.inheritType=parseInt(l.InheritType.value)),"GeometricTranslation"in l&&(c.translation=l.GeometricTranslation.value),"GeometricRotation"in l&&(c.rotation=l.GeometricRotation.value),"GeometricScaling"in l&&(c.scale=l.GeometricScaling.value);const h=Cf(c);return this.genGeometry(t,a,s,h)}genGeometry(e,t,n,i){const s=new yt;e.attrName&&(s.name=e.attrName);const o=this.parseGeoNode(e,t),a=this.genBuffers(o),l=new Ne(a.vertex,3);if(l.applyMatrix4(i),s.setAttribute("position",l),a.colors.length>0&&s.setAttribute("color",new Ne(a.colors,3)),t&&(s.setAttribute("skinIndex",new Zc(a.weightsIndices,4)),s.setAttribute("skinWeight",new Ne(a.vertexWeights,4)),s.FBX_Deformer=t),a.normal.length>0){const c=new ct().getNormalMatrix(i),h=new Ne(a.normal,3);h.applyNormalMatrix(c),s.setAttribute("normal",h)}if(a.uvs.forEach(function(c,h){const u=h===0?"uv":`uv${h}`;s.setAttribute(u,new Ne(a.uvs[h],2))}),o.material&&o.material.mappingType!=="AllSame"){let c=a.materialIndex[0],h=0;if(a.materialIndex.forEach(function(u,d){u!==c&&(s.addGroup(h,d-h,c),c=u,h=d)}),s.groups.length>0){const u=s.groups[s.groups.length-1],d=u.start+u.count;d!==a.materialIndex.length&&s.addGroup(d,a.materialIndex.length-d,c)}s.groups.length===0&&s.addGroup(0,a.materialIndex.length,a.materialIndex[0])}return this.addMorphTargets(s,e,n,i),s}parseGeoNode(e,t){const n={};if(n.vertexPositions=e.Vertices!==void 0?e.Vertices.a:[],n.vertexIndices=e.PolygonVertexIndex!==void 0?e.PolygonVertexIndex.a:[],e.LayerElementColor&&(n.color=this.parseVertexColors(e.LayerElementColor[0])),e.LayerElementMaterial&&(n.material=this.parseMaterialIndices(e.LayerElementMaterial[0])),e.LayerElementNormal&&(n.normal=this.parseNormals(e.LayerElementNormal[0])),e.LayerElementUV){n.uv=[];let i=0;for(;e.LayerElementUV[i];)e.LayerElementUV[i].UV&&n.uv.push(this.parseUVs(e.LayerElementUV[i])),i++}return n.weightTable={},t!==null&&(n.skeleton=t,t.rawBones.forEach(function(i,s){i.indices.forEach(function(o,a){n.weightTable[o]===void 0&&(n.weightTable[o]=[]),n.weightTable[o].push({id:s,weight:i.weights[a]})})})),n}genBuffers(e){const t={vertex:[],normal:[],colors:[],uvs:[],materialIndex:[],vertexWeights:[],weightsIndices:[]};let n=0,i=0,s=!1,o=[],a=[],l=[],c=[],h=[],u=[];const d=this;return e.vertexIndices.forEach(function(f,g){let v,m=!1;f<0&&(f=f^-1,m=!0);let p=[],w=[];if(o.push(f*3,f*3+1,f*3+2),e.color){const y=ea(g,n,f,e.color);l.push(y[0],y[1],y[2])}if(e.skeleton){if(e.weightTable[f]!==void 0&&e.weightTable[f].forEach(function(y){w.push(y.weight),p.push(y.id)}),w.length>4){s||(console.warn("THREE.FBXLoader: Vertex has more than 4 skinning weights assigned to vertex. Deleting additional weights."),s=!0);const y=[0,0,0,0],b=[0,0,0,0];w.forEach(function(D,R){let P=D,M=p[R];b.forEach(function(_,x,T){if(P>_){T[x]=P,P=_;const F=y[x];y[x]=M,M=F}})}),p=y,w=b}for(;w.length<4;)w.push(0),p.push(0);for(let y=0;y<4;++y)h.push(w[y]),u.push(p[y])}if(e.normal){const y=ea(g,n,f,e.normal);a.push(y[0],y[1],y[2])}e.material&&e.material.mappingType!=="AllSame"&&(v=ea(g,n,f,e.material)[0],v<0&&(d.negativeMaterialIndices=!0,v=0)),e.uv&&e.uv.forEach(function(y,b){const D=ea(g,n,f,y);c[b]===void 0&&(c[b]=[]),c[b].push(D[0]),c[b].push(D[1])}),i++,m&&(d.genFace(t,e,o,v,a,l,c,h,u,i),n++,i=0,o=[],a=[],l=[],c=[],h=[],u=[])}),t}getNormalNewell(e){const t=new L(0,0,0);for(let n=0;n<e.length;n++){const i=e[n],s=e[(n+1)%e.length];t.x+=(i.y-s.y)*(i.z+s.z),t.y+=(i.z-s.z)*(i.x+s.x),t.z+=(i.x-s.x)*(i.y+s.y)}return t.normalize(),t}getNormalTangentAndBitangent(e){const t=this.getNormalNewell(e),i=(Math.abs(t.z)>.5?new L(0,1,0):new L(0,0,1)).cross(t).normalize(),s=t.clone().cross(i).normalize();return{normal:t,tangent:i,bitangent:s}}flattenVertex(e,t,n){return new ye(e.dot(t),e.dot(n))}genFace(e,t,n,i,s,o,a,l,c,h){let u;if(h>3){const d=[],f=t.baseVertexPositions||t.vertexPositions;for(let p=0;p<n.length;p+=3)d.push(new L(f[n[p]],f[n[p+1]],f[n[p+2]]));const{tangent:g,bitangent:v}=this.getNormalTangentAndBitangent(d),m=[];for(const p of d)m.push(this.flattenVertex(p,g,v));u=Qc.triangulateShape(m,[])}else u=[[0,1,2]];for(const[d,f,g]of u)e.vertex.push(t.vertexPositions[n[d*3]]),e.vertex.push(t.vertexPositions[n[d*3+1]]),e.vertex.push(t.vertexPositions[n[d*3+2]]),e.vertex.push(t.vertexPositions[n[f*3]]),e.vertex.push(t.vertexPositions[n[f*3+1]]),e.vertex.push(t.vertexPositions[n[f*3+2]]),e.vertex.push(t.vertexPositions[n[g*3]]),e.vertex.push(t.vertexPositions[n[g*3+1]]),e.vertex.push(t.vertexPositions[n[g*3+2]]),t.skeleton&&(e.vertexWeights.push(l[d*4]),e.vertexWeights.push(l[d*4+1]),e.vertexWeights.push(l[d*4+2]),e.vertexWeights.push(l[d*4+3]),e.vertexWeights.push(l[f*4]),e.vertexWeights.push(l[f*4+1]),e.vertexWeights.push(l[f*4+2]),e.vertexWeights.push(l[f*4+3]),e.vertexWeights.push(l[g*4]),e.vertexWeights.push(l[g*4+1]),e.vertexWeights.push(l[g*4+2]),e.vertexWeights.push(l[g*4+3]),e.weightsIndices.push(c[d*4]),e.weightsIndices.push(c[d*4+1]),e.weightsIndices.push(c[d*4+2]),e.weightsIndices.push(c[d*4+3]),e.weightsIndices.push(c[f*4]),e.weightsIndices.push(c[f*4+1]),e.weightsIndices.push(c[f*4+2]),e.weightsIndices.push(c[f*4+3]),e.weightsIndices.push(c[g*4]),e.weightsIndices.push(c[g*4+1]),e.weightsIndices.push(c[g*4+2]),e.weightsIndices.push(c[g*4+3])),t.color&&(e.colors.push(o[d*3]),e.colors.push(o[d*3+1]),e.colors.push(o[d*3+2]),e.colors.push(o[f*3]),e.colors.push(o[f*3+1]),e.colors.push(o[f*3+2]),e.colors.push(o[g*3]),e.colors.push(o[g*3+1]),e.colors.push(o[g*3+2])),t.material&&t.material.mappingType!=="AllSame"&&(e.materialIndex.push(i),e.materialIndex.push(i),e.materialIndex.push(i)),t.normal&&(e.normal.push(s[d*3]),e.normal.push(s[d*3+1]),e.normal.push(s[d*3+2]),e.normal.push(s[f*3]),e.normal.push(s[f*3+1]),e.normal.push(s[f*3+2]),e.normal.push(s[g*3]),e.normal.push(s[g*3+1]),e.normal.push(s[g*3+2])),t.uv&&t.uv.forEach(function(v,m){e.uvs[m]===void 0&&(e.uvs[m]=[]),e.uvs[m].push(a[m][d*2]),e.uvs[m].push(a[m][d*2+1]),e.uvs[m].push(a[m][f*2]),e.uvs[m].push(a[m][f*2+1]),e.uvs[m].push(a[m][g*2]),e.uvs[m].push(a[m][g*2+1])})}addMorphTargets(e,t,n,i){if(n.length===0)return;e.morphTargetsRelative=!0,e.morphAttributes.position=[];const s=this;n.forEach(function(o){o.rawTargets.forEach(function(a){const l=mt.Objects.Geometry[a.geoID];l!==void 0&&s.genMorphGeometry(e,t,l,i,a.name)})})}genMorphGeometry(e,t,n,i,s){const o=t.Vertices!==void 0?t.Vertices.a:[],a=t.PolygonVertexIndex!==void 0?t.PolygonVertexIndex.a:[],l=n.Vertices!==void 0?n.Vertices.a:[],c=n.Indexes!==void 0?n.Indexes.a:[],h=e.attributes.position.count*3,u=new Float32Array(h);for(let v=0;v<c.length;v++){const m=c[v]*3;u[m]=l[v*3],u[m+1]=l[v*3+1],u[m+2]=l[v*3+2]}const d={vertexIndices:a,vertexPositions:u,baseVertexPositions:o},f=this.genBuffers(d),g=new Ne(f.vertex,3);g.name=s||n.attrName,g.applyMatrix4(i),e.morphAttributes.position.push(g)}parseNormals(e){const t=e.MappingInformationType,n=e.ReferenceInformationType,i=e.Normals.a;let s=[];return n==="IndexToDirect"&&("NormalIndex"in e?s=e.NormalIndex.a:"NormalsIndex"in e&&(s=e.NormalsIndex.a)),{dataSize:3,buffer:i,indices:s,mappingType:t,referenceType:n}}parseUVs(e){const t=e.MappingInformationType,n=e.ReferenceInformationType,i=e.UV.a;let s=[];return n==="IndexToDirect"&&(s=e.UVIndex.a),{dataSize:2,buffer:i,indices:s,mappingType:t,referenceType:n}}parseVertexColors(e){const t=e.MappingInformationType,n=e.ReferenceInformationType,i=e.Colors.a;let s=[];n==="IndexToDirect"&&(s=e.ColorIndex.a);for(let o=0,a=new ke;o<i.length;o+=4)a.fromArray(i,o),rt.toWorkingColorSpace(a,vt),a.toArray(i,o);return{dataSize:4,buffer:i,indices:s,mappingType:t,referenceType:n}}parseMaterialIndices(e){const t=e.MappingInformationType,n=e.ReferenceInformationType;if(t==="NoMappingInformation")return{dataSize:1,buffer:[0],indices:[0],mappingType:"AllSame",referenceType:n};const i=e.Materials.a,s=[];for(let o=0;o<i.length;++o)s.push(o);return{dataSize:1,buffer:i,indices:s,mappingType:t,referenceType:n}}parseNurbsGeometry(e){const t=parseInt(e.Order);if(isNaN(t))return console.error("THREE.FBXLoader: Invalid Order %s given for geometry ID: %s",e.Order,e.id),new yt;const n=t-1,i=e.KnotVector.a,s=[],o=e.Points.a;for(let u=0,d=o.length;u<d;u+=4)s.push(new at().fromArray(o,u));let a,l;if(e.Form==="Closed")s.push(s[0]);else if(e.Form==="Periodic"){a=n,l=i.length-1-a;for(let u=0;u<n;++u)s.push(s[u])}const h=new zy(n,i,s,a,l).getPoints(s.length*12);return new yt().setFromPoints(h)}}class hb{parse(){const e=[],t=this.parseClips();if(t!==void 0)for(const n in t){const i=t[n],s=this.addClip(i);e.push(s)}return e}parseClips(){if(mt.Objects.AnimationCurve===void 0)return;const e=this.parseAnimationCurveNodes();this.parseAnimationCurves(e);const t=this.parseAnimationLayers(e);return this.parseAnimStacks(t)}parseAnimationCurveNodes(){const e=mt.Objects.AnimationCurveNode,t=new Map;for(const n in e){const i=e[n];if(i.attrName.match(/S|R|T|DeformPercent/)!==null){const s={id:i.id,attr:i.attrName,curves:{}};t.set(s.id,s)}}return t}parseAnimationCurves(e){const t=mt.Objects.AnimationCurve;for(const n in t){const i={id:t[n].id,times:t[n].KeyTime.a.map(mb),values:t[n].KeyValueFloat.a},s=Kt.get(i.id);if(s!==void 0){const o=s.parents[0].ID,a=s.parents[0].relationship;a.match(/X/)?e.get(o).curves.x=i:a.match(/Y/)?e.get(o).curves.y=i:a.match(/Z/)?e.get(o).curves.z=i:a.match(/DeformPercent/)&&e.has(o)&&(e.get(o).curves.morph=i)}}}parseAnimationLayers(e){const t=mt.Objects.AnimationLayer,n=new Map;for(const i in t){const s=[],o=Kt.get(parseInt(i));o!==void 0&&(o.children.forEach(function(l,c){if(e.has(l.ID)){const h=e.get(l.ID);if(h.curves.x!==void 0||h.curves.y!==void 0||h.curves.z!==void 0){if(s[c]===void 0){const u=Kt.get(l.ID).parents.filter(function(d){return d.relationship!==void 0})[0].ID;if(u!==void 0){const d=mt.Objects.Model[u.toString()];if(d===void 0){console.warn("THREE.FBXLoader: Encountered a unused curve.",l);return}const f={modelName:d.attrName?Ct.sanitizeNodeName(d.attrName):"",ID:d.id,initialPosition:[0,0,0],initialRotation:[0,0,0],initialScale:[1,1,1]};An.traverse(function(g){g.ID===d.id&&(f.transform=g.matrix,g.userData.transformData&&(f.eulerOrder=g.userData.transformData.eulerOrder))}),f.transform||(f.transform=new Ee),"PreRotation"in d&&(f.preRotation=d.PreRotation.value),"PostRotation"in d&&(f.postRotation=d.PostRotation.value),s[c]=f}}s[c]&&(s[c][h.attr]=h)}else if(h.curves.morph!==void 0){if(s[c]===void 0){const u=Kt.get(l.ID).parents.filter(function(p){return p.relationship!==void 0})[0].ID,d=Kt.get(u).parents[0].ID,f=Kt.get(d).parents[0].ID,g=Kt.get(f).parents[0].ID,v=mt.Objects.Model[g],m={modelName:v.attrName?Ct.sanitizeNodeName(v.attrName):"",morphName:mt.Objects.Deformer[u].attrName};s[c]=m}s[c][h.attr]=h}}}),n.set(parseInt(i),s))}return n}parseAnimStacks(e){const t=mt.Objects.AnimationStack,n={};for(const i in t){const s=Kt.get(parseInt(i)).children;s.length>1&&console.warn("THREE.FBXLoader: Encountered an animation stack with multiple layers, this is currently not supported. Ignoring subsequent layers.");const o=e.get(s[0].ID);n[i]={name:t[i].attrName,layer:o}}return n}addClip(e){let t=[];const n=this;return e.layer.forEach(function(i){t=t.concat(n.generateTracks(i))}),new Dc(e.name,-1,t)}generateTracks(e){const t=[];let n=new L,i=new L;if(e.transform&&e.transform.decompose(n,new St,i),n=n.toArray(),i=i.toArray(),e.T!==void 0&&Object.keys(e.T.curves).length>0){const s=this.generateVectorTrack(e.modelName,e.T.curves,n,"position");s!==void 0&&t.push(s)}if(e.R!==void 0&&Object.keys(e.R.curves).length>0){const s=this.generateRotationTrack(e.modelName,e.R.curves,e.preRotation,e.postRotation,e.eulerOrder);s!==void 0&&t.push(s)}if(e.S!==void 0&&Object.keys(e.S.curves).length>0){const s=this.generateVectorTrack(e.modelName,e.S.curves,i,"scale");s!==void 0&&t.push(s)}if(e.DeformPercent!==void 0){const s=this.generateMorphTrack(e);s!==void 0&&t.push(s)}return t}generateVectorTrack(e,t,n,i){const s=this.getTimesForAllAxes(t),o=this.getKeyframeTrackValues(s,t,n);return new Ms(e+"."+i,s,o)}generateRotationTrack(e,t,n,i,s){let o,a;if(t.x!==void 0&&t.y!==void 0&&t.z!==void 0){const d=this.interpolateRotations(t.x,t.y,t.z,s);o=d[0],a=d[1]}const l=Jr(0);n!==void 0&&(n=n.map(Pt.degToRad),n.push(l),n=new Bt().fromArray(n),n=new St().setFromEuler(n)),i!==void 0&&(i=i.map(Pt.degToRad),i.push(l),i=new Bt().fromArray(i),i=new St().setFromEuler(i).invert());const c=new St,h=new Bt,u=[];if(!a||!o)return new bs(e+".quaternion",[0],[0]);for(let d=0;d<a.length;d+=3)h.set(a[d],a[d+1],a[d+2],s),c.setFromEuler(h),n!==void 0&&c.premultiply(n),i!==void 0&&c.multiply(i),d>2&&new St().fromArray(u,(d-3)/3*4).dot(c)<0&&c.set(-c.x,-c.y,-c.z,-c.w),c.toArray(u,d/3*4);return new bs(e+".quaternion",o,u)}generateMorphTrack(e){const t=e.DeformPercent.curves.morph,n=t.values.map(function(s){return s/100}),i=An.getObjectByName(e.modelName).morphTargetDictionary[e.morphName];return new $r(e.modelName+".morphTargetInfluences["+i+"]",t.times,n)}getTimesForAllAxes(e){let t=[];if(e.x!==void 0&&(t=t.concat(e.x.times)),e.y!==void 0&&(t=t.concat(e.y.times)),e.z!==void 0&&(t=t.concat(e.z.times)),t=t.sort(function(n,i){return n-i}),t.length>1){let n=1,i=t[0];for(let s=1;s<t.length;s++){const o=t[s];o!==i&&(t[n]=o,i=o,n++)}t=t.slice(0,n)}return t}getKeyframeTrackValues(e,t,n){const i=n,s=[];let o=-1,a=-1,l=-1;return e.forEach(function(c){if(t.x&&(o=t.x.times.indexOf(c)),t.y&&(a=t.y.times.indexOf(c)),t.z&&(l=t.z.times.indexOf(c)),o!==-1){const h=t.x.values[o];s.push(h),i[0]=h}else s.push(i[0]);if(a!==-1){const h=t.y.values[a];s.push(h),i[1]=h}else s.push(i[1]);if(l!==-1){const h=t.z.values[l];s.push(h),i[2]=h}else s.push(i[2])}),s}interpolateRotations(e,t,n,i){const s=[],o=[];s.push(e.times[0]),o.push(Pt.degToRad(e.values[0])),o.push(Pt.degToRad(t.values[0])),o.push(Pt.degToRad(n.values[0]));for(let a=1;a<e.values.length;a++){const l=[e.values[a-1],t.values[a-1],n.values[a-1]];if(isNaN(l[0])||isNaN(l[1])||isNaN(l[2]))continue;const c=l.map(Pt.degToRad),h=[e.values[a],t.values[a],n.values[a]];if(isNaN(h[0])||isNaN(h[1])||isNaN(h[2]))continue;const u=h.map(Pt.degToRad),d=[h[0]-l[0],h[1]-l[1],h[2]-l[2]],f=[Math.abs(d[0]),Math.abs(d[1]),Math.abs(d[2])];if(f[0]>=180||f[1]>=180||f[2]>=180){const v=Math.max(...f)/180,m=new Bt(...c,i),p=new Bt(...u,i),w=new St().setFromEuler(m),y=new St().setFromEuler(p);w.dot(y)&&y.set(-y.x,-y.y,-y.z,-y.w);const b=e.times[a-1],D=e.times[a]-b,R=new St,P=new Bt;for(let M=0;M<1;M+=1/v)R.copy(w.clone().slerp(y.clone(),M)),s.push(b+M*D),P.setFromQuaternion(R,i),o.push(P.x),o.push(P.y),o.push(P.z)}else s.push(e.times[a]),o.push(Pt.degToRad(e.values[a])),o.push(Pt.degToRad(t.values[a])),o.push(Pt.degToRad(n.values[a]))}return[s,o]}}class ub{getPrevNode(){return this.nodeStack[this.currentIndent-2]}getCurrentNode(){return this.nodeStack[this.currentIndent-1]}getCurrentProp(){return this.currentProp}pushStack(e){this.nodeStack.push(e),this.currentIndent+=1}popStack(){this.nodeStack.pop(),this.currentIndent-=1}setCurrentProp(e,t){this.currentProp=e,this.currentPropName=t}parse(e){this.currentIndent=0,this.allNodes=new Rf,this.nodeStack=[],this.currentProp=[],this.currentPropName="";const t=this,n=e.split(/[\r\n]+/);return n.forEach(function(i,s){const o=i.match(/^[\s\t]*;/),a=i.match(/^[\s\t]*$/);if(o||a)return;const l=i.match("^\\t{"+t.currentIndent+"}(\\w+):(.*){",""),c=i.match("^\\t{"+t.currentIndent+"}(\\w+):[\\s\\t\\r\\n](.*)"),h=i.match("^\\t{"+(t.currentIndent-1)+"}}");l?t.parseNodeBegin(i,l):c?t.parseNodeProperty(i,c,n[++s]):h?t.popStack():i.match(/^[^\s\t}]/)&&t.parseNodePropertyContinued(i)}),this.allNodes}parseNodeBegin(e,t){const n=t[1].trim().replace(/^"/,"").replace(/"$/,""),i=t[2].split(",").map(function(l){return l.trim().replace(/^"/,"").replace(/"$/,"")}),s={name:n},o=this.parseNodeAttr(i),a=this.getCurrentNode();this.currentIndent===0?this.allNodes.add(n,s):n in a?(n==="PoseNode"?a.PoseNode.push(s):a[n].id!==void 0&&(a[n]={},a[n][a[n].id]=a[n]),o.id!==""&&(a[n][o.id]=s)):typeof o.id=="number"?(a[n]={},a[n][o.id]=s):n!=="Properties70"&&(n==="PoseNode"?a[n]=[s]:a[n]=s),typeof o.id=="number"&&(s.id=o.id),o.name!==""&&(s.attrName=o.name),o.type!==""&&(s.attrType=o.type),this.pushStack(s)}parseNodeAttr(e){let t=e[0];e[0]!==""&&(t=parseInt(e[0]),isNaN(t)&&(t=e[0]));let n="",i="";return e.length>1&&(n=e[1].replace(/^(\w+)::/,""),i=e[2]),{id:t,name:n,type:i}}parseNodeProperty(e,t,n){let i=t[1].replace(/^"/,"").replace(/"$/,"").trim(),s=t[2].replace(/^"/,"").replace(/"$/,"").trim();i==="Content"&&s===","&&(s=n.replace(/"/g,"").replace(/,$/,"").trim());const o=this.getCurrentNode();if(o.name==="Properties70"){this.parseNodeSpecialProperty(e,i,s);return}if(i==="C"){const l=s.split(",").slice(1),c=parseInt(l[0]),h=parseInt(l[1]);let u=s.split(",").slice(3);u=u.map(function(d){return d.trim().replace(/^"/,"")}),i="connections",s=[c,h],_b(s,u),o[i]===void 0&&(o[i]=[])}i==="Node"&&(o.id=s),i in o&&Array.isArray(o[i])?o[i].push(s):i!=="a"?o[i]=s:o.a=s,this.setCurrentProp(o,i),i==="a"&&s.slice(-1)!==","&&(o.a=Ol(s))}parseNodePropertyContinued(e){const t=this.getCurrentNode();t.a+=e,e.slice(-1)!==","&&(t.a=Ol(t.a))}parseNodeSpecialProperty(e,t,n){const i=n.split('",').map(function(h){return h.trim().replace(/^\"/,"").replace(/\s/,"_")}),s=i[0],o=i[1],a=i[2],l=i[3];let c=i[4];switch(o){case"int":case"enum":case"bool":case"ULongLong":case"double":case"Number":case"FieldOfView":c=parseFloat(c);break;case"Color":case"ColorRGB":case"Vector3D":case"Lcl_Translation":case"Lcl_Rotation":case"Lcl_Scaling":c=Ol(c);break}this.getPrevNode()[s]={type:o,type2:a,flag:l,value:c},this.setCurrentProp(this.getPrevNode(),s)}}class db{parse(e){const t=new rd(e);t.skip(23);const n=t.getUint32();if(n<6400)throw new Error("THREE.FBXLoader: FBX version not supported, FileVersion: "+n);const i=new Rf;for(;!this.endOfContent(t);){const s=this.parseNode(t,n);s!==null&&i.add(s.name,s)}return i}endOfContent(e){return e.size()%16===0?(e.getOffset()+160+16&-16)>=e.size():e.getOffset()+160+16>=e.size()}parseNode(e,t){const n={},i=t>=7500?e.getUint64():e.getUint32(),s=t>=7500?e.getUint64():e.getUint32();t>=7500?e.getUint64():e.getUint32();const o=e.getUint8(),a=e.getString(o);if(i===0)return null;const l=[];for(let d=0;d<s;d++)l.push(this.parseProperty(e));const c=l.length>0?l[0]:"",h=l.length>1?l[1]:"",u=l.length>2?l[2]:"";for(n.singleProperty=s===1&&e.getOffset()===i;i>e.getOffset();){const d=this.parseNode(e,t);d!==null&&this.parseSubNode(a,n,d)}return n.propertyList=l,typeof c=="number"&&(n.id=c),h!==""&&(n.attrName=h),u!==""&&(n.attrType=u),a!==""&&(n.name=a),n}parseSubNode(e,t,n){if(n.singleProperty===!0){const i=n.propertyList[0];Array.isArray(i)?(t[n.name]=n,n.a=i):t[n.name]=i}else if(e==="Connections"&&n.name==="C"){const i=[];n.propertyList.forEach(function(s,o){o!==0&&i.push(s)}),t.connections===void 0&&(t.connections=[]),t.connections.push(i)}else if(n.name==="Properties70")Object.keys(n).forEach(function(s){t[s]=n[s]});else if(e==="Properties70"&&n.name==="P"){let i=n.propertyList[0],s=n.propertyList[1];const o=n.propertyList[2],a=n.propertyList[3];let l;i.indexOf("Lcl ")===0&&(i=i.replace("Lcl ","Lcl_")),s.indexOf("Lcl ")===0&&(s=s.replace("Lcl ","Lcl_")),s==="Color"||s==="ColorRGB"||s==="Vector"||s==="Vector3D"||s.indexOf("Lcl_")===0?l=[n.propertyList[4],n.propertyList[5],n.propertyList[6]]:l=n.propertyList[4],t[i]={type:s,type2:o,flag:a,value:l}}else t[n.name]===void 0?typeof n.id=="number"?(t[n.name]={},t[n.name][n.id]=n):t[n.name]=n:n.name==="PoseNode"?(Array.isArray(t[n.name])||(t[n.name]=[t[n.name]]),t[n.name].push(n)):t[n.name][n.id]===void 0&&(t[n.name][n.id]=n)}parseProperty(e){const t=e.getString(1);let n;switch(t){case"C":return e.getBoolean();case"D":return e.getFloat64();case"F":return e.getFloat32();case"I":return e.getInt32();case"L":return e.getInt64();case"R":return n=e.getUint32(),e.getArrayBuffer(n);case"S":return n=e.getUint32(),e.getString(n);case"Y":return e.getInt16();case"b":case"c":case"d":case"f":case"i":case"l":const i=e.getUint32(),s=e.getUint32(),o=e.getUint32();if(s===0)switch(t){case"b":case"c":return e.getBooleanArray(i);case"d":return e.getFloat64Array(i);case"f":return e.getFloat32Array(i);case"i":return e.getInt32Array(i);case"l":return e.getInt64Array(i)}const a=eb(new Uint8Array(e.getArrayBuffer(o))),l=new rd(a.buffer);switch(t){case"b":case"c":return l.getBooleanArray(i);case"d":return l.getFloat64Array(i);case"f":return l.getFloat32Array(i);case"i":return l.getInt32Array(i);case"l":return l.getInt64Array(i)}break;default:throw new Error("THREE.FBXLoader: Unknown property type "+t)}}}class rd{constructor(e,t){this.dv=new DataView(e),this.offset=0,this.littleEndian=t!==void 0?t:!0,this._textDecoder=new TextDecoder}getOffset(){return this.offset}size(){return this.dv.buffer.byteLength}skip(e){this.offset+=e}getBoolean(){return(this.getUint8()&1)===1}getBooleanArray(e){const t=[];for(let n=0;n<e;n++)t.push(this.getBoolean());return t}getUint8(){const e=this.dv.getUint8(this.offset);return this.offset+=1,e}getInt16(){const e=this.dv.getInt16(this.offset,this.littleEndian);return this.offset+=2,e}getInt32(){const e=this.dv.getInt32(this.offset,this.littleEndian);return this.offset+=4,e}getInt32Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getInt32());return t}getUint32(){const e=this.dv.getUint32(this.offset,this.littleEndian);return this.offset+=4,e}getInt64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t&2147483648?(t=~t&4294967295,e=~e&4294967295,e===4294967295&&(t=t+1&4294967295),e=e+1&4294967295,-(t*4294967296+e)):t*4294967296+e}getInt64Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getInt64());return t}getUint64(){let e,t;return this.littleEndian?(e=this.getUint32(),t=this.getUint32()):(t=this.getUint32(),e=this.getUint32()),t*4294967296+e}getFloat32(){const e=this.dv.getFloat32(this.offset,this.littleEndian);return this.offset+=4,e}getFloat32Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getFloat32());return t}getFloat64(){const e=this.dv.getFloat64(this.offset,this.littleEndian);return this.offset+=8,e}getFloat64Array(e){const t=[];for(let n=0;n<e;n++)t.push(this.getFloat64());return t}getArrayBuffer(e){const t=this.dv.buffer.slice(this.offset,this.offset+e);return this.offset+=e,t}getString(e){const t=this.offset;let n=new Uint8Array(this.dv.buffer,t,e);this.skip(e);const i=n.indexOf(0);return i>=0&&(n=new Uint8Array(this.dv.buffer,t,i)),this._textDecoder.decode(n)}}class Rf{add(e,t){this[e]=t}}function fb(r){const e="Kaydara FBX Binary  \0";return r.byteLength>=e.length&&e===Pf(r,0,e.length)}function pb(r){const e=["K","a","y","d","a","r","a","\\","F","B","X","\\","B","i","n","a","r","y","\\","\\"];let t=0;function n(i){const s=r[i-1];return r=r.slice(t+i),t++,s}for(let i=0;i<e.length;++i)if(n(1)===e[i])return!1;return!0}function od(r){const e=/FBXVersion: (\d+)/,t=r.match(e);if(t)return parseInt(t[1]);throw new Error("THREE.FBXLoader: Cannot find the version number for the file given.")}function mb(r){return r/46186158e3}const gb=[];function ea(r,e,t,n){let i;switch(n.mappingType){case"ByPolygonVertex":i=r;break;case"ByPolygon":i=e;break;case"ByVertice":i=t;break;case"AllSame":i=n.indices[0];break;default:console.warn("THREE.FBXLoader: unknown attribute mapping type "+n.mappingType)}n.referenceType==="IndexToDirect"&&(i=n.indices[i]);const s=i*n.dataSize,o=s+n.dataSize;return vb(gb,n.buffer,s,o)}const Fl=new Bt,Zs=new L;function Cf(r){const e=new Ee,t=new Ee,n=new Ee,i=new Ee,s=new Ee,o=new Ee,a=new Ee,l=new Ee,c=new Ee,h=new Ee,u=new Ee,d=new Ee,f=r.inheritType?r.inheritType:0;r.translation&&e.setPosition(Zs.fromArray(r.translation));const g=Jr(0);if(r.preRotation){const T=r.preRotation.map(Pt.degToRad);T.push(g),t.makeRotationFromEuler(Fl.fromArray(T))}if(r.rotation){const T=r.rotation.map(Pt.degToRad);T.push(r.eulerOrder||g),n.makeRotationFromEuler(Fl.fromArray(T))}if(r.postRotation){const T=r.postRotation.map(Pt.degToRad);T.push(g),i.makeRotationFromEuler(Fl.fromArray(T)),i.invert()}r.scale&&s.scale(Zs.fromArray(r.scale)),r.scalingOffset&&a.setPosition(Zs.fromArray(r.scalingOffset)),r.scalingPivot&&o.setPosition(Zs.fromArray(r.scalingPivot)),r.rotationOffset&&l.setPosition(Zs.fromArray(r.rotationOffset)),r.rotationPivot&&c.setPosition(Zs.fromArray(r.rotationPivot)),r.parentMatrixWorld&&(u.copy(r.parentMatrix),h.copy(r.parentMatrixWorld));const v=t.clone().multiply(n).multiply(i),m=new Ee;m.extractRotation(h);const p=new Ee;p.copyPosition(h);const w=p.clone().invert().multiply(h),y=m.clone().invert().multiply(w),b=s,D=new Ee;if(f===0)D.copy(m).multiply(v).multiply(y).multiply(b);else if(f===1)D.copy(m).multiply(y).multiply(v).multiply(b);else{const F=new Ee().scale(new L().setFromMatrixScale(u)).clone().invert(),k=y.clone().multiply(F);D.copy(m).multiply(v).multiply(k).multiply(b)}const R=c.clone().invert(),P=o.clone().invert();let M=e.clone().multiply(l).multiply(c).multiply(t).multiply(n).multiply(i).multiply(R).multiply(a).multiply(o).multiply(s).multiply(P);const _=new Ee().copyPosition(M),x=h.clone().multiply(_);return d.copyPosition(x),M=d.clone().multiply(D),M.premultiply(h.invert()),M}function Jr(r){r=r||0;const e=["ZYX","YZX","XZY","ZXY","YXZ","XYZ"];return r===6?(console.warn("THREE.FBXLoader: unsupported Euler Order: Spherical XYZ. Animations and rotations may be incorrect."),e[0]):e[r]}function Ol(r){return r.split(",").map(function(t){return parseFloat(t)})}function Pf(r,e,t){return e===void 0&&(e=0),t===void 0&&(t=r.byteLength),new TextDecoder().decode(new Uint8Array(r,e,t))}function _b(r,e){for(let t=0,n=r.length,i=e.length;t<i;t++,n++)r[n]=e[t]}function vb(r,e,t,n){for(let i=t,s=0;i<n;i++,s++)r[s]=e[i];return r}const xb=/^[og]\s*(.+)?/,yb=/^mtllib /,bb=/^usemtl /,Mb=/^usemap /,ad=/\s+/,ld=new L,Bl=new L,cd=new L,hd=new L,Vn=new L,ta=new ke;function wb(){const r={objects:[],object:{},vertices:[],normals:[],colors:[],uvs:[],materials:{},materialLibraries:[],startObject:function(e,t){if(this.object&&this.object.fromDeclaration===!1){this.object.name=e,this.object.fromDeclaration=t!==!1;return}const n=this.object&&typeof this.object.currentMaterial=="function"?this.object.currentMaterial():void 0;if(this.object&&typeof this.object._finalize=="function"&&this.object._finalize(!0),this.object={name:e||"",fromDeclaration:t!==!1,geometry:{vertices:[],normals:[],colors:[],uvs:[],hasUVIndices:!1},materials:[],smooth:!0,startMaterial:function(i,s){const o=this._finalize(!1);o&&(o.inherited||o.groupCount<=0)&&this.materials.splice(o.index,1);const a={index:this.materials.length,name:i||"",mtllib:Array.isArray(s)&&s.length>0?s[s.length-1]:"",smooth:o!==void 0?o.smooth:this.smooth,groupStart:o!==void 0?o.groupEnd:0,groupEnd:-1,groupCount:-1,inherited:!1,clone:function(l){const c={index:typeof l=="number"?l:this.index,name:this.name,mtllib:this.mtllib,smooth:this.smooth,groupStart:0,groupEnd:-1,groupCount:-1,inherited:!1};return c.clone=this.clone.bind(c),c}};return this.materials.push(a),a},currentMaterial:function(){if(this.materials.length>0)return this.materials[this.materials.length-1]},_finalize:function(i){const s=this.currentMaterial();if(s&&s.groupEnd===-1&&(s.groupEnd=this.geometry.vertices.length/3,s.groupCount=s.groupEnd-s.groupStart,s.inherited=!1),i&&this.materials.length>1)for(let o=this.materials.length-1;o>=0;o--)this.materials[o].groupCount<=0&&this.materials.splice(o,1);return i&&this.materials.length===0&&this.materials.push({name:"",smooth:this.smooth}),s}},n&&n.name&&typeof n.clone=="function"){const i=n.clone(0);i.inherited=!0,this.object.materials.push(i)}this.objects.push(this.object)},finalize:function(){this.object&&typeof this.object._finalize=="function"&&this.object._finalize(!0)},parseVertexIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseNormalIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/3)*3},parseUVIndex:function(e,t){const n=parseInt(e,10);return(n>=0?n-1:n+t/2)*2},addVertex:function(e,t,n){const i=this.vertices,s=this.object.geometry.vertices;s.push(i[e+0],i[e+1],i[e+2]),s.push(i[t+0],i[t+1],i[t+2]),s.push(i[n+0],i[n+1],i[n+2])},addVertexPoint:function(e){const t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addVertexLine:function(e){const t=this.vertices;this.object.geometry.vertices.push(t[e+0],t[e+1],t[e+2])},addNormal:function(e,t,n){const i=this.normals,s=this.object.geometry.normals;s.push(i[e+0],i[e+1],i[e+2]),s.push(i[t+0],i[t+1],i[t+2]),s.push(i[n+0],i[n+1],i[n+2])},addFaceNormal:function(e,t,n){const i=this.vertices,s=this.object.geometry.normals;ld.fromArray(i,e),Bl.fromArray(i,t),cd.fromArray(i,n),Vn.subVectors(cd,Bl),hd.subVectors(ld,Bl),Vn.cross(hd),Vn.normalize(),s.push(Vn.x,Vn.y,Vn.z),s.push(Vn.x,Vn.y,Vn.z),s.push(Vn.x,Vn.y,Vn.z)},addColor:function(e,t,n){const i=this.colors,s=this.object.geometry.colors;i[e]!==void 0&&s.push(i[e+0],i[e+1],i[e+2]),i[t]!==void 0&&s.push(i[t+0],i[t+1],i[t+2]),i[n]!==void 0&&s.push(i[n+0],i[n+1],i[n+2])},addUV:function(e,t,n){const i=this.uvs,s=this.object.geometry.uvs;s.push(i[e+0],i[e+1]),s.push(i[t+0],i[t+1]),s.push(i[n+0],i[n+1])},addDefaultUV:function(){const e=this.object.geometry.uvs;e.push(0,0),e.push(0,0),e.push(0,0)},addUVLine:function(e){const t=this.uvs;this.object.geometry.uvs.push(t[e+0],t[e+1])},addFace:function(e,t,n,i,s,o,a,l,c){const h=this.vertices.length;let u=this.parseVertexIndex(e,h),d=this.parseVertexIndex(t,h),f=this.parseVertexIndex(n,h);if(this.addVertex(u,d,f),this.addColor(u,d,f),a!==void 0&&a!==""){const g=this.normals.length;u=this.parseNormalIndex(a,g),d=this.parseNormalIndex(l,g),f=this.parseNormalIndex(c,g),this.addNormal(u,d,f)}else this.addFaceNormal(u,d,f);if(i!==void 0&&i!==""){const g=this.uvs.length;u=this.parseUVIndex(i,g),d=this.parseUVIndex(s,g),f=this.parseUVIndex(o,g),this.addUV(u,d,f),this.object.geometry.hasUVIndices=!0}else this.addDefaultUV()},addPointGeometry:function(e){this.object.geometry.type="Points";const t=this.vertices.length;for(let n=0,i=e.length;n<i;n++){const s=this.parseVertexIndex(e[n],t);this.addVertexPoint(s),this.addColor(s)}},addLineGeometry:function(e,t){this.object.geometry.type="Line";const n=this.vertices.length,i=this.uvs.length;for(let s=0,o=e.length;s<o;s++)this.addVertexLine(this.parseVertexIndex(e[s],n));for(let s=0,o=t.length;s<o;s++)this.addUVLine(this.parseUVIndex(t[s],i))}};return r.startObject("",!1),r}class Sb extends Zn{constructor(e){super(e),this.materials=null}load(e,t,n,i){const s=this,o=new no(this.manager);o.setPath(this.path),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(a){try{t(s.parse(a))}catch(l){i?i(l):console.error(l),s.manager.itemError(e)}},n,i)}setMaterials(e){return this.materials=e,this}parse(e){const t=new wb;e.indexOf(`\r
`)!==-1&&(e=e.replace(/\r\n/g,`
`)),e.indexOf(`\\
`)!==-1&&(e=e.replace(/\\\n/g,""));const n=e.split(`
`);let i=[];for(let a=0,l=n.length;a<l;a++){const c=n[a].trimStart();if(c.length===0)continue;const h=c.charAt(0);if(h!=="#")if(h==="v"){const u=c.split(ad);switch(u[0]){case"v":t.vertices.push(parseFloat(u[1]),parseFloat(u[2]),parseFloat(u[3])),u.length>=7?(ta.setRGB(parseFloat(u[4]),parseFloat(u[5]),parseFloat(u[6]),vt),t.colors.push(ta.r,ta.g,ta.b)):t.colors.push(void 0,void 0,void 0);break;case"vn":t.normals.push(parseFloat(u[1]),parseFloat(u[2]),parseFloat(u[3]));break;case"vt":t.uvs.push(parseFloat(u[1]),parseFloat(u[2]));break}}else if(h==="f"){const d=c.slice(1).trim().split(ad),f=[];for(let v=0,m=d.length;v<m;v++){const p=d[v];if(p.length>0){const w=p.split("/");f.push(w)}}const g=f[0];for(let v=1,m=f.length-1;v<m;v++){const p=f[v],w=f[v+1];t.addFace(g[0],p[0],w[0],g[1],p[1],w[1],g[2],p[2],w[2])}}else if(h==="l"){const u=c.substring(1).trim().split(" ");let d=[];const f=[];if(c.indexOf("/")===-1)d=u;else for(let g=0,v=u.length;g<v;g++){const m=u[g].split("/");m[0]!==""&&d.push(m[0]),m[1]!==""&&f.push(m[1])}t.addLineGeometry(d,f)}else if(h==="p"){const d=c.slice(1).trim().split(" ");t.addPointGeometry(d)}else if((i=xb.exec(c))!==null){const u=(" "+i[0].slice(1).trim()).slice(1);t.startObject(u)}else if(bb.test(c))t.object.startMaterial(c.substring(7).trim(),t.materialLibraries);else if(yb.test(c))t.materialLibraries.push(c.substring(7).trim());else if(Mb.test(c))console.warn('THREE.OBJLoader: Rendering identifier "usemap" not supported. Textures must be defined in MTL files.');else if(h==="s"){if(i=c.split(" "),i.length>1){const d=i[1].trim().toLowerCase();t.object.smooth=d!=="0"&&d!=="off"}else t.object.smooth=!0;const u=t.object.currentMaterial();u&&(u.smooth=t.object.smooth)}else{if(c==="\0")continue;console.warn('THREE.OBJLoader: Unexpected line: "'+c+'"')}}t.finalize();const s=new wt;if(s.materialLibraries=[].concat(t.materialLibraries),!(t.objects.length===1&&t.objects[0].geometry.vertices.length===0)===!0)for(let a=0,l=t.objects.length;a<l;a++){const c=t.objects[a],h=c.geometry,u=c.materials,d=h.type==="Line",f=h.type==="Points";let g=!1;if(h.vertices.length===0)continue;const v=new yt;v.setAttribute("position",new Ne(h.vertices,3)),h.normals.length>0&&v.setAttribute("normal",new Ne(h.normals,3)),h.colors.length>0&&(g=!0,v.setAttribute("color",new Ne(h.colors,3))),h.hasUVIndices===!0&&v.setAttribute("uv",new Ne(h.uvs,2));const m=[];for(let w=0,y=u.length;w<y;w++){const b=u[w],D=b.name+"_"+b.smooth+"_"+g;let R=t.materials[D];if(this.materials!==null){if(R=this.materials.create(b.name),d&&R&&!(R instanceof Yn)){const P=new Yn;ai.prototype.copy.call(P,R),P.color.copy(R.color),R=P}else if(f&&R&&!(R instanceof ps)){const P=new ps({size:10,sizeAttenuation:!1});ai.prototype.copy.call(P,R),P.color.copy(R.color),P.map=R.map,R=P}}R===void 0&&(d?R=new Yn:f?R=new ps({size:1,sizeAttenuation:!1}):R=new kn,R.name=b.name,R.flatShading=!b.smooth,R.vertexColors=g,t.materials[D]=R),m.push(R)}let p;if(m.length>1){for(let w=0,y=u.length;w<y;w++){const b=u[w];v.addGroup(b.groupStart,b.groupCount,w)}d?p=new vr(v,m):f?p=new Vr(v,m):p=new ve(v,m)}else d?p=new vr(v,m[0]):f?p=new Vr(v,m[0]):p=new ve(v,m[0]);p.name=c.name,s.add(p)}else if(t.vertices.length>0){const a=new ps({size:1,sizeAttenuation:!1}),l=new yt;l.setAttribute("position",new Ne(t.vertices,3)),t.colors.length>0&&t.colors[0]!==void 0&&(l.setAttribute("color",new Ne(t.colors,3)),a.vertexColors=!0);const c=new Vr(l,a);s.add(c)}return s}}class Eb extends Zn{constructor(e){super(e)}load(e,t,n,i){const s=this,o=new no(this.manager);o.setPath(this.path),o.setResponseType("arraybuffer"),o.setRequestHeader(this.requestHeader),o.setWithCredentials(this.withCredentials),o.load(e,function(a){try{t(s.parse(a))}catch(l){i?i(l):console.error(l),s.manager.itemError(e)}},n,i)}parse(e){function t(c){const h=new DataView(c),u=32/8*3+32/8*3*3+16/8,d=h.getUint32(80,!0);if(80+32/8+d*u===h.byteLength)return!0;const g=[115,111,108,105,100];for(let v=0;v<5;v++)if(n(g,h,v))return!1;return!0}function n(c,h,u){for(let d=0,f=c.length;d<f;d++)if(c[d]!==h.getUint8(u+d))return!1;return!0}function i(c){const h=new DataView(c),u=h.getUint32(80,!0);let d,f,g,v=!1,m,p,w,y,b;for(let T=0;T<70;T++)h.getUint32(T,!1)==1129270351&&h.getUint8(T+4)==82&&h.getUint8(T+5)==61&&(v=!0,m=new Float32Array(u*3*3),p=h.getUint8(T+6)/255,w=h.getUint8(T+7)/255,y=h.getUint8(T+8)/255,b=h.getUint8(T+9)/255);const D=84,R=12*4+2,P=new yt,M=new Float32Array(u*3*3),_=new Float32Array(u*3*3),x=new ke;for(let T=0;T<u;T++){const F=D+T*R,k=h.getFloat32(F,!0),G=h.getFloat32(F+4,!0),K=h.getFloat32(F+8,!0);if(v){const z=h.getUint16(F+48,!0);(z&32768)===0?(d=(z&31)/31,f=(z>>5&31)/31,g=(z>>10&31)/31):(d=p,f=w,g=y)}for(let z=1;z<=3;z++){const Z=F+z*12,V=T*3*3+(z-1)*3;M[V]=h.getFloat32(Z,!0),M[V+1]=h.getFloat32(Z+4,!0),M[V+2]=h.getFloat32(Z+8,!0),_[V]=k,_[V+1]=G,_[V+2]=K,v&&(x.setRGB(d,f,g,vt),m[V]=x.r,m[V+1]=x.g,m[V+2]=x.b)}}return P.setAttribute("position",new Rn(M,3)),P.setAttribute("normal",new Rn(_,3)),v&&(P.setAttribute("color",new Rn(m,3)),P.hasColors=!0,P.alpha=b),P}function s(c){const h=new yt,u=/solid([\s\S]*?)endsolid/g,d=/facet([\s\S]*?)endfacet/g,f=/solid\s(.+)/;let g=0;const v=/[\s]+([+-]?(?:\d*)(?:\.\d*)?(?:[eE][+-]?\d+)?)/.source,m=new RegExp("vertex"+v+v+v,"g"),p=new RegExp("normal"+v+v+v,"g"),w=[],y=[],b=[],D=new L;let R,P=0,M=0,_=0;for(;(R=u.exec(c))!==null;){M=_;const x=R[0],T=(R=f.exec(x))!==null?R[1]:"";for(b.push(T);(R=d.exec(x))!==null;){let G=0,K=0;const z=R[0];for(;(R=p.exec(z))!==null;)D.x=parseFloat(R[1]),D.y=parseFloat(R[2]),D.z=parseFloat(R[3]),K++;for(;(R=m.exec(z))!==null;)w.push(parseFloat(R[1]),parseFloat(R[2]),parseFloat(R[3])),y.push(D.x,D.y,D.z),G++,_++;K!==1&&console.error("THREE.STLLoader: Something isn't right with the normal of face number "+g),G!==3&&console.error("THREE.STLLoader: Something isn't right with the vertices of face number "+g),g++}const F=M,k=_-M;h.userData.groupNames=b,h.addGroup(F,k,P),P++}return h.setAttribute("position",new Ne(w,3)),h.setAttribute("normal",new Ne(y,3)),h}function o(c){return typeof c!="string"?new TextDecoder().decode(c):c}function a(c){if(typeof c=="string"){const h=new Uint8Array(c.length);for(let u=0;u<c.length;u++)h[u]=c.charCodeAt(u)&255;return h.buffer||h}else return c}const l=a(e);return t(l)?i(l):s(o(e))}}class Oa extends Mt{constructor(e=document.createElement("div")){super(),this.isCSS2DObject=!0,this.element=e,this.element.style.position="absolute",this.element.style.userSelect="none",this.element.setAttribute("draggable",!1),this.center=new ye(.5,.5),this.addEventListener("removed",function(){this.traverse(function(t){t.element instanceof t.element.ownerDocument.defaultView.Element&&t.element.parentNode!==null&&t.element.remove()})})}copy(e,t){return super.copy(e,t),this.element=e.element.cloneNode(!0),this.center=e.center,this}}const Ks=new L,ud=new Ee,dd=new Ee,fd=new L,pd=new L;class Tb{constructor(e={}){const t=this;let n,i,s,o;const a={objects:new WeakMap},l=e.element!==void 0?e.element:document.createElement("div");l.style.overflow="hidden",this.domElement=l,this.getSize=function(){return{width:n,height:i}},this.render=function(g,v){g.matrixWorldAutoUpdate===!0&&g.updateMatrixWorld(),v.parent===null&&v.matrixWorldAutoUpdate===!0&&v.updateMatrixWorld(),ud.copy(v.matrixWorldInverse),dd.multiplyMatrices(v.projectionMatrix,ud),h(g,g,v),f(g)},this.setSize=function(g,v){n=g,i=v,s=n/2,o=i/2,l.style.width=g+"px",l.style.height=v+"px"};function c(g){g.isCSS2DObject&&(g.element.style.display="none");for(let v=0,m=g.children.length;v<m;v++)c(g.children[v])}function h(g,v,m){if(g.visible===!1){c(g);return}if(g.isCSS2DObject){Ks.setFromMatrixPosition(g.matrixWorld),Ks.applyMatrix4(dd);const p=Ks.z>=-1&&Ks.z<=1&&g.layers.test(m.layers)===!0,w=g.element;w.style.display=p===!0?"":"none",p===!0&&(g.onBeforeRender(t,v,m),w.style.transform="translate("+-100*g.center.x+"%,"+-100*g.center.y+"%)translate("+(Ks.x*s+s)+"px,"+(-Ks.y*o+o)+"px)",w.parentNode!==l&&l.appendChild(w),g.onAfterRender(t,v,m));const y={distanceToCameraSquared:u(m,g)};a.objects.set(g,y)}for(let p=0,w=g.children.length;p<w;p++)h(g.children[p],v,m)}function u(g,v){return fd.setFromMatrixPosition(g.matrixWorld),pd.setFromMatrixPosition(v.matrixWorld),fd.distanceToSquared(pd)}function d(g){const v=[];return g.traverseVisible(function(m){m.isCSS2DObject&&v.push(m)}),v}function f(g){const v=d(g).sort(function(p,w){if(p.renderOrder!==w.renderOrder)return w.renderOrder-p.renderOrder;const y=a.objects.get(p).distanceToCameraSquared,b=a.objects.get(w).distanceToCameraSquared;return y-b}),m=v.length;for(let p=0,w=v.length;p<w;p++)v[p].element.style.zIndex=m-p}}}class Ab{editor;enabled;radius;selectedPoints=new Set;constructor(e){this.editor=e}deregisterEventListeners(){const e=this.editor.eventHandler.eventBus;e.off("eraser:toggled",this.handleEraserToggled),e.off("eraser:sizeChanged",this.handleSizeChanged),e.off("eraser:intersectionDetected",this.handleIntersectionDetected),e.off("eraser:intersectionsDetected",this.handleIntersectionDetected),e.off("eraser:unselectPoints",this.handleUnselectPoints),e.off("eraser:deletePoints",this.handleDeletePoints)}dispose(){this.deregisterEventListeners()}erasePoints(e){const t=e.point,n=this.editor.cloudPoints,i=e.distance,s=this.getScreenDiagonal(13.5),o=this.radius*i/s,a=n.geometry.attributes.position.array,l=a.length/3,c=[];for(let u=0;u<l;u++){const d=a[u*3],f=a[u*3+1],g=a[u*3+2];Math.sqrt((d-t.x)**2+(f-t.y)**2+(g-t.z)**2)>o&&c.push([d.toString(),f.toString(),g.toString(),this.editor.cloudPointsData?this.editor.cloudPointsData[u][3]:"0"])}this.editor.cloudPointsData=c;const h=c.flatMap(u=>u.slice(0,3).map(parseFloat));n.geometry.setAttribute("position",new Ne(h,3)),n.geometry.attributes.position.needsUpdate=!0}registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("eraser:toggled",this.handleEraserToggled),e.on("eraser:sizeChanged",this.handleSizeChanged),e.on("eraser:intersectionDetected",this.handleIntersectionDetected),e.on("eraser:intersectionsDetected",this.handleEraserIntersectionsDetected),e.on("eraser:unselectPoints",this.handleUnselectPoints),e.on("eraser:deletePoints",this.handleDeletePoints)}selectPoints(e,t=16753920){for(const n of e)typeof n.index=="number"&&!this.selectedPoints.has(n.index)&&this.selectedPoints.add(n.index);this.selectedPoints.size&&this.highlightPoints(t)}unselectPoints(e=3800852){this.selectedPoints.size&&(this.highlightPoints(e),this.selectedPoints.clear())}deletePoints(){if(!this.selectedPoints.size)return;const t=this.editor.cloudPoints.geometry.getAttribute("position"),n=[];for(let i=0;i<t.count;i++){if(this.selectedPoints.has(i))continue;const s=t.getX(i),o=t.getY(i),a=t.getZ(i),l=this.editor.cloudPointsData[i][3];n.push([s.toString(),o.toString(),a.toString(),l.toString()])}this.editor.pointsManager.updateCloud(n),this.selectedPoints.clear()}getScreenDiagonal(e=1){const t=window.innerWidth,n=window.innerHeight;return Math.sqrt(t**2+n**2)/e}handleEraserToggled=e=>{this.enabled=e,e||this.unselectPoints()};handleIntersectionDetected=e=>{this.erasePoints(e)};handleEraserIntersectionsDetected=e=>{this.selectPoints(e)};handleUnselectPoints=()=>{this.unselectPoints()};handleDeletePoints=()=>{this.deletePoints()};handleSizeChanged=e=>{this.radius=e};highlightPoints=e=>{const n=this.editor.cloudPoints.geometry.getAttribute("color"),[i,s,o]=this.toRGBArray(e);for(const a of this.selectedPoints)n.setXYZ(a,i,s,o);n.needsUpdate=!0};toRGBArray(e){const t=new ke(e);return[t.r,t.g,t.b]}ensureVertexColors(e,t=16777215){const i=e.getAttribute("position").count;let s=e.getAttribute("color");if(!s||s.count!==i){const[o,a,l]=this.toRGBArray(t),c=new Float32Array(i*3);for(let u=0;u<i;u++)c[u*3]=o,c[u*3+1]=a,c[u*3+2]=l;s=new Ne(c,3),e.setAttribute("color",s);const h=this.editor.cloudPointsMaterial;h.vertexColors||(h.vertexColors=!0,h.needsUpdate=!0)}}}function Rb(r){return{all:r=r||new Map,on:function(e,t){var n=r.get(e);n?n.push(t):r.set(e,[t])},off:function(e,t){var n=r.get(e);n&&(t?n.splice(n.indexOf(t)>>>0,1):r.set(e,[]))},emit:function(e,t){var n=r.get(e);n&&n.slice().map(function(i){i(t)}),(n=r.get("*"))&&n.slice().map(function(i){i(e,t)})}}}class Cb{editor;eventBus;constructor(e){this.editor=e,this.eventBus=Rb()}registerEventListeners(){this.eventBus.on("objectRemoved",this.handleObjectRemoved),this.eventBus.on("cloudLoaded",this.handleCloudLoaded),this.eventBus.on("topoLoaded",this.handleTopoLoaded),this.eventBus.on("quickAddNode",this.handleQuickAnnotation)}registerCanvasEventListeners(){const e=this.getCanvas();e&&e.addEventListener("mousedown",this.handleCanvasMouseDown)}deregisterEventListeners(){this.eventBus.off("objectRemoved",this.handleObjectRemoved),this.eventBus.off("cloudLoaded",this.handleCloudLoaded),this.eventBus.off("topoLoaded",this.handleTopoLoaded),this.eventBus.off("quickAddNode",this.handleQuickAnnotation)}deregisterCanvasEventListeners(){const e=this.getCanvas();e&&e.removeEventListener("mousedown",this.handleCanvasMouseDown)}dispose(){this.deregisterEventListeners(),this.deregisterCanvasEventListeners()}handleTopoLoaded=e=>{this.editor.clear({clearCloud:!1,clearTopo:!0}),this.editor.drawTopo(e.topoData)};handleCloudLoaded=e=>{this.editor.clear({clearCloud:!0,clearTopo:!1}),this.editor.pointsManager.updateCloud(e)};handleObjectRemoved=e=>{e.object.clear(),this.editor.nodeManager.removeAllArrowsRelatedTo(e.object);const t=this.editor.selectableObjects.indexOf(e.object);t>-1&&this.editor.selectableObjects.splice(t,1)};handleQuickAnnotation=()=>{const e=this.editor.robotManager.mainRobot,t={x:e.position.x,y:e.position.y,z:e.position.z,rz:e.rotation.z};this.editor.nodeManager.addNode("GOAL",t)};handleCanvasMouseDown=()=>{const e=this.getCanvas();e&&e.focus()};getCanvas(){return document.querySelector("#three-canvas")}}const ms={GOAL:"GOAL",ROUTE:"ROUTE",INIT:"INIT"};class Pb{editor;goalMesh;routeMesh;initMesh;constructor(e){this.editor=e}addLabel(e){const t=window.innerWidth<=768,n=document.createElement("div");n.className="nodeLabel italic text-base p-1 font-semibold rounded-sm",n.textContent=e.name,n.style.cssText=`
      background: #1e2337;
      color: #c0caf5;
      border-left: ${t?4:11}px solid #fa8c16;
    `;const i=new Oa(n);i.visible=!0,i.userData.keep=!0,i.userData.labelType="node",i.name="label",i.center.set(0,-.5),e.add(i);const s={obj:i,bucket:null,worldPosition:null};this.editor.eventHandler.eventBus.emit("labelAdded",s)}addNode(e,t,n=null){let i=this.goalMesh;if(!i)return;e===ms.ROUTE?i=this.routeMesh:e===ms.INIT&&(i=this.initMesh);const s=i.clone();s.material=i.material.clone(),s.position.set(t.x,t.y,0),s.rotation.z=t.rz;const o=e===ms.GOAL?"G":e===ms.ROUTE?"R":"I";return s.name=`${o}_${s.id}`,s.userData.id=`N_${s.id}`,s.userData.type=e,s.userData.links=[],s.userData.links_from=[],s.userData.slamLinks=[],s.userData.slamLinks_from=[],s.userData.info="",n&&(s.rotation.z=n.rz*(Math.PI/180),s.name=n.name,s.userData.id=n.id,s.userData.info=n.info),this.addLabel(s),this.editor.zUpGroup.add(s),this.editor.selectableObjects.push(s),this.editor.eventHandler.eventBus.emit("nodeAdded",s),s}alignNodesByAxis(e,t){if(!this.editor.selectedObjects.length)return;const n=t==="min",i=n?Math.min:Math.max,s=n?1/0:-1/0,o=this.editor.selectedObjects.reduce((a,l)=>i(a,l.position[e]),s);for(let a=0,l=this.editor.selectedObjects.length;a<l;a++){const c=this.editor.selectedObjects[a];c.position[e]=o}this.updateLinks(),this.editor.eventHandler.eventBus.emit("objectTransformChanged")}alignNodesWithSpacing(e,t){if(!this.editor.selectedObjects.length)return;const n=this.editor.selectedObjects.map(o=>o.position[e]),i=e==="x"?Math.min(...n):Math.max(...n),s=e==="x"?1:-1;for(let o=0,a=this.editor.selectedObjects.length;o<a;o++){const l=this.editor.selectedObjects[o];l.position[e]=i+s*t*o}this.updateLinks(),this.editor.eventHandler.eventBus.emit("objectTransformChanged")}alignNodesTheta(){if(!this.editor.selectedObjects.length)return;let e=0,t=0;for(let i=0,s=this.editor.selectedObjects.length;i<s;i++){const a=this.editor.selectedObjects[i].rotation.z;e+=Math.sin(a),t+=Math.cos(a)}const n=Math.atan2(e,t);for(let i=0,s=this.editor.selectedObjects.length;i<s;i++){const o=this.editor.selectedObjects[i];o.rotation.z=n}}async cacheMeshes(){this.goalMesh=this.createBoxMesh(.68,.51,.19975,.75,new ke(16753920),new ke(4251856),{widthSegments:5}),this.routeMesh=this.createBoxMesh(.33,.33,.19975,.75,new ke(6591981),new ke(4251856),{widthSegments:5}),this.initMesh=this.createBoxMesh(.68,.51,.19975,.75,new ke(6381921),new ke(16777215),{widthSegments:5})}drawArrow(e,t,n=14540253){const i=e.position,s=t.position,o=new L().subVectors(s,i).normalize(),a=i.distanceTo(s),l=.55,c=new uf(o,i,a-l,n);c.setLength(a-l,.2,.12),c.userData={from:e.id,to:t.id},this.editor.zUpGroup.add(c)}linkNodes(e,t){if(e.userData.links.includes(t.uuid))return;this.drawArrow(e,t);const n=[...e.userData.links];n.includes(t.uuid)||(n.push(t.uuid),e.userData.links=n);const i=[...t.userData.links_from];i.includes(e.uuid)||(i.push(e.uuid),t.userData.links_from=i);const s=[...e.userData.slamLinks];s.includes(t.userData.id)||(s.push(t.userData.id),e.userData.slamLinks=s);const o=[...t.userData.slamLinks_from];o.includes(e.userData.id)||(o.push(e.userData.id),t.userData.slamLinks_from=o)}updateLinks=()=>{const e=this.editor.selectedObjects;for(let t=0,n=e.length;t<n;t++){const i=e[t];this.removeAllArrowsRelatedTo(i);const s=i.userData.links,o=i.userData.links_from;for(let a=0;a<s.length;a++){const l=this.editor.zUpGroup.getObjectByProperty("uuid",s[a]);l&&this.drawArrow(i,l)}for(let a=0;a<o.length;a++){const l=this.editor.zUpGroup.getObjectByProperty("uuid",o[a]);l&&this.drawArrow(l,i)}}};updateNodeName(e){const t=this.editor.selected;t!==null&&(this.removeLabel(t),t.name=e,this.addLabel(t),this.editor.eventHandler.eventBus.emit("objectNameChanged",t.name))}removeAllArrowsRelatedTo=e=>{const t=[],n=this.editor.zUpGroup.children;for(let i=0,s=n.length;i<s;i++){const o=n[i];if(o.type!=="ArrowHelper")continue;const{from:a,to:l}=o.userData;(a===e.id||l===e.id)&&t.push(o)}for(let i=0;i<t.length;i++)this.editor.zUpGroup.remove(t[i])};removeAllLinksRelatedTo(e){e.userData.links_from.map(n=>this.editor.zUpGroup.getObjectByProperty("uuid",n)).filter(n=>n!=null).forEach(n=>{const i=n.userData.links.indexOf(e.uuid);i!==-1&&n.userData.links.splice(i,1);const s=n.userData.links_from.indexOf(e.uuid);s!==-1&&n.userData.links_from.splice(s,1);const o=n.userData.slamLinks.indexOf(e.userData.id);o!==-1&&n.userData.slamLinks.splice(o,1);const a=n.userData.slamLinks_from.indexOf(e.userData.id);a!==-1&&n.userData.slamLinks_from.splice(a,1)}),e.userData.links=[],e.userData.links_from=[],e.userData.slamLinks=[],e.userData.slamLinks_from=[]}removeLabel(e){e.traverse(t=>{t.name==="label"&&e.remove(t)})}transformNodes(e,t){if(!this.editor.selectedObjects.length)return;for(let s=0,o=this.editor.selectedObjects.length;s<o;s++){const a=this.editor.selectedObjects[s];switch(e){case"x":a.position.x+=t;break;case"y":a.position.y+=t;break;case"rz":{const l=t*Math.PI/180;a.rotation.z+=l;break}}}const n=this.editor.selectedObjects[this.editor.selectedObjects.length-1],i=Pt.radToDeg(n.rotation.z);this.editor.eventHandler.eventBus.emit("objectTransformChanged",{x:n.position.x.toString().slice(0,6),y:n.position.y.toString().slice(0,6),rz:i.toString().slice(0,6)})}transformNodesByInput(e,t){if(this.editor.selectedObjects.length===0)return;const n=Number(t);if(Number.isNaN(n))return;let i=0;e==="rz"&&(i=n*Math.PI/180);for(let a=0,l=this.editor.selectedObjects.length;a<l;a++){const c=this.editor.selectedObjects[a];switch(e){case"x":c.position.x=n;break;case"y":c.position.y=n;break;case"rz":c.rotation.z=i;break}}const s=this.editor.selectedObjects[this.editor.selectedObjects.length-1],o=Pt.radToDeg(s.rotation.z);this.editor.eventHandler.eventBus.emit("objectTransformChanged",{x:s.position.x.toString().slice(0,6),y:s.position.y.toString().slice(0,6),rz:o.toString().slice(0,6)})}createBoxMesh(e,t,n,i,s,o,a={}){const l=new Zt(e,t,n,a.widthSegments??1,a.heightSegments??1,a.depthSegments??1),c=[],h=-e/2,u=e/2,d=h+(u-h)*i;for(let g=0;g<l.attributes.position.count;g++){const v=new L;v.fromBufferAttribute(l.attributes.position,g);const m=v.x<=d?s:o;c.push(m.r,m.g,m.b)}l.setAttribute("color",new Ne(c,3));const f=new zn({vertexColors:!0,transparent:!0});return new ve(l,f)}}const Lb=.07,Db=.2,Ib=.3,Nb=3;class Ub{editor;globalPath;globalPathMap;localPath;constructor(e){this.editor=e,this.globalPathMap=new Map;const t=new Bc,n=new Ta({color:16711680,linewidth:Lb,vertexColors:!1,worldUnits:!0,dashed:!1});this.globalPath=new id(t,n),this.globalPath.visible=!1;const i=new Bc,s=new Ta({color:34812,linewidth:Db,vertexColors:!1,worldUnits:!0,dashed:!0,dashSize:Ib,dashScale:Nb});this.localPath=new id(i,s),this.localPath.visible=!1}dispose(){this.editor.eventHandler.eventBus.off("topoCleared",this.handleTopoCleared)}registerEventBusHandler(){this.editor.eventHandler.eventBus.on("topoCleared",this.handleTopoCleared)}updateLocalPath(e){if(e.length){const t=this.convertDataToPositions(e);this.localPath.geometry.setPositions(t),this.localPath.computeLineDistances(),this.localPath.visible=!0}else this.localPath.visible=!1}convertDataToPositions(e){return e.flatMap(t=>t.map(n=>{const i=Number(n);return isNaN(i)&&console.warn(`Invalid number conversion for value: ${n}`),i}))}handleTopoCleared=()=>{this.globalPathMap.clear()}}class lh{boundary;capacity;points;divided;children;constructor(e,t=20){this.boundary=e,this.capacity=t,this.points=[],this.divided=!1,this.children=[]}dispose(){if(this.divided)for(const e of this.children)e.dispose();this.points=[],this.children=[],this.boundary=null,this.divided=!1}insert(e,t){if(!this.boundary.containsPoint(e))return!1;if(this.points.length<this.capacity)return this.points.push({position:e.clone(),index:t}),!0;this.divided||this.subdivide();for(const n of this.children)if(n.insert(e,t))return!0;return!1}subdivide(){const{min:e,max:t}=this.boundary,n=new L().addVectors(e,t).multiplyScalar(.5);for(let i=0;i<2;i++)for(let s=0;s<2;s++)for(let o=0;o<2;o++){const a=new L(i===0?e.x:n.x,s===0?e.y:n.y,o===0?e.z:n.z),l=new L(i===0?n.x:t.x,s===0?n.y:t.y,o===0?n.z:t.z),c=new Cn(a,l);this.children.push(new lh(c,this.capacity))}for(const{position:i,index:s}of this.points)for(const o of this.children)if(o.insert(i,s))break;this.points=[],this.divided=!0}}class ch{boundary;capacity;points;divided;children;constructor(e,t=8){this.boundary=e.clone(),this.capacity=t,this.points=[],this.divided=!1,this.children=[]}insert(e,t){if(!this.boundary.containsPoint(new ye(e.x,e.y)))return!1;if(!this.divided&&this.points.length<this.capacity)return this.points.push({position:e.clone(),index:t}),!0;this.divided||this.subdivide();for(const n of this.children)if(n.insert(e,t))return!0;return!1}subdivide(){const{min:e,max:t}=this.boundary,n=new ye((e.x+t.x)/2,(e.y+t.y)/2),i=[new ir(new ye(e.x,e.y),new ye(n.x,n.y)),new ir(new ye(n.x,e.y),new ye(t.x,n.y)),new ir(new ye(e.x,n.y),new ye(n.x,t.y)),new ir(new ye(n.x,n.y),new ye(t.x,t.y))];this.children=i.map(s=>new ch(s,this.capacity));for(const{position:s,index:o}of this.points)for(const a of this.children)if(a.insert(s,o))break;this.points=[],this.divided=!0}queryRange(e,t=[]){if(!this.boundary.intersectsBox(e))return t;if(this.divided)for(const n of this.children)n.queryRange(e,t);else for(const n of this.points)e.containsPoint(new ye(n.position.x,n.position.y))&&t.push(n);return t}clear(){this.points=[];for(const e of this.children)e.clear();this.children=[],this.divided=!1}}const ui=[{r:44/255,g:123/255,b:182/255},{r:171/255,g:217/255,b:233/255},{r:1,g:1,b:191/255},{r:253/255,g:174/255,b:97/255},{r:215/255,g:25/255,b:28/255}],Fb=1024*3;class Ob{editor;pointsOctree;pointsQuadTree;lidarPositionAttr;lastLidarSphereUpdateTime=0;sphereUpdateInterval=1e3;constructor(e){this.editor=e,this.pointsOctree=null,this.pointsQuadTree=null;const t=Fb;this.lidarPositionAttr=new Ne(new Float32Array(t),3)}registerEventListeners(){this.editor.eventHandler.eventBus.on("lidarUpdated",this.handleLidarUpdated)}deregisterEventListeners(){this.editor.eventHandler.eventBus.off("lidarUpdated",this.handleLidarUpdated)}changeCloudOpacity(e){this.editor.cloudPointsMaterial.opacity=e*.01}clearCloud(){this.editor.cloudPointsGeometry.deleteAttribute("position"),this.editor.cloudPointsGeometry.setAttribute("position",new Ne([],3)),this.editor.cloudPointsGeometry.boundingSphere=null,this.editor.cloudPointsGeometry.attributes.position.needsUpdate=!0,this.editor.cloudPointsData=[],this.editor.eventHandler.eventBus.emit("cloudCleared")}dispose(){this.pointsOctree&&(this.pointsOctree.dispose(),this.pointsOctree=null),this.editor.cloudPointsGeometry.dispose(),this.editor.cloudPointsMaterial.dispose(),this.editor.cloudPointsData=null,this.editor.lidarPointsGeometry.dispose(),this.editor.lidarPointsMaterial.dispose(),this.deregisterEventListeners()}updateCloud(e){if(!this.editor.cloudPointsGeometry)return;const{positions:t,numPoints:n}=this.updatePositions(e),{boundaries:i}=this.calculateBoundaries(t,n);this.updateColors(i),this.finalizeUpdate(),this.createCloudQuadTree(),this.editor.cloudPointsData=e}flattenCloud(){if(!this.editor.cloudPointsGeometry)return;const e=this.editor.cloudPointsGeometry.getAttribute("position");if(!e||!e.array.length){console.warn("[Flatten Cloud] No position attribute found in geometry.");return}for(let t=0;t<e.count;t++)e.setZ(t,0);this.finalizeUpdate()}restoreCloudDepth(){if(!this.editor.cloudPointsGeometry)return;if(!this.editor.cloudPointsData){console.warn("Original cloud data is missing.");return}const e=this.editor.cloudPointsGeometry.getAttribute("position");if(!e||!e.array.length){console.warn("[Restore Cloud] Position attribute not found in geometry.");return}for(let t=0;t<this.editor.cloudPointsData.length;t++){const n=this.editor.cloudPointsData[t],i=parseFloat(n[2]);e.setZ(t,i)}this.finalizeUpdate()}calculateBoundaries(e,t){let n=1/0,i=-1/0;for(let a=0;a<t;a++){const l=e[a*3+2];l<n&&(n=l),l>i&&(i=l)}if(n===i)return{minZ:n,maxZ:i,boundaries:null};const s=i-n,o=[n,n+s*.2,n+s*.4,n+s*.6,n+s*.8,i];return{minZ:n,maxZ:i,boundaries:o}}createCloudOctree(){const e=this.editor.cloudPointsGeometry.getAttribute("position"),t=new Cn().setFromBufferAttribute(e);t.expandByScalar(1);const n=new lh(t,20);for(let i=0;i<e.count;i++){const s=new L().fromBufferAttribute(e,i);n.insert(s,i)}this.pointsOctree=n}createCloudQuadTree(){const e=this.editor.cloudPointsGeometry.getAttribute("position"),t=new Cn().setFromBufferAttribute(e),n=new ir(new ye(t.min.x,t.min.y),new ye(t.max.x,t.max.y));n.expandByScalar(1);const i=new ch(n,20);for(let s=0;s<e.count;s++){const o=new L().fromBufferAttribute(e,s);i.insert(o,s)}this.pointsQuadTree=i}ensureCapacity(e){const t=this.lidarPositionAttr.array;if(e>t.length){const n=Math.max(e,t.length*2),i=new Float32Array(n);i.set(t),this.lidarPositionAttr.array=i,this.editor.lidarPointsGeometry.setAttribute("position",this.lidarPositionAttr)}}finalizeUpdate(){this.editor.cloudPointsGeometry.attributes.position.needsUpdate=!0,this.editor.cloudPointsGeometry.computeBoundingSphere()}handleLidarUpdated=e=>{const t=this.transformLidarPointsToWorld(e.lidarPoints,e.pose);this.ensureCapacity(t.length),this.lidarPositionAttr.array.set(t),this.editor.lidarPointsGeometry.setAttribute("position",this.lidarPositionAttr);const n=t.length/3;this.editor.lidarPointsGeometry.setDrawRange(0,n),this.editor.lidarPointsGeometry.attributes.position.needsUpdate=!0,this.shouldUpdateSphere()&&this.editor.lidarPointsGeometry.computeBoundingSphere()};shouldUpdateSphere(){const e=performance.now();return e-this.lastLidarSphereUpdateTime>this.sphereUpdateInterval?(this.lastLidarSphereUpdateTime=e,!0):!1}updateColors(e){const t=this.editor.cloudPointsGeometry,n=t.getAttribute("position"),i=n.count,s=n.array;let o=t.getAttribute("color");if((!o||o.count!==i)&&(o=new Ne(new Float32Array(i*3),3),t.setAttribute("color",o)),!e){const a=.2235294117647059,l=255/255,c=20/255;for(let h=0;h<i;h++)o.setXYZ(h,a,l,c);o.needsUpdate=!0;return}for(let a=0;a<i;a++){const l=s[a*3+2];let c,h,u,d;l<e[1]?(c=ui[0],h=ui[1],u=e[0],d=e[1]):l<e[2]?(c=ui[1],h=ui[2],u=e[1],d=e[2]):l<e[3]?(c=ui[2],h=ui[3],u=e[2],d=e[3]):l<e[4]?(c=ui[3],h=ui[4],u=e[3],d=e[4]):(c=ui[4],h=ui[4],u=e[4],d=e[5]);const f=d-u||1;let g=(l-u)/f;g=Math.max(0,Math.min(1,g));const v=c.r*(1-g)+h.r*g,m=c.g*(1-g)+h.g*g,p=c.b*(1-g)+h.b*g;o.setXYZ(a,v,m,p)}o.needsUpdate=!0}transformLidarPointToWorld=(e,t)=>{const n=e[0],i=e[1],s=n*Math.cos(t.rz)-i*Math.sin(t.rz),o=n*Math.sin(t.rz)+i*Math.cos(t.rz),a=t.x+s,l=t.y+o;return[a,l,e[2]]};transformLidarPointsToWorld(e,t){return e.map(n=>{const[i,s,o]=n.slice(0,3).map(a=>parseFloat(a));return[i,s,o]}).map(n=>this.transformLidarPointToWorld(n,t)).flat()}updatePositions(e){const t=[];e.forEach(([i,s,o])=>{t.push(+i,+s,+o)});const n=new Ne(t,3);return this.editor.cloudPointsGeometry.setAttribute("position",n),{positions:t,numPoints:t.length/3}}}const Lf=r=>{const{protocol:e,hostname:t}=window.location;return`${e}//${t}:5177${r}`},Ba=r=>Lf(`/models${r}`),Bb=r=>Lf(`/data/joint${r}`);class Df{constructor(e=120){this.cap=e}buf=[];push(e){this.buf.push(e),this.buf.length>this.cap&&this.buf.shift()}bracket(e){let t,n;for(let i=this.buf.length-1;i>=0;--i)if(this.buf[i].t<=e){t=this.buf[i],n=this.buf[i+1];break}return[t,n]}sampleTransform(e){const[t,n]=this.bracket(e),i=t,s=n;if(!i)return null;if(!s)return{...i,t:e};const o=(e-t.t)/(n.t-t.t||1e-6);return{t:e,x:this.lerpNum(i.x,s.x,o),y:this.lerpNum(i.y,s.y,o),rz:this.lerpNum(i.rz,s.rz,o)}}sampleJoint(e){const[t,n]=this.bracket(e),i=t,s=n;if(!i)return null;if(!s)return{...i,t:e};const o=(e-i.t)/(s.t-i.t||1e-6);return{t:e,map:this.lerpMap(i.map,s.map,o)}}lerpNum(e,t,n){return e+(t-e)*n}lerpMap(e,t,n){const i={};for(const s in t){const o=e?e[s]??t[s]:t[s];i[s]=this.lerpNum(o,t[s],n)}return i}}class If extends wt{transformBuf=new Df;jointBuf;constructor(){super()}pushPointsSnapShot(e){this.transformBuf.push(e)}pushJointsSnapshot(e,t=performance.now()/1e3){this.jointBuf&&this.jointBuf.push({t,map:e})}tick(e){const t=this.transformBuf.sampleTransform(e);if(t&&(this.position.set(t.x,t.y,0),this.rotation.z=Pt.degToRad(t.rz)),this.jointBuf){const n=this.jointBuf.sampleJoint(e);n&&this.applyJointValues?.(n.map)}}}class hh extends If{static async create(){const e=new hh;return await e._initAsync(),e}constructor(){super(),this.name="RB-S100",this.userData.keep=!0}async _initAsync(){const e=new Af,t=Ba("/s100low.fbx");try{const n=await e.loadAsync(t);n.traverse(i=>{if(i.userData.keep=!0,i instanceof ve){const s=i.material;Array.isArray(s)?i.material=s.map(o=>new Kr({color:o.color})):i.material=new Kr({color:s.color})}}),n.scale.setScalar(.1),n.rotation.set(Math.PI/2,0,0),n.updateMatrixWorld(!0),this.add(n)}catch(n){n instanceof Error?console.error("RB-S100 Load Failed:",n.message):console.error("RB-S100 Load Failed:",n)}}update(e){this.position.set(Number(e.x),Number(e.y),0),this.rotation.z=Pt.degToRad(Number(e.rz))}applyPose(e){const t={t:performance.now()*.001,x:Number(e.x),y:Number(e.y),rz:Number(e.rz)};this.pushPointsSnapShot(t)}}const md=new L,kb=new Bt,na=new Ee,qi=new Ee,ia=new St,sa=new L(1,1,1),ra=new L;class ka extends Mt{constructor(...e){super(...e),this.urdfNode=null,this.urdfName=""}copy(e,t){return super.copy(e,t),this.urdfNode=e.urdfNode,this.urdfName=e.urdfName,this}}class zb extends ka{constructor(...e){super(...e),this.isURDFCollider=!0,this.type="URDFCollider"}}class Hb extends ka{constructor(...e){super(...e),this.isURDFVisual=!0,this.type="URDFVisual"}}class Nf extends ka{constructor(...e){super(...e),this.isURDFLink=!0,this.type="URDFLink"}}class Uf extends ka{get jointType(){return this._jointType}set jointType(e){if(this.jointType!==e)switch(this._jointType=e,this.matrixWorldNeedsUpdate=!0,e){case"fixed":this.jointValue=[];break;case"continuous":case"revolute":case"prismatic":this.jointValue=new Array(1).fill(0);break;case"planar":this.jointValue=new Array(3).fill(0),this.axis=new L(0,0,1);break;case"floating":this.jointValue=new Array(6).fill(0);break}}get angle(){return this.jointValue[0]}constructor(...e){super(...e),this.isURDFJoint=!0,this.type="URDFJoint",this.jointValue=null,this.jointType="fixed",this.axis=new L(1,0,0),this.limit={lower:0,upper:0},this.ignoreLimits=!1,this.origPosition=null,this.origQuaternion=null,this.mimicJoints=[]}copy(e,t){return super.copy(e,t),this.jointType=e.jointType,this.axis=e.axis.clone(),this.limit.lower=e.limit.lower,this.limit.upper=e.limit.upper,this.ignoreLimits=!1,this.jointValue=[...e.jointValue],this.origPosition=e.origPosition?e.origPosition.clone():null,this.origQuaternion=e.origQuaternion?e.origQuaternion.clone():null,this.mimicJoints=[...e.mimicJoints],this}setJointValue(...e){e=e.map(n=>n===null?null:parseFloat(n)),(!this.origPosition||!this.origQuaternion)&&(this.origPosition=this.position.clone(),this.origQuaternion=this.quaternion.clone());let t=!1;switch(this.mimicJoints.forEach(n=>{t=n.updateFromMimickedJoint(...e)||t}),this.jointType){case"fixed":return t;case"continuous":case"revolute":{let n=e[0];return n==null||n===this.jointValue[0]?t:(!this.ignoreLimits&&this.jointType==="revolute"&&(n=Math.min(this.limit.upper,n),n=Math.max(this.limit.lower,n)),this.quaternion.setFromAxisAngle(this.axis,n).premultiply(this.origQuaternion),this.jointValue[0]!==n?(this.jointValue[0]=n,this.matrixWorldNeedsUpdate=!0,!0):t)}case"prismatic":{let n=e[0];return n==null||n===this.jointValue[0]?t:(this.ignoreLimits||(n=Math.min(this.limit.upper,n),n=Math.max(this.limit.lower,n)),this.position.copy(this.origPosition),md.copy(this.axis).applyEuler(this.rotation),this.position.addScaledVector(md,n),this.jointValue[0]!==n?(this.jointValue[0]=n,this.matrixWorldNeedsUpdate=!0,!0):t)}case"floating":return this.jointValue.every((n,i)=>e[i]===n||e[i]===null)?t:(this.jointValue[0]=e[0]!==null?e[0]:this.jointValue[0],this.jointValue[1]=e[1]!==null?e[1]:this.jointValue[1],this.jointValue[2]=e[2]!==null?e[2]:this.jointValue[2],this.jointValue[3]=e[3]!==null?e[3]:this.jointValue[3],this.jointValue[4]=e[4]!==null?e[4]:this.jointValue[4],this.jointValue[5]=e[5]!==null?e[5]:this.jointValue[5],qi.compose(this.origPosition,this.origQuaternion,sa),ia.setFromEuler(kb.set(this.jointValue[3],this.jointValue[4],this.jointValue[5],"XYZ")),ra.set(this.jointValue[0],this.jointValue[1],this.jointValue[2]),na.compose(ra,ia,sa),qi.premultiply(na),this.position.setFromMatrixPosition(qi),this.rotation.setFromRotationMatrix(qi),this.matrixWorldNeedsUpdate=!0,!0);case"planar":return this.jointValue.every((n,i)=>e[i]===n||e[i]===null)?t:(this.jointValue[0]=e[0]!==null?e[0]:this.jointValue[0],this.jointValue[1]=e[1]!==null?e[1]:this.jointValue[1],this.jointValue[2]=e[2]!==null?e[2]:this.jointValue[2],qi.compose(this.origPosition,this.origQuaternion,sa),ia.setFromAxisAngle(this.axis,this.jointValue[2]),ra.set(this.jointValue[0],this.jointValue[1],0),na.compose(ra,ia,sa),qi.premultiply(na),this.position.setFromMatrixPosition(qi),this.rotation.setFromRotationMatrix(qi),this.matrixWorldNeedsUpdate=!0,!0)}return t}}class gd extends Uf{constructor(...e){super(...e),this.type="URDFMimicJoint",this.mimicJoint=null,this.offset=0,this.multiplier=1}updateFromMimickedJoint(...e){const t=e.map(n=>n*this.multiplier+this.offset);return super.setJointValue(...t)}copy(e,t){return super.copy(e,t),this.mimicJoint=e.mimicJoint,this.offset=e.offset,this.multiplier=e.multiplier,this}}class Vb extends Nf{constructor(...e){super(...e),this.isURDFRobot=!0,this.urdfNode=null,this.urdfRobotNode=null,this.robotName=null,this.links=null,this.joints=null,this.colliders=null,this.visual=null,this.frames=null}copy(e,t){super.copy(e,t),this.urdfRobotNode=e.urdfRobotNode,this.robotName=e.robotName,this.links={},this.joints={},this.colliders={},this.visual={},this.traverse(n=>{n.isURDFJoint&&n.urdfName in e.joints&&(this.joints[n.urdfName]=n),n.isURDFLink&&n.urdfName in e.links&&(this.links[n.urdfName]=n),n.isURDFCollider&&n.urdfName in e.colliders&&(this.colliders[n.urdfName]=n),n.isURDFVisual&&n.urdfName in e.visual&&(this.visual[n.urdfName]=n)});for(const n in this.joints)this.joints[n].mimicJoints=this.joints[n].mimicJoints.map(i=>this.joints[i.name]);return this.frames={...this.colliders,...this.visual,...this.links,...this.joints},this}getFrame(e){return this.frames[e]}setJointValue(e,...t){const n=this.joints[e];return n?n.setJointValue(...t):!1}setJointValues(e){let t=!1;for(const n in e){const i=e[n];Array.isArray(i)?t=this.setJointValue(n,...i)||t:t=this.setJointValue(n,i)||t}return t}}const kl=new St,_d=new Bt;function $s(r){return r?r.trim().split(/\s+/g).map(e=>parseFloat(e)):[0,0,0]}function vd(r,e,t=!1){t||r.rotation.set(0,0,0),_d.set(e[0],e[1],e[2],"ZYX"),kl.setFromEuler(_d),kl.multiply(r.quaternion),r.quaternion.copy(kl)}class Gb{constructor(e){this.manager=e||cf,this.loadMeshCb=this.defaultMeshLoader.bind(this),this.parseVisual=!0,this.parseCollision=!1,this.packages="",this.workingPath="",this.fetchOptions={}}loadAsync(e){return new Promise((t,n)=>{this.load(e,t,null,n)})}load(e,t,n,i){const s=this.manager,o=nh.extractUrlBase(e),a=this.manager.resolveURL(e);s.itemStart(a),fetch(a,this.fetchOptions).then(l=>{if(l.ok)return n&&n(null),l.text();throw new Error(`URDFLoader: Failed to load url '${a}' with error code ${l.status} : ${l.statusText}.`)}).then(l=>{const c=this.parse(l,this.workingPath||o);t(c),s.itemEnd(a)}).catch(l=>{i?i(l):console.error("URDFLoader: Error loading file.",l),s.itemError(a),s.itemEnd(a)})}parse(e,t=this.workingPath){const n=this.packages,i=this.loadMeshCb,s=this.parseVisual,o=this.parseCollision,a=this.manager,l={},c={},h={};function u(w){if(!/^package:\/\//.test(w))return t?t+w:w;const[y,b]=w.replace(/^package:\/\//,"").split(/\/(.+)/);if(typeof n=="string")return n.endsWith(y)?n+"/"+b:n+"/"+y+"/"+b;if(n instanceof Function)return n(y)+"/"+b;if(typeof n=="object")return y in n?n[y]+"/"+b:(console.error(`URDFLoader : ${y} not found in provided package list.`),null)}function d(w){let y;w instanceof Document?y=[...w.children]:w instanceof Element?y=[w]:y=[...new DOMParser().parseFromString(w,"text/xml").children];const b=y.filter(D=>D.nodeName==="robot").pop();return f(b)}function f(w){const y=[...w.children],b=y.filter(T=>T.nodeName.toLowerCase()==="link"),D=y.filter(T=>T.nodeName.toLowerCase()==="joint"),R=y.filter(T=>T.nodeName.toLowerCase()==="material"),P=new Vb;P.robotName=w.getAttribute("name"),P.urdfRobotNode=w,R.forEach(T=>{const F=T.getAttribute("name");h[F]=m(T)});const M={},_={};b.forEach(T=>{const F=T.getAttribute("name"),k=w.querySelector(`child[link="${F}"]`)===null;l[F]=v(T,M,_,k?P:null)}),D.forEach(T=>{const F=T.getAttribute("name");c[F]=g(T)}),P.joints=c,P.links=l,P.colliders=_,P.visual=M;const x=Object.values(c);return x.forEach(T=>{T instanceof gd&&c[T.mimicJoint].mimicJoints.push(T)}),x.forEach(T=>{const F=new Set,k=G=>{if(F.has(G))throw new Error("URDFLoader: Detected an infinite loop of mimic joints.");F.add(G),G.mimicJoints.forEach(K=>{k(K)})};k(T)}),P.frames={..._,...M,...l,...c},P}function g(w){const y=[...w.children],b=w.getAttribute("type");let D;const R=y.find(F=>F.nodeName.toLowerCase()==="mimic");R?(D=new gd,D.mimicJoint=R.getAttribute("joint"),D.multiplier=parseFloat(R.getAttribute("multiplier")||1),D.offset=parseFloat(R.getAttribute("offset")||0)):D=new Uf,D.urdfNode=w,D.name=w.getAttribute("name"),D.urdfName=D.name,D.jointType=b;let P=null,M=null,_=[0,0,0],x=[0,0,0];y.forEach(F=>{const k=F.nodeName.toLowerCase();k==="origin"?(_=$s(F.getAttribute("xyz")),x=$s(F.getAttribute("rpy"))):k==="child"?M=l[F.getAttribute("link")]:k==="parent"?P=l[F.getAttribute("link")]:k==="limit"&&(D.limit.lower=parseFloat(F.getAttribute("lower")||D.limit.lower),D.limit.upper=parseFloat(F.getAttribute("upper")||D.limit.upper))}),P.add(D),D.add(M),vd(D,x),D.position.set(_[0],_[1],_[2]);const T=y.filter(F=>F.nodeName.toLowerCase()==="axis")[0];if(T){const F=T.getAttribute("xyz").split(/\s+/g).map(k=>parseFloat(k));D.axis=new L(F[0],F[1],F[2]),D.axis.normalize()}return D}function v(w,y,b,D=null){D===null&&(D=new Nf);const R=[...w.children];return D.name=w.getAttribute("name"),D.urdfName=D.name,D.urdfNode=w,s&&R.filter(M=>M.nodeName.toLowerCase()==="visual").forEach(M=>{const _=p(M,h);if(D.add(_),M.hasAttribute("name")){const x=M.getAttribute("name");_.name=x,_.urdfName=x,y[x]=_}}),o&&R.filter(M=>M.nodeName.toLowerCase()==="collision").forEach(M=>{const _=p(M);if(D.add(_),M.hasAttribute("name")){const x=M.getAttribute("name");_.name=x,_.urdfName=x,b[x]=_}}),D}function m(w){const y=[...w.children],b=new kn;return b.name=w.getAttribute("name")||"",y.forEach(D=>{const R=D.nodeName.toLowerCase();if(R==="color"){const P=D.getAttribute("rgba").split(/\s/g).map(M=>parseFloat(M));b.color.setRGB(P[0],P[1],P[2]),b.opacity=P[3],b.transparent=P[3]<1,b.depthWrite=!b.transparent}else if(R==="texture"){const P=D.getAttribute("filename");if(P){const M=new Ia(a),_=u(P);b.map=M.load(_),b.map.colorSpace=vt}}}),b}function p(w,y={}){const b=w.nodeName.toLowerCase()==="collision",D=[...w.children];let R=null;const P=D.filter(_=>_.nodeName.toLowerCase()==="material")[0];if(P){const _=P.getAttribute("name");_&&_ in y?R=y[_]:R=m(P)}else R=new kn;const M=b?new zb:new Hb;return M.urdfNode=w,D.forEach(_=>{const x=_.nodeName.toLowerCase();if(x==="geometry"){const T=_.children[0].nodeName.toLowerCase();if(T==="mesh"){const F=_.children[0].getAttribute("filename"),k=u(F);if(k!==null){const G=_.children[0].getAttribute("scale");if(G){const K=$s(G);M.scale.set(K[0],K[1],K[2])}i(k,a,(K,z)=>{z?console.error("URDFLoader: Error loading mesh.",z):K&&(K instanceof ve&&(K.material=R),K.position.set(0,0,0),K.quaternion.identity(),M.add(K))})}}else if(T==="box"){const F=new ve;F.geometry=new Zt(1,1,1),F.material=R;const k=$s(_.children[0].getAttribute("size"));F.scale.set(k[0],k[1],k[2]),M.add(F)}else if(T==="sphere"){const F=new ve;F.geometry=new to(1,30,30),F.material=R;const k=parseFloat(_.children[0].getAttribute("radius"))||0;F.scale.set(k,k,k),M.add(F)}else if(T==="cylinder"){const F=new ve;F.geometry=new sn(1,1,1,30),F.material=R;const k=parseFloat(_.children[0].getAttribute("radius"))||0,G=parseFloat(_.children[0].getAttribute("length"))||0;F.scale.set(k,G,k),F.rotation.set(Math.PI/2,0,0),M.add(F)}}else if(x==="origin"){const T=$s(_.getAttribute("xyz")),F=$s(_.getAttribute("rpy"));M.position.set(T[0],T[1],T[2]),M.rotation.set(0,0,0),vd(M,F)}}),M}return d(e)}defaultMeshLoader(e,t,n){/\.stl$/i.test(e)?new Eb(t).load(e,s=>{const o=new ve(s,new kn);n(o)}):/\.dae$/i.test(e)?new ab(t).load(e,s=>n(s.scene)):console.warn(`URDFLoader: Could not load model at ${e}.
No loader available`)}}var ma={exports:{}};/* @license
Papa Parse
v5.5.3
https://github.com/mholt/PapaParse
License: MIT
*/var Wb=ma.exports,xd;function Xb(){return xd||(xd=1,function(r,e){((t,n)=>{r.exports=n()})(Wb,function t(){var n=typeof self<"u"?self:typeof window<"u"?window:n!==void 0?n:{},i,s=!n.document&&!!n.postMessage,o=n.IS_PAPA_WORKER||!1,a={},l=0,c={};function h(M){this._handle=null,this._finished=!1,this._completed=!1,this._halted=!1,this._input=null,this._baseIndex=0,this._partialLine="",this._rowCount=0,this._start=0,this._nextChunk=null,this.isFirstChunk=!0,this._completeResults={data:[],errors:[],meta:{}},function(_){var x=D(_);x.chunkSize=parseInt(x.chunkSize),_.step||_.chunk||(x.chunkSize=null),this._handle=new v(x),(this._handle.streamer=this)._config=x}.call(this,M),this.parseChunk=function(_,x){var T=parseInt(this._config.skipFirstNLines)||0;if(this.isFirstChunk&&0<T){let k=this._config.newline;k||(F=this._config.quoteChar||'"',k=this._handle.guessLineEndings(_,F)),_=[..._.split(k).slice(T)].join(k)}this.isFirstChunk&&P(this._config.beforeFirstChunk)&&(F=this._config.beforeFirstChunk(_))!==void 0&&(_=F),this.isFirstChunk=!1,this._halted=!1;var T=this._partialLine+_,F=(this._partialLine="",this._handle.parse(T,this._baseIndex,!this._finished));if(!this._handle.paused()&&!this._handle.aborted()){if(_=F.meta.cursor,T=(this._finished||(this._partialLine=T.substring(_-this._baseIndex),this._baseIndex=_),F&&F.data&&(this._rowCount+=F.data.length),this._finished||this._config.preview&&this._rowCount>=this._config.preview),o)n.postMessage({results:F,workerId:c.WORKER_ID,finished:T});else if(P(this._config.chunk)&&!x){if(this._config.chunk(F,this._handle),this._handle.paused()||this._handle.aborted())return void(this._halted=!0);this._completeResults=F=void 0}return this._config.step||this._config.chunk||(this._completeResults.data=this._completeResults.data.concat(F.data),this._completeResults.errors=this._completeResults.errors.concat(F.errors),this._completeResults.meta=F.meta),this._completed||!T||!P(this._config.complete)||F&&F.meta.aborted||(this._config.complete(this._completeResults,this._input),this._completed=!0),T||F&&F.meta.paused||this._nextChunk(),F}this._halted=!0},this._sendError=function(_){P(this._config.error)?this._config.error(_):o&&this._config.error&&n.postMessage({workerId:c.WORKER_ID,error:_,finished:!1})}}function u(M){var _;(M=M||{}).chunkSize||(M.chunkSize=c.RemoteChunkSize),h.call(this,M),this._nextChunk=s?function(){this._readChunk(),this._chunkLoaded()}:function(){this._readChunk()},this.stream=function(x){this._input=x,this._nextChunk()},this._readChunk=function(){if(this._finished)this._chunkLoaded();else{if(_=new XMLHttpRequest,this._config.withCredentials&&(_.withCredentials=this._config.withCredentials),s||(_.onload=R(this._chunkLoaded,this),_.onerror=R(this._chunkError,this)),_.open(this._config.downloadRequestBody?"POST":"GET",this._input,!s),this._config.downloadRequestHeaders){var x,T=this._config.downloadRequestHeaders;for(x in T)_.setRequestHeader(x,T[x])}var F;this._config.chunkSize&&(F=this._start+this._config.chunkSize-1,_.setRequestHeader("Range","bytes="+this._start+"-"+F));try{_.send(this._config.downloadRequestBody)}catch(k){this._chunkError(k.message)}s&&_.status===0&&this._chunkError()}},this._chunkLoaded=function(){_.readyState===4&&(_.status<200||400<=_.status?this._chunkError():(this._start+=this._config.chunkSize||_.responseText.length,this._finished=!this._config.chunkSize||this._start>=(x=>(x=x.getResponseHeader("Content-Range"))!==null?parseInt(x.substring(x.lastIndexOf("/")+1)):-1)(_),this.parseChunk(_.responseText)))},this._chunkError=function(x){x=_.statusText||x,this._sendError(new Error(x))}}function d(M){(M=M||{}).chunkSize||(M.chunkSize=c.LocalChunkSize),h.call(this,M);var _,x,T=typeof FileReader<"u";this.stream=function(F){this._input=F,x=F.slice||F.webkitSlice||F.mozSlice,T?((_=new FileReader).onload=R(this._chunkLoaded,this),_.onerror=R(this._chunkError,this)):_=new FileReaderSync,this._nextChunk()},this._nextChunk=function(){this._finished||this._config.preview&&!(this._rowCount<this._config.preview)||this._readChunk()},this._readChunk=function(){var F=this._input,k=(this._config.chunkSize&&(k=Math.min(this._start+this._config.chunkSize,this._input.size),F=x.call(F,this._start,k)),_.readAsText(F,this._config.encoding));T||this._chunkLoaded({target:{result:k}})},this._chunkLoaded=function(F){this._start+=this._config.chunkSize,this._finished=!this._config.chunkSize||this._start>=this._input.size,this.parseChunk(F.target.result)},this._chunkError=function(){this._sendError(_.error)}}function f(M){var _;h.call(this,M=M||{}),this.stream=function(x){return _=x,this._nextChunk()},this._nextChunk=function(){var x,T;if(!this._finished)return x=this._config.chunkSize,_=x?(T=_.substring(0,x),_.substring(x)):(T=_,""),this._finished=!_,this.parseChunk(T)}}function g(M){h.call(this,M=M||{});var _=[],x=!0,T=!1;this.pause=function(){h.prototype.pause.apply(this,arguments),this._input.pause()},this.resume=function(){h.prototype.resume.apply(this,arguments),this._input.resume()},this.stream=function(F){this._input=F,this._input.on("data",this._streamData),this._input.on("end",this._streamEnd),this._input.on("error",this._streamError)},this._checkIsFinished=function(){T&&_.length===1&&(this._finished=!0)},this._nextChunk=function(){this._checkIsFinished(),_.length?this.parseChunk(_.shift()):x=!0},this._streamData=R(function(F){try{_.push(typeof F=="string"?F:F.toString(this._config.encoding)),x&&(x=!1,this._checkIsFinished(),this.parseChunk(_.shift()))}catch(k){this._streamError(k)}},this),this._streamError=R(function(F){this._streamCleanUp(),this._sendError(F)},this),this._streamEnd=R(function(){this._streamCleanUp(),T=!0,this._streamData("")},this),this._streamCleanUp=R(function(){this._input.removeListener("data",this._streamData),this._input.removeListener("end",this._streamEnd),this._input.removeListener("error",this._streamError)},this)}function v(M){var _,x,T,F,k=Math.pow(2,53),G=-k,K=/^\s*-?(\d+\.?|\.\d+|\d+\.\d+)([eE][-+]?\d+)?\s*$/,z=/^((\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d\.\d+([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z))|(\d{4}-[01]\d-[0-3]\dT[0-2]\d:[0-5]\d([+-][0-2]\d:[0-5]\d|Z)))$/,Z=this,V=0,Y=0,ue=!1,ie=!1,he=[],se={data:[],errors:[],meta:{}};function H(ce){return M.skipEmptyLines==="greedy"?ce.join("").trim()==="":ce.length===1&&ce[0].length===0}function j(){if(se&&T&&(te("Delimiter","UndetectableDelimiter","Unable to auto-detect delimiting character; defaulted to '"+c.DefaultDelimiter+"'"),T=!1),M.skipEmptyLines&&(se.data=se.data.filter(function(Re){return!H(Re)})),J()){let Re=function(Je,We){P(M.transformHeader)&&(Je=M.transformHeader(Je,We)),he.push(Je)};if(se)if(Array.isArray(se.data[0])){for(var ce=0;J()&&ce<se.data.length;ce++)se.data[ce].forEach(Re);se.data.splice(0,1)}else se.data.forEach(Re)}function be(Re,Je){for(var We=M.header?{}:[],B=0;B<Re.length;B++){var ht=B,Le=Re[B],Le=((tt,me)=>(Qe=>(M.dynamicTypingFunction&&M.dynamicTyping[Qe]===void 0&&(M.dynamicTyping[Qe]=M.dynamicTypingFunction(Qe)),(M.dynamicTyping[Qe]||M.dynamicTyping)===!0))(tt)?me==="true"||me==="TRUE"||me!=="false"&&me!=="FALSE"&&((Qe=>{if(K.test(Qe)&&(Qe=parseFloat(Qe),G<Qe&&Qe<k))return 1})(me)?parseFloat(me):z.test(me)?new Date(me):me===""?null:me):me)(ht=M.header?B>=he.length?"__parsed_extra":he[B]:ht,Le=M.transform?M.transform(Le,ht):Le);ht==="__parsed_extra"?(We[ht]=We[ht]||[],We[ht].push(Le)):We[ht]=Le}return M.header&&(B>he.length?te("FieldMismatch","TooManyFields","Too many fields: expected "+he.length+" fields but parsed "+B,Y+Je):B<he.length&&te("FieldMismatch","TooFewFields","Too few fields: expected "+he.length+" fields but parsed "+B,Y+Je)),We}var xe;se&&(M.header||M.dynamicTyping||M.transform)&&(xe=1,!se.data.length||Array.isArray(se.data[0])?(se.data=se.data.map(be),xe=se.data.length):se.data=be(se.data,0),M.header&&se.meta&&(se.meta.fields=he),Y+=xe)}function J(){return M.header&&he.length===0}function te(ce,be,xe,Re){ce={type:ce,code:be,message:xe},Re!==void 0&&(ce.row=Re),se.errors.push(ce)}P(M.step)&&(F=M.step,M.step=function(ce){se=ce,J()?j():(j(),se.data.length!==0&&(V+=ce.data.length,M.preview&&V>M.preview?x.abort():(se.data=se.data[0],F(se,Z))))}),this.parse=function(ce,be,xe){var Re=M.quoteChar||'"',Re=(M.newline||(M.newline=this.guessLineEndings(ce,Re)),T=!1,M.delimiter?P(M.delimiter)&&(M.delimiter=M.delimiter(ce),se.meta.delimiter=M.delimiter):((Re=((Je,We,B,ht,Le)=>{var tt,me,Qe,ze;Le=Le||[",","	","|",";",c.RECORD_SEP,c.UNIT_SEP];for(var O=0;O<Le.length;O++){for(var A,$=Le[O],ae=0,de=0,re=0,Ce=(Qe=void 0,new p({comments:ht,delimiter:$,newline:We,preview:10}).parse(Je)),Me=0;Me<Ce.data.length;Me++)B&&H(Ce.data[Me])?re++:(A=Ce.data[Me].length,de+=A,Qe===void 0?Qe=A:0<A&&(ae+=Math.abs(A-Qe),Qe=A));0<Ce.data.length&&(de/=Ce.data.length-re),(me===void 0||ae<=me)&&(ze===void 0||ze<de)&&1.99<de&&(me=ae,tt=$,ze=de)}return{successful:!!(M.delimiter=tt),bestDelimiter:tt}})(ce,M.newline,M.skipEmptyLines,M.comments,M.delimitersToGuess)).successful?M.delimiter=Re.bestDelimiter:(T=!0,M.delimiter=c.DefaultDelimiter),se.meta.delimiter=M.delimiter),D(M));return M.preview&&M.header&&Re.preview++,_=ce,x=new p(Re),se=x.parse(_,be,xe),j(),ue?{meta:{paused:!0}}:se||{meta:{paused:!1}}},this.paused=function(){return ue},this.pause=function(){ue=!0,x.abort(),_=P(M.chunk)?"":_.substring(x.getCharIndex())},this.resume=function(){Z.streamer._halted?(ue=!1,Z.streamer.parseChunk(_,!0)):setTimeout(Z.resume,3)},this.aborted=function(){return ie},this.abort=function(){ie=!0,x.abort(),se.meta.aborted=!0,P(M.complete)&&M.complete(se),_=""},this.guessLineEndings=function(Je,Re){Je=Je.substring(0,1048576);var Re=new RegExp(m(Re)+"([^]*?)"+m(Re),"gm"),xe=(Je=Je.replace(Re,"")).split("\r"),Re=Je.split(`
`),Je=1<Re.length&&Re[0].length<xe[0].length;if(xe.length===1||Je)return`
`;for(var We=0,B=0;B<xe.length;B++)xe[B][0]===`
`&&We++;return We>=xe.length/2?`\r
`:"\r"}}function m(M){return M.replace(/[.*+?^${}()|[\]\\]/g,"\\$&")}function p(M){var _=(M=M||{}).delimiter,x=M.newline,T=M.comments,F=M.step,k=M.preview,G=M.fastMode,K=null,z=!1,Z=M.quoteChar==null?'"':M.quoteChar,V=Z;if(M.escapeChar!==void 0&&(V=M.escapeChar),(typeof _!="string"||-1<c.BAD_DELIMITERS.indexOf(_))&&(_=","),T===_)throw new Error("Comment character same as delimiter");T===!0?T="#":(typeof T!="string"||-1<c.BAD_DELIMITERS.indexOf(T))&&(T=!1),x!==`
`&&x!=="\r"&&x!==`\r
`&&(x=`
`);var Y=0,ue=!1;this.parse=function(ie,he,se){if(typeof ie!="string")throw new Error("Input must be a string");var H=ie.length,j=_.length,J=x.length,te=T.length,ce=P(F),be=[],xe=[],Re=[],Je=Y=0;if(!ie)return ae();if(G||G!==!1&&ie.indexOf(Z)===-1){for(var We=ie.split(x),B=0;B<We.length;B++){if(Re=We[B],Y+=Re.length,B!==We.length-1)Y+=x.length;else if(se)return ae();if(!T||Re.substring(0,te)!==T){if(ce){if(be=[],ze(Re.split(_)),de(),ue)return ae()}else ze(Re.split(_));if(k&&k<=B)return be=be.slice(0,k),ae(!0)}}return ae()}for(var ht=ie.indexOf(_,Y),Le=ie.indexOf(x,Y),tt=new RegExp(m(V)+m(Z),"g"),me=ie.indexOf(Z,Y);;)if(ie[Y]===Z)for(me=Y,Y++;;){if((me=ie.indexOf(Z,me+1))===-1)return se||xe.push({type:"Quotes",code:"MissingQuotes",message:"Quoted field unterminated",row:be.length,index:Y}),A();if(me===H-1)return A(ie.substring(Y,me).replace(tt,Z));if(Z===V&&ie[me+1]===V)me++;else if(Z===V||me===0||ie[me-1]!==V){ht!==-1&&ht<me+1&&(ht=ie.indexOf(_,me+1));var Qe=O((Le=Le!==-1&&Le<me+1?ie.indexOf(x,me+1):Le)===-1?ht:Math.min(ht,Le));if(ie.substr(me+1+Qe,j)===_){Re.push(ie.substring(Y,me).replace(tt,Z)),ie[Y=me+1+Qe+j]!==Z&&(me=ie.indexOf(Z,Y)),ht=ie.indexOf(_,Y),Le=ie.indexOf(x,Y);break}if(Qe=O(Le),ie.substring(me+1+Qe,me+1+Qe+J)===x){if(Re.push(ie.substring(Y,me).replace(tt,Z)),$(me+1+Qe+J),ht=ie.indexOf(_,Y),me=ie.indexOf(Z,Y),ce&&(de(),ue))return ae();if(k&&be.length>=k)return ae(!0);break}xe.push({type:"Quotes",code:"InvalidQuotes",message:"Trailing quote on quoted field is malformed",row:be.length,index:Y}),me++}}else if(T&&Re.length===0&&ie.substring(Y,Y+te)===T){if(Le===-1)return ae();Y=Le+J,Le=ie.indexOf(x,Y),ht=ie.indexOf(_,Y)}else if(ht!==-1&&(ht<Le||Le===-1))Re.push(ie.substring(Y,ht)),Y=ht+j,ht=ie.indexOf(_,Y);else{if(Le===-1)break;if(Re.push(ie.substring(Y,Le)),$(Le+J),ce&&(de(),ue))return ae();if(k&&be.length>=k)return ae(!0)}return A();function ze(re){be.push(re),Je=Y}function O(re){var Ce=0;return Ce=re!==-1&&(re=ie.substring(me+1,re))&&re.trim()===""?re.length:Ce}function A(re){return se||(re===void 0&&(re=ie.substring(Y)),Re.push(re),Y=H,ze(Re),ce&&de()),ae()}function $(re){Y=re,ze(Re),Re=[],Le=ie.indexOf(x,Y)}function ae(re){if(M.header&&!he&&be.length&&!z){var Ce=be[0],Me=Object.create(null),Fe=new Set(Ce);let gt=!1;for(let ge=0;ge<Ce.length;ge++){let Te=Ce[ge];if(Me[Te=P(M.transformHeader)?M.transformHeader(Te,ge):Te]){let qe,et=Me[Te];for(;qe=Te+"_"+et,et++,Fe.has(qe););Fe.add(qe),Ce[ge]=qe,Me[Te]++,gt=!0,(K=K===null?{}:K)[qe]=Te}else Me[Te]=1,Ce[ge]=Te;Fe.add(Te)}gt&&console.warn("Duplicate headers found and renamed."),z=!0}return{data:be,errors:xe,meta:{delimiter:_,linebreak:x,aborted:ue,truncated:!!re,cursor:Je+(he||0),renamedHeaders:K}}}function de(){F(ae()),be=[],xe=[]}},this.abort=function(){ue=!0},this.getCharIndex=function(){return Y}}function w(M){var _=M.data,x=a[_.workerId],T=!1;if(_.error)x.userError(_.error,_.file);else if(_.results&&_.results.data){var F={abort:function(){T=!0,y(_.workerId,{data:[],errors:[],meta:{aborted:!0}})},pause:b,resume:b};if(P(x.userStep)){for(var k=0;k<_.results.data.length&&(x.userStep({data:_.results.data[k],errors:_.results.errors,meta:_.results.meta},F),!T);k++);delete _.results}else P(x.userChunk)&&(x.userChunk(_.results,F,_.file),delete _.results)}_.finished&&!T&&y(_.workerId,_.results)}function y(M,_){var x=a[M];P(x.userComplete)&&x.userComplete(_),x.terminate(),delete a[M]}function b(){throw new Error("Not implemented.")}function D(M){if(typeof M!="object"||M===null)return M;var _,x=Array.isArray(M)?[]:{};for(_ in M)x[_]=D(M[_]);return x}function R(M,_){return function(){M.apply(_,arguments)}}function P(M){return typeof M=="function"}return c.parse=function(M,_){var x=(_=_||{}).dynamicTyping||!1;if(P(x)&&(_.dynamicTypingFunction=x,x={}),_.dynamicTyping=x,_.transform=!!P(_.transform)&&_.transform,!_.worker||!c.WORKERS_SUPPORTED)return x=null,c.NODE_STREAM_INPUT,typeof M=="string"?(M=(T=>T.charCodeAt(0)!==65279?T:T.slice(1))(M),x=new(_.download?u:f)(_)):M.readable===!0&&P(M.read)&&P(M.on)?x=new g(_):(n.File&&M instanceof File||M instanceof Object)&&(x=new d(_)),x.stream(M);(x=(()=>{var T;return!!c.WORKERS_SUPPORTED&&(T=(()=>{var F=n.URL||n.webkitURL||null,k=t.toString();return c.BLOB_URL||(c.BLOB_URL=F.createObjectURL(new Blob(["var global = (function() { if (typeof self !== 'undefined') { return self; } if (typeof window !== 'undefined') { return window; } if (typeof global !== 'undefined') { return global; } return {}; })(); global.IS_PAPA_WORKER=true; ","(",k,")();"],{type:"text/javascript"})))})(),(T=new n.Worker(T)).onmessage=w,T.id=l++,a[T.id]=T)})()).userStep=_.step,x.userChunk=_.chunk,x.userComplete=_.complete,x.userError=_.error,_.step=P(_.step),_.chunk=P(_.chunk),_.complete=P(_.complete),_.error=P(_.error),delete _.worker,x.postMessage({input:M,config:_,workerId:x.id})},c.unparse=function(M,_){var x=!1,T=!0,F=",",k=`\r
`,G='"',K=G+G,z=!1,Z=null,V=!1,Y=((()=>{if(typeof _=="object"){if(typeof _.delimiter!="string"||c.BAD_DELIMITERS.filter(function(he){return _.delimiter.indexOf(he)!==-1}).length||(F=_.delimiter),typeof _.quotes!="boolean"&&typeof _.quotes!="function"&&!Array.isArray(_.quotes)||(x=_.quotes),typeof _.skipEmptyLines!="boolean"&&typeof _.skipEmptyLines!="string"||(z=_.skipEmptyLines),typeof _.newline=="string"&&(k=_.newline),typeof _.quoteChar=="string"&&(G=_.quoteChar),typeof _.header=="boolean"&&(T=_.header),Array.isArray(_.columns)){if(_.columns.length===0)throw new Error("Option columns is empty");Z=_.columns}_.escapeChar!==void 0&&(K=_.escapeChar+G),_.escapeFormulae instanceof RegExp?V=_.escapeFormulae:typeof _.escapeFormulae=="boolean"&&_.escapeFormulae&&(V=/^[=+\-@\t\r].*$/)}})(),new RegExp(m(G),"g"));if(typeof M=="string"&&(M=JSON.parse(M)),Array.isArray(M)){if(!M.length||Array.isArray(M[0]))return ue(null,M,z);if(typeof M[0]=="object")return ue(Z||Object.keys(M[0]),M,z)}else if(typeof M=="object")return typeof M.data=="string"&&(M.data=JSON.parse(M.data)),Array.isArray(M.data)&&(M.fields||(M.fields=M.meta&&M.meta.fields||Z),M.fields||(M.fields=Array.isArray(M.data[0])?M.fields:typeof M.data[0]=="object"?Object.keys(M.data[0]):[]),Array.isArray(M.data[0])||typeof M.data[0]=="object"||(M.data=[M.data])),ue(M.fields||[],M.data||[],z);throw new Error("Unable to serialize unrecognized input");function ue(he,se,H){var j="",J=(typeof he=="string"&&(he=JSON.parse(he)),typeof se=="string"&&(se=JSON.parse(se)),Array.isArray(he)&&0<he.length),te=!Array.isArray(se[0]);if(J&&T){for(var ce=0;ce<he.length;ce++)0<ce&&(j+=F),j+=ie(he[ce],ce);0<se.length&&(j+=k)}for(var be=0;be<se.length;be++){var xe=(J?he:se[be]).length,Re=!1,Je=J?Object.keys(se[be]).length===0:se[be].length===0;if(H&&!J&&(Re=H==="greedy"?se[be].join("").trim()==="":se[be].length===1&&se[be][0].length===0),H==="greedy"&&J){for(var We=[],B=0;B<xe;B++){var ht=te?he[B]:B;We.push(se[be][ht])}Re=We.join("").trim()===""}if(!Re){for(var Le=0;Le<xe;Le++){0<Le&&!Je&&(j+=F);var tt=J&&te?he[Le]:Le;j+=ie(se[be][tt],Le)}be<se.length-1&&(!H||0<xe&&!Je)&&(j+=k)}}return j}function ie(he,se){var H,j;return he==null?"":he.constructor===Date?JSON.stringify(he).slice(1,25):(j=!1,V&&typeof he=="string"&&V.test(he)&&(he="'"+he,j=!0),H=he.toString().replace(Y,K),(j=j||x===!0||typeof x=="function"&&x(he,se)||Array.isArray(x)&&x[se]||((J,te)=>{for(var ce=0;ce<te.length;ce++)if(-1<J.indexOf(te[ce]))return!0;return!1})(H,c.BAD_DELIMITERS)||-1<H.indexOf(F)||H.charAt(0)===" "||H.charAt(H.length-1)===" ")?G+H+G:H)}},c.RECORD_SEP="",c.UNIT_SEP="",c.BYTE_ORDER_MARK="\uFEFF",c.BAD_DELIMITERS=["\r",`
`,'"',c.BYTE_ORDER_MARK],c.WORKERS_SUPPORTED=!s&&!!n.Worker,c.NODE_STREAM_INPUT=1,c.LocalChunkSize=10485760,c.RemoteChunkSize=5242880,c.DefaultDelimiter=",",c.Parser=p,c.ParserHandle=v,c.NetworkStreamer=u,c.FileStreamer=d,c.StringStreamer=f,c.ReadableStreamStreamer=g,n.jQuery&&((i=n.jQuery).fn.parse=function(M){var _=M.config||{},x=[];return this.each(function(k){if(!(i(this).prop("tagName").toUpperCase()==="INPUT"&&i(this).attr("type").toLowerCase()==="file"&&n.FileReader)||!this.files||this.files.length===0)return!0;for(var G=0;G<this.files.length;G++)x.push({file:this.files[G],inputElem:this,instanceConfig:i.extend({},_)})}),T(),this;function T(){if(x.length===0)P(M.complete)&&M.complete();else{var k,G,K,z,Z=x[0];if(P(M.before)){var V=M.before(Z.file,Z.inputElem);if(typeof V=="object"){if(V.action==="abort")return k="AbortError",G=Z.file,K=Z.inputElem,z=V.reason,void(P(M.error)&&M.error({name:k},G,K,z));if(V.action==="skip")return void F();typeof V.config=="object"&&(Z.instanceConfig=i.extend(Z.instanceConfig,V.config))}else if(V==="skip")return void F()}var Y=Z.instanceConfig.complete;Z.instanceConfig.complete=function(ue){P(Y)&&Y(ue,Z.file,Z.inputElem),F()},c.parse(Z.file,Z.instanceConfig)}}function F(){x.splice(0,1),T()}}),o&&(n.onmessage=function(M){M=M.data,c.WORKER_ID===void 0&&M&&(c.WORKER_ID=M.workerId),typeof M.input=="string"?n.postMessage({workerId:c.WORKER_ID,results:c.parse(M.input,M.config),finished:!0}):(n.File&&M.input instanceof File||M.input instanceof Object)&&(M=c.parse(M.input,M.config))&&n.postMessage({workerId:c.WORKER_ID,results:M,finished:!0})}),(u.prototype=Object.create(h.prototype)).constructor=u,(d.prototype=Object.create(h.prototype)).constructor=d,(f.prototype=Object.create(f.prototype)).constructor=f,(g.prototype=Object.create(h.prototype)).constructor=g,c})}(ma)),ma.exports}var jb=Xb();const qb=zf(jb);class uh extends If{robot;static async create(){const e=new uh;return await e._initAsync(),e}constructor(){super(),this.jointBuf=new Df,this.name="RBQ",this.userData.keep=!0}async _initAsync(){const e=new lf,t=new Gb(e),n=Ba("/rbq/rbq10.urdf");try{const i=await t.loadAsync(n);this.robot=i,this.add(i)}catch(i){console.error(i)}}update(e){this.position.set(+e.x,+e.y,0),this.rotation.z=Pt.degToRad(+e.rz)}applyPose(e){this.pushPointsSnapShot({t:performance.now()*.001,x:+e.x,y:+e.y,rz:+e.rz})}async loadJointData(e,t=!0,n=1){const i=Bb(e),s=await fetch(i).then(c=>c.text()),{data:o}=qb.parse(s,{header:!0,dynamicTyping:!0,skipEmptyLines:!0}),a=o.sort((c,h)=>c.time-h.time),l=performance.now()/1e3;for(const c of a){const{time:h,...u}=c,d=u,f=l+h/n;t?setTimeout(()=>this.pushJointsSnapshot(d,f),h/n*1e3):this.pushJointsSnapshot(d,f)}}applyJointValues(e){this.robot?.setJointValues(e)}}const yd=["#0087fc","#f77468","#f37a32","#dc8932","#ca9232","#bb9832","#ae9d31","#9fa131","#8ea631","#77ab31","#50b131","#32b25c","#33b07a","#34af8c","#35ae99","#36ada4","#36acae","#37aab9","#38a9c5","#39a7d5","#3ba3ec","#6e9bf4","#9591f4","#b287f4","#cc7af4","#e866f4","#f560e4","#f565cc","#f66ab7","#f66da2"];class Yb{editor;mainRobot;rbq;s100;robotMap;previousUpdateTime;availableColors;constructor(e){this.editor=e,this.s100=null,this.rbq=null,this.robotMap=new Map,this.previousUpdateTime=Date.now(),this.availableColors=[...yd]}addLabel(e){const t=document.createElement("div");t.className="nodeLabel",t.textContent=e.name,t.style.color="white",t.style.backgroundColor="transparent",t.style.position="absolute",t.style.fontSize="6.5px",t.style.zIndex="-999";const n=new Oa(t);n.userData.keep=!0,n.userData.labelType="robot",n.name="label",n.center.set(0,-.5),e.add(n)}count(){return this.robotMap.size}dispose(){this.rbq=null,this.s100=null,this.mainRobot=null}async loadMainRobot(e){if(!this.mainRobot){switch(e){case"S100":this.mainRobot=await hh.create(),this.s100=this.mainRobot;break;case"RBQ":this.mainRobot=await uh.create(),this.rbq=this.mainRobot;break}this.editor.zUpGroup.add(this.mainRobot),this.robotMap.set("mainRobot",this.mainRobot),this.editor.eventHandler.eventBus.emit("robotmanager:mainrobot:loaded")}}update=(e,t)=>{e.visible?(e.position.set(t.x,t.y,e.position.z),e.rotation.z=t.rz*Math.PI/180):(e.position.set(t.x,t.y,0),e.rotation.z=t.rz,e.visible=!0)};updateAll(e){this.mainRobot?.tick(e)}addAxesHelper(e){const t=new rh(1e3);t.userData.keep=!0,e.add(t)}cloneEdgeLine(e,t){const n=e.getObjectByName("edgeLine"),i=t.getObjectByName("edgeLine");n&&i&&(i.material=n.material.clone())}cloneRobot(e){const t=e.clone();t.name="robot";const n=e.material.clone();return n.color=new ke(this.getUniqueColor()),t.material=n,t}getUniqueColor(){return this.availableColors.length===0&&(this.availableColors=[...yd]),this.availableColors.splice(0,1)[0]}}const di=new ye,zl=new ir,ni=new Ua;ni.params.Points.threshold=.5;class Zb{editor;mode;_invMat=new Ee;constructor(e){this.editor=e,this.mode="single"}dispose(){const e=this.editor.eventHandler.eventBus;e.off("intersectionsDetected",this.handleIntersectionsDetected),e.off("changeSelectMode",this.handleChangeSelectMode),e.off("boxIntersectionsDetected",this.handleBoxIntersectionsDetected),e.off("nodesCopied",this.handleNodesCopied),e.off("objectRemoved",this.handleObjectRemoved)}getSelectionBoxIntersects(e,t,n){zl.min=new ye(Math.min(t.x,n.x),Math.min(t.y,n.y)),zl.max=new ye(Math.max(t.x,n.x),Math.max(t.y,n.y));const i=[],s=this.editor.selectableObjects,o=s.length;for(let l=0;l<o;l++){const c=s[l],h=this.toScreenPosition(e,c),u=new ye(h.x,h.y);zl.containsPoint(u)&&i.push(c)}return this.getSortedIntersects(i)}getPointerPlaneIntersection(e,t){return di.set(e.x*2-1,-(e.y*2)+1),ni.setFromCamera(di,t),this.computeGlobalPlaneIntersection(ni)}getPointerObjectIntersections(e,t){return di.set(e.x*2-1,-(e.y*2)+1),ni.setFromCamera(di,t),this.computeObjectIntersects(ni)}getPointerOctreeIntersections(e,t){return di.set(e.x*2-1,-(e.y*2)+1),ni.setFromCamera(di,t),this.computeOctreePointIntersections(ni,t)}getPointerQuadTreeIntersections(e,t){return di.set(e.x*2-1,-(e.y*2)+1),ni.setFromCamera(di,t),this.computeQuadtreePointIntersections(ni,t)}getPointerNearestPointIntersection(e,t){return di.set(e.x*2-1,-(e.y*2)+1),ni.setFromCamera(di,t),this.computeNearestPointIntersect(ni,t)}registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("intersectionsDetected",this.handleIntersectionsDetected),e.on("changeSelectMode",this.handleChangeSelectMode),e.on("boxIntersectionsDetected",this.handleBoxIntersectionsDetected),e.on("nodesCopied",this.handleNodesCopied),e.on("objectRemoved",this.handleObjectRemoved)}accumulateOctreeIntersections(e,t,n,i,s){if(e.intersectsBox(t.boundary))if(t.divided)for(const o of t.children)this.accumulateOctreeIntersections(e,o,n,i,s);else for(const{position:o,index:a}of t.points){const l=e.distanceToPoint(o);if(l<=n){const c=i.position.distanceTo(o);s.push({point:o.clone(),index:a,distance:l,cameraDist:c})}}}computeGlobalPlaneIntersection(e){return e.intersectObject(this.editor.globalPlane)}computeNearestPointIntersect(e,t){const n=e.ray,i=this.editor.pointsManager.pointsOctree;return this.findNearestOctreeIntersection(n,i,e.params.Points.threshold,t)}computeObjectIntersects(e){return e.intersectObjects(this.editor.selectableObjects,!1)}computeOctreePointIntersections(e,t){const n=e.ray,i=[],s=this.editor.pointsManager.pointsOctree;return this.accumulateOctreeIntersections(n,s,e.params.Points.threshold,t,i),i}findNearestOctreeIntersection(e,t,n,i){if(!e.intersectsBox(t.boundary))return null;let s=null;if(t.divided)for(const o of t.children){const a=this.findNearestOctreeIntersection(e,o,n,i);a!==null&&(s===null||a.cameraDist<s.cameraDist)&&(s=a)}else for(const{position:o,index:a}of t.points){const l=e.distanceToPoint(o);if(l<=n){const c=i.position.distanceTo(o);(s===null||c<s.cameraDist)&&(s={point:o.clone(),index:a,distance:l,cameraDist:c})}}return s}getSortedIntersects(e){return e.sort((t,n)=>{const i=t.position.x-n.position.x;return i!==0?i:n.position.y-t.position.y}),e}handleBoxIntersectionsDetected=e=>{this.select(null),this.multiSelect(e)};handleChangeSelectMode=e=>{this.mode=e,this.select(null)};handleIntersectionsDetected=e=>{if(e.length>0){const t=e[0].object;this.select(t)}else this.select(null)};handleNodesCopied=e=>{this.select(null),this.multiSelect(e)};handleObjectRemoved=()=>{this.select(null)};multiSelect=e=>{this.editor.selected=e[e.length-1],this.editor.selectedObjects=e,this.editor.eventHandler.eventBus.emit("objectsSelected",{selectedObjects:e})};select=e=>{this.editor.selected!==e&&(this.editor.selected=e,e?this.editor.selectedObjects.includes(e)||this.editor.selectedObjects.push(e):this.editor.selectedObjects=[],this.editor.eventHandler.eventBus.emit("objectSelected",{object:e,selectedObjects:this.editor.selectedObjects}))};toScreenPosition(e,t){const n=e.getBoundingClientRect(),i=new L;return t.updateMatrixWorld(),i.setFromMatrixPosition(t.matrixWorld),i.project(this.editor.camera),{x:(i.x+1)/2*n.width+n.left,y:(-i.y+1)/2*n.height+n.top}}computeQuadtreePointIntersections(e,t){const n=[],i=this.editor.pointsManager.pointsQuadTree;if(!i)return n;const s=this.worldRayToLocal(e.ray,this.editor.zUpGroup),o=e.params.Points.threshold??1;return this.accumulateQuadtreeIntersections(s,i,o,t,n),n}worldRayToLocal(e,t){this._invMat.copy(t.matrixWorld).invert();const n=e.origin.clone().applyMatrix4(this._invMat),i=e.direction.clone().transformDirection(this._invMat).normalize();return new Es(n,i)}_visualizeRay(e,t,n,i=30,s=65535){const o=new uf(t,e,i,s,.3,.3);n.add(o)}accumulateQuadtreeIntersections(e,t,n,i,s){const o=t.boundary.clone().expandByScalar(n),a=new Cn(new L(o.min.x,o.min.y,-n),new L(o.max.x,o.max.y,n));if(e.intersectsBox(a))if(t.divided)for(const l of t.children)this.accumulateQuadtreeIntersections(e,l,n,i,s);else for(const{position:l,index:c}of t.points){const h=e.distanceToPoint(l);if(h<=n){const u=i.position.distanceTo(l);s.push({point:l.clone(),index:c,distance:h,cameraDist:u})}}}}/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */function rn(r,e,t,n){function i(s){return s instanceof t?s:new t(function(o){o(s)})}return new(t||(t=Promise))(function(s,o){function a(h){try{c(n.next(h))}catch(u){o(u)}}function l(h){try{c(n.throw(h))}catch(u){o(u)}}function c(h){h.done?s(h.value):i(h.value).then(a,l)}c((n=n.apply(r,[])).next())})}class ro{constructor(){this.name="",this.minZoom=0,this.maxZoom=20,this.bounds=[],this.center=[]}fetchTile(e,t,n){return null}getMetaData(){return rn(this,void 0,void 0,function*(){})}}class Kb extends ro{constructor(e="https://a.tile.openstreetmap.org/"){super(),this.address=e,this.format="png",this.maxZoom=19}fetchTile(e,t,n){return new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",o.src=this.address+e+"/"+t+"/"+n+"."+this.format})}}class dh{static createOffscreenCanvas(e,t){if(typeof OffscreenCanvas<"u")return new OffscreenCanvas(e,t);{let n=document.createElement("canvas");return n.width=e,n.height=t,n}}}class Ff{static createFillTexture(e="#000000",t=1,n=1){const i=dh.createOffscreenCanvas(t,n),s=i.getContext("2d");s.fillStyle=e,s.fillRect(0,0,t,n);const o=new Wt(i);return o.format=wn,o.magFilter=mn,o.minFilter=mn,o.generateMipmaps=!1,o.needsUpdate=!0,o}}class Yt{}Yt.root=-1;Yt.topLeft=0;Yt.topRight=1;Yt.bottomLeft=2;Yt.bottomRight=3;class Mn extends ve{constructor(e=null,t=null,n=Yt.root,i=0,s=0,o=0,a=null,l=null){super(a,l),this.mapView=null,this.parentNode=null,this.subdivided=!1,this.disposed=!1,this.nodesLoaded=0,this.childrenCache=null,this.isMesh=!0,this.mapView=t,this.parentNode=e,this.disposed=!1,this.location=n,this.level=i,this.x=s,this.y=o,this.initialize()}initialize(){return rn(this,void 0,void 0,function*(){})}createChildNodes(){}subdivide(){const e=this.mapView.maxZoom();this.children.length>0||this.level+1>e||this.parentNode!==null&&this.parentNode.nodesLoaded<Mn.childrens||(this.mapView.cacheTiles&&this.childrenCache!==null?(this.isMesh=!1,this.children=this.childrenCache,this.nodesLoaded=this.childrenCache.length):this.createChildNodes(),this.subdivided=!0)}simplify(){const e=this.mapView.minZoom();if(!(this.level-1<e)){if(this.mapView.cacheTiles)this.childrenCache=this.children;else for(let t=0;t<this.children.length;t++)this.children[t].dispose();this.subdivided=!1,this.isMesh=!0,this.children=[],this.nodesLoaded=0}}loadData(){return rn(this,void 0,void 0,function*(){if(this.level<this.mapView.provider.minZoom||this.level>this.mapView.provider.maxZoom){console.warn("Geo-Three: Loading tile outside of provider range.",this),this.material.map=Mn.defaultTexture,this.material.needsUpdate=!0;return}try{const e=yield this.mapView.provider.fetchTile(this.level,this.x,this.y);yield this.applyTexture(e)}catch{if(this.disposed)return;console.warn("Geo-Three: Failed to load node tile data.",this),this.material.map=Mn.defaultTexture}this.material.needsUpdate=!0})}applyTexture(e){return rn(this,void 0,void 0,function*(){if(this.disposed)return;const t=new Wt(e);parseInt(gs)>=152&&(t.colorSpace="srgb"),t.generateMipmaps=!1,t.format=wn,t.magFilter=mn,t.minFilter=mn,t.needsUpdate=!0,this.material.map=t})}nodeReady(){if(this.disposed){console.warn("Geo-Three: nodeReady() called for disposed node.",this),this.dispose();return}if(this.parentNode!==null){if(this.parentNode.nodesLoaded++,this.parentNode.nodesLoaded===Mn.childrens){this.parentNode.subdivided===!0&&(this.parentNode.isMesh=!1);for(let e=0;e<this.parentNode.children.length;e++)this.parentNode.children[e].visible=!0}this.parentNode.nodesLoaded>Mn.childrens&&console.error("Geo-Three: Loaded more children objects than expected.",this.parentNode.nodesLoaded,this)}else this.visible=!0}dispose(){this.disposed=!0;const e=this;try{const t=e.material;t.dispose(),t.map&&t.map!==Mn.defaultTexture&&t.map.dispose()}catch{}try{e.geometry.dispose()}catch{}}}Mn.defaultTexture=Ff.createFillTexture();Mn.baseGeometry=null;Mn.baseScale=null;Mn.childrens=4;class Bi extends yt{constructor(e=1,t=1,n=1,i=1,s=!1,o=10){super();const a=[],l=[],c=[],h=[];Bi.buildPlane(e,t,n,i,a,l,c,h),s&&Bi.buildSkirt(e,t,n,i,o,a,l,c,h),this.setIndex(a),this.setAttribute("position",new Ne(l,3)),this.setAttribute("normal",new Ne(c,3)),this.setAttribute("uv",new Ne(h,2))}static buildPlane(e=1,t=1,n=1,i=1,s,o,a,l){const c=e/2,h=t/2,u=n+1,d=i+1,f=e/n,g=t/i;for(let v=0;v<d;v++){const m=v*g-h;for(let p=0;p<u;p++){const w=p*f-c;o.push(w,0,m),a.push(0,1,0),l.push(p/n,1-v/i)}}for(let v=0;v<i;v++)for(let m=0;m<n;m++){const p=m+u*v,w=m+u*(v+1),y=m+1+u*(v+1),b=m+1+u*v;s.push(p,w,b,w,y,b)}}static buildSkirt(e=1,t=1,n=1,i=1,s,o,a,l,c){const h=e/2,u=t/2,d=n+1,f=i+1,g=e/n,v=t/i;let m=a.length/3;for(let w=0;w<d;w++){const y=w*g-h,b=-u;a.push(y,-s,b),l.push(0,1,0),c.push(w/n,1)}for(let w=0;w<n;w++){const y=w,b=w+1,D=w+m,R=w+m+1;o.push(b,D,y,b,R,D)}m=a.length/3;for(let w=0;w<d;w++){const y=w*g-h,b=i*v-u;a.push(y,-s,b),l.push(0,1,0),c.push(w/n,0)}let p=d*f-n-1;for(let w=0;w<n;w++){const y=p+w,b=p+w+1,D=w+m,R=w+m+1;o.push(y,D,b,D,R,b)}m=a.length/3;for(let w=0;w<f;w++){const y=w*v-u,b=-h;a.push(b,-s,y),l.push(0,1,0),c.push(0,1-w/i)}for(let w=0;w<i;w++){const y=w*f,b=(w+1)*f,D=w+m,R=w+m+1;o.push(y,D,b,D,R,b)}m=a.length/3;for(let w=0;w<f;w++){const y=w*v-u,b=n*g-h;a.push(b,-s,y),l.push(0,1,0),c.push(1,1-w/i)}for(let w=0;w<i;w++){const y=w*f+i,b=(w+1)*f+i,D=w+m,R=w+m+1;o.push(b,D,y,b,R,D)}}}class Hl{constructor(e,t){this.latitude=e,this.longitude=t}}class _t{static datumsToSpherical(e,t){const n=t*_t.EARTH_ORIGIN/180;let i=Math.log(Math.tan((90+e)*Math.PI/360))/(Math.PI/180);return i=i*_t.EARTH_ORIGIN/180,new ye(n,i)}static sphericalToDatums(e,t){const n=e/_t.EARTH_ORIGIN*180;let i=t/_t.EARTH_ORIGIN*180;return i=180/Math.PI*(2*Math.atan(Math.exp(i*Math.PI/180))-Math.PI/2),new Hl(i,n)}static quadtreeToDatums(e,t,n){const i=Math.pow(2,e),s=t/i*360-180,a=180*(Math.atan(Math.sinh(Math.PI*(1-2*n/i)))/Math.PI);return new Hl(a,s)}static vectorToDatums(e){const t=180/Math.PI,n=Math.atan2(e.y,Math.sqrt(Math.pow(e.x,2)+Math.pow(-e.z,2)))*t,i=Math.atan2(-e.z,e.x)*t;return new Hl(n,i)}static datumsToVector(e,t){const n=Math.PI/180,i=t*n,s=e*n;var o=Math.cos(s);return new L(-Math.cos(i+Math.PI)*o,Math.sin(s),Math.sin(i+Math.PI)*o)}static mapboxAltitude(e){return(e.r*255*65536+e.g*255*256+e.b*255)*.1-1e4}static getTileSize(e){const t=_t.WEB_MERCATOR_MAX_EXTENT,n=Math.pow(2,e);return 2*t/n}static tileBounds(e,t,n){const i=_t.getTileSize(e),s=-_t.WEB_MERCATOR_MAX_EXTENT+t*i,o=_t.WEB_MERCATOR_MAX_EXTENT-(n+1)*i;return[s,i,o,i]}static webMercatorToLatitude(e,t){const n=_t.WEB_MERCATOR_MAX_EXTENT-t*_t.getTileSize(e);return Math.atan(Math.sinh(n/_t.EARTH_RADIUS))}static webMercatorToLongitude(e,t){return(-_t.WEB_MERCATOR_MAX_EXTENT+t*_t.getTileSize(e))/_t.EARTH_RADIUS}}_t.EARTH_RADIUS=6371008;_t.EARTH_RADIUS_A=6378137;_t.EARTH_RADIUS_B=6356752314245e-6;_t.EARTH_PERIMETER=2*Math.PI*_t.EARTH_RADIUS;_t.EARTH_ORIGIN=_t.EARTH_PERIMETER/2;_t.WEB_MERCATOR_MAX_EXTENT=2003750834e-2;class Kn extends Mn{constructor(e=null,t=null,n=Yt.root,i=0,s=0,o=0){super(e,t,n,i,s,o,Kn.geometry,new zn({wireframe:!1})),this.matrixAutoUpdate=!1,this.isMesh=!0,this.visible=!1}initialize(){const e=Object.create(null,{initialize:{get:()=>super.initialize}});return rn(this,void 0,void 0,function*(){e.initialize.call(this),yield this.loadData(),this.nodeReady()})}createChildNodes(){const e=this.level+1,t=this.x*2,n=this.y*2,i=Object.getPrototypeOf(this).constructor;let s=new i(this,this.mapView,Yt.topLeft,e,t,n);s.scale.set(.5,1,.5),s.position.set(-.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new i(this,this.mapView,Yt.topRight,e,t+1,n),s.scale.set(.5,1,.5),s.position.set(.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new i(this,this.mapView,Yt.bottomLeft,e,t,n+1),s.scale.set(.5,1,.5),s.position.set(-.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new i(this,this.mapView,Yt.bottomRight,e,t+1,n+1),s.scale.set(.5,1,.5),s.position.set(.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0)}raycast(e,t){this.isMesh===!0&&super.raycast(e,t)}}Kn.geometry=new Bi(1,1,1,1,!1);Kn.baseGeometry=Kn.geometry;Kn.baseScale=new L(_t.EARTH_PERIMETER,1,_t.EARTH_PERIMETER);class $b extends yt{constructor(e=1,t=1,n=1,i=1,s=!1,o=10,a=null,l=!0){super();const c=[],h=[],u=[],d=[];Bi.buildPlane(e,t,n,i,c,h,u,d);const f=a.data;for(let g=0,v=0;g<f.length&&v<h.length;g+=4,v+=3){const m=f[g],p=f[g+1],w=f[g+2],y=(m*65536+p*256+w)*.1-1e4;h[v+1]=y}s&&Bi.buildSkirt(e,t,n,i,o,c,h,u,d),this.setIndex(c),this.setAttribute("position",new Ne(h,3)),this.setAttribute("normal",new Ne(u,3)),this.setAttribute("uv",new Ne(d,2)),l&&this.computeNormals(n,i)}computeNormals(e,t){const n=this.getAttribute("position");if(n!==void 0){let i=this.getAttribute("normal");const s=t*e;for(let v=0;v<s;v++)i.setXYZ(v,0,0,0);const o=new L,a=new L,l=new L,c=new L,h=new L,u=new L,d=new L,f=new L,g=t*e*6;for(let v=0;v<g;v+=3){const m=this.index.getX(v+0),p=this.index.getX(v+1),w=this.index.getX(v+2);o.fromBufferAttribute(n,m),a.fromBufferAttribute(n,p),l.fromBufferAttribute(n,w),d.subVectors(l,a),f.subVectors(o,a),d.cross(f),c.fromBufferAttribute(i,m),h.fromBufferAttribute(i,p),u.fromBufferAttribute(i,w),c.add(d),h.add(d),u.add(d),i.setXYZ(m,c.x,c.y,c.z),i.setXYZ(p,h.x,h.y,h.z),i.setXYZ(w,u.x,u.y,u.z)}this.normalizeNormals(),i.needsUpdate=!0}}}class oi extends Mn{constructor(e=null,t=null,n=Yt.root,i=0,s=0,o=0,a=oi.geometry,l=new kn({wireframe:!1,color:16777215})){super(e,t,n,i,s,o,a,l),this.heightLoaded=!1,this.textureLoaded=!1,this.geometrySize=16,this.geometryNormals=!1,this.isMesh=!0,this.visible=!1,this.matrixAutoUpdate=!1}initialize(){const e=Object.create(null,{initialize:{get:()=>super.initialize}});return rn(this,void 0,void 0,function*(){e.initialize.call(this),yield this.loadData(),yield this.loadHeightGeometry(),this.nodeReady()})}loadData(){const e=Object.create(null,{loadData:{get:()=>super.loadData}});return rn(this,void 0,void 0,function*(){yield e.loadData.call(this),this.textureLoaded=!0})}loadHeightGeometry(){return rn(this,void 0,void 0,function*(){if(this.mapView.heightProvider===null)throw new Error("GeoThree: MapView.heightProvider provider is null.");if(this.level<this.mapView.heightProvider.minZoom||this.level>this.mapView.heightProvider.maxZoom){console.warn("Geo-Three: Loading tile outside of provider range.",this),this.geometry=Kn.baseGeometry;return}try{const e=yield this.mapView.heightProvider.fetchTile(this.level,this.x,this.y);if(this.disposed)return;const t=dh.createOffscreenCanvas(this.geometrySize+1,this.geometrySize+1),n=t.getContext("2d");n.imageSmoothingEnabled=!1,n.drawImage(e,0,0,oi.tileSize,oi.tileSize,0,0,t.width,t.height);const i=n.getImageData(0,0,t.width,t.height);this.geometry=new $b(1,1,this.geometrySize,this.geometrySize,!0,10,i,!0)}catch{if(this.disposed)return;this.geometry=Kn.baseGeometry}this.heightLoaded=!0})}createChildNodes(){const e=this.level+1,t=Object.getPrototypeOf(this).constructor,n=this.x*2,i=this.y*2;let s=new t(this,this.mapView,Yt.topLeft,e,n,i);s.scale.set(.5,1,.5),s.position.set(-.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new t(this,this.mapView,Yt.topRight,e,n+1,i),s.scale.set(.5,1,.5),s.position.set(.25,0,-.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new t(this,this.mapView,Yt.bottomLeft,e,n,i+1),s.scale.set(.5,1,.5),s.position.set(-.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0),s=new t(this,this.mapView,Yt.bottomRight,e,n+1,i+1),s.scale.set(.5,1,.5),s.position.set(.25,0,.25),this.add(s),s.updateMatrix(),s.updateMatrixWorld(!0)}raycast(e,t){this.isMesh===!0&&super.raycast(e,t)}}oi.tileSize=256;oi.geometry=new Bi(1,1,1,1);oi.baseGeometry=Kn.geometry;oi.baseScale=new L(_t.EARTH_PERIMETER,1,_t.EARTH_PERIMETER);class Of extends yt{constructor(e,t,n,i,s,o,a){super();const l=o+a;let c=0;const h=[],u=new L,d=new L,f=[],g=[],v=[],m=[];for(let p=0;p<=n;p++){const w=[],y=p/n;for(let b=0;b<=t;b++){const D=b/t;u.x=-e*Math.cos(i+D*s)*Math.sin(o+y*a),u.y=e*Math.cos(o+y*a),u.z=e*Math.sin(i+D*s)*Math.sin(o+y*a),g.push(u.x,u.y,u.z),d.set(u.x,u.y,u.z).normalize(),v.push(d.x,d.y,d.z),m.push(D,1-y),w.push(c++)}h.push(w)}for(let p=0;p<n;p++)for(let w=0;w<t;w++){const y=h[p][w+1],b=h[p][w],D=h[p+1][w],R=h[p+1][w+1];(p!==0||o>0)&&f.push(y,b,R),(p!==n-1||l<Math.PI)&&f.push(b,D,R)}this.setIndex(f),this.setAttribute("position",new Ne(g,3)),this.setAttribute("normal",new Ne(v,3)),this.setAttribute("uv",new Ne(m,2))}}class ws extends Mn{constructor(e=null,t=null,n=Yt.root,i=0,s=0,o=0){let a=_t.tileBounds(i,s,o);const l=`
		varying vec3 vPosition;

		void main() {
			vPosition = position;
			gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
		}
		`,c=`
		#define PI 3.1415926538
		varying vec3 vPosition;
		uniform sampler2D uTexture;
		uniform vec4 webMercatorBounds;

		void main() {
			// this could also be a constant, but for some reason using a constant causes more visible tile gaps at high zoom
			float radius = length(vPosition);

			float latitude = asin(vPosition.y / radius);
			float longitude = atan(-vPosition.z, vPosition.x);

			float web_mercator_x = radius * longitude;
			float web_mercator_y = radius * log(tan(PI / 4.0 + latitude / 2.0));
			float y = (web_mercator_y - webMercatorBounds.z) / webMercatorBounds.w;
			float x = (web_mercator_x - webMercatorBounds.x) / webMercatorBounds.y;

			vec4 color = texture2D(uTexture, vec2(x, y));
			gl_FragColor = color;
			${parseInt(gs)<152?"":`
				#include <tonemapping_fragment>
				#include ${parseInt(gs)>=154?"<colorspace_fragment>":"<encodings_fragment>"}
				`}
		}
		`;let h=new at(...a);const u=new _i({uniforms:{uTexture:{value:new Wt},webMercatorBounds:{value:h}},vertexShader:l,fragmentShader:c});super(e,t,n,i,s,o,ws.createGeometry(i,s,o),u),this.applyScaleNode(),this.matrixAutoUpdate=!1,this.isMesh=!0,this.visible=!1}initialize(){const e=Object.create(null,{initialize:{get:()=>super.initialize}});return rn(this,void 0,void 0,function*(){e.initialize.call(this),yield this.loadData(),this.nodeReady()})}static createGeometry(e,t,n){const i=Math.pow(2,e),s=40,o=Math.floor(ws.segments*(s/(e+1))/s),a=t>0?_t.webMercatorToLongitude(e,t)+Math.PI:0,l=t<i-1?_t.webMercatorToLongitude(e,t+1)+Math.PI:2*Math.PI,c=a,h=l-a,u=n>0?_t.webMercatorToLatitude(e,n):Math.PI/2,d=n<i-1?_t.webMercatorToLatitude(e,n+1):-Math.PI/2,f=u-d,g=Math.PI-(u+Math.PI/2);return new Of(1,o,o,c,h,g,f)}applyTexture(e){return rn(this,void 0,void 0,function*(){const n=new Ia().load(e.src,function(){parseInt(gs)>=152&&(n.colorSpace="srgb")});this.material.uniforms.uTexture.value=n,this.material.uniforms.uTexture.needsUpdate=!0})}applyScaleNode(){this.geometry.computeBoundingBox();const t=this.geometry.boundingBox.clone().getCenter(new L),n=new Ee;n.compose(new L(-t.x,-t.y,-t.z),new St,new L(_t.EARTH_RADIUS,_t.EARTH_RADIUS,_t.EARTH_RADIUS)),this.geometry.applyMatrix4(n),this.position.copy(t),this.updateMatrix(),this.updateMatrixWorld()}updateMatrix(){this.matrix.setPosition(this.position),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e=!1){(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorld.copy(this.matrix),this.matrixWorldNeedsUpdate=!1)}createChildNodes(){const e=this.level+1,t=this.x*2,n=this.y*2,i=Object.getPrototypeOf(this).constructor;let s=new i(this,this.mapView,Yt.topLeft,e,t,n);this.add(s),s=new i(this,this.mapView,Yt.topRight,e,t+1,n),this.add(s),s=new i(this,this.mapView,Yt.bottomLeft,e,t,n+1),this.add(s),s=new i(this,this.mapView,Yt.bottomRight,e,t+1,n+1),this.add(s)}raycast(e,t){this.isMesh===!0&&super.raycast(e,t)}}ws.baseGeometry=new Of(_t.EARTH_RADIUS,64,64,0,2*Math.PI,0,Math.PI);ws.baseScale=new L(1,1,1);ws.segments=80;class bn extends oi{constructor(e=null,t=null,n=Yt.root,i=0,s=0,o=0){const a=bn.prepareMaterial(new kn({map:Mn.defaultTexture,color:16777215}));super(e,t,n,i,s,o,bn.geometry,a),this.frustumCulled=!1}static prepareMaterial(e){return e.userData={heightMap:{value:bn.defaultHeightTexture}},e.onBeforeCompile=t=>{for(const n in e.userData)t.uniforms[n]=e.userData[n];t.vertexShader=`
			uniform sampler2D heightMap;
			`+t.vertexShader,t.vertexShader=t.vertexShader.replace("#include <fog_vertex>",`
			#include <fog_vertex>
	
			// Calculate height of the title
			vec4 _theight = texture2D(heightMap, vUv);
			float _height = ((_theight.r * 255.0 * 65536.0 + _theight.g * 255.0 * 256.0 + _theight.b * 255.0) * 0.1) - 10000.0;
			vec3 _transformed = position + _height * normal;
	
			// Vertex position based on height
			gl_Position = projectionMatrix * modelViewMatrix * vec4(_transformed, 1.0);
			`)},e}loadData(){const e=Object.create(null,{loadData:{get:()=>super.loadData}});return rn(this,void 0,void 0,function*(){yield e.loadData.call(this),this.textureLoaded=!0})}loadHeightGeometry(){return rn(this,void 0,void 0,function*(){if(this.mapView.heightProvider===null)throw new Error("GeoThree: MapView.heightProvider provider is null.");if(this.level<this.mapView.heightProvider.minZoom||this.level>this.mapView.heightProvider.maxZoom){console.warn("Geo-Three: Loading tile outside of provider range.",this),this.material.map=bn.defaultTexture,this.material.needsUpdate=!0;return}try{const e=yield this.mapView.heightProvider.fetchTile(this.level,this.x,this.y);if(this.disposed)return;const t=new Wt(e);t.generateMipmaps=!1,t.format=wn,t.magFilter=gn,t.minFilter=gn,t.needsUpdate=!0,this.material.userData.heightMap.value=t}catch{if(this.disposed)return;console.error("Geo-Three: Failed to load node tile height data.",this),this.material.userData.heightMap.value=bn.defaultHeightTexture}this.material.needsUpdate=!0,this.heightLoaded=!0})}raycast(e,t){this.isMesh===!0&&(this.geometry=Kn.geometry,super.raycast(e,t),this.geometry=bn.geometry)}dispose(){super.dispose(),this.material.userData.heightMap.value&&this.material.userData.heightMap.value!==bn.defaultHeightTexture&&this.material.userData.heightMap.value.dispose()}}bn.defaultHeightTexture=Ff.createFillTexture("#0186C0");bn.geometrySize=256;bn.geometry=new Bi(1,1,bn.geometrySize,bn.geometrySize,!0);bn.baseGeometry=Kn.geometry;bn.baseScale=new L(_t.EARTH_PERIMETER,1,_t.EARTH_PERIMETER);class Jb{constructor(){this.subdivisionRays=1,this.thresholdUp=.6,this.thresholdDown=.15,this.raycaster=new Ua,this.mouse=new ye,this.powerDistance=!1,this.scaleDistance=!0}updateLOD(e,t,n,i){const s=[];for(let o=0;o<this.subdivisionRays;o++){this.mouse.set(Math.random()*2-1,Math.random()*2-1),this.raycaster.setFromCamera(this.mouse,t);let a=[];this.raycaster.intersectObjects(e.children,!0,a),a.length>0&&s.push(a[0])}for(let o=0;o<s.length;o++){const a=s[o].object;let l=s[o].distance;if(this.powerDistance&&(l=Math.pow(l*2,a.level)),this.scaleDistance){const c=a.matrixWorld.elements;l=new L(c[0],c[1],c[2]).length()/l}l>this.thresholdUp?a.subdivide():l<this.thresholdDown&&a.parentNode&&a.parentNode.simplify()}}}class Qb{constructor(e=257){this.gridSize=e;const t=e-1;if(t&t-1)throw new Error(`Expected grid size to be 2^n+1, got ${e}.`);this.numTriangles=t*t*2-2,this.numParentTriangles=this.numTriangles-t*t,this.indices=new Uint32Array(this.gridSize*this.gridSize),this.coords=new Uint16Array(this.numTriangles*4);for(let n=0;n<this.numTriangles;n++){let i=n+2,s=0,o=0,a=0,l=0,c=0,h=0;for(i&1?a=l=c=t:s=o=h=t;(i>>=1)>1;){const d=s+a>>1,f=o+l>>1;i&1?(a=s,l=o,s=c,o=h):(s=a,o=l,a=c,l=h),c=d,h=f}const u=n*4;this.coords[u+0]=s,this.coords[u+1]=o,this.coords[u+2]=a,this.coords[u+3]=l}}createTile(e){return new eM(e,this)}}class eM{constructor(e,t){const n=t.gridSize;if(e.length!==n*n)throw new Error(`Expected terrain data of length ${n*n} (${n} x ${n}), got ${e.length}.`);this.terrain=e,this.martini=t,this.errors=new Float32Array(e.length),this.update()}update(){const{numTriangles:e,numParentTriangles:t,coords:n,gridSize:i}=this.martini,{terrain:s,errors:o}=this;for(let a=e-1;a>=0;a--){const l=a*4,c=n[l+0],h=n[l+1],u=n[l+2],d=n[l+3],f=c+u>>1,g=h+d>>1,v=f+g-h,m=g+c-f,p=(s[h*i+c]+s[d*i+u])/2,w=g*i+f,y=Math.abs(p-s[w]);if(o[w]=Math.max(o[w],y),a<t){const b=(h+m>>1)*i+(c+v>>1),D=(d+m>>1)*i+(u+v>>1);o[w]=Math.max(o[w],o[b],o[D])}}}getMesh(e=0,t=!1){const{gridSize:n,indices:i}=this.martini,{errors:s}=this;let o=0,a=0;const l=n-1;let c,h,u=0;const d=[],f=[],g=[],v=[];i.fill(0);function m(P,M,_,x,T,F){const k=P+_>>1,G=M+x>>1;Math.abs(P-T)+Math.abs(M-F)>1&&s[G*n+k]>e?(m(T,F,P,M,k,G),m(_,x,T,F,k,G)):(c=M*n+P,h=x*n+_,u=F*n+T,i[c]===0&&(t&&(P===0?d.push(o):P===l&&f.push(o),M===0?g.push(o):M===l&&v.push(o)),i[c]=++o),i[h]===0&&(t&&(_===0?d.push(o):_===l&&f.push(o),x===0?g.push(o):x===l&&v.push(o)),i[h]=++o),i[u]===0&&(t&&(T===0?d.push(o):T===l&&f.push(o),F===0?g.push(o):F===l&&v.push(o)),i[u]=++o),a++)}m(0,0,l,l,l,0),m(l,l,0,0,0,l);let p=o*2,w=a*3;t&&(p+=(d.length+f.length+g.length+v.length)*2,w+=((d.length-1)*2+(f.length-1)*2+(g.length-1)*2+(v.length-1)*2)*3);const y=new Uint16Array(p),b=new Uint32Array(w);let D=0;function R(P,M,_,x,T,F){const k=P+_>>1,G=M+x>>1;if(Math.abs(P-T)+Math.abs(M-F)>1&&s[G*n+k]>e)R(T,F,P,M,k,G),R(_,x,T,F,k,G);else{const K=i[M*n+P]-1,z=i[x*n+_]-1,Z=i[F*n+T]-1;y[2*K]=P,y[2*K+1]=M,y[2*z]=_,y[2*z+1]=x,y[2*Z]=T,y[2*Z+1]=F,b[D++]=K,b[D++]=z,b[D++]=Z}}if(R(0,0,l,l,l,0),R(l,l,0,0,0,l),t){let M=function(_){const x=_.length;for(let T=0;T<x-1;T++){const F=_[T],k=_[T+1],G=P/2,K=(P+2)/2;y[P++]=y[2*F],y[P++]=y[2*F+1],b[D++]=F,b[D++]=G,b[D++]=k,b[D++]=G,b[D++]=K,b[D++]=k}y[P++]=y[2*_[x-1]],y[P++]=y[2*_[x-1]+1]};d.sort((_,x)=>y[2*_+1]-y[2*x+1]),f.sort((_,x)=>y[2*x+1]-y[2*_+1]),g.sort((_,x)=>y[2*x]-y[2*_]),v.sort((_,x)=>y[2*_]-y[2*x]);let P=o*2;M(d),M(f),M(g),M(v)}return{vertices:y,triangles:b,numVerticesWithoutSkirts:o}}}class Wn extends oi{constructor(e=null,t=null,n=Yt.root,i=0,s=0,o=0,{elevationDecoder:a=null,meshMaxError:l=10,exageration:c=1}={}){super(e,t,n,i,s,o,Wn.geometry,Wn.prepareMaterial(new kn({map:Wn.emptyTexture,color:16777215,side:Xn}),i,c)),this.elevationDecoder={rScaler:256,gScaler:1,bScaler:1/256,offset:-32768},this.exageration=1,this.meshMaxError=10,a&&(this.elevationDecoder=a),this.meshMaxError=l,this.exageration=c,this.frustumCulled=!1}static prepareMaterial(e,t,n=1){return e.userData={heightMap:{value:Wn.emptyTexture},drawNormals:{value:0},drawBlack:{value:0},zoomlevel:{value:t},computeNormals:{value:1},drawTexture:{value:1}},e.onBeforeCompile=i=>{for(let s in e.userData)i.uniforms[s]=e.userData[s];i.vertexShader=`
				uniform bool computeNormals;
				uniform float zoomlevel;
				uniform sampler2D heightMap;
				`+i.vertexShader,i.fragmentShader=`
				uniform bool drawNormals;
				uniform bool drawTexture;
				uniform bool drawBlack;
				`+i.fragmentShader,i.fragmentShader=i.fragmentShader.replace("#include <dithering_fragment>",`
				if(drawBlack) {
					gl_FragColor = vec4( 0.0,0.0,0.0, 1.0 );
				} else if(drawNormals) {
					gl_FragColor = vec4( ( 0.5 * vNormal + 0.5 ), 1.0 );
				} else if (!drawTexture) {
					gl_FragColor = vec4( 0.0,0.0,0.0, 0.0 );
				}`),i.vertexShader=i.vertexShader.replace("#include <fog_vertex>",`
				#include <fog_vertex>

				// queried pixels:
				// +-----------+
				// |   |   |   |
				// | a | b | c |
				// |   |   |   |
				// +-----------+
				// |   |   |   |
				// | d | e | f |
				// |   |   |   |
				// +-----------+
				// |   |   |   |
				// | g | h | i |
				// |   |   |   |
				// +-----------+

				if (computeNormals) {
					float e = getElevation(vUv, 0.0);
					ivec2 size = textureSize(heightMap, 0);
					float offset = 1.0 / float(size.x);
					float a = getElevation(vUv + vec2(-offset, -offset), 0.0);
					float b = getElevation(vUv + vec2(0, -offset), 0.0);
					float c = getElevation(vUv + vec2(offset, -offset), 0.0);
					float d = getElevation(vUv + vec2(-offset, 0), 0.0);
					float f = getElevation(vUv + vec2(offset, 0), 0.0);
					float g = getElevation(vUv + vec2(-offset, offset), 0.0);
					float h = getElevation(vUv + vec2(0, offset), 0.0);
					float i = getElevation(vUv + vec2(offset,offset), 0.0);


					float normalLength = 500.0 / zoomlevel;

					vec3 v0 = vec3(0.0, 0.0, 0.0);
					vec3 v1 = vec3(0.0, normalLength, 0.0);
					vec3 v2 = vec3(normalLength, 0.0, 0.0);
					v0.z = (e + d + g + h) / 4.0;
					v1.z = (e+ b + a + d) / 4.0;
					v2.z = (e+ h + i + f) / 4.0;
					vNormal = (normalize(cross(v2 - v0, v1 - v0))).rbg;
				}
				`)},e}static getTerrain(e,t,n){const{rScaler:i,bScaler:s,gScaler:o,offset:a}=n,l=t+1,c=new Float32Array(l*l);for(let h=0,u=0;u<t;u++)for(let d=0;d<t;d++,h++){const f=h*4,g=e[f+0],v=e[f+1],m=e[f+2];c[h+u]=g*i+v*o+m*s+a}for(let h=l*(l-1),u=0;u<l-1;u++,h++)c[h]=c[h-l];for(let h=l-1,u=0;u<l;u++,h+=l)c[h]=c[h-1];return c}static getMeshAttributes(e,t,n,i,s){const o=n+1,a=e.length/2,l=new Float32Array(a*3),c=new Float32Array(a*2),[h,u,d,f]=i||[0,0,n,n],g=(d-h)/n,v=(f-u)/n;for(let m=0;m<a;m++){const p=e[m*2],w=e[m*2+1],y=w*o+p;l[3*m+0]=p*g+h,l[3*m+1]=-t[y]*s,l[3*m+2]=-w*v+f,c[2*m+0]=p/n,c[2*m+1]=w/n}return{position:{value:l,size:3},uv:{value:c,size:2}}}processHeight(e){return rn(this,void 0,void 0,function*(){const t=e.width,n=t+1;var i=dh.createOffscreenCanvas(t,t),s=i.getContext("2d");s.imageSmoothingEnabled=!1,s.drawImage(e,0,0,t,t,0,0,i.width,i.height);var o=s.getImageData(0,0,i.width,i.height),a=o.data;const l=Wn.getTerrain(a,t,this.elevationDecoder),h=new Qb(n).createTile(l),{vertices:u,triangles:d}=h.getMesh(typeof this.meshMaxError=="function"?this.meshMaxError(this.level):this.meshMaxError),f=Wn.getMeshAttributes(u,l,t,[-.5,-.5,.5,.5],this.exageration);this.geometry=new yt,this.geometry.setIndex(new Kc(d,1)),this.geometry.setAttribute("position",new Ne(f.position.value,f.position.size)),this.geometry.setAttribute("uv",new Ne(f.uv.value,f.uv.size)),this.geometry.rotateX(Math.PI);var g=new Wt(e);g.generateMipmaps=!1,g.format=wn,g.magFilter=gn,g.minFilter=gn,g.needsUpdate=!0,this.material.userData.heightMap.value=g,this.material.map=g,this.material.needsUpdate=!0})}loadHeightGeometry(){return rn(this,void 0,void 0,function*(){if(this.mapView.heightProvider===null)throw new Error("GeoThree: MapView.heightProvider provider is null.");const e=yield this.mapView.heightProvider.fetchTile(this.level,this.x,this.y);this.disposed||(this.processHeight(e),this.heightLoaded=!0,this.nodeReady())})}}Wn.geometrySize=16;Wn.emptyTexture=new Wt;Wn.geometry=new Bi(1,1,1,1);Wn.tileSize=256;class pn extends ve{constructor(e=pn.PLANAR,t=new Kb,n=null){super(void 0,new zn({transparent:!0,opacity:0,depthWrite:!1,colorWrite:!1})),this.lod=null,this.provider=null,this.heightProvider=null,this.root=null,this.cacheTiles=!1,this.onBeforeRender=(i,s,o,a,l,c)=>{this.lod.updateLOD(this,o,i,s)},this.lod=new Jb,this.provider=t,this.heightProvider=n,this.setRoot(e),this.preSubdivide()}setRoot(e){if(typeof e=="number"){if(!pn.mapModes.has(e))throw new Error("Map mode "+e+" does is not registered.");const t=pn.mapModes.get(e);e=new t(null,this)}this.root!==null&&(this.remove(this.root),this.root=null),this.root=e,this.root!==null&&(this.geometry=this.root.constructor.baseGeometry,this.scale.copy(this.root.constructor.baseScale),this.root.mapView=this,this.add(this.root),this.root.initialize())}preSubdivide(){var e,t;function n(s,o){if(!(o<=0)){s.subdivide();for(let a=0;a<s.children.length;a++)if(s.children[a]instanceof Mn){const l=s.children[a];n(l,o-1)}}}const i=Math.max(this.provider.minZoom,(t=(e=this.heightProvider)===null||e===void 0?void 0:e.minZoom)!==null&&t!==void 0?t:-1/0);i>0&&n(this.root,i)}setProvider(e){e!==this.provider&&(this.provider=e,this.clear())}setHeightProvider(e){e!==this.heightProvider&&(this.heightProvider=e,this.clear())}clear(){return this.traverse(function(e){e.childrenCache&&(e.childrenCache=null),e.initialize&&e.initialize()}),this}minZoom(){var e,t;return Math.max(this.provider.minZoom,(t=(e=this.heightProvider)===null||e===void 0?void 0:e.minZoom)!==null&&t!==void 0?t:-1/0)}maxZoom(){var e,t;return Math.min(this.provider.maxZoom,(t=(e=this.heightProvider)===null||e===void 0?void 0:e.maxZoom)!==null&&t!==void 0?t:1/0)}getMetaData(){this.provider.getMetaData()}raycast(e,t){return!1}}pn.PLANAR=200;pn.SPHERICAL=201;pn.HEIGHT=202;pn.HEIGHT_SHADER=203;pn.MARTINI=204;pn.mapModes=new Map([[pn.PLANAR,Kn],[pn.SPHERICAL,ws],[pn.HEIGHT,oi],[pn.HEIGHT_SHADER,bn],[pn.MARTINI,Wn]]);new L;new L;new Ee;new L;new Pa;new L;class Bf{static get(e){return rn(this,void 0,void 0,function*(){return new Promise(function(t,n){const i=new XMLHttpRequest;i.overrideMimeType("text/plain"),i.open("GET",e,!0),i.onload=function(){t(i.response)},i.onerror=n,i.send(null)})})}static getRaw(e){return rn(this,void 0,void 0,function*(){return new Promise(function(t,n){var i=new XMLHttpRequest;i.responseType="arraybuffer",i.open("GET",e,!0),i.onload=function(){t(i.response)},i.onerror=n,i.send(null)})})}static request(e,t,n,i,s,o,a){function l(h){try{return JSON.parse(h)}catch{return h}}const c=new XMLHttpRequest;if(c.overrideMimeType("text/plain"),c.open(t,e,!0),n!=null)for(const h in n)c.setRequestHeader(h,n[h]);return s!==void 0&&(c.onload=function(h){s(l(c.response),c)}),o!==void 0&&(c.onerror=o),a!==void 0&&(c.onprogress=a),c.send(i!==void 0?i:null),c}}class gi extends ro{constructor(e="",t=gi.AERIAL){super(),this.maxZoom=19,this.minZoom=1,this.format="jpeg",this.mapSize=512,this.subdomain="t1",this.meta=null,this.apiKey=e,this.type=t}getMetaData(){return rn(this,void 0,void 0,function*(){const e=gi.ADDRESS+"/REST/V1/Imagery/Metadata/RoadOnDemand?output=json&include=ImageryProviders&key="+this.apiKey,t=yield Bf.get(e);this.meta=JSON.parse(t)})}static quadKey(e,t,n){let i="";for(let s=e;s>0;s--){const o=1<<s-1;let a=0;(t&o)!==0&&a++,(n&o)!==0&&(a+=2),i+=a}return i}fetchTile(e,t,n){return new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",o.src="http://ecn."+this.subdomain+".tiles.virtualearth.net/tiles/"+this.type+gi.quadKey(e,t,n)+".jpeg?g=1173"})}}gi.ADDRESS="https://dev.virtualearth.net";gi.AERIAL="a";gi.ROAD="r";gi.AERIAL_LABELS="h";gi.OBLIQUE="o";gi.OBLIQUE_LABELS="b";class tM extends ro{constructor(e="",t="",n="base",i="normal.day",s="png",o=512){super(),this.appId=e,this.appCode=t,this.style=n,this.scheme=i,this.format=s,this.size=o,this.version="newest",this.server=1}nextServer(){this.server=this.server%4===0?1:this.server+1}getMetaData(){return rn(this,void 0,void 0,function*(){})}fetchTile(e,t,n){return this.nextServer(),new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",o.src="https://"+this.server+"."+this.style+".maps.api.here.com/maptile/2.1/maptile/"+this.version+"/"+this.scheme+"/"+e+"/"+t+"/"+n+"/"+this.size+"/"+this.format+"?app_id="+this.appId+"&app_code="+this.appCode})}}tM.PATH="/maptile/2.1/";class Pi extends ro{constructor(e="",t="",n=Pi.STYLE,i="png",s=!1,o="v4"){super(),this.apiToken=e,this.format=i,this.useHDPI=s,this.mode=n,this.mapId=t,this.style=t,this.version=o}getMetaData(){return rn(this,void 0,void 0,function*(){const e=Pi.ADDRESS+this.version+"/"+this.mapId+".json?access_token="+this.apiToken,t=yield Bf.get(e),n=JSON.parse(t);this.name=n.name,this.minZoom=n.minZoom,this.maxZoom=n.maxZoom,this.bounds=n.bounds,this.center=n.center})}fetchTile(e,t,n){return new Promise((i,s)=>{const o=document.createElement("img");o.onload=function(){i(o)},o.onerror=function(){s()},o.crossOrigin="Anonymous",this.mode===Pi.STYLE?o.src=Pi.ADDRESS+"styles/v1/"+this.style+"/tiles/"+e+"/"+t+"/"+n+(this.useHDPI?"@2x?access_token=":"?access_token=")+this.apiToken:o.src=Pi.ADDRESS+"v4/"+this.mapId+"/"+e+"/"+t+"/"+n+(this.useHDPI?"@2x.":".")+this.format+"?access_token="+this.apiToken})}}Pi.ADDRESS="https://api.mapbox.com/";Pi.STYLE=100;Pi.MAP_ID=101;class nM extends ro{mapName;constructor(){super()}fetchTile(e,t,n){if(this.mapName)return new Promise((i,s)=>{const o=document.createElement("img");o.onload=()=>i(o),o.onerror=()=>s(),o.crossOrigin="anonymous",o.src=`${Vf}/api/map/tiles/${this.mapName}/${e}/${t}/${n}`})}setMapName(e){this.mapName=e}}class iM{tileProvider;mapView;editor;constructor(e){const t=new nM;t.minZoom=0,t.maxZoom=25;const n=new pn(pn.PLANAR,t);n.position.set(0,-.2,-0),this.editor=e,this.mapView=n,this.tileProvider=t}dispose=()=>{this.deregisterEventListeners()};handleMapName=e=>{this.tileProvider.setMapName(e)};registerEventListeners=()=>{const e=this.editor.eventHandler.eventBus;e.on("setTileVisibility",this.handleToggleTile),e.on("updatemapNameData",this.handleMapName)};deregisterEventListeners=()=>{const e=this.editor.eventHandler.eventBus;e.off("setTileVisibility",this.handleToggleTile),e.off("updatemapNameData",this.handleMapName)};handleToggleTile=e=>{e?this.addToScene():this.removeToScene()};addToScene=()=>{this.editor.scene.add(this.mapView)};removeToScene=()=>{this.editor.scene.remove(this.mapView)}}class sM extends wt{constructor(){super(),this.name="S100Helper",this.userData.keep=!0,this.visible=!1,this._init()}updatePosition(e){const t=this.parent.worldToLocal(e.clone());this.position.copy(t)}updateRotation(e){const t=this.parent.worldToLocal(e.clone()),n=t.x-this.position.x,i=t.y-this.position.y;this.rotation.z=Math.atan2(i,n)}_init(){const e=new Af,t=Ba("/s100low.fbx");new Promise((n,i)=>{e.load(t,s=>{s.traverse(a=>{if(a.userData.keep=!0,a instanceof ve){const l=a.material;Array.isArray(l)&&(a.material=l.map(()=>new Kr({color:new ke(12436423),transparent:!0,opacity:.3})))}}),s.scale.setScalar(.1),s.rotation.set(Math.PI/2,0,0),s.updateMatrixWorld(!0),s.userData.keep=!0;const o=new rh(10);o.userData.keep=!0,o.rotation.x=-Math.PI/2,s.add(o),n(s)},void 0,s=>{console.error(s),i(s)})}).then(n=>{this.add(n)}).catch(n=>{console.error("Failed to load s100 model:",n)})}}const Qr=new Qt(50,1,.01,1e3);Qr.name="Camera";Qr.position.set(0,20,0);Qr.lookAt(new L);class or{static instance;env="prod";nodeManager;eventHandler;robotManager;selector;eraser;pathDrawer;pointsManager;scene;sceneHelpers;zUpGroup;camera;viewportCamera;_selected;selectableObjects;selectedObjects;previewHelper;globalPlane;lidarPoints;lidarPointsGeometry;lidarPointsMaterial;cloudPoints;cloudPointsGeometry;cloudPointsMaterial;cloudPointsData;tileMap;constructor(){this._selected=null,this.nodeManager=new Pb(this),this.eventHandler=new Cb(this),this.robotManager=new Yb(this),this.selector=new Zb(this),this.eraser=new Ab(this),this.pathDrawer=new Ub(this),this.pointsManager=new Ob(this),this.tileMap=new iM(this)}static getInstance(){return or.instance||(or.instance=new or),or.instance}get selected(){return this._selected}set selected(e){this._selected=e}async initialize(){this.scene=new Rc,this.sceneHelpers=new Rc,this.zUpGroup=new wt,this.zUpGroup.rotation.x=-Math.PI/2,this.zUpGroup.name="zUpGroup",this.zUpGroup.userData.keep=!0,this.scene.add(this.zUpGroup),this.camera=Qr.clone(),this.viewportCamera=this.camera;const e=new xr(1e4,1e4),t=new zn({visible:!1}),n=new ve(e,t);n.name="globalPlane",n.userData.keep=!0,this.globalPlane=n,this.zUpGroup.add(this.globalPlane),this.lidarPointsGeometry=new yt,this.lidarPointsMaterial=new ps({size:.2,color:16725342}),this.lidarPoints=new Vr(this.lidarPointsGeometry,this.lidarPointsMaterial),this.lidarPoints.userData.keep=!0,this.zUpGroup.add(this.lidarPoints),this.cloudPointsGeometry=new yt,this.cloudPointsGeometry.setAttribute("position",new Ne([],3)),this.cloudPointsMaterial=new ps({size:.15,vertexColors:!0,transparent:!0,opacity:1}),this.cloudPoints=new Vr(this.cloudPointsGeometry,this.cloudPointsMaterial),this.cloudPoints.userData.keep=!0,this.zUpGroup.add(this.cloudPoints),this.cloudPointsData=[];const i=new th(16777215);i.userData.keep=!0,this.scene.add(i);const s=new Ea(16777215);s.userData.keep=!0,s.position.set(0,1e4,0),this.scene.add(s);const o=new Ea(16777215);o.userData.keep=!0,o.position.set(0,-1e4,0),this.scene.add(o),this.sceneHelpers.add(new cg(16777215,8947848,2)),this.selectableObjects=[],this.selectedObjects=[],this.eventHandler.registerEventListeners(),this.eventHandler.registerCanvasEventListeners(),this.selector.registerEventListeners(),this.pointsManager.registerEventListeners(),this.tileMap.registerEventListeners(),this.eraser.registerEventListeners(),this.nodeManager.cacheMeshes(),this.setupPreviewHelper(),this.eventHandler.eventBus.emit("editor:initialized")}addOrigin(e){const t=new to(.1),n=new zn({color:16711680}),i=new ve(t,n);i.name="origin";const s=new rh(e);i.add(s),this.zUpGroup.add(i)}clear(e={clearCloud:!0,clearTopo:!0}){e.clearCloud&&this.pointsManager.clearCloud(),e.clearTopo&&this.clearTopo()}resetCamera(){this.camera.copy(Qr),this.eventHandler.eventBus.emit("cameraReset")}clearTopo(){const e=[];this.zUpGroup.traverse(t=>{t instanceof Oa&&t.userData.labelType==="node"?(t.element&&t.element.parentNode&&t.element.parentNode.removeChild(t.element),e.push(t)):t.userData.keep||e.push(t)});for(let t=0,n=e.length;t<n;t++){const i=e[t];this.removeObject(i)}this.resetSelections(),this.eventHandler.eventBus.emit("topoCleared")}resetSelections(){this.selected=null,this.selectableObjects=[],this.selectedObjects=[]}dispose(){for(this.eventHandler.dispose(),this.eraser.dispose(),this.pathDrawer.dispose(),this.robotManager.dispose(),this.selector.dispose(),this.pointsManager.dispose(),this.tileMap.dispose(),this.scene.traverse(e=>{e instanceof ve&&(e.geometry&&e.geometry.dispose(),e.material&&Array.isArray(e.material)&&e.material.forEach(t=>{t.dispose()}))});this.scene.children.length>0;)this.scene.remove(this.scene.children[0])}async drawTopo(e){if(!e||!e.length)return;const t=e.map((n,i)=>{const s=n.pose.split(",").map(Number),o={x:s[0],y:s[1],z:s[2],rz:s[5],idx:i},a={name:n.name,id:n.id,info:n.info,rz:o.rz};if(n.type===ms.GOAL)return this.nodeManager.addNode("GOAL",o,a);if(n.type===ms.ROUTE)return this.nodeManager.addNode("ROUTE",o,a);if(n.type===ms.INIT)return this.nodeManager.addNode("INIT",o,a)});await Promise.all(t);for(let n=0,i=e.length;n<i;n++){const s=e[n],o=this.zUpGroup.getObjectByName(s.name);for(let a=0;a<s.links.length;a++){const l=s.links[a],c=this.getObjectBySlamId(l);o&&c&&this.nodeManager.linkNodes(o,c)}}}getObjectBySlamId(e){let t=null;return this.zUpGroup.traverse(n=>{n.userData.id===e&&(t=n)}),t}removeObject(e){e.parent!==null&&(e.parent.remove(e),this.eventHandler.eventBus.emit("objectRemoved",{object:e,label:e.children[0]}))}setupPreviewHelper(){const e=new sM;this.previewHelper=e,this.zUpGroup.add(this.previewHelper)}}class rM extends ib{constructor(e,t){super(e,t);const n=document.createElement("div");n.id="viewHelper",n.style.position="absolute",n.style.right=`${window.innerWidth-t.clientWidth}px`,n.style.bottom="0px",n.style.height="128px",n.style.width="128px",n.addEventListener("pointerup",i=>{i.stopPropagation(),this.handleClick(i)}),n.addEventListener("pointerdown",function(i){i.stopPropagation()}),t.appendChild(n)}}var Wr=function(){var r=0,e=document.createElement("div");e.style.cssText="position:fixed;top:0;left:0;cursor:pointer;opacity:0.9;z-index:10000",e.addEventListener("click",function(h){h.preventDefault(),n(++r%e.children.length)},!1);function t(h){return e.appendChild(h.dom),h}function n(h){for(var u=0;u<e.children.length;u++)e.children[u].style.display=u===h?"block":"none";r=h}var i=(performance||Date).now(),s=i,o=0,a=t(new Wr.Panel("FPS","#0ff","#002")),l=t(new Wr.Panel("MS","#0f0","#020"));if(self.performance&&self.performance.memory)var c=t(new Wr.Panel("MB","#f08","#201"));return n(0),{REVISION:16,dom:e,addPanel:t,showPanel:n,begin:function(){i=(performance||Date).now()},end:function(){o++;var h=(performance||Date).now();if(l.update(h-i,200),h>=s+1e3&&(a.update(o*1e3/(h-s),100),s=h,o=0,c)){var u=performance.memory;c.update(u.usedJSHeapSize/1048576,u.jsHeapSizeLimit/1048576)}return h},update:function(){i=this.end()},domElement:e,setMode:n}};Wr.Panel=function(r,e,t){var n=1/0,i=0,s=Math.round,o=s(window.devicePixelRatio||1),a=80*o,l=48*o,c=3*o,h=2*o,u=3*o,d=15*o,f=74*o,g=30*o,v=document.createElement("canvas");v.width=a,v.height=l,v.style.cssText="width:80px;height:48px";var m=v.getContext("2d");return m.font="bold "+9*o+"px Helvetica,Arial,sans-serif",m.textBaseline="top",m.fillStyle=t,m.fillRect(0,0,a,l),m.fillStyle=e,m.fillText(r,c,h),m.fillRect(u,d,f,g),m.fillStyle=t,m.globalAlpha=.9,m.fillRect(u,d,f,g),{dom:v,update:function(p,w){n=Math.min(n,p),i=Math.max(i,p),m.fillStyle=t,m.globalAlpha=1,m.fillRect(0,0,a,d),m.fillStyle=e,m.fillText(s(p)+" "+r+" ("+s(n)+"-"+s(i)+")",c,h),m.drawImage(v,u+o,d,f-o,g,u,d,f-o,g),m.fillRect(u+f-o,d,o,g),m.fillStyle=t,m.globalAlpha=.9,m.fillRect(u+f-o,d,o,s((1-p/w)*g))}}};const bd=new ye,Md=new ye,Vl=new ye;let Js=null,wd=0;const oM=200,aM=3,Sd=new ye,Ed=new ye,oa=new Cn,Yi=new ye,Qs=new ye,lM=[0,1,2],cM=.15,Td=[1,3,6,12,20,40],aa=["text-7xl","text-5xl","text-4xl","text-base","text-sm","text-xs","hidden"];class hM{editor;_renderCSS2D;container;scene;sceneHelpers;camera;renderer;css2DRenderer;robotPos=new L;robotQuat=new St;lookOffset=new L;robotForward=new L;PRIMARY_MOUSE_BUTTON=0;tmpView=new L;control;arcball;orbit;transformControls;viewHelper;selectionBox;boxSelectHelper;labels;clock;grid;stats;interactionTimer;constructor(e,t){this.editor=e,this._renderCSS2D=!1,this.scene=e.scene,this.sceneHelpers=e.sceneHelpers,this.camera=e.camera,this.labels=[],this.clock=new mg;const n=document.querySelector("#three-canvas");this.renderer=new cy({canvas:n,antialias:!0});const i=document.querySelector(`#${t}-canvas__wrapper`);this.container=i,this.stats=[],this.editor.env==="dev"&&lM.forEach(h=>{const u=new Wr;u.showPanel(h),u.dom.style.position="absolute",u.dom.style.top="",u.dom.style.bottom="10px",u.dom.style.left=`${100+h*100}px`,this.container.appendChild(u.dom),this.stats.push(u)}),this.renderer.domElement.addEventListener("pointerdown",this.onPointerDown),this.renderer.setClearColor(3355443),this.renderer.setPixelRatio(window.devicePixelRatio),this.renderer.setSize(i.clientWidth,i.clientHeight),this.renderer.setAnimationLoop(this.animate),n.tabIndex=0,n.style.outline="none",this.camera instanceof Qt&&(this.camera.aspect=n.clientWidth/n.clientHeight,this.camera.updateProjectionMatrix()),this.css2DRenderer=new Tb,this.css2DRenderer.setSize(n.clientWidth,n.clientHeight),this.css2DRenderer.domElement.style.position="absolute",this.css2DRenderer.domElement.style.top=`${n.parentElement?.offsetTop}px`,this.css2DRenderer.domElement.style.pointerEvents="none",n.parentElement?.appendChild(this.css2DRenderer.domElement),this.control="orbit",this.orbit=new uy(this.editor.camera,this.renderer.domElement),this.orbit.mouseButtons={LEFT:Ni.PAN,MIDDLE:Ni.DOLLY,RIGHT:Ni.ROTATE},this.orbit.touches={ONE:$i.PAN,TWO:$i.DOLLY_ROTATE},this.orbit.panSpeed=.75,this.orbit.rotateSpeed=.75,this.orbit.zoomSpeed=.5,this.orbit.enableRotate=!0,this.orbit.maxPolarAngle=Math.PI/2,this.orbit.zoomToCursor=!0,this.orbit.addEventListener("change",this.handleOrbitChange),this.transformControls=new Sy(this.camera,this.renderer.domElement),this.transformControls.addEventListener("dragging-changed",h=>{this.orbit.enabled=!h.value}),this.transformControls.addEventListener("objectChange",this.handleTransformChange),this.transformControls.addEventListener("object-changed",this.handleTransformChange);const s=this.transformControls.getHelper();this.sceneHelpers.add(s),this.viewHelper=new rM(this.camera,i),this.viewHelper.center=this.orbit.target,this.selectionBox=new Tg(oa),this.selectionBox.material.depthTest=!1,this.selectionBox.material.transparent=!0,this.selectionBox.visible=!1,this.sceneHelpers.add(this.selectionBox),this.boxSelectHelper=document.createElement("div"),this.boxSelectHelper.style.position="absolute",this.boxSelectHelper.style.border="1px dashed #ffffff",this.boxSelectHelper.style.background="rgba(255, 255, 255, 0.1)",this.boxSelectHelper.style.pointerEvents="none",document.body.appendChild(this.boxSelectHelper);const o=[5592405,8947848],a=new wt;a.rotation.x=-Math.PI/2;const l=new gu(50,50);l.material.color.setHex(o[0]),l.material.vertexColors=!1,l.rotateX(Math.PI/2),a.add(l);const c=new gu(50,10);c.material.color.setHex(o[1]),c.material.vertexColors=!1,c.rotateX(Math.PI/2),a.add(c),this.grid=a,this.grid.visible=!1,this.render(),this.registerEventListeners()}get renderCSS2D(){return this._renderCSS2D}set renderCSS2D(e){this._renderCSS2D=e}animate=e=>{const t=this.clock.getDelta();this.viewHelper.animating===!0&&this.viewHelper.update(t);const n=e*.001-cM;this.editor.robotManager.updateAll(n),this.control==="follow"&&this.alignCameraToRobotView(),this.render(),this.editor.env==="dev"&&this.stats.forEach(i=>i.update())};registerEventListeners(){const e=this.editor.eventHandler.eventBus;e.on("cameraReset",this.handleCameraReset),e.on("objectSelected",this.handleObjectSelected),e.on("objectsSelected",this.handleObjectsSelected),e.on("objectTransformChanged",this.handleObjectTransformChanged),e.on("changeSelectMode",this.handleChangeSelectMode),e.on("cloudCleared",this.handleCloudCleared),e.on("objectRemoved",this.handleObjectRemoved),e.on("setGridVisibility",this.handleSetGridVisibility),e.on("controlChanged",this.handleControlChanged),e.on("toggleTransformAxisY",this.handleToggleTransformAxisY),e.on("setLocalizationMode",this.handleSetLocalizationMode),e.on("setLabelVisibility",this.handleSetLabelVisibility),e.on("labelAdded",this.handleLabelAdded),e.on("setTransformControlsEnable",this.handleSetTransformControlsEnable),window.addEventListener("resize",this.resizeWindow)}deregisterEventListeners(){const e=this.editor.eventHandler.eventBus;e.off("cameraReset",this.handleCameraReset),e.off("objectSelected",this.handleObjectSelected),e.off("objectsSelected",this.handleObjectsSelected),e.off("objectTransformChanged",this.handleObjectTransformChanged),e.off("changeSelectMode",this.handleChangeSelectMode),e.off("cloudCleared",this.handleCloudCleared),e.off("objectRemoved",this.handleObjectRemoved),e.off("setGridVisibility",this.handleSetGridVisibility),e.off("controlChanged",this.handleControlChanged),e.off("toggleTransformAxisY",this.handleToggleTransformAxisY),e.off("setLocalizationMode",this.handleSetLocalizationMode),e.off("setLabelVisibility",this.handleSetLabelVisibility),e.off("labelAdded",this.handleLabelAdded),e.off("setTransformControlsEnable",this.handleSetTransformControlsEnable),window.removeEventListener("resize",this.resizeWindow)}dispose(){this.editor.env==="dev"&&this.stats.forEach(t=>t.dom.remove()),this.renderer.setAnimationLoop(null),this.renderer.dispose(),this.css2DRenderer.domElement.remove();const e=document.getElementById("viewHelper");e&&e.remove(),this.renderer.domElement.removeEventListener("pointerdown",this.onPointerDown),this.orbit.dispose(),this.deregisterEventListeners()}handleSetTransformControlsEnable=e=>{if(!e){this.selectionBox.visible=!1,this.transformControls.detach();const t=this.editor.selectableObjects;for(let n=0;n<t.length;n++){const i=t[n];i.material.opacity=1}}this.transformControls.enabled=e};handleLabelAdded=e=>{this.labels.push(e)};handleSetLabelVisibility=e=>{this.renderCSS2D=e,this.resizeLabels(),this.css2DRenderer.domElement.style.display=this.renderCSS2D?"":"none";const t=this.editor.selectableObjects;for(let n=0;n<t.length;n++)t[n].traverse(s=>{s instanceof Oa&&(s.visible=e)})};handleSetLocalizationMode=e=>{e?(this.editor.previewHelper.visible=!0,this.transformControls.setMode("rotate"),this.transformControls.showX=!1,this.transformControls.showY=!0,this.transformControls.showZ=!1,this.transformControls.attach(this.editor.previewHelper)):(this.editor.previewHelper.visible=!1,this.transformControls.setMode("translate"),this.transformControls.showX=!0,this.transformControls.showY=!1,this.transformControls.showZ=!0,this.transformControls.detach()),this.orbit.update()};render=()=>{this.renderer.render(this.editor.scene,this.editor.viewportCamera),this.renderCSS2D&&this.css2DRenderer.render(this.editor.scene,this.editor.viewportCamera),this.renderer.autoClear=!1,this.renderer.render(this.grid,this.editor.viewportCamera),this.viewHelper.render(this.renderer),this.sceneHelpers.visible&&this.renderer.render(this.sceneHelpers,this.editor.viewportCamera),this.renderer.autoClear=!0};resizeWindow=()=>{const e=this.editor.camera,n=this.renderer.domElement.parentNode;e instanceof Qt&&(e.aspect=n.clientWidth/n.clientHeight,e.updateProjectionMatrix(),this.renderer.setSize(n.clientWidth,n.clientHeight),this.css2DRenderer.setSize(n.clientWidth,n.clientHeight))};depthToBucket(e){for(let t=0;t<Td.length;t++)if(e<Td[t])return t;return aa.length-1}resizeLabels=()=>{const{camera:e,labels:t,tmpView:n}=this;e.updateMatrixWorld();const i=e.matrixWorldInverse;for(const s of t){s.worldPosition||(s.worldPosition=new L,s.obj.getWorldPosition(s.worldPosition)),n.copy(s.worldPosition).applyMatrix4(i);const o=Math.abs(n.z),a=this.depthToBucket(o);if(a!==s.bucket){const l=s.obj.element;s.bucket!==null?l.classList.replace(aa[s.bucket],aa[a]):l.classList.add(aa[a]),s.bucket=a}}};alignCameraToRobotView(){this.editor.robotManager.mainRobot&&(this.setCameraPosition(),this.setCameraOrientation())}getRobotWorldPose(){const e=this.editor.robotManager.mainRobot;return e.getWorldPosition(this.robotPos),e.getWorldQuaternion(this.robotQuat),{pos:this.robotPos,quat:this.robotQuat}}computeShoulderOffset(e){return this.lookOffset.set(-4,0,2).applyQuaternion(e)}setCameraPosition(){const{pos:e,quat:t}=this.getRobotWorldPose(),n=this.computeShoulderOffset(t);this.camera.position.copy(e).add(n)}setCameraOrientation(){const{pos:e,quat:t}=this.getRobotWorldPose(),n=this.robotForward.set(1,0,0).applyQuaternion(t);this.camera.lookAt(e.clone().add(n.multiplyScalar(10)))}getNormalizedPos(e,t){const n=this.renderer.domElement.getBoundingClientRect();return[(e-n.left)/n.width,(t-n.top)/n.height]}onPointerDown=e=>{wd=performance.now(),e.preventDefault(),e.target===this.renderer.domElement&&(this.renderer.domElement.setPointerCapture(e.pointerId),Js=e.pointerId,bd.fromArray(this.getNormalizedPos(e.clientX,e.clientY)),Sd.set(e.clientX,e.clientY),e.pointerType==="mouse"&&this.editor.selector.mode==="box"&&e.button===0&&(Yi.set(e.clientX,e.clientY),Object.assign(this.boxSelectHelper.style,{left:`${Yi.x}px`,top:`${Yi.y}px`,width:"0px",height:"0px",display:"block"})),this.renderer.domElement.addEventListener("pointermove",this.onPointerMove,{passive:!1}),this.renderer.domElement.addEventListener("pointerup",this.onPointerUp),this.renderer.domElement.addEventListener("pointercancel",this.onPointerUp))};onPointerMove=e=>{if(!(e.pointerId!==Js||(e.preventDefault(),Md.fromArray(this.getNormalizedPos(e.clientX,e.clientY)),!this.editor.selector.getPointerPlaneIntersection(Md,this.editor.camera).length))&&e.pointerType==="mouse"&&e.buttons===1&&this.editor.selector.mode==="box"){Qs.set(e.clientX,e.clientY);const n=Math.min(Yi.x,Qs.x),i=Math.min(Yi.y,Qs.y),s=Math.abs(Qs.x-Yi.x),o=Math.abs(Qs.y-Yi.y);Object.assign(this.boxSelectHelper.style,{left:`${n}px`,top:`${i}px`,width:`${s}px`,height:`${o}px`})}};finishPointer=()=>{this.renderer.domElement.removeEventListener("pointermove",this.onPointerMove),this.renderer.domElement.removeEventListener("pointerup",this.onPointerUp),this.renderer.domElement.removeEventListener("pointercancel",this.onPointerUp),Js!==null&&(this.renderer.domElement.releasePointerCapture(Js),Js=null),this.boxSelectHelper.style.display="none"};onPointerUp=e=>{if(e.pointerId!==Js)return;Vl.fromArray(this.getNormalizedPos(e.clientX,e.clientY)),Ed.set(e.clientX,e.clientY);const t=e.pointerType==="mouse"&&e.button===this.PRIMARY_MOUSE_BUTTON,n=e.pointerType==="touch";(t||n)&&this.handlePrimaryPointerAction(),this.finishPointer()};handlePrimaryPointerAction=()=>{const e=performance.now()-wd,t=Sd.distanceToSquared(Ed),n=Math.pow(aM*devicePixelRatio,2);e<oM&&t<=n?this.editor.eraser.enabled?this.handleErase():this.editor.previewHelper.visible?this.updatePreviewOnPointer():this.transformControls.enabled&&this.handleSelect():this.editor.selector.mode==="box"&&this.handleBoxSelect(),this.render()};handleErase=()=>{const e=this.editor.selector.getPointerQuadTreeIntersections(Vl,this.editor.camera);this.editor.eventHandler.eventBus.emit("eraser:intersectionsDetected",e)};updatePreviewOnPointer=()=>{const e=this.editor.selector.getPointerPlaneIntersection(bd,this.editor.camera);e.length&&(this.editor.previewHelper.updatePosition(e[0].point),this.transformControls.attach(this.editor.previewHelper))};handleSelect=()=>{const e=this.editor.selector.getPointerObjectIntersections(Vl,this.editor.camera);this.editor.eventHandler.eventBus.emit("intersectionsDetected",e)};handleCameraReset=()=>{const e=this.renderer.domElement;this.camera instanceof Qt&&(this.camera.aspect=e.clientWidth/e.clientHeight,this.camera.updateProjectionMatrix(),this.orbit.target.set(0,0,0))};handleBoxSelect=()=>{this.boxSelectHelper.style.display="none";const e=this.editor.selector.getSelectionBoxIntersects(this.renderer.domElement,Yi,Qs);e.length&&this.editor.eventHandler.eventBus.emit("boxIntersectionsDetected",e)};handleTransformChange=()=>{if(this.transformControls.object){const e=Pt.radToDeg(this.transformControls.object.rotation.z);this.editor.eventHandler.eventBus.emit("objectTransformChanged",{x:this.transformControls.object.position.x.toString().slice(0,6),y:this.transformControls.object.position.y.toString().slice(0,6),rz:e.toString().slice(0,6)})}else this.editor.eventHandler.eventBus.emit("objectTransformChanged",null)};handleObjectSelected=e=>{this.selectionBox.visible=!1,this.transformControls.detach();const t=e.object;if(t!==null){oa.setFromObject(t,!0),oa.isEmpty()||(this.selectionBox.visible=!0);const n=t.material;n.opacity=.4,this.transformControls.attach(t)}else{const n=this.editor.selectableObjects;for(let i=0;i<n.length;i++){const s=n[i];s.material.opacity=1}}};handleObjectsSelected=e=>{const t=e.selectedObjects;for(let n=0;n<t.length;n++){const s=t[n].material;s.opacity=.4}};handleObjectTransformChanged=()=>{if(this.editor.nodeManager.updateLinks(),this.editor.selected){oa.setFromObject(this.editor.selected,!0);const e=this.editor.selected.children[0];if(e){if(!this.renderCSS2D)return;clearTimeout(this.interactionTimer),this.interactionTimer=setTimeout(()=>{const t=this.labels.find(n=>n.obj===e);t.worldPosition=new L,t.obj.getWorldPosition(t.worldPosition),this.resizeLabels()},200)}}};handleChangeSelectMode=e=>{e==="box"?this.orbit.enablePan=!1:(this.orbit.enablePan=!0,this.boxSelectHelper.style.display="none")};handleCloudCleared=()=>{this.selectionBox.visible=!1,this.transformControls.detach()};handleObjectRemoved=e=>{if(!e.label)return;const t=e.label,n=this.labels.findIndex(i=>i.obj===t);n>-1&&this.labels.splice(n,1),this.selectionBox.visible=!1,this.transformControls.detach()};handleSetGridVisibility=e=>{this.grid.visible=e};handleControlChanged=e=>{e==="orbit"?this.activateOrbitMode():e==="follow"&&this.activateFollowMode()};activateOrbitMode(){this.orbit.enabled=!0;const{pos:e}=this.getRobotWorldPose();this.orbit.target.copy(e);const t=this.editor.robotManager.mainRobot,n=new vi;new Cn().setFromObject(t).getBoundingSphere(n);const i=n.radius||1,s=this.camera.position.clone().sub(this.orbit.target).normalize(),o=Pt.clamp(i*15,this.orbit.minDistance+.1,this.orbit.maxDistance-.1);this.camera.position.copy(this.orbit.target).addScaledVector(s,o),this.orbit.update(),this.control="orbit"}activateFollowMode(){this.orbit.enabled=!1,this.control="follow"}handleToggleTransformAxisY=e=>{this.transformControls.showY=e};handleOrbitChange=()=>{this.renderCSS2D&&(clearTimeout(this.interactionTimer),this.interactionTimer=setTimeout(()=>{this.resizeLabels()},200))}}const uM=({className:r})=>ga("div",{className:Pd("absolute z-50 flex justify-center items-center w-full h-full text-5xl text-white bg-[#333]",r),children:ga(Gf,{size:"3rem"})}),{forwardRef:dM,useEffect:er,useImperativeHandle:fM,useMemo:pM,useRef:Ad,useState:Rd,useCallback:Cd}=await jf("react"),mM=dM(({className:r,parameters:e,onSelectChange:t,onLoadingChange:n},i)=>{const[s,o]=Rd(!1),[a,l]=Rd(!1),c=Ad(or.getInstance()).current,h=Wf(),u=qf(),d=Ad(c.eventHandler.eventBus).current,f=!s||!a,g=pM(()=>({clear(){c.clear({clearCloud:!0,clearTopo:!0})},deleteNodes(){c.selectedObjects.forEach(p=>{c.removeObject(p)})},deletePoints(){d.emit("eraser:deletePoints")},getAnnotationData(){return c.selectableObjects.map(p=>{const y=p.position.toArray().map(M=>M.toString().slice(0,6)).toString(),D=p.rotation.toArray().slice(0,3).map(M=>(M*(180/Math.PI)).toString().slice(0,6)).toString(),R=`${y},${D}`,P=p.userData.slamLinks;return{id:p.userData.id,name:p.name,pose:R,info:p.userData.info,links:P,type:p.userData.type}})},getCloudPointsData(){return c.cloudPointsData},getPreviewHelperTransformData(){const p=c.previewHelper;return{x:p.position.x.toString(),y:p.position.y.toString(),z:p.position.z.toString(),rz:(p.rotation.z*(180/Math.PI)).toString()}},linkSelectedNodesBidirectionally(){const p=c.selectedObjects;if(p.length>1)for(let w=0;w<p.length-1;w++){const y=p[w],b=p[w+1];c.nodeManager.linkNodes(y,b),c.nodeManager.linkNodes(b,y)}},quickAddNode(){c.eventHandler.eventBus.emit("quickAddNode")},setControlMode(p){c.eventHandler.eventBus.emit("controlChanged",p)},setLabelVisibility(p){d.emit("setLabelVisibility",p)},setLocalizationMode(p){d.emit("setLocalizationMode",p)},setGridVisibility(p){c.eventHandler.eventBus.emit("setGridVisibility",p)},setTileVisibility(p){c.eventHandler.eventBus.emit("setTileVisibility",p)},setTransformControlsEnable(p){d.emit("setTransformControlsEnable",p)},toggleEraser(p){d.emit("eraser:toggled",p)},toggleLidarVisibility(){c.lidarPoints.visible=!c.lidarPoints.visible},unselectPoints(){d.emit("eraser:unselectPoints")},updateCloudData(p){p===void 0?c.clear({clearCloud:!0,clearTopo:!1}):c.eventHandler.eventBus.emit("cloudLoaded",p)},updateTopoData(p){p===void 0?c.clear({clearCloud:!1,clearTopo:!0}):c.eventHandler.eventBus.emit("topoLoaded",{reset:!1,topoData:p})},updateMapNameData(p){p&&c.eventHandler.eventBus.emit("updatemapNameData",p)}}),[c,d]);fM(i,()=>g,[g]);const v=Cd(async()=>{o(!0)},[]),m=Cd(async()=>{setTimeout(()=>{l(!0)},300)},[]);return er(()=>{console.log("====== EDITOR INIT ======"),d.on("editor:initialized",v),d.on("robotmanager:mainrobot:loaded",m),c.initialize();const p=new hM(c,"editor");return()=>{c.dispose(),p.dispose(),d.off("editor:initialized",v),d.off("robotmanager:mainrobot:loaded",m),console.log("====== EDITOR DISPOSED ======")}},[c,d,v,m]),er(()=>{s&&(c.robotManager.loadMainRobot(e.robot),d.emit("setGridVisibility",e.isGridVisible),d.emit("toggleTransformAxisY",e.useAxisY))},[s]),er(()=>{if(t)return c.eventHandler.eventBus.on("objectSelected",t),()=>{c.eventHandler.eventBus.off("objectSelected",t)}},[c,t]),er(()=>{if(u?.data){const p={x:parseFloat(u.pose.x),y:parseFloat(u.pose.y),rz:parseFloat(u.pose.rz)*Math.PI/180};c.eventHandler.eventBus.emit("lidarUpdated",{lidarPoints:u.data,pose:p})}},[c,u]),er(()=>{const p=c.robotManager.mainRobot;p&&h.pose&&p.applyPose(h.pose)},[c,h]),er(()=>{n&&n(f)},[f,n]),Xf("div",{id:"editor-canvas__wrapper",className:Pd("h-full w-full",r),children:[(!s||!a)&&ga(uM,{}),ga("canvas",{id:"three-canvas"})]})});mM.displayName="EditorComponent";class yM extends wt{centerToLegX=.19725;centerToLegY=.09;centerToHipX=.11493;hipToThigh=.10285;thighToKnee=.3;kneeToFoot=.294;rearRightLeg;rearLeftLeg;frontRightLeg;frontLeftLeg;constructor(){super(),this.name="RBQ10_Robot",this.userData.keep=!0,this.init()}loadObj(e){return new Promise((t,n)=>{new Sb().load(e,s=>t(s),void 0,s=>n(s))})}init(){const t=["fuselage","leg3","hip1","hip3","thigh_right","thigh_left","calf","foot"].map(n=>{const i=Ba(`/rbq10/${n}.obj`);return this.loadObj(i).then(s=>({name:n,obj:s}))});Promise.all(t).then(n=>{const i={};n.forEach(o=>{i[o.name]=o.obj}),this.name="rbq10";const s=i.fuselage.clone();s.name="fuselage",this.add(s),this.rotateX(Pt.degToRad(90)),this.rearRightLeg=this.createRearRightLeg(i),this.rearRightLeg.position.set(-this.centerToLegX,0,this.centerToLegY),this.add(this.rearRightLeg),this.rearLeftLeg=this.createRearLeftLeg(i),this.rearLeftLeg.position.set(-this.centerToLegX,0,-this.centerToLegY),this.add(this.rearLeftLeg),this.frontRightLeg=this.createFrontRightLeg(i),this.frontRightLeg.position.set(this.centerToLegX,0,this.centerToLegY),this.add(this.frontRightLeg),this.frontLeftLeg=this.createFrontLeftLeg(i),this.frontLeftLeg.position.set(this.centerToLegX,0,-this.centerToLegY),this.add(this.frontLeftLeg)}).catch(n=>{console.error("Error loading robot parts:",n)})}createRearRightLeg(e){const t=new wt;t.name="rearRightLegGroup";const n=e.leg3.clone();n.name="rearRightLegReducer",t.add(n);const i=new wt;i.name="rearRightHipGroup",i.position.set(-this.centerToHipX,0,0);const s=e.hip3.clone();s.name="rearRightHipMesh",s.rotateY(Pt.degToRad(180)),i.add(s),t.add(i);const o=new wt;o.name="rearRightThighGroup",o.position.set(0,0,this.hipToThigh);const a=e.thigh_right.clone();a.name="rearRightThighMesh",o.add(a),i.add(o);const l=new wt;l.name="rearRightCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="rearRightCalfMesh",l.add(c),o.add(l);const h=new wt;h.name="rearRightFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="rearRightFootMesh",h.add(u),l.add(h),t}createRearLeftLeg(e){const t=new wt;t.name="rearLeftLegGroup";const n=e.leg3.clone();n.name="rearLeftLegReducer",t.add(n);const i=new wt;i.name="rearLeftHipGroup",i.position.set(-this.centerToHipX,0,0);const s=e.hip1.clone();s.name="rearLeftHipMesh",i.add(s),t.add(i);const o=new wt;o.name="rearLeftThighGroup",o.position.set(0,0,-this.hipToThigh);const a=e.thigh_left.clone();a.name="rearLeftThighMesh",o.add(a),i.add(o);const l=new wt;l.name="rearLeftCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="rearLeftCalfMesh",l.add(c),o.add(l);const h=new wt;h.name="rearLeftFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="rearLeftFootMesh",h.add(u),l.add(h),t}createFrontRightLeg(e){const t=new wt;t.name="frontRightLegGroup";const n=e.leg3.clone();n.name="frontRightLegReducer",t.add(n);const i=new wt;i.name="frontRightHipGroup",i.position.set(this.centerToHipX,0,0);const s=e.hip1.clone();s.name="frontRightHipMesh",s.rotateY(Pt.degToRad(180)),i.add(s),t.add(i);const o=new wt;o.name="frontRightThighGroup",o.position.set(0,0,this.hipToThigh);const a=e.thigh_right.clone();a.name="frontRightThighMesh",o.add(a),i.add(o);const l=new wt;l.name="frontRightCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="frontRightCalfMesh",l.add(c),o.add(l);const h=new wt;h.name="frontRightFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="frontRightFootMesh",h.add(u),l.add(h),t}createFrontLeftLeg(e){const t=new wt;t.name="frontLeftLegGroup";const n=e.leg3.clone();n.name="frontLeftLegReducer",t.add(n);const i=new wt;i.name="frontLeftHipGroup",i.position.set(this.centerToHipX,0,0);const s=e.hip3.clone();s.name="frontLeftHipMesh",i.add(s),t.add(i);const o=new wt;o.name="frontLeftThighGroup",o.position.set(0,0,-this.hipToThigh);const a=e.thigh_left.clone();a.name="frontLeftThighMesh",o.add(a),i.add(o);const l=new wt;l.name="frontLeftCalfGroup",l.position.set(0,-this.thighToKnee,0);const c=e.calf.clone();c.name="frontLeftCalfMesh",l.add(c),o.add(l);const h=new wt;h.name="frontLeftFootGroup",h.position.set(0,-this.kneeToFoot,0);const u=e.foot.clone();return u.name="frontLeftFootMesh",h.add(u),l.add(h),t}update(){}}export{or as Editor,mM as EditorComponent,Ab as Eraser,Cb as EventHandler,Pb as NodeManager,Ub as PathDrawer,yM as RBQ10,Yb as RobotManager,Zb as Selector,hM as Viewport};
