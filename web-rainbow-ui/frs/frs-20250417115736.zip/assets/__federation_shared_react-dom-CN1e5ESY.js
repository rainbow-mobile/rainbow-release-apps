import{g as r}from"./index-zCPSE6if.js";import{r as o}from"./index-CjeWTpq4.js";var t=o();const m=r(t);export{m as default};
