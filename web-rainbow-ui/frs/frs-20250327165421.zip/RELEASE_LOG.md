# Release log

## [frs-20250327105340] - 2025-03-27
- [App: frs, Version: frs-20250327105340] release 배포


## [frs-20250327101836] - 2025-03-27
- [App: frs, Version: frs-20250327101836] release 배포


## [frs-20250327101016] - 2025-03-27
- [App: frs, Version: frs-20250327101016] release 배포


## [frs-20250326213351] - 2025-03-26
- [App: frs, Version: frs-20250326213351] release 배포


## [frs-20250326193504] - 2025-03-26
- [App: frs, Version: frs-20250326193504] release 배포


## [frs-20250326193050] - 2025-03-26
- [App: frs, Version: frs-20250326193050] release 배포


## [frs-20250326192528] - 2025-03-26
- [App: frs, Version: frs-20250326192528] release 배포


## [frs-20250326191337] - 2025-03-26
- [App: frs, Version: frs-20250326191337] release 배포


## [frs-20250326190724] - 2025-03-26
- [App: frs, Version: frs-20250326190724] release 배포


## [frs-20250326185555] - 2025-03-26
- [App: frs, Version: frs-20250326185555] release 배포


## [frs-RBQ-dev-20250326180411] - 2025-03-26
- [App: frs, Service: RBQ-dev, Version: frs-RBQ-dev-20250326180411] release 배포

