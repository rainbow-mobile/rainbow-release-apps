export declare class MoveCommandDto {
    command: string;
    goal_id: string;
    method: string;
    preset: string;
    x: string;
    y: string;
    z: string;
    rz: string;
    vx: string;
    vy: string;
    wz: string;
    time: string;
}
