export declare class MoveModule {
}
