export declare class PresetDto {
    LIMIT_V: string;
    LIMIT_W: string;
    LIMIT_V_ACC: string;
    LIMIT_W_ACC: string;
    LIMIT_PIVOT_W: string;
    ST_V: string;
    ED_V: string;
    DRIVE_T: string;
    DRIVE_H: string;
    DRIVE_A: string;
    DRIVE_B: string;
    DRIVE_L: string;
    DRIVE_K: string;
    DRIVE_EPS: string;
}
