export declare class SettingModule {
}
