import { SocketGateway } from '@sockets/gateway/sockets.gateway';
export declare class SSHService {
    private readonly socketGateway;
    constructor(socketGateway: SocketGateway);
}
