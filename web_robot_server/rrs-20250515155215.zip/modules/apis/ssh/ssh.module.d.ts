export declare class SSHModule {
}
