export declare class CommandDto {
    command: string;
}
