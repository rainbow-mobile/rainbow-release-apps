export declare class InfluxDBModule {
}
