export declare class SoundModule {
}
