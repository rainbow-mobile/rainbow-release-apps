export declare class SoundPlayDto {
    fileNm: string;
    volume: number;
    waitDone: boolean;
    repeat: boolean;
}
