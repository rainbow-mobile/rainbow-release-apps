export declare class OnvifDeviceModule {
}
