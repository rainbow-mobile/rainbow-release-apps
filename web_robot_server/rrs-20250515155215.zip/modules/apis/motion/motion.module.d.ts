export declare class MotionModule {
}
