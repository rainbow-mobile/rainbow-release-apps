export declare class NetworkModule {
}
