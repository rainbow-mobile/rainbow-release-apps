export declare class NetworkDto {
    name: string;
    device: string;
    ip: string;
    gateway: string;
    mask: string;
    dns: string[];
}
