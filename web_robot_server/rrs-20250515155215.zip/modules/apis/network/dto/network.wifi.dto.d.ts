export declare class NetworkWifiDto {
    ssid: string;
    password: string;
}
