export declare class TaskSaveDto {
    data: [];
}
