export declare class DownloadMapDto {
    name: string;
    userId: string;
    token: string;
}
