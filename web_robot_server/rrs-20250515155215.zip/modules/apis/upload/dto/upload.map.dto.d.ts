export declare class UploadMapDto {
    name: string;
    mapNm: string;
}
