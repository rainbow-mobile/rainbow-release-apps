export declare class LidarControlDto {
    command: string;
    frequency: number;
}
