export declare class LocalizationDto {
    command: string;
    x: string;
    y: string;
    z: string;
    rz: string;
}
