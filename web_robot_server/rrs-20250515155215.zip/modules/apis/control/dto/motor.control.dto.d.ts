export declare class MotorControlDto {
    command: string;
}
