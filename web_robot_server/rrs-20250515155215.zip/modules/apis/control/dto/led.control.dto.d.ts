export declare class LedControlDto {
    command: string;
    led: string;
}
