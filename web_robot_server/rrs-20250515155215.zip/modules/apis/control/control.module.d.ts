export declare class ControlModule {
}
