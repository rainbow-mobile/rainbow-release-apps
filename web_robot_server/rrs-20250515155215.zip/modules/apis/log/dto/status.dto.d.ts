export declare class StatusTestDto {
    time: string;
}
