export declare class StatusTaskEntity {
    connection: boolean;
    file: string;
    running: boolean;
    id: number;
}
