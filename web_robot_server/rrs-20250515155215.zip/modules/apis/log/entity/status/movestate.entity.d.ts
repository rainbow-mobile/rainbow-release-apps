export declare class MoveStatusStateEntity {
    state: string;
    auto_move: string;
    dock_move: string;
    jog_move: string;
    obs: string;
    path: string;
}
