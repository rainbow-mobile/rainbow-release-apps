export declare class StatusImuEntity {
    acc_x: number;
    acc_y: number;
    acc_z: number;
    gyr_x: number;
    gyr_y: number;
    gyr_z: number;
    imu_rx: number;
    imu_ry: number;
    imu_rz: number;
}
