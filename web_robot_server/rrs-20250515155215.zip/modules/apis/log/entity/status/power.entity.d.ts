export declare class StatusPowerEntity {
    bat_in: number;
    bat_out: number;
    bat_current: number;
    power: number;
    total_power: number;
    charge_current: number;
    contact_voltage: number;
}
