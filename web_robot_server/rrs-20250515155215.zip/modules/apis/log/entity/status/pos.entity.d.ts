export declare class StatusPosEntity {
    x: number;
    y: number;
    rz: number;
    vx: number;
    vy: number;
    wz: number;
}
