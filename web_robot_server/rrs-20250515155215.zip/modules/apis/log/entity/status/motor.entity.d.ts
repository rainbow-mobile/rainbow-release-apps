export declare class StatusMotorEntity {
    connection: boolean;
    current: number;
    status: number;
    temp: number;
}
