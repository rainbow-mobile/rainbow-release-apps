export declare class StatusConditionEntity {
    inlier_ratio: number;
    inlier_error: number;
}
