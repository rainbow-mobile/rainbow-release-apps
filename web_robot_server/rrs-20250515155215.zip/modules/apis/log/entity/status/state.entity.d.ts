export declare class StatusStateEntity {
    charge: string;
    dock: string;
    localization: string;
    power: boolean;
}
