export declare class MapModule {
}
