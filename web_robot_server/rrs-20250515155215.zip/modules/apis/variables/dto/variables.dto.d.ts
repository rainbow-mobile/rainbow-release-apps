export declare class VariableDto {
    key: string;
    value: string;
}
