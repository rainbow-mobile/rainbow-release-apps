export declare class VariablesEntity {
    key: string;
    value: string;
}
