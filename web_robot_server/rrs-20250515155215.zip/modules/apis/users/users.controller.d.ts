export declare class UsersController {
}
