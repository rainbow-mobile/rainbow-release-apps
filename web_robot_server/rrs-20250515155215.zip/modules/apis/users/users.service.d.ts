export declare class UsersService {
}
