export declare class ProcessService {
}
