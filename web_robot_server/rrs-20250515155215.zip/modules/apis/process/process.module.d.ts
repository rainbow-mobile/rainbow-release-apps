export declare class ProcessModule {
}
