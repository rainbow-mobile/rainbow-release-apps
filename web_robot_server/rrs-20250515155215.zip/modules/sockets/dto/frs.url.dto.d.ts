export declare class FrsUrlDto {
    url: string;
}
