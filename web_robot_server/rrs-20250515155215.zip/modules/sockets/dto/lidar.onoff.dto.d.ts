export declare class EmitOnOffDto {
    command: string;
    frequency: number;
}
