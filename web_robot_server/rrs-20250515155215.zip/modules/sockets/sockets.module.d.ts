export declare class SocketsModule {
}
