export declare class AuthService {
}
