export declare class AuthController {
}
