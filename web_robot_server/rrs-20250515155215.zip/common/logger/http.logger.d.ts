declare const httpLogger: import("winston").Logger;
export default httpLogger;
