declare const socketLogger: import("winston").Logger;
export default socketLogger;
