import { Request, Response } from 'express';
export declare function loggerMiddleware(req: Request, res: Response, next: () => void): void;
