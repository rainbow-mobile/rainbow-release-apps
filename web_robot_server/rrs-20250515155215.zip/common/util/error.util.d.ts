export declare function errorToJson(error: any): string;
