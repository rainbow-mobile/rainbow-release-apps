export declare function getMacAddresses(): any[];
export declare function stringifyAllValues(obj: any): any;
