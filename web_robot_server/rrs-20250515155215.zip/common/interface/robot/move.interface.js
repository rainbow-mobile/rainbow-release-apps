"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=move.interface.js.map