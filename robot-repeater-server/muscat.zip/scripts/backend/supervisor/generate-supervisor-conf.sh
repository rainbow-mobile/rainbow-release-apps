#!/bin/bash
# 활성 서비스 목록을 받아 /etc/supervisor/conf.d/{svc}.conf 들을 생성한다.
#
# 입력 (환경변수)
#   RB_ENABLED_SERVICES   : "common,manipulate,amr,..."  (콤마/공백 구분, 없으면 자동 감지)
#   RB_MODE               : prod | dev   (기본 prod)
#   RB_LOG_MAX_MB         : 서비스 stdout 로그 파일 최대 크기 MB (기본 prod=50, dev=50)
#   RB_LOG_BACKUPS        : 로그 백업 개수 (기본 prod=5, dev=0)
#   RB_BIN_DIR            : prod에서 .bin 마운트 디렉토리 (기본 /app/services)
#   RB_DEV_BACKEND_DIR    : dev에서 backend 디렉토리 (기본 /app/backend)
#
# 자동 감지(prod): $RB_BIN_DIR/<svc>/<svc>.<arch>.bin 또는 /<svc>.<arch>.bin 존재 여부로 감지.
# 자동 감지(dev) : /app/backend/services/<svc>/run.py 존재 여부로 감지.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEMPLATE="${SCRIPT_DIR}/program.conf.template"
BASE_TEMPLATE="${SCRIPT_DIR}/supervisord.conf.template"

RB_MODE="${RB_MODE:-prod}"
RB_BIN_DIR="${RB_BIN_DIR:-/app/services}"
RB_DEV_BACKEND_DIR="${RB_DEV_BACKEND_DIR:-/app/backend}"

if [[ "$RB_MODE" == "dev" ]]; then
  : "${RB_LOG_MAX_MB:=50}"
  : "${RB_LOG_BACKUPS:=0}"
else
  : "${RB_LOG_MAX_MB:=50}"
  : "${RB_LOG_BACKUPS:=5}"
fi

ARCH="$(uname -m)"
case "$ARCH" in
  x86_64)  CONVERTED_ARCH="amd64" ;;
  aarch64) CONVERTED_ARCH="arm64" ;;
  arm64)   CONVERTED_ARCH="arm64" ;;
  *) echo "❌ 지원하지 않는 아키텍처: $ARCH" >&2; exit 1 ;;
esac

mkdir -p /etc/supervisor/conf.d
mkdir -p /app/data/log/services

# 베이스 supervisord.conf 설치
install -m 0644 "$BASE_TEMPLATE" /etc/supervisor/supervisord.conf

# 활성 서비스 목록 결정
declare -a ENABLED=()
RAW="${RB_ENABLED_SERVICES:-}"
RAW="${RAW//,/ }"
if [[ -n "$RAW" ]]; then
  for tok in $RAW; do
    [[ -z "$tok" ]] && continue
    [[ "$tok" == "host" ]] && continue
    ENABLED+=("$tok")
  done
else
  # 자동 감지
  if [[ "$RB_MODE" == "dev" ]]; then
    if [[ -d "$RB_DEV_BACKEND_DIR/services" ]]; then
      for d in "$RB_DEV_BACKEND_DIR/services"/*; do
        [[ -d "$d" ]] || continue
        name="$(basename "$d")"
        [[ "$name" == "host" ]] && continue
        [[ -f "$d/run.py" ]] || continue
        ENABLED+=("$name")
      done
    fi
  else
    # prod: 마운트된 .bin 자동 감지
    # 우선 /app/services/<svc>/<svc>.<arch>.bin 패턴, 다음으로 루트 /<svc>.<arch>.bin
    for d in "$RB_BIN_DIR"/*; do
      [[ -d "$d" ]] || continue
      name="$(basename "$d")"
      [[ "$name" == "host" ]] && continue
      if [[ -f "$d/$name.$CONVERTED_ARCH.bin" || -f "$d/$name.bin" ]]; then
        ENABLED+=("$name")
      fi
    done
    # 레거시: 루트 /<svc>.<arch>.bin 만 있는 경우
    if (( ${#ENABLED[@]} == 0 )); then
      for f in /*."$CONVERTED_ARCH".bin; do
        [[ -f "$f" ]] || continue
        name="$(basename "$f" ."$CONVERTED_ARCH".bin)"
        [[ "$name" == "host" ]] && continue
        ENABLED+=("$name")
      done
    fi
  fi
fi

if (( ${#ENABLED[@]} == 0 )); then
  echo "❌ 활성화할 서비스가 없습니다. RB_ENABLED_SERVICES 설정을 확인하세요." >&2
  exit 1
fi

echo "ℹ️  RB_MODE=$RB_MODE"
echo "ℹ️  활성 서비스: ${ENABLED[*]}"

# 기존 동적 생성 conf 정리
rm -f /etc/supervisor/conf.d/*.conf 2>/dev/null || true

# 서비스별 config.env에서 PORT 읽기
# 레거시 호환:
#   - 단일 서비스 컨테이너 모드 (기존 rrs-py-{svc}-service 처럼 ENABLED 가 1개) 에서
#     deploy.sh 가 -e PORT=... 만 전달하고 config.env 마운트 없는 경우, env 의 PORT 를 사용한다.
#   - dev 컨테이너의 첫 부팅 시점에 backend/services/{svc}/config.env 가 아직 마운트 안 됐을 때도
#     env 가 있으면 그것을 우선한다.
read_port() {
  local svc="$1"
  # legacy: 단일 서비스 모드 + PORT env 직접 전달
  if (( ${#ENABLED[@]} == 1 )) && [[ -n "${PORT:-}" ]]; then
    echo "$PORT"
    return
  fi
  local conf=""
  if [[ "$RB_MODE" == "dev" ]]; then
    conf="$RB_DEV_BACKEND_DIR/services/$svc/config.env"
  else
    if [[ -f "$RB_BIN_DIR/$svc/config.env" ]]; then
      conf="$RB_BIN_DIR/$svc/config.env"
    elif [[ -f "/config.env.$svc" ]]; then
      conf="/config.env.$svc"
    elif [[ -f "/config.env" ]]; then
      # legacy: deploy.sh 가 /config.env 단일 파일로 마운트한 경우
      conf="/config.env"
    fi
  fi
  if [[ -n "$conf" && -f "$conf" ]]; then
    grep -E '^PORT=' "$conf" 2>/dev/null | head -n1 | cut -d= -f2 | tr -d ' \r'
  fi
}

# 서비스별 command 결정
# stdbuf 로 line-buffer 강제하여 uvicorn/.bin 의 stdout/stderr 가 supervisor 파일에 즉시 흘러가게 한다.
build_cmd() {
  local svc="$1"
  local port="$2"
  local stdbuf_prefix=""
  if command -v stdbuf >/dev/null 2>&1; then
    stdbuf_prefix="stdbuf -oL -eL "
  fi
  if [[ "$RB_MODE" == "dev" ]]; then
    local svc_dir="$RB_DEV_BACKEND_DIR/services/$svc"
    echo "${stdbuf_prefix}/usr/local/bin/rb-runtime run-with-extensions -- uv run uvicorn app.main:app --host 0.0.0.0 --port $port --reload --reload-dir $svc_dir --reload-dir $RB_DEV_BACKEND_DIR/packages --reload-include **/*.py"
  else
    local bin_path=""
    if [[ -f "$RB_BIN_DIR/$svc/$svc.$CONVERTED_ARCH.bin" ]]; then
      bin_path="$RB_BIN_DIR/$svc/$svc.$CONVERTED_ARCH.bin"
    elif [[ -f "$RB_BIN_DIR/$svc/$svc.bin" ]]; then
      bin_path="$RB_BIN_DIR/$svc/$svc.bin"
    elif [[ -f "/$svc.$CONVERTED_ARCH.bin" ]]; then
      bin_path="/$svc.$CONVERTED_ARCH.bin"
    else
      echo "/bin/false # NO_BIN_FOR_$svc"
      return
    fi
    chmod +x "$bin_path" 2>/dev/null || true
    echo "${stdbuf_prefix}/usr/local/bin/rb-runtime run-with-extensions -- $bin_path"
  fi
}

build_dir() {
  local svc="$1"
  if [[ "$RB_MODE" == "dev" ]]; then
    echo "$RB_DEV_BACKEND_DIR/services/$svc"
  else
    if [[ -d "$RB_BIN_DIR/$svc" ]]; then
      echo "$RB_BIN_DIR/$svc"
    else
      echo "/"
    fi
  fi
}

for svc in "${ENABLED[@]}"; do
  port="$(read_port "$svc" || true)"
  if [[ -z "$port" ]]; then
    echo "⚠️  [$svc] PORT 미설정 → 서비스 스킵"
    continue
  fi
  cmd="$(build_cmd "$svc" "$port")"
  dir="$(build_dir "$svc")"

  out="/etc/supervisor/conf.d/${svc}.conf"
  sed \
    -e "s|__SVC__|${svc}|g" \
    -e "s|__PORT__|${port}|g" \
    -e "s|__LOG_MAX_MB__|${RB_LOG_MAX_MB}|g" \
    -e "s|__LOG_BACKUPS__|${RB_LOG_BACKUPS}|g" \
    -e "s|__DIR__|${dir}|g" \
    "$TEMPLATE" > "$out"
  # command 라인은 |를 포함할 수 있어 별도로 치환
  python3 - "$out" "$cmd" <<'PY'
import sys, pathlib
p = pathlib.Path(sys.argv[1])
cmd = sys.argv[2]
text = p.read_text()
text = text.replace("__CMD__", cmd)
p.write_text(text)
PY
done

echo "✅ supervisor 설정 생성 완료: $(ls /etc/supervisor/conf.d/ | tr '\n' ' ')"
