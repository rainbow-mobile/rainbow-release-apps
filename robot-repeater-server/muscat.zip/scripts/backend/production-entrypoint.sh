#!/bin/bash
# muscat 단일 컨테이너 운영 entrypoint.
# 동작:
#   1) /etc/hosts에 서비스 alias 추가 → 코드의 http://{svc}:{port} 가 그대로 동작
#   2) RB_ENABLED_SERVICES (또는 .bin 자동 감지) 기반으로 supervisord conf 생성
#   3) supervisord 기동 (PID 1)
#
# 환경변수:
#   RB_ENABLED_SERVICES   "common,manipulate,..."  미설정시 자동 감지
#   RB_LOG_MAX_MB         서비스 stdout 로그 파일 최대 MB (기본 50)
#   RB_LOG_BACKUPS        로그 백업 개수 (기본 5)
#
# 레거시 호환:
#   첫 인자가 rb-runtime인 경우 그대로 위임 (기존 docker exec rb-runtime 사용처 보호)
#   첫 인자가 그 외 명령인 경우 그대로 exec (디버깅용)
#
#   레거시 SERVICE 환경변수가 있고 RB_ENABLED_SERVICES가 비어있으면 SERVICE를 활성화 대상으로 사용.

set -euo pipefail

if [[ "${1:-}" == "rb-runtime" ]]; then
  shift
  exec /usr/local/bin/rb-runtime "$@"
fi

if [[ $# -gt 0 ]]; then
  exec "$@"
fi

# 레거시 SERVICE → RB_ENABLED_SERVICES 마이그레이션
if [[ -z "${RB_ENABLED_SERVICES:-}" && -n "${SERVICE:-}" ]]; then
  export RB_ENABLED_SERVICES="${SERVICE}"
fi

export RB_MODE="prod"
export RB_BIN_DIR="${RB_BIN_DIR:-/app/services}"

echo "============================================================"
echo " muscat (prod) starting"
echo "   RB_ENABLED_SERVICES = ${RB_ENABLED_SERVICES:-(auto-detect)}"
echo "   RB_BIN_DIR          = ${RB_BIN_DIR}"
echo "============================================================"

# 1) /etc/hosts에 서비스 alias 추가 (이미 있으면 skip)
KNOWN_SERVICES=(common manipulate amr vision deploy log rby1 accessory)
if ! grep -q "# muscat service aliases" /etc/hosts 2>/dev/null; then
  {
    echo ""
    echo "# muscat service aliases (added by production-entrypoint.sh)"
    for svc in "${KNOWN_SERVICES[@]}"; do
      echo "127.0.0.1 $svc"
    done
  } >> /etc/hosts 2>/dev/null || true
fi

# 2) supervisor conf 생성
mkdir -p /app/data/log/services
SUPERVISOR_DIR="/opt/rb-supervisor"

if [[ ! -x "$SUPERVISOR_DIR/generate-supervisor-conf.sh" ]]; then
  echo "❌ supervisor 템플릿을 찾을 수 없습니다: $SUPERVISOR_DIR" >&2
  exit 1
fi

bash "$SUPERVISOR_DIR/generate-supervisor-conf.sh"

# 3) supervisord 기동 (PID 1)
exec /usr/bin/supervisord -c /etc/supervisor/supervisord.conf
