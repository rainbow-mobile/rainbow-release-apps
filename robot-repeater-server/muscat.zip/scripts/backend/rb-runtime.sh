#!/bin/bash
set -euo pipefail

RB_ROS_DISTRO="${RB_ROS_DISTRO:-${ROS_DISTRO:-jazzy}}"
RB_RUNTIME_ROOT="${RB_RUNTIME_ROOT:-${DATA_DIR:-/app/data}/runtime}"
RB_RUNTIME_VENV="${RB_RUNTIME_VENV:-${RB_RUNTIME_ROOT}/venv}"
RB_ROS_WS="${RB_ROS_WS:-${RB_RUNTIME_ROOT}/ros2_ws}"
RB_EXTENSIONS_DIR="${RB_EXTENSIONS_DIR:-${RB_RUNTIME_ROOT}/extensions}"
RB_EXTENSIONS_AVAILABLE_DIR="${RB_EXTENSIONS_AVAILABLE_DIR:-${RB_EXTENSIONS_DIR}/available}"
RB_EXTENSIONS_ENABLED_DIR="${RB_EXTENSIONS_ENABLED_DIR:-${RB_EXTENSIONS_DIR}/enabled}"
RB_RUNTIME_STATE_DIR="${RB_RUNTIME_STATE_DIR:-${RB_RUNTIME_ROOT}/state}"
RB_RUNTIME_LOG_DIR="${RB_RUNTIME_LOG_DIR:-${RB_RUNTIME_STATE_DIR}/logs}"
RB_RUNTIME_TMP_DIR="${RB_RUNTIME_TMP_DIR:-${RB_RUNTIME_ROOT}/tmp}"
RB_ROS_AUTO_BUILD="${RB_ROS_AUTO_BUILD:-0}"
RB_EXTENSIONS_AUTOSTART="${RB_EXTENSIONS_AUTOSTART:-1}"

rb_runtime_usage() {
  cat <<'EOF'
사용법:
  rb-runtime prepare
  rb-runtime install <name> <source> [--enable] [--editable]
  rb-runtime enable <name>
  rb-runtime disable <name>
  rb-runtime list
  rb-runtime build-workspace
  rb-runtime start
  rb-runtime run-with-extensions -- <cmd> [args...]
  rb-runtime print-env
  rb-runtime shell

개념:
  - install: 확장 소스를 영속 디렉토리에 적재합니다.
  - enable: 확장을 Python/ROS2 런타임 경로에 연결합니다.
  - start: enabled 확장의 start.sh 또는 extension.env의 시작 명령을 실행합니다.
EOF
}

rb_runtime_log() {
  printf '[rb-runtime] %s\n' "$*"
}

rb_runtime_warn() {
  printf '[rb-runtime] 경고: %s\n' "$*" >&2
}

rb_runtime_init_dirs() {
  mkdir -p \
    "$RB_RUNTIME_ROOT" \
    "$RB_ROS_WS/src" \
    "$RB_EXTENSIONS_AVAILABLE_DIR" \
    "$RB_EXTENSIONS_ENABLED_DIR" \
    "$RB_RUNTIME_STATE_DIR" \
    "$RB_RUNTIME_LOG_DIR" \
    "$RB_RUNTIME_TMP_DIR"
}

rb_runtime_ros_setup_path() {
  local setup="/opt/ros/${RB_ROS_DISTRO}/setup.bash"
  if [[ -f "$setup" ]]; then
    printf '%s\n' "$setup"
  fi
}

rb_runtime_source_ros() {
  local ros_setup
  local restore_nounset=0

  if [[ $- == *u* ]]; then
    restore_nounset=1
    set +u
  fi

  ros_setup="$(rb_runtime_ros_setup_path || true)"
  if [[ -n "$ros_setup" ]]; then
    # shellcheck disable=SC1090
    source "$ros_setup"
  fi

  if [[ -f "${RB_ROS_WS}/install/setup.bash" ]]; then
    # shellcheck disable=SC1091
    source "${RB_ROS_WS}/install/setup.bash"
  elif [[ -f "${RB_ROS_WS}/install/local_setup.bash" ]]; then
    # shellcheck disable=SC1091
    source "${RB_ROS_WS}/install/local_setup.bash"
  fi

  if (( restore_nounset )); then
    set -u
  fi
}

rb_runtime_ensure_venv() {
  if [[ ! -x "${RB_RUNTIME_VENV}/bin/python" ]]; then
    python3 -m venv --system-site-packages "$RB_RUNTIME_VENV"
    "$RB_RUNTIME_VENV/bin/python" -m pip install --upgrade pip setuptools wheel >/dev/null
  fi
}

rb_runtime_venv_site_packages() {
  "$RB_RUNTIME_VENV/bin/python" - <<'PY'
import site
paths = site.getsitepackages()
print(paths[0] if paths else '')
PY
}

rb_runtime_collect_python_paths() {
  local -a paths=()
  local target
  local venv_site

  rb_runtime_ensure_venv
  venv_site="$(rb_runtime_venv_site_packages)"
  if [[ -n "$venv_site" && -d "$venv_site" ]]; then
    paths+=("$venv_site")
  fi

  shopt -s nullglob
  for target in "$RB_EXTENSIONS_ENABLED_DIR"/*; do
    [[ -e "$target" ]] || continue
    target="$(cd "$target" 2>/dev/null && pwd -P)"
    [[ -n "$target" ]] || continue

    [[ -d "$target" ]] && paths+=("$target")
    [[ -d "$target/src" ]] && paths+=("$target/src")
    [[ -d "$target/python" ]] && paths+=("$target/python")

    while IFS= read -r site_dir; do
      [[ -d "$site_dir" ]] && paths+=("$site_dir")
    done < <(find "$target" -type d -path '*/site-packages' 2>/dev/null | sort -u)
  done
  shopt -u nullglob

  printf '%s\n' "${paths[@]}" | awk 'NF && !seen[$0]++'
}

rb_runtime_export_pythonpath() {
  local joined=""
  local path
  while IFS= read -r path; do
    [[ -n "$path" ]] || continue
    if [[ -z "$joined" ]]; then
      joined="$path"
    else
      joined="${joined}:$path"
    fi
  done < <(rb_runtime_collect_python_paths)

  if [[ -n "$joined" ]]; then
    export PYTHONPATH="$joined${PYTHONPATH:+:${PYTHONPATH}}"
  fi
}

rb_runtime_workspace_has_sources() {
  find "${RB_ROS_WS}/src" -mindepth 1 -maxdepth 3 \( -name package.xml -o -name setup.py -o -name pyproject.toml \) -print -quit 2>/dev/null | grep -q .
}

rb_runtime_workspace_needs_build() {
  local stamp="${RB_RUNTIME_STATE_DIR}/workspace.build.stamp"

  if [[ ! -f "${RB_ROS_WS}/install/setup.bash" && ! -f "${RB_ROS_WS}/install/local_setup.bash" ]]; then
    return 0
  fi

  if [[ ! -f "$stamp" ]]; then
    return 0
  fi

  find "${RB_ROS_WS}/src" -type f \( -name '*.py' -o -name '*.xml' -o -name '*.yaml' -o -name '*.yml' -o -name '*.launch.py' -o -name 'package.xml' -o -name 'setup.py' -o -name 'pyproject.toml' -o -name 'CMakeLists.txt' \) -newer "$stamp" -print -quit 2>/dev/null | grep -q .
}

rb_runtime_build_workspace() {
  rb_runtime_init_dirs

  if ! command -v colcon >/dev/null 2>&1; then
    rb_runtime_warn "colcon이 없어 ROS2 워크스페이스를 빌드할 수 없습니다."
    return 1
  fi

  if ! rb_runtime_workspace_has_sources; then
    rb_runtime_log "빌드할 ROS2 소스가 없어 워크스페이스 빌드를 건너뜁니다."
    return 0
  fi

  rb_runtime_source_ros
  rb_runtime_export_pythonpath

  rb_runtime_log "ROS2 워크스페이스 빌드를 시작합니다: ${RB_ROS_WS}"
  (
    cd "$RB_ROS_WS"
    colcon build --merge-install --symlink-install --base-paths src
  )
  touch "${RB_RUNTIME_STATE_DIR}/workspace.build.stamp"
}

rb_runtime_prepare() {
  rb_runtime_init_dirs
  rb_runtime_ensure_venv
  rb_runtime_source_ros
  rb_runtime_export_pythonpath
  export PATH="${RB_RUNTIME_VENV}/bin:${PATH}"

  if [[ "$RB_ROS_AUTO_BUILD" == "1" ]] && rb_runtime_workspace_has_sources; then
    if rb_runtime_workspace_needs_build; then
      rb_runtime_build_workspace
      rb_runtime_source_ros
    fi
  fi
}

rb_runtime_copy_source() {
  local source="$1"
  local destination="$2"

  rm -rf "$destination"
  mkdir -p "$destination"

  case "$source" in
    http://*|https://*|git@*|ssh://*)
      git clone --depth 1 "$source" "$destination"
      ;;
    *.tar.gz|*.tgz)
      tar -xzf "$source" -C "$destination" --strip-components=1
      ;;
    *.tar)
      tar -xf "$source" -C "$destination" --strip-components=1
      ;;
    *.zip)
      unzip -q "$source" -d "$destination"
      local entries
      entries="$(find "$destination" -mindepth 1 -maxdepth 1 -type d | wc -l | tr -d ' ')"
      if [[ "$entries" == "1" ]] && [[ -z "$(find "$destination" -mindepth 1 -maxdepth 1 -type f -print -quit)" ]]; then
        local inner
        inner="$(find "$destination" -mindepth 1 -maxdepth 1 -type d -print -quit)"
        if [[ -n "$inner" ]]; then
          find "$inner" -mindepth 1 -maxdepth 1 -exec mv {} "$destination"/ \;
          rmdir "$inner"
        fi
      fi
      ;;
    *)
      if [[ -d "$source" ]]; then
        cp -R "$source"/. "$destination"/
      else
        rb_runtime_warn "지원하지 않는 source 형식입니다: $source"
        return 1
      fi
      ;;
  esac
}

rb_runtime_install_python_bits() {
  local extension_dir="$1"
  local editable_mode="$2"

  rb_runtime_ensure_venv

  if [[ -f "${extension_dir}/requirements.txt" ]]; then
    rb_runtime_log "requirements.txt를 영속 venv에 설치합니다."
    "$RB_RUNTIME_VENV/bin/pip" install -r "${extension_dir}/requirements.txt"
  fi

  if [[ "$editable_mode" == "1" ]]; then
    if [[ -f "${extension_dir}/pyproject.toml" || -f "${extension_dir}/setup.py" ]]; then
      rb_runtime_log "확장을 editable 모드로 영속 venv에 설치합니다."
      "$RB_RUNTIME_VENV/bin/pip" install --editable "$extension_dir"
    else
      rb_runtime_warn "editable 설치 조건(pyproject.toml/setup.py)이 없어 건너뜁니다."
    fi
  fi
}

rb_runtime_link_extension_workspace() {
  local name="$1"
  local extension_dir="$2"
  local workspace_link_root="${RB_ROS_WS}/src/extensions"

  mkdir -p "$workspace_link_root"
  rm -f "${workspace_link_root}/${name}"

  if [[ -d "${extension_dir}/ros2_ws/src" ]]; then
    ln -sfn "${extension_dir}/ros2_ws/src" "${workspace_link_root}/${name}"
    return 0
  fi

  if [[ -f "${extension_dir}/package.xml" || -f "${extension_dir}/setup.py" || -f "${extension_dir}/pyproject.toml" ]]; then
    ln -sfn "$extension_dir" "${workspace_link_root}/${name}"
    return 0
  fi

  if find "$extension_dir" -mindepth 1 -maxdepth 3 -name package.xml -print -quit 2>/dev/null | grep -q .; then
    ln -sfn "$extension_dir" "${workspace_link_root}/${name}"
  fi
}

rb_runtime_install_extension() {
  local name="$1"
  local source="$2"
  shift 2
  local enable_mode=0
  local editable_mode=0
  local extension_dir="${RB_EXTENSIONS_AVAILABLE_DIR}/${name}"
  local staging_dir="${RB_RUNTIME_TMP_DIR}/install-${name}-$$"

  while [[ $# -gt 0 ]]; do
    case "$1" in
      --enable)
        enable_mode=1
        ;;
      --editable)
        editable_mode=1
        ;;
      *)
        rb_runtime_warn "알 수 없는 install 옵션: $1"
        return 1
        ;;
    esac
    shift
  done

  rb_runtime_init_dirs
  rm -rf "$staging_dir"
  rb_runtime_copy_source "$source" "$staging_dir"

  rm -rf "$extension_dir"
  mv "$staging_dir" "$extension_dir"

  rb_runtime_install_python_bits "$extension_dir" "$editable_mode"

  if [[ "$enable_mode" == "1" ]]; then
    rb_runtime_enable_extension "$name"
  fi

  rb_runtime_log "확장 설치 완료: ${name} -> ${extension_dir}"
}

rb_runtime_enable_extension() {
  local name="$1"
  local extension_dir="${RB_EXTENSIONS_AVAILABLE_DIR}/${name}"

  if [[ ! -d "$extension_dir" ]]; then
    rb_runtime_warn "설치된 확장이 없습니다: $name"
    return 1
  fi

  rb_runtime_init_dirs
  ln -sfn "$extension_dir" "${RB_EXTENSIONS_ENABLED_DIR}/${name}"
  rb_runtime_link_extension_workspace "$name" "$extension_dir"
  rb_runtime_log "확장 활성화 완료: $name"
}

rb_runtime_disable_extension() {
  local name="$1"
  rm -f "${RB_EXTENSIONS_ENABLED_DIR}/${name}"
  rm -f "${RB_ROS_WS}/src/extensions/${name}"
  rb_runtime_log "확장 비활성화 완료: $name"
}

rb_runtime_list_extensions() {
  local name
  local status
  shopt -s nullglob
  for path in "$RB_EXTENSIONS_AVAILABLE_DIR"/*; do
    [[ -d "$path" ]] || continue
    name="$(basename "$path")"
    status="installed"
    if [[ -e "${RB_EXTENSIONS_ENABLED_DIR}/${name}" ]]; then
      status="enabled"
    fi
    printf '%s\t%s\n' "$name" "$status"
  done
  shopt -u nullglob
}

rb_runtime_start_extensions_once() {
  local -n _pids_ref=$1
  local target
  local name
  local log_file
  local start_cmd

  if [[ "$RB_EXTENSIONS_AUTOSTART" != "1" ]]; then
    rb_runtime_log "RB_EXTENSIONS_AUTOSTART=0 이므로 확장 시작을 건너뜁니다."
    return 0
  fi

  shopt -s nullglob
  for target in "$RB_EXTENSIONS_ENABLED_DIR"/*; do
    [[ -e "$target" ]] || continue
    name="$(basename "$target")"
    target="$(cd "$target" 2>/dev/null && pwd -P)"
    [[ -n "$target" ]] || continue

    unset RB_EXTENSION_START_CMD
    if [[ -f "${target}/extension.env" ]]; then
      # shellcheck disable=SC1090
      source "${target}/extension.env"
    fi

    start_cmd="${RB_EXTENSION_START_CMD:-}"
    log_file="${RB_RUNTIME_LOG_DIR}/${name}.log"

    if [[ -x "${target}/start.sh" ]]; then
      rb_runtime_log "확장 시작: ${name} (start.sh)"
      (
        cd "$target"
        exec bash "${target}/start.sh"
      ) >>"$log_file" 2>&1 &
      _pids_ref+=("$!")
      continue
    fi

    if [[ -n "$start_cmd" ]]; then
      rb_runtime_log "확장 시작: ${name} (extension.env)"
      (
        cd "$target"
        exec bash -lc "$start_cmd"
      ) >>"$log_file" 2>&1 &
      _pids_ref+=("$!")
      continue
    fi

    rb_runtime_log "시작 정의가 없어 확장 시작을 건너뜁니다: ${name}"
  done
  shopt -u nullglob
}

rb_runtime_cleanup_pids() {
  local -a pids=("$@")
  local pid
  for pid in "${pids[@]}"; do
    if [[ -n "$pid" ]] && kill -0 "$pid" >/dev/null 2>&1; then
      kill "$pid" >/dev/null 2>&1 || true
      wait "$pid" 2>/dev/null || true
    fi
  done
}

rb_runtime_start_extensions_forever() {
  local -a extension_pids=()
  rb_runtime_prepare
  rb_runtime_start_extensions_once extension_pids

  trap 'rb_runtime_cleanup_pids "${extension_pids[@]-}"' EXIT INT TERM

  if [[ ${#extension_pids[@]} -eq 0 ]]; then
    rb_runtime_log "시작된 확장이 없습니다."
    return 0
  fi

  set +e
  wait "${extension_pids[@]}"
  local status=$?
  set -e
  return "$status"
}

rb_runtime_run_with_extensions() {
  if [[ $# -eq 0 ]]; then
    rb_runtime_warn "run-with-extensions 뒤에는 실행할 명령이 필요합니다."
    return 1
  fi

  rb_runtime_prepare

  local -a extension_pids=()
  rb_runtime_start_extensions_once extension_pids

  # main_pid 는 local 인데 cleanup trap 이 함수 종료 후에도 EXIT 로 트리거될 수 있다.
  # 그 시점엔 local 변수가 unset 이므로 set -u 환경에서 unbound 가 난다.
  # ${var-} 패턴으로 unbound 안전, 그리고 함수 종료 직전 trap 을 해제한다.
  local main_pid=""

  "$@" &
  main_pid=$!

  cleanup() {
    rb_runtime_cleanup_pids "${main_pid-}" "${extension_pids[@]-}"
  }

  trap cleanup EXIT INT TERM

  set +e
  wait "$main_pid"
  local status=$?
  set -e

  # 정상 종료 경로 — trap 해제하여 함수 외부 EXIT 에서 cleanup 재호출되지 않게 한다
  trap - EXIT INT TERM

  rb_runtime_cleanup_pids "${extension_pids[@]-}"
  return "$status"
}

rb_runtime_print_env() {
  rb_runtime_prepare
  cat <<EOF
RB_ROS_DISTRO=${RB_ROS_DISTRO}
RB_RUNTIME_ROOT=${RB_RUNTIME_ROOT}
RB_RUNTIME_VENV=${RB_RUNTIME_VENV}
RB_ROS_WS=${RB_ROS_WS}
RB_EXTENSIONS_DIR=${RB_EXTENSIONS_DIR}
RB_RUNTIME_STATE_DIR=${RB_RUNTIME_STATE_DIR}
PYTHONPATH=${PYTHONPATH:-}
EOF
}

rb_runtime_shell() {
  rb_runtime_prepare
  exec bash
}

main() {
  local command="${1:-}"
  case "$command" in
    prepare)
      shift
      rb_runtime_prepare
      ;;
    install)
      shift
      [[ $# -ge 2 ]] || { rb_runtime_usage; exit 1; }
      rb_runtime_install_extension "$@"
      ;;
    enable)
      shift
      [[ $# -eq 1 ]] || { rb_runtime_usage; exit 1; }
      rb_runtime_enable_extension "$1"
      ;;
    disable)
      shift
      [[ $# -eq 1 ]] || { rb_runtime_usage; exit 1; }
      rb_runtime_disable_extension "$1"
      ;;
    list)
      shift
      rb_runtime_list_extensions
      ;;
    build-workspace)
      shift
      rb_runtime_build_workspace
      ;;
    start)
      shift
      rb_runtime_start_extensions_forever
      ;;
    run-with-extensions)
      shift
      if [[ "${1:-}" == "--" ]]; then
        shift
      fi
      rb_runtime_run_with_extensions "$@"
      ;;
    print-env)
      shift
      rb_runtime_print_env
      ;;
    shell)
      shift
      rb_runtime_shell
      ;;
    -h|--help|help|"")
      rb_runtime_usage
      ;;
    *)
      rb_runtime_warn "알 수 없는 명령: ${command}"
      rb_runtime_usage
      exit 1
      ;;
  esac
}

main "$@"
