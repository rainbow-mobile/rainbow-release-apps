#!/bin/bash

NGINX_CONF="/etc/nginx/nginx.conf"

inotifywait -m -e modify "$NGINX_CONF" | while read -r path event file; do
  echo "🔄 변경 감지됨: $path$file → nginx reload"
  nginx -s reload
done


