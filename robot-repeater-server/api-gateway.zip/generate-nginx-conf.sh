#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$SCRIPT_DIR/.."
TEMPLATE="$SCRIPT_DIR/nginx.template.conf"
OUTPUT="$SCRIPT_DIR/nginx.conf"
SERVICES_DIR="$REPO_ROOT/backend/services"
DEV_MODE=false
PREVIEW_MODE=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --dev*)
      DEV_MODE=true
      shift
      ;;
    --preview*)
      PREVIEW_MODE=true
      shift
      ;;
  esac
done


# A failed `docker run -v .../nginx.conf:...` can leave nginx.conf as an empty
# directory (Docker auto-creates missing bind-mount sources as dirs). Clean it up
# so the redirect below writes a real file instead of failing with "Is a directory".
if [ -d "$OUTPUT" ]; then
  rmdir "$OUTPUT" 2>/dev/null || rm -rf "$OUTPUT"
fi

SERVICE_BLOCKS=""

for service_path in "$SERVICES_DIR"/*; do
  echo "service_path: $service_path"
  [ -d "$service_path" ] || continue

  CONF="$service_path/config.env"

  [ -f "$CONF" ] || continue

  SERVICE_NAME=$(grep -E '^SERVICE_NAME=' "$CONF" | cut -d= -f2 | tr -d '\r')
  PORT=$(grep -E '^PORT=' "$CONF" | cut -d= -f2 | tr -d '\r')

  [ -n "$SERVICE_NAME" ] || continue
  [ -n "$PORT" ] || continue

  IS_LINUX=false
  [ "$(uname -s)" = "Linux" ] && IS_LINUX=true

  if [ "$DEV_MODE" = true ]; then
    if [ "$SERVICE_NAME" = "host" ]; then
      # host는 컨테이너 외부 실행 — Linux도 extra_hosts로 host.docker.internal 사용
      PROXY_PASS="http://host.docker.internal:${PORT}"
    else
      PROXY_PASS="http://muscat-dev:${PORT}"
    fi
  elif [ "$PREVIEW_MODE" = true ]; then
    if [ "$SERVICE_NAME" = "host" ]; then
      # Linux preview: host network이므로 127.0.0.1로 직접 접근
      # Mac/Windows preview: host service 미실행이라 사실상 사용 안 됨
      if [ "$IS_LINUX" = true ]; then
        PROXY_PASS="http://127.0.0.1:${PORT}"
      else
        PROXY_PASS="http://host.docker.internal:${PORT}"
      fi
    else
      if [ "$IS_LINUX" = true ]; then
        PROXY_PASS="http://127.0.0.1:${PORT}"
      else
        PROXY_PASS="http://muscat-preview:${PORT}"
      fi
    fi
  else
    PROXY_PASS="http://127.0.0.1:${PORT}"
  fi

  LOCATION_PREFIX="$SERVICE_NAME"

  if [ "$SERVICE_NAME" = "host" ]; then
    SERVICE_BLOCKS+="

        location ^~ /${LOCATION_PREFIX}/ {
            rewrite ^/${LOCATION_PREFIX}/(.*)$ /\$1 break;
            proxy_pass ${PROXY_PASS};

            proxy_http_version 1.1;
            proxy_set_header Upgrade \$http_upgrade;
            proxy_set_header Connection \$connection_upgrade;
            proxy_set_header Host \$host;
            proxy_set_header X-Real-IP \$remote_addr;
            proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto \$scheme;

            proxy_read_timeout 120s;
            proxy_send_timeout 120s;

            proxy_buffering off;
        }"
  else
    SERVICE_BLOCKS+="

        set \$${LOCATION_PREFIX}_upstream ${PROXY_PASS};

        location ^~ /${LOCATION_PREFIX}/ {
            rewrite ^/${LOCATION_PREFIX}/(.*)$ /\$1 break;
            proxy_pass \$${LOCATION_PREFIX}_upstream;

            proxy_http_version 1.1;
            proxy_set_header Upgrade \$http_upgrade;
            proxy_set_header Connection \$connection_upgrade;
            proxy_set_header Host \$host;
            proxy_set_header X-Real-IP \$remote_addr;
            proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto \$scheme;

            proxy_read_timeout 120s;
            proxy_send_timeout 120s;

            proxy_buffering off;
        }"
  fi

done

{
  while IFS= read -r line || [ -n "$line" ]; do
    if echo "$line" | grep -q '{{SERVICE_BLOCKS}}'; then
      printf "%s\n" "$SERVICE_BLOCKS"
    else
      printf "%s\n" "$line"
    fi
  done < "$TEMPLATE"
} > "$OUTPUT"

echo "✅ nginx.conf 생성 완료"
